<div id="cargador" class="atom-spinner vh-100 vw-100 overflow-hidden m-0"> 
  <div class="d-flex align-items-center h-100 w-100 text-center">
    <div class="d-inline w-50 h-50 m-auto">
      <img src="{{asset('imagenes\general\administracion\logo.png')}}" class="img-fluid">
    </div>
  </div>  
</div>