<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab"
           aria-controls="general"
           aria-selected="true">GENERAL</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="ingresosoficina-tab" data-toggle="tab" href="#ingresosoficina" role="tab"
           aria-controls="ingresosoficina" aria-selected="false">INGRESOS OFICINA</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="ingresosventas-tab" data-toggle="tab" href="#ingresosventas" role="tab"
           aria-controls="ingresosventas" aria-selected="false">INGRESOS VENTAS</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="productividad-tab" data-toggle="tab" href="#productividad" role="tab"
           aria-controls="productividad" aria-selected="false">PRODUCTIVIDAD</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="cobranza-tab" data-toggle="tab" href="#cobranza" role="tab" aria-controls="cobranza"
           aria-selected="false">COBRANZA</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="gastos-tab" data-toggle="tab" href="#gastos" role="tab" aria-controls="gastos"
           aria-selected="false">GASTOS</a>
    </li>
    @if(Auth::user()->rol_id == 7)
        <li class="nav-item">
            <a class="nav-link" id="historial-tab" data-toggle="tab" href="#historial" role="tab"
               aria-controls="historial"
               aria-selected="false">HISTORIAL</a>
        </li>
    @endif
</ul>
<div class="tab-content" style="margin-top:30px;">
    <div class="tab-pane active" id="general" role="tabpanel" aria-labelledby="general-tab">
        <div class="col-12">
            <form action="{{route('agregarObservacion',[$idFranquicia,$idPoliza])}}" enctype="multipart/form-data"
                  method="POST" onsubmit="btnSubmit.disabled = true;">
                @csrf
                <div class="row">
                    <div class="col-10">
                        <div class="form-group">
                            <label>OBSERVACIONES:</label>
                            @if($poliza[0]->observaciones == null)
                                <input type="text" name="observaciones"
                                       class="form-control {!! $errors->first('observaciones','is-invalid')!!}"
                                       placeholder="observaciones" value="{{ old('observaciones') }}">
                                {!! $errors->first('observaciones','<div class="invalid-feedback">La observación es
                                    obligatoria.</div>')!!}
                            @else
                                <input type="text" name="observaciones"
                                       class="form-control {!! $errors->first('observaciones','is-invalid')!!}"
                                       placeholder="observaciones" readonly value="{{ $poliza[0]->observaciones}}">
                                {!! $errors->first('observaciones','<div class="invalid-feedback">La observación es
                                    obligatoria.</div>')!!}
                            @endif
                        </div>
                    </div>
                    <div class="col-2">
                        <!-- <label> &nbsp; </label> -->
                        <div class="form-group">
                            @if($poliza[0]->observaciones == null)
                                <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">
                                    Agregar
                                </button>
                            @else
                                <label> &nbsp; </label>
                                <button class="btn btn-outline-danger btn-block" name="btnSubmit" type="submit">
                                    Eliminar
                                </button>
                            @endif
                        </div>

                    </div>
                </div>
            </form>
        </div>

        <div class="container">
            <div class="row" style="margin-bottom:20px;">
                <div class="col-4" style="color:#0AA09E">
                    <h6>SALDO ANTERIOR EN CAJA</h6>
                </div>
                <div class="col-4" style="color:#0AA09E">
                    <h6>${{$totalUltimaPoliza}}</h6>
                </div>
            </div>

            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>INGRESOS ADMINISTRACION</h6>
                </div>
                <div class="col-4">
                    <h6>$ {{$ingresosAdmin}}</h6>
                </div>
            </div>

            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>INGRESOS VENTAS</h6>
                </div>
                <div class="col-4">
                    <h6>$ {{$ingresosVentas}}</h6>
                </div>
            </div>
            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>INGRESOS DE COBRANZA</h6>
                </div>
                <div class="col-4">
                    <u>
                        <h6>$ {{$ingresosCobranza}}</h6>
                    </u>
                </div>
            </div>
            <hr>
            <div class="row" style="margin-left:10%;margin-bottom:30px;">
                <div class="col-3" style="color:#0AA09E">
                    <h5>TOTAL INGRESOS</h5>
                </div>
                <div class="col-4" style="color:#0AA09E">
                    <h3>$ {{$totalUltimaPoliza+$ingresosAdmin+$ingresosVentas+$ingresosCobranza}}</h3>
                </div>
            </div>

            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>GASTOS ADMINISTRACION</h6>
                </div>
                <div class="col-4">
                    <h6>${{$gastosAdmin}}</h6>
                </div>
            </div>
            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>GASTOS VENTAS</h6>
                </div>
                <div class="col-4">
                    <h6>$ {{$gastoVentas}}</h6>
                </div>
            </div>
            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>GASTOS COBRANZA</h6>
                </div>
                <div class="col-4">
                    <h6>$ {{$gastosCobranza}}</h6>
                </div>
            </div>

            <div class="row" style="margin-bottom:20px;">
                <div class="col-4">
                    <h6>OTROS GASTOS</h6>
                </div>
                <div class="col-4">
                    <u>
                        <h6>$ {{$otrosGastos}}</h6>
                    </u>
                </div>
            </div>
            <hr>
            <div class="row" style="margin-left:10%;margin-bottom:40px;">
                <div class="col-3" style="color:#0AA09E">
                    <h5>TOTAL GASTOS</h5>
                </div>
                <div class="col" style="color:#0AA09E">
                    <h3>$ {{$gastosAdmin+$gastoVentas+$gastosCobranza+$otrosGastos}}</h3>
                </div>
            </div>
            <div class="row" style="margin-bottom:20px;">
                <div class="col-5" style="color:#0AA09E">
                    <h3>REALIZO: {{$poliza[0]->realizo}}</h3>
                </div>
                <div class="col" style="color:#0AA09E">
                    <h3>AUTORIZO: {{$poliza[0]->autorizo}}</h3>
                </div>
            </div>
            <div class="row" style="margin-bottom:20px;">
                <div class="col-5" style="color:#0AA09E">
                    <h3>TOTAL POLIZA</h3>
                </div>
                <div class="col-2" style="background-color:#0AA09E;text-align:center;color:white;">
                    <h3>
                        $ {{($totalUltimaPoliza+$ingresosAdmin+$ingresosVentas+$ingresosCobranza)-($gastosAdmin+$gastoVentas+$gastosCobranza+$otrosGastos)}}</h3>
                </div>
            </div>
            <hr>
        </div>
    </div>

    <div class="tab-pane" id="ingresosoficina" role="tabpanel" aria-labelledby="ingresosoficina-tab">
        <div class="col-12">
            @if($poliza[0]->estatus == 0)
                <form action="{{route('ingresarOficina',[$idFranquicia,$idPoliza])}}" enctype="multipart/form-data"
                      method="POST" onsubmit="btnSubmit.disabled = true;">
                    @csrf
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label>Descripcion:</label>
                                <input type="text" name="descripcion"
                                       class="form-control {!! $errors->first('descripcion','is-invalid')!!}"
                                       placeholder="Descripcion" value="{{ old('descripcion') }}">
                                {!! $errors->first('descripcion','<div class="invalid-feedback">La descripcion es
                                    obligatoria.</div>')!!}
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Recibo:</label>
                                <input type="number" name="recibo" min="0"
                                       class="form-control {!! $errors->first('recibo','is-invalid')!!}"
                                       placeholder="Recibo"
                                       value="{{ old('recibo') }}">
                                {!! $errors->first('recibo','<div class="invalid-feedback">El Recibo es obligatorio.</div>
                                ')!!}
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label>Foto del recibo:</label>
                                <input type="file" name="fotorecibo"
                                       class="form-control-file  {!! $errors->first('fotorecibo','is-invalid')!!}"
                                       accept="image/jpg">
                                {!! $errors->first('fotorecibo','<div class="invalid-feedback">obligatorio
                                </div>')!!}
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Monto:</label>
                                <input type="number" name="monto" min="0"
                                       class="form-control {!! $errors->first('monto','is-invalid')!!}"
                                       placeholder="Monto"
                                       value="{{ old('monto') }}">
                                {!! $errors->first('monto','<div class="invalid-feedback">El monto es obligatorio.</div>
                                ')!!}
                            </div>
                        </div>
                        <div class="col-2">
                            <!-- <label> &nbsp; </label> -->
                            <div class="form-group">
                                <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">
                                    Agregar
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            @endif
            <table id="tablaHistorialC" class="table table-bordered">
                <thead>
                <tr>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">DESCRIPCIÓN
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">RECIBO</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FOTO</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">MONTO</th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">
                            ELIMINAR
                        </th>
                    @endif
                </tr>
                </thead>
                @if(sizeof($ingresos) === 0)
                    <tbody>
                    <tr>
                        <td align='center' colspan="5">Sin registros</td>
                    </tr>
                    </tbody>
                @else
                    <tbody>
                    @foreach($ingresos as $ingreso)
                        <tr>
                            <td align='center' style="color:#0AA09E;font-size:15px;">{{$ingreso->descripcion}}</td>
                            <td align='center' style="color:#0AA09E;font-size:15px;">{{$ingreso->numrecibo}}</td>
                            @if(isset($ingreso->foto))
                                <td align='center'><img src="{{asset($ingreso->foto)}}" class="img-thumbnail"
                                                        style="width:100px;height:65px;"></td>
                            @else
                                <td align='center' style="color:#0AA09E;font-size:15px;">NA</td>
                            @endif
                            <td align='center' style="color:#0AA09E;font-size:15px;">$ {{$ingreso->monto}}</td>
                            @if($poliza[0]->estatus == 0)
                                <td align='center'><a type="button" class="btn btn-danger" style="color:#FEFEFE;"
                                                      href="{{route('eliminarOficina',[$idFranquicia,$ingreso->id_poliza, $ingreso->id])}}">ELIMINAR</a>
                                </td>
                            @endif
                        </tr>
                    @endforeach
                    <td align='center' style="color:#0AA09E;font-size:5px;"></td>
                    <td align='center' style="color:#0AA09E;"></td>
                    <td align='center' style="color:#0AA09E;font-size:35px;">TOTAL</td>
                    <td align='center' style="color:#0AA09E;font-size:35px;">$ {{$sumaoficina[0]->suma}}</td>
                    </tbody>
                @endif

            </table>
            <hr>
        </div>

    </div>
    <div class="tab-pane" id="ingresosventas" role="tabpanel" aria-labelledby="ingresosventas-tab">
        <table id="tablaVentas" class="table table-bordered" style=" text-align:center;">
            <thead>
            <tr>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    OPTOMETRISTAS
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" colspan="6">
                    VENTAS
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    VENTAS ACUMULADAS
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    ASISTENCIA
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    INGRESO GOTAS
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    INGRESO DE ENGANCHE
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    INGRESO POLIZA
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    INGRESO VENTAS
                </th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" rowspan="2">
                    INGRESO ACUMULADO SEMANA
                </th>
            </tr>
            <tr>
                <th align='center' colspan=""
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;bordercolor:#0AA09E">Lu
                </th>
                <th align='center' colspan=""
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;bordercolor:#0AA09E">Ma
                </th>
                <th align='center' colspan=""
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;bordercolor:#0AA09E">Mi
                </th>
                <th align='center' colspan=""
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;bordercolor:#0AA09E">Ju
                </th>
                <th align='center' colspan=""
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;bordercolor:#0AA09E">Vi
                </th>
                <th align='center' colspan=""
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;bordercolor:#0AA09E">Sa
                </th>
            </tr>
            </thead>
            <tbody>
            @foreach($ventas as $venta)
                <tr>
                    <td align='center'>{{$venta->nombre}}</td>
                    <td align='center' colspan="">{{$venta->lunes}}</td>
                    <td align='center' colspan="">{{$venta->martes}}</td>
                    <td align='center' colspan="">{{$venta->miercoles}}</td>
                    <td align='center' colspan="">{{$venta->jueves}}</td>
                    <td align='center' colspan="">{{$venta->viernes}}</td>
                    <td align='center' colspan="">{{$venta->sabado}}</td>
                    <td align='center' colspan="">{{$venta->acumuladas}}</td>
                    @if($venta->asistencia == 0)
                        <td align='center' colspan="">F</td>
                    @endif
                    @if($venta->asistencia == 1)
                        <td align='center' colspan="">A</td>
                    @endif
                    @if($venta->asistencia == 2)
                        <td align='center' colspan="">R</td>
                    @endif
                    <td align='center' colspan="">{{$venta->ingresosgotas}}</td>
                    <td align='center' colspan="">{{$venta->ingresosenganche}}</td>
                    <td align='center' colspan="">{{$venta->ingresospoliza}}</td>
                    <td align='center' colspan="">{{$venta->ingresosventas}}</td>
                    <td align='center' colspan="">$ {{$venta->ingresosventasacumulado}}</td>
                </tr>
            @endforeach
            <td align='center' colspan="" style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;">
                ASISTENTES
            </td>
            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" colspan="7">
                VENTAS
            </th>
            <td align='center' colspan="6"
                style="text-align:center;background-color:#0AA09E;color:#FFFFFF;"></td>
            @foreach($ventasAsistente as $venta)
                <tr>
                    <td align='center'>{{$venta->nombre}}</td>
                    <td align='center' colspan="">{{$venta->lunes}}</td>
                    <td align='center' colspan="">{{$venta->martes}}</td>
                    <td align='center' colspan="">{{$venta->miercoles}}</td>
                    <td align='center' colspan="">{{$venta->jueves}}</td>
                    <td align='center' colspan="">{{$venta->viernes}}</td>
                    <td align='center' colspan="">{{$venta->sabado}}</td>
                    <td align='center' colspan="">{{$venta->acumuladas}}</td>
                    @if($venta->asistencia == 0)
                        <td align='center' colspan="">F</td>
                    @endif
                    @if($venta->asistencia == 1)
                        <td align='center' colspan="">A</td>
                    @endif
                    @if($venta->asistencia == 2)
                        <td align='center' colspan="">R</td>
                    @endif
                    <td align='center' colspan="">{{$venta->ingresosgotas}}</td>
                    <td align='center' colspan="">{{$venta->ingresosenganche}}</td>
                    <td align='center' colspan="">{{$venta->ingresospoliza}}</td>
                    <td align='center' colspan="">0</td>
                    <td align='center' colspan="">$0</td>
                </tr>
            @endforeach
            <tr>
                <td align='center' colspan="11"
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;"></td>
                <td align='center'>TOTAL DIA</td>
                @if($poliza[0]->estatus == 1)
                    <td align='center'>$ 0</td>
                @else
                    <td align='center'>$ 0</td>
                @endif
                <td align='center'></td>
            </tr>
            <tr>
                <td align='center' colspan="11"
                    style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;"></td>
                <td align='center' colspan="2">TOTAL ACUMULADO</td>
                @if($poliza[0]->estatus == 1)
                    <td align='center'>$ 0</td>
                @else
                    <td align='center'>$ 0</td>
                @endif
            </tr>
            </tbody>
        </table>
    </div>
    <div class="tab-pane" id="productividad" role="tabpanel" aria-labelledby="productividad-tab">
        @if($poliza[0]->estatus == 0)
            <div class="col-12">
                <form action="{{route('ingresarProductividadG',[$idFranquicia,$idPoliza])}}"
                      enctype="multipart/form-data"
                      method="POST" onsubmit="btnSubmit.disabled = true;">
                    <div class="row">
                        @csrf
                        <div class="col-2">
                            <div class="form-group">
                                <label>SALIERON:</label>
                                <input type="text" name="salieron"
                                       class="form-control {!! $errors->first('salieron','is-invalid')!!}"
                                       placeholder="Salieron"
                                       value="@if($productividadgasto != null) {{$productividadgasto[0]->salieron}}  @endif">
                                @if($errors->has('salieron'))
                                    <div class="invalid-feedback">{{$errors->first('salieron')}}</div>
                                @endif
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>TRASPORTE:</label>
                                <input type="text" name="trasporte"
                                       class="form-control {!! $errors->first('trasporte','is-invalid')!!}"
                                       placeholder="Trasporte"
                                       value="@if($productividadgasto != null) {{$productividadgasto[0]->monto}}  @endif">
                                @if($errors->has('trasporte'))
                                    <div class="invalid-feedback">{{$errors->first('trasporte')}}</div>
                                @endif
                            </div>
                        </div>
                        @if($productividadgasto == null)
                            <div class="col-2">
                                <label>&nbsp;</label>
                                <div class="form-group">
                                    <button class="btn btn-primary" name="btnSubmit" name="btnSubmit" type="submit">
                                        AGREGAR
                                    </button>
                                </div>
                            </div>
                        @endif
                        @if($productividadgasto != null)
                            <div class="col-2">
                                <div class="form-group">
                                    <label>TOTAL POR PERSONA:</label>
                                    <input type="text" name="persona"
                                           class="form-control {!! $errors->first('persona','is-invalid')!!}"
                                           placeholder="total por persona"
                                           value="@if($productividadgasto != null) @if($productividadgasto[0]->salieron == 0) {{$productividadgasto[0]->monto}} @else {{$productividadgasto[0]->monto/$productividadgasto[0]->salieron}}  @endif @endif">
                                    @if($errors->has('persona'))
                                        <div class="invalid-feedback">{{$errors->first('persona')}}</div>
                                    @endif
                                </div>
                            </div>
                        @endif
                    </div>
                </form>
            </div>
        @endif
            <div id="contenedorProductividad">
                <table id="tablaPro" class="table table-bordered" style=" text-align:center;">
                    <thead>
                    <tr>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="2"> ECO JR</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="2">JR</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="2">DORADO 1 Y 2</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="2">PLATINO</th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                    </tr>
                    <tr>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NOMBRE</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">PUESTO</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">SUELDO</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TOTAL</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TOTAL</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TOTAL</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TOTAL</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NO. VENTAS</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">POR ENTREGAR</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">MONTO TOTAL</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">ENTREGADOS
                            TOTAL
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" colspan="2">
                            OBJETIVO EN
                            VENTAS 30
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col" colspan="2">
                            OBJETIVO EN
                            VENTAS 40
                        </th>
                        @if(Auth::user()->rol_id == 7)
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">INSUMOS</th>
                        @endif
                        @if($poliza[0]->estatus == 0)
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">ACTUALIZAR</th>
                        @endif
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($productividad as $pro)
                        <tr>
                            <td align='center' colspan="">{{$pro->name}}</td>
                            <td align='center' colspan="">OPTOMETRISTA</td>
                            <td align='center' colspan="">$ {{$pro->sueldo}}</td>
                            <td align='center' colspan=""><b><i>24</i></b></td>
                            <td align='center' colspan="">{{$pro->totaleco}}</td>
                            <td align='center' colspan=""><b><i>4</i></b></td>
                            <td align='center' colspan="">{{$pro->totaljr}}</td>
                            <td align='center' colspan=""><b><i>10</i></b></td>
                            <td align='center' colspan="">{{$pro->totaldoradouno+$pro->totaldoradodos}}</td>
                            <td align='center' colspan=""><b><i>2</i></b></td>
                            <td align='center' colspan="">{{$pro->totalplatino}}</td>
                            <td align='center' colspan="">{{$pro->numeroventas}}</td>
                            <td align='center' colspan="">{{$pro->contratosporentregar}}</td>
                            <td align='center' colspan="">$ {{$pro->montototalreal}}</td>
                            <td align='center' colspan="">$ {{$pro->montoentregadostotalreal}}</td>
                            @if(round((100 / 30) * $pro->numeroventas, 2) > 100)
                                <td align='center' colspan="">% 100</td>
                            @else
                                <td align='center' colspan="">% {{round((100 / 30) * $pro->numeroventas, 2)}}</td>
                            @endif
                            <td align='center' colspan="">$ {{$pro->dineroobjetivoventastreinta}}</td>
                            @if(round((100 / 40) * $pro->numeroventas, 2) > 100)
                                <td align='center' colspan="">% 100</td>
                            @else
                                <td align='center' colspan="">% {{round((100 / 40) * $pro->numeroventas, 2)}}</td>
                            @endif
                            <td align='center' colspan="">$ {{$pro->dineroobjetivoventascuarenta}}</td>
                            @if(Auth::user()->rol_id == 7)
                                <td align='center' colspan="">$ {{$pro->insumos}}</td>
                            @endif
                            @if($poliza[0]->estatus == 0)
                                <td align='center' colspan=""><a href="{{route('polizaactualizarasisoptocobranza',[$idFranquicia,$idPoliza,$pro->id_usuario])}}" class="btn btn-primary">APLICAR</a></td>
                            @endif
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        <hr style="background-color: #0AA09E; height: 2px;">
            <div id="contenedorProductividadSemana">
                <table id="tablaPro" class="table table-bordered" style=" text-align:center;">
                    <thead>
                    <tr>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="2">SEMANA ANTERIOR</th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;" scope="col"></th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="2">SEMANA ACTUAL</th>
                    </tr>
                    <tr>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NOMBRE</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO 10</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO 16</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NO. VENTAS (DIA)</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">APROBADAS</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">VENTAS ACUMULADAS</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">VENTAS ACUMULADAS APROBADAS</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">COMISION</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO 10</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBJETIVO 16</th>
                        @if($poliza[0]->estatus == 0)
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">ACTUALIZAR</th>
                        @endif
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($productividadAsistente as $pro)
                        <tr>
                            <td align='center' colspan="">{{$pro->name}}</td>
                            @if($pro->numObjetivoSemanaAnterior >= 16)
                                <td align='center' colspan="">NA</td>
                                <td align='center' colspan="">{{$pro->numObjetivoSemanaAnterior}} (Cumplido)</td>
                            @else
                                @if($pro->numObjetivoSemanaAnterior >= 10)
                                    <td align='center' colspan="">{{$pro->numObjetivoSemanaAnterior}} (Cumplido)</td>
                                    <td align='center' colspan="">NA</td>
                                @else
                                    <td align='center' colspan="">{{$pro->numObjetivoSemanaAnterior}} (NA)</td>
                                    <td align='center' colspan="">NA</td>
                                @endif
                            @endif
                            <td align='center' colspan="">{{$pro->sumaContratosNumVentas}}</td>
                            <td align='center' colspan="">{{$pro->sumaContratosAprobadas}}</td>
                            <td align='center' colspan="">{{$pro->sumaContratosVentasAcumuladas}}</td>
                            <td align='center' colspan="">{{$pro->sumaContratosVentasAcumuladasAprobadas}}</td>
                            @if($pro->numObjetivoSemanaAnterior >= 16)
                                <td align='center' colspan="">$ {{$pro->sumaContratosVentasAcumuladasAprobadas * 100}}</td>
                            @else
                                @if($pro->numObjetivoSemanaAnterior >= 10)
                                    <td align='center' colspan="">$ {{$pro->sumaContratosVentasAcumuladasAprobadas * 70}}</td>
                                @else
                                    <td align='center' colspan="">$ 0</td>
                                @endif
                            @endif
                            @if($pro->sumaContratosVentasAcumuladasAprobadas >= 16)
                                <td align='center' colspan="">NA</td>
                                <td align='center' colspan="">Cumplido</td>
                            @else
                                @if($pro->sumaContratosVentasAcumuladasAprobadas >= 10)
                                    <td align='center' colspan="">Cumplido</td>
                                    <td align='center' colspan="">NA</td>
                                @else
                                    <td align='center' colspan="">NA</td>
                                    <td align='center' colspan="">NA</td>
                                @endif
                            @endif
                            @if($poliza[0]->estatus == 0)
                                <td align='center' colspan=""><a href="{{route('polizaactualizarasisoptocobranza',[$idFranquicia,$idPoliza,$pro->id_usuario])}}" class="btn btn-primary">APLICAR</a></td>
                            @endif
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
    </div>
    <div class="tab-pane" id="cobranza" role="tabpanel" aria-labelledby="cobranza-tab">
        @if($poliza[0]->estatus == 0)
            <div class="col-12">
                <form action="{{route('ingresarCobranza',[$idFranquicia,$idPoliza])}}" enctype="multipart/form-data"
                      method="POST" onsubmit="btnSubmit.disabled = true;">
                    @csrf
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label>CANTIDAD:</label>
                                <input type="number" name="cantidad"
                                       class="form-control {!! $errors->first('cantidad','is-invalid')!!}"
                                       placeholder="Cantidad" value="{{ old('cantidad') }}">
                                {!! $errors->first('cantidad','<div class="invalid-feedback">La cantidad es
                                    obligatoria.</div>')!!}
                            </div>
                        </div>
                        <div class="col-3">
                            <label for="">USUARIO:</label>
                            <select class="custom-select {!! $errors->first('usuario','is-invalid')!!}"
                                    name="usuario"
                                    id="usuario">
                                <option selected value="nada">Seleccionar</option>
                                @foreach($usuarioscobranza as $uc)
                                    <option value="{{$uc->id}}">{{$uc->name}}</option>
                                @endforeach
                            </select>
                            {!! $errors->first('usuario','<div class="invalid-feedback">Elegir un usuario </div>
                            ')!!}
                        </div>
                        <div class="col-3">
                            <label for="">TIPO;</label>
                            <select class="custom-select {!! $errors->first('tipo','is-invalid')!!}" name="tipo"
                                    id="tipo">
                                <option selected value="nada">Seleccionar</option>
                                <option value="1" {{ old('tipo') == '1' ? 'selected' : '' }}>Archivo</option>
                                <option value="2" {{ old('tipo') == '2' ? 'selected' : '' }}>Garantia</option>
                                <option value="3" {{ old('tipo') == '3' ? 'selected' : '' }}>Gas</option>
                            </select>
                            {!! $errors->first('tipo','<div class="invalid-feedback">Elegir una forma de gasto </div>
                            ')!!}
                        </div>
                        <div class="col-3">
                            <!-- <label> &nbsp; </label> -->
                            <div class="form-group">
                                <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">
                                    Agregar
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        @endif

        <div id="contenedorCobranza">
            <table id="tablaCobranza" class="table table-bordered">
                <thead>
                <tr>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NOMBRE</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">ZONA</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TABULAR</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">ARCHIVO</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJETAS
                        PAGADAS
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJETA COBRADA
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJ.
                        ACUMULADA-SEMANA
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col"> DIARIO
                        ACUMULADO
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">$ ABONO PROMEDIO
                        ACUMULADO
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">GAS</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">INGRESO
                        COBRANZA
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">INGRESO
                        OFICINA
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">INGRESO
                        ACUMULADO
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJETAS 75%</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJ. POR COBRAR
                        75%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">$ POR COBRAR
                        75%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJETAS 80%</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJ. POR COBRAR
                        80%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">$ POR COBRAR
                        80%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJETAS 85%</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJ. POR COBRAR
                        85%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">$ POR COBRAR
                        85%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJETAS 90%</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TARJ. POR COBRAR
                        90%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">$ POR COBRAR
                        90%
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">SUELDO BASE</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">6% - 75%</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">8% - 80</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">9% - 85</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">10% - 90</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">TOTAL A PAGAR
                    </th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">ACTUALIZAR</th>
                    @endif
                </tr>
                </thead>
                @if(sizeof($cobranzatabla) === 0 && $poliza[0]->estatus != 1)
                    <tbody>
                    <tr>
                        <td align='center' colspan="23">Sin registros</td>
                    </tr>
                    </tbody>
                @else
                    <tbody>
                    @foreach($cobranzatabla as $cobranza)
                        <tr>
                            <td align='center' style="font-size:15px;">{{$cobranza->nombre}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->zona}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->tabular}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->archivo}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->pagadas}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->cobradas}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->acumuladasemana}}</td>
                            <td align='center' style="font-size:15px;">%{{round($cobranza->diarioacumulado,2)}}</td>
                            <td align='center'
                                style="font-size:15px;"> {{round($cobranza->promedioacumulado,2)}}</td>
                            <td align='center' style="font-size:15px;">{{$cobranza->gas}}</td>
                            <td align='center' style="font-size:15px;">$ {{$cobranza->ingresocobranza}}</td>
                            <td align='center' style="font-size:15px;">$ {{$cobranza->ingresooficina}}</td>
                            <td align='center' style="font-size:15px;">$ {{$cobranza->ingresoacumulado}}</td>
                            <td align='center' style="font-size:15px;">{{round($cobranza->tabular * 0.75,2)}}</td>
                            @if(round(($cobranza->tabular * 0.75) - $cobranza->acumuladasemana,2) < 0)
                                <td align='center' style="font-size:15px;">0</td>
                            @else
                                <td align='center' style="font-size:15px;">{{round(($cobranza->tabular * 0.75) - $cobranza->acumuladasemana,2)}}</td>
                            @endif
                            @if(round((($cobranza->tabular * 0.75) - $cobranza->acumuladasemana) * 150,2) < 0)
                                <td align='center' style="font-size:15px;">$ 0</td>
                            @else
                                <td align='center' style="font-size:15px;">$ {{round((($cobranza->tabular * 0.75) - $cobranza->acumuladasemana) * 150,2)}}</td>
                            @endif
                            <td align='center' style="font-size:15px;">{{round($cobranza->tabular * 0.80,2)}}</td>
                            @if(round(($cobranza->tabular * 0.80) - $cobranza->acumuladasemana,2) < 0)
                                <td align='center' style="font-size:15px;">0</td>
                            @else
                                <td align='center' style="font-size:15px;">{{round(($cobranza->tabular * 0.80) - $cobranza->acumuladasemana,2)}}</td>
                            @endif
                            @if(round((($cobranza->tabular * 0.80) - $cobranza->acumuladasemana) * 150,2) < 0)
                                <td align='center' style="font-size:15px;">$ 0</td>
                            @else
                                <td align='center' style="font-size:15px;">$ {{round((($cobranza->tabular * 0.80) - $cobranza->acumuladasemana) * 150,2)}}</td>
                            @endif
                            <td align='center' style="font-size:15px;">{{round($cobranza->tabular * 0.85,2)}}</td>
                            @if(round(($cobranza->tabular * 0.85) - $cobranza->acumuladasemana,2) < 0)
                                <td align='center' style="font-size:15px;">0</td>
                            @else
                                <td align='center' style="font-size:15px;">{{round(($cobranza->tabular * 0.85) - $cobranza->acumuladasemana,2)}}</td>
                            @endif
                            @if(round((($cobranza->tabular * 0.85) - $cobranza->acumuladasemana) * 150,2) < 0)
                                <td align='center' style="font-size:15px;">$ 0</td>
                            @else
                                <td align='center' style="font-size:15px;">$ {{round((($cobranza->tabular * 0.85) - $cobranza->acumuladasemana) * 150,2)}}</td>
                            @endif
                            <td align='center' style="font-size:15px;">{{round($cobranza->tabular * 0.90,2)}}</td>
                            @if(round(($cobranza->tabular * 0.90) - $cobranza->acumuladasemana,2) < 0)
                                <td align='center' style="font-size:15px;">0</td>
                            @else
                                <td align='center' style="font-size:15px;">{{round(($cobranza->tabular * 0.90) - $cobranza->acumuladasemana,2)}}</td>
                            @endif
                            @if(round((($cobranza->tabular * 0.90) - $cobranza->acumuladasemana) * 150,2) < 0)
                                <td align='center' style="font-size:15px;">$ 0</td>
                            @else
                                <td align='center' style="font-size:15px;">$ {{round((($cobranza->tabular * 0.90) - $cobranza->acumuladasemana) * 150,2)}}</td>
                            @endif
                            <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo}}</td>
                            @if(round($cobranza->promedioacumulado,2) >= 150)
                                @if(round(($cobranza->tabular * 0.90) - $cobranza->acumuladasemana,2) <= 0)
                                    <td align='center' style="font-size:15px;">$ 0</td>
                                    <td align='center' style="font-size:15px;">$ 0</td>
                                    <td align='center' style="font-size:15px;">$ 0</td>
                                    <td align='center' style="font-size:15px;">$ {{$cobranza->ingresoacumulado * 0.10}}</td>
                                    <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo + ($cobranza->ingresoacumulado * 0.10)}}</td>
                                @else
                                    @if(round(($cobranza->tabular * 0.85) - $cobranza->acumuladasemana,2) <= 0)
                                        <td align='center' style="font-size:15px;">$ 0</td>
                                        <td align='center' style="font-size:15px;">$ 0</td>
                                        <td align='center' style="font-size:15px;">$ {{$cobranza->ingresoacumulado * 0.09}}</td>
                                        <td align='center' style="font-size:15px;">$ 0</td>
                                        <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo + ($cobranza->ingresoacumulado * 0.09)}}</td>
                                    @else
                                        @if(round(($cobranza->tabular * 0.80) - $cobranza->acumuladasemana,2) <= 0)
                                            <td align='center' style="font-size:15px;">$ 0</td>
                                            <td align='center' style="font-size:15px;">$ {{$cobranza->ingresoacumulado * 0.08}}</td>
                                            <td align='center' style="font-size:15px;">$ 0</td>
                                            <td align='center' style="font-size:15px;">$ 0</td>
                                            <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo + ($cobranza->ingresoacumulado * 0.08)}}</td>
                                        @else
                                            @if(round(($cobranza->tabular * 0.75) - $cobranza->acumuladasemana,2) <= 0)
                                                <td align='center' style="font-size:15px;">$ {{$cobranza->ingresoacumulado * 0.06}}</td>
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo + ($cobranza->ingresoacumulado * 0.06)}}</td>
                                            @else
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ 0</td>
                                                <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo}}</td>
                                            @endif
                                        @endif
                                    @endif
                                @endif
                            @else
                                <td align='center' style="font-size:15px;">$ 0</td>
                                <td align='center' style="font-size:15px;">$ 0</td>
                                <td align='center' style="font-size:15px;">$ 0</td>
                                <td align='center' style="font-size:15px;">$ 0</td>
                                <td align='center' style="font-size:15px;">$ {{$cobranza->sueldo}}</td>
                            @endif
                            @if($poliza[0]->estatus == 0)
                                <td align='center' style="font-size:15px;"><a href="{{route('polizaactualizarasisoptocobranza',[$idFranquicia,$idPoliza,$cobranza->id_usuario])}}" class="btn btn-primary">APLICAR</a></td>
                            @endif
                        </tr>
                    @endforeach
                    </tbody>
                @endif
            </table>
        </div>
    </div>
    <div class="tab-pane" id="gastos" role="tabpanel" aria-labelledby="gastos-tab">
        <div class="col-12">
            @if($poliza[0]->estatus == 0)
                <div class="col-12">
                    <form action="{{route('ingresarGasto',[$idFranquicia,$idPoliza])}}"
                          enctype="multipart/form-data"
                          method="POST" onsubmit="btnSubmit2.disabled = true;">
                        @csrf
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Descripcion:</label>
                                    <input type="text" name="descripcion2"
                                           class="form-control {!! $errors->first('descripcion2','is-invalid')!!}"
                                           placeholder="Descripcion" value="{{ old('descripcion2') }}">
                                    {!! $errors->first('descripcion2','<div class="invalid-feedback">La descripcion es
                                        obligatoria.</div>')!!}
                                </div>
                            </div>
                            <div class="col-1">
                                <div class="form-group">
                                    <label>No. Factura:</label>
                                    <input type="number" name="factura" min="0"
                                           class="form-control {!! $errors->first('factura','is-invalid')!!}"
                                           placeholder="Factura"
                                           value="{{ old('factura') }}">
                                    {!! $errors->first('factura','<div class="invalid-feedback">la factura es obligatorio.</div>
                                    ')!!}
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Foto de la factura:</label>
                                    <input type="file" name="fotofactura"
                                           class="form-control-file  {!! $errors->first('fotofactura','is-invalid')!!}"
                                           accept="image/jpg">
                                    {!! $errors->first('fotofactura','<div class="invalid-feedback">Obligatorio
                                        .</div>')!!}
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Observaciones:</label>
                                    <input type="text" name="observaciones"
                                           class="form-control {!! $errors->first('observaciones','is-invalid')!!}"
                                           placeholder="observaciones" value="{{ old('observaciones') }}">
                                    {!! $errors->first('descripcion2','<div class="invalid-feedback">La descripcion es
                                        obligatoria.</div>')!!}
                                </div>
                            </div>
                            <div class="col-1">
                                <div class="form-group">
                                    <label>Monto:</label>
                                    <input type="number" name="monto2" min="0"
                                           class="form-control {!! $errors->first('monto2','is-invalid')!!}"
                                           placeholder="Monto"
                                           value="{{ old('monto2') }}">
                                    {!! $errors->first('monto2','<div class="invalid-feedback">El monto es obligatorio.</div>
                                    ')!!}
                                </div>
                            </div>
                            <div class="col-2">
                                <label for="">Tipo gasto;</label>
                                <select class="custom-select {!! $errors->first('tipogasto','is-invalid')!!}"
                                        name="tipogasto"
                                        id="tipogasto">
                                    <option selected>Seleccionar</option>
                                    <option value="0" {{ old('tipogasto') == '0' ? 'selected' : '' }}>Gastos
                                        Administración
                                    </option>
                                    <option value="1" {{ old('tipogasto') == '1' ? 'selected' : '' }}>Gastos
                                        ventas
                                    </option>
                                    <option value="2" {{ old('tipogasto') == '2' ? 'selected' : '' }}>Gastos
                                        cobranza
                                    </option>
                                    <option value="3" {{ old('tipogasto') == '3' ? 'selected' : '' }}>Otros gastos
                                    </option>
                                </select>
                                {!! $errors->first('tipogasto','<div class="invalid-feedback">Elegir una forma de gasto </div>
                                ')!!}
                            </div>
                            <div class="col-1">
                                <!-- <label> &nbsp; </label> -->
                                <div class="form-group">
                                    <button class="btn btn-outline-success btn-block" name="btnSubmit2"
                                            type="submit">Agregar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            @endif
            <h3 style="text-align:center;">Gastos de administración</h3>
            <table id="tablaGastosAdmon" class="table table-bordered">
                <thead>
                <tr>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FECHA</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">DESCRIPCION
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NO. FACTURA
                    </th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FOTO</th>
                    @endif
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBSERVACIONES
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">MONTO</th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">
                            ELIMINAR
                        </th>
                    @endif
                </tr>
                </thead>
                @if($gastosadmon == null || sizeof($gastosadmon) === 0)
                    <tbody>
                    <tr>
                        <td align='center' colspan="7">Sin registros</td>
                    </tr>
                    </tbody>

                @else
                    <tbody>
                    @foreach($gastosadmon as $gadmin)
                        <tr>
                            <td align='center'>{{$gadmin->created_at}}</td>
                            <td align='center'>{{$gadmin->descripcion}}</td>
                            <td align='center'>{{$gadmin->factura}}</td>
                            @if($poliza[0]->estatus == 0)
                                @if(isset($gadmin->foto))
                                    <td align='center'><img src="{{asset($gadmin->foto)}}" class="img-thumbnail"
                                                            style="width:100px;height:65px;"></td>
                                @else
                                    <td align='center'>NA</td>
                                @endif
                            @endif
                            <td align='center'>{{$gadmin->observaciones}}</td>
                            <td align='center'>$ {{$gadmin->monto}}</td>
                            @if($poliza[0]->estatus == 0)
                                <td align='center'><a type="button" class="btn btn-danger" style="color:#FEFEFE;"
                                                      href="{{route('eliminarGasto',[$idFranquicia,$gadmin->id_poliza, $gadmin->id])}}">ELIMINAR</a>
                                </td>
                            @endif
                        </tr>
                    @endforeach
                    @if($poliza[0]->estatus == 0)
                        <td align='center' colspan="4"></td>
                    @else
                        <td align='center' colspan="3"></td>
                    @endif
                    <td align='center' style="color:#0AA09E;">TOTAL GASTOS DE ADMINISTRACIÓN</td>
                    <td align='center' style="color:#0AA09E;" colspan="2">$ {{$sumaadmin[0]->suma}}</td>
                    </tbody>
                @endif
            </table>
            <hr>
            <h3 style="text-align:center;">Gastos ventas</h3>
            <table id="tablaGastosVentas" class="table table-bordered">
                <thead>
                <tr>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FECHA</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">DESCRIPCION
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NO. FACTURA
                    </th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FOTO</th>
                    @endif
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBSERVACIONES
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">MONTO</th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">
                            ELIMINAR
                        </th>
                    @endif
                </tr>
                </thead>
                @if($gastosventas == null || sizeof($gastosventas)===0)
                    <tbody>
                    <tr>
                        <td align='center' colspan="7">Sin registros</td>
                    </tr>
                    </tbody>
                @else
                    <tbody>
                    @foreach($gastosventas as $gastosventa)
                        <tr>
                            <td align='center'>{{$gastosventa->created_at}}</td>
                            <td align='center'>{{$gastosventa->descripcion}}</td>
                            <td align='center'>{{$gastosventa->factura}}</td>
                            @if($poliza[0]->estatus == 0)
                                @if(isset($gastosventa->foto))
                                    <td align='center'><img src="{{asset($gastosventa->foto)}}"
                                                            class="img-thumbnail"
                                                            style="width:100px;height:65px;"></td>
                                @else
                                    <td align='center'>NA</td>
                                @endif
                            @endif
                            <td align='center'>{{$gastosventa->observaciones}}</td>
                            <td align='center'>$ {{$gastosventa->monto}}</td>
                            @if($poliza[0]->estatus == 0)
                                <td align='center'><a type="button" class="btn btn-danger" style="color:#FEFEFE;"
                                                      href="{{route('eliminarGasto',[$idFranquicia,$gastosventa->id_poliza, $gastosventa->id])}}">ELIMINAR</a>
                                </td>
                            @endif
                        </tr>
                    @endforeach
                    @if($poliza[0]->estatus == 0)
                        <td align='center' colspan="4"></td>
                    @else
                        <td align='center' colspan="3"></td>
                    @endif
                    <td align='center' style="color:#0AA09E;">TOTAL GASTOS VENTAS</td>
                    <td align='center' style="color:#0AA09E;" colspan="2">$ {{$sumaventas[0]->suma}}</td>
                    </tbody>
                @endif

            </table>
            <hr>
            <h3 style="text-align:center;">Gastos Cobranza</h3>
            <table id="tablaGastosCobranza" class="table table-bordered">
                <thead>
                <tr>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FECHA</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">DESCRIPCION
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NO. FACTURA
                    </th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FOTO</th>
                    @endif
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBSERVACIONES
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">MONTO</th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">
                            ELIMINAR
                        </th>
                    @endif
                </tr>
                </thead>
                @if($gastoscobranza == null || sizeof($gastoscobranza)===0)
                    <tbody>
                    <tr>
                        <td align='center' colspan="7">Sin registros</td>
                    </tr>
                    </tbody>
                @else
                    <tbody>
                    @foreach($gastoscobranza as $gc)
                        <tr>
                            <td align='center'>{{$gc->created_at}}</td>
                            <td align='center'>{{$gc->descripcion}}</td>
                            <td align='center'>{{$gc->factura}}</td>
                            @if($poliza[0]->estatus == 0)
                                @if(isset($gc->foto))
                                    <td align='center'><img src="{{asset($gc->foto)}}" class="img-thumbnail"
                                                            style="width:100px;height:65px;"></td>
                                @else
                                    <td align='center'>NA</td>
                                @endif
                            @endif
                            <td align='center'>{{$gc->observaciones}}</td>
                            <td align='center'>$ {{$gc->monto}}</td>
                            @if($poliza[0]->estatus == 0)
                                <td align='center'><a type="button" class="btn btn-danger" style="color:#FEFEFE;"
                                                      href="{{route('eliminarGasto',[$idFranquicia,$gc->id_poliza, $gc->id])}}">ELIMINAR</a>
                                </td>
                            @endif
                        </tr>
                    @endforeach
                    @if($poliza[0]->estatus == 0)
                        <td align='center' colspan="4"></td>
                    @else
                        <td align='center' colspan="3"></td>
                    @endif
                    <td align='center' style="color:#0AA09E;">TOTAL GASTOS DE COBRANZA</td>
                    <td align='center' style="color:#0AA09E;" colspan="2">$ {{$sumacobranza[0]->suma}}</td>
                    </tbody>
                @endif

            </table>
            <hr>
            <h3 style="text-align:center;">Otros Gastos</h3>
            <table id="tablaOtrosGastos" class="table table-bordered">
                <thead>
                <tr>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FECHA</th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">DESCRIPCION
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">NO. FACTURA
                    </th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FOTO</th>
                    @endif
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">OBSERVACIONES
                    </th>
                    <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">MONTO</th>
                    @if($poliza[0]->estatus == 0)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">
                            ELIMINAR
                        </th>
                    @endif
                </tr>
                </thead>
                @if($otrosgastos == null || sizeof($otrosgastos)===0)
                    <tbody>
                    <tr>
                        <td align='center' colspan="7">Sin registros</td>
                    </tr>
                    </tbody>
                @else
                    <tbody>
                    @foreach($otrosgastos as $og)
                        <tr>
                            <td align='center'>{{$og->created_at}}</td>
                            <td align='center'>{{$og->descripcion}}</td>
                            <td align='center'>{{$og->factura}}</td>
                            @if($poliza[0]->estatus == 0)
                                @if(isset($og->foto))
                                    <td align='center'><img src="{{asset($og->foto)}}" class="img-thumbnail"
                                                            style="width:100px;height:65px;"></td>
                                @else
                                    <td align='center'>NA</td>
                                @endif
                            @endif
                            <td align='center'>{{$og->observaciones}}</td>
                            <td align='center'>$ {{$og->monto}}</td>
                            @if($poliza[0]->estatus == 0)
                                <td align='center'><a type="button" class="btn btn-danger" style="color:#FEFEFE;"
                                                      href="{{route('eliminarGasto',[$idFranquicia,$og->id_poliza, $og->id])}}">ELIMINAR</a>
                                </td>
                            @endif
                        </tr>
                    @endforeach
                    @if($poliza[0]->estatus == 0)
                        <td align='center' colspan="4"></td>
                    @else
                        <td align='center' colspan="3"></td>
                    @endif
                    <td align='center' style="color:#0AA09E;">TOTAL OTROS GASTOS</td>
                    <td align='center' style="color:#0AA09E;" colspan="2">$ {{$sumaotros[0]->suma}}</td>
                    </tbody>
                @endif
            </table>
            <hr>
        </div>
    </div>
    <div class="tab-pane" id="historial" role="tabpanel" aria-labelledby="historial-tab">
        <table id="tablaHistorial" class="table table-bordered">
            <thead>
            <tr>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">USUARIO</th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">CAMBIOS</th>
                <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" scope="col">FECHA</th>
            </tr>
            </thead>
            @if(sizeof($historial) === 0)
                <tbody>
                <tr>
                    <td align='center' colspan="7">Sin registros</td>
                </tr>
                </tbody>
            @else
                <tbody>
                @foreach($historial as $ht)
                    <tr>
                        <td align='center'>{{$ht->name}}</td>
                        <td align='center'>{{$ht->cambios}}</td>
                        <td align='center'>{{$ht->created_at}}</td>
                    </tr>
                @endforeach
                </tbody>
            @endif
        </table>
    </div>
</div>
    <script>
        @if(session('pestaña'))
        $(function () {
            @switch(session('pestaña'))
            @case('general')
            $('#myTab a[href="#general"]').tab('show');
            @break
            @case('oficina')
            $('#myTab a[href="#ingresosoficina"]').tab('show');
            @break
            @case('gastos')
            $('#myTab a[href="#gastos"]').tab('show');
            @break
            @case('productividad')
            $('#myTab a[href="#productividad"]').tab('show');
            @break
            @case('ventas')
            $('#myTab a[href="#ingresosventas"]').tab('show');
            @break
            @case('cobranza')
            $('#myTab a[href="#cobranza"]').tab('show');
            @break
            @default
            @endswitch
        });
        @endif
    </script>
