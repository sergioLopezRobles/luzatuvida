@extends('layouts.app')
@section('titulo','Lista Franquicias'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
{{--    <div class="row">--}}
{{--        <div class="col-9">--}}
{{--        </div>--}}
{{--        <div class="col-3">--}}
{{--            <a class="btn btn-outline-success btn-block" href="{{route('crearpoliza',$idFranquicia)}}">NUEVA POLIZA</a>--}}
{{--        </div>--}}
{{--    </div>--}}
    <h2>Polizas</h2>
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Estado</label>
                <input type="text" name="estado" class="form-control" readonly value="{{$franquiciaPoliza[0]->estado}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ciudad</label>
                <input type="text" name="ciudad" class="form-control" readonly value="{{$franquiciaPoliza[0]->ciudad}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="colonia" class="form-control" readonly
                       value="{{$franquiciaPoliza[0]->colonia}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Numero Interior/Exterior</label>
                <input type="text" name="numero" class="form-control" readonly value="{{$franquiciaPoliza[0]->numero}}">
            </div>
        </div>
    </div>

    <table id="tablaFranquicias" class="table table-bordered">
        @if(sizeof($polizas)>0)
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">POLIZA</th>
                <th style=" text-align:center;" scope="col">FRANQUICIA</th>
                <th style=" text-align:center;" scope="col">TERMINO</th>
                <th style=" text-align:center;" scope="col">AUTORIZO</th>
                <th style=" text-align:center;" scope="col">TOTAL</th>
                <th style=" text-align:center;" scope="col">FECHA</th>
                <th style=" text-align:center;" scope="col">VER</th>
            </tr>
            </thead>
        @endif
        <tbody>
        @foreach($polizas as $poliza)
            <tr>
                <td align='center'>{{$poliza->ID}}</td>
                <td align='center'>{{$poliza->FRANQUICIA}}</td>
                <td align='center'>{{$poliza->REALIZO}}</td>
                <td align='center'>{{$poliza->AUTORIZO}}</td>
                <td align='center'>{{$poliza->TOTAL}}</td>
                <td align='center'>{{$poliza->CREATED_AT}}</td>
                <td align='center'><a href="{{route('verpoliza',[$idFranquicia,$poliza->ID])}}">
                        <button style="margin:0px;" type="button" class="btn btn-outline-success"><i
                                class="fas fa-book-open"></i></button>
                    </a></td>
            </tr>
        @endforeach
        </tbody>
    </table>
    @if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
        @if($polizas!=null)
            <div class="d-flex justify-content-center">
                {{$polizas->links('pagination::bootstrap-4')}}
            </div>
        @endif
    @endif
@endsection
