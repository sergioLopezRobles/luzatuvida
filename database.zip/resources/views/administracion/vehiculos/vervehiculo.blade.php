@extends('layouts.app')
@section('titulo','Vehiculos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <h2>Editar vehículo</h2>
    <form id="frmCrearVehiculo" action="{{route('actualizarvehiculo',[$idFranquicia,$vehiculo[0]->numserie])}}" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
        @csrf
        <div class="col" style="padding-top: 20px;">
            <div class="row">
                <div class="col-3">
                    <div class="form-group">
                        <label>Numero de serie</label>
                        <input type="text" name="numSerie" id="numSerie" class="form-control {!! $errors->first('numSerie','is-invalid')!!}"  placeholder="EJ012345678901234 (17 digitos)" value="{{$vehiculo[0]->numserie}}">
                        {!! $errors->first('numSerie','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <div class="form-group">
                        <label>Marca</label>
                        <input type="text" name="marcaVehiculo" id="marcaVehiculo" class="form-control {!! $errors->first('marcaVehiculo','is-invalid')!!}"  placeholder="Honda | Yamaha | Italika | Suzuki" value="{{$vehiculo[0]->marca}}">
                        {!! $errors->first('marcaVehiculo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label>Numero de cilindros</label>
                        <input type="number" name="numCilindros" id="numCilindros" class="form-control {!! $errors->first('numCilindros','is-invalid')!!}"  placeholder="1" min="0" value="{{$vehiculo[0]->cilindros}}">
                        {!! $errors->first('numCilindros','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label>Linea</label>
                        <input type="text" name="lineaVehiculo" id="lineaVehiculo" class="form-control {!! $errors->first('lineaVehiculo','is-invalid')!!}"  placeholder="DIO" value="{{$vehiculo[0]->linea}}">
                        {!! $errors->first('lineaVehiculo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label>Modelo</label>
                        <input type="text" name="modeloVehiculo" id="modeloVehiculo" class="form-control {!! $errors->first('modeloVehiculo','is-invalid')!!}"  placeholder="<?php echo date('Y'); ?>" value="{{$vehiculo[0]->modelo}}">
                        {!! $errors->first('modeloVehiculo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <div class="form-group">
                        <label>Clase</label>
                        <input type="text" name="claseVehiculo" id="claseVehiculo" class="form-control {!! $errors->first('claseVehiculo','is-invalid')!!}"  placeholder="Turismo | Trabajo | Crucero" value="{{$vehiculo[0]->clase}}">
                        {!! $errors->first('claseVehiculo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label>Tipo</label>
                        <input type="text" name="tipoVehiculo" id="tipoVehiculo" class="form-control {!! $errors->first('tipoVehiculo','is-invalid')!!}"  placeholder="Moto nueva" value="{{$vehiculo[0]->tipo}}">
                        {!! $errors->first('tipoVehiculo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label>Capacidad</label>
                        <input type="text" name="capacidad" id="capacidad" class="form-control {!! $errors->first('capacidad','is-invalid')!!}"  placeholder="110CC/125CC" value="{{$vehiculo[0]->capacidad}}">
                        {!! $errors->first('capacidad','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label>Numero de motor</label>
                        <input type="text" name="numMotor" id="numMotor" class="form-control {!! $errors->first('numMotor','is-invalid')!!}"  placeholder="EJ1234567890 (11-17 Digitos)" value="{{$vehiculo[0]->nummotor}}">
                        {!! $errors->first('numMotor','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                </div>
            </div>
            <div class="row" style="justify-content: end;">
                <div class="col-3"> <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">Actualizar</button> </div>
            </div>
            <hr style="background-color: #0AA09E; height: 1px;">
        </div>
    </form>
    <div class="row" style="justify-content: end; padding-right: 10px; padding-bottom: 30px;">
        <div class="col-3"> <button class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#modalnuevoservicio" id="btnNuevoServicio">Nuevo servicio</button> </div>
    </div>
    <table id="tblServicios" class="table table-bordered">
        <tr>
            <th  style =" text-align:center;" scope="col">SERVICIO</th>
            <th  style =" text-align:center;" scope="col">KILOMETRAJE</th>
            <th  style =" text-align:center;" scope="col">SIGUIENTE KILOMETRAJE</th>
            <th  style =" text-align:center;" scope="col">SERVICIO</th>
            <th  style =" text-align:center;" scope="col">SIGUIENTE SERVICIO</th>
            <th  style =" text-align:center;" scope="col">FACTURA</th>
            <th  style =" text-align:center;" scope="col">DESCRIPCIÓN</th>
        </tr>
        <tbody>
        @if(count($servicios) > 0)
            @foreach($servicios as $servicio)
                <tr style="align-items: center">
                    <th style="font-size: 12px; text-align: center; vertical-align: middle">{{$i = $i - 1}}</th>
                    <td style="font-size: 12px; text-align: center; vertical-align: middle">{{$servicio->kilometraje}}</td>
                    <td style="font-size: 12px; text-align: center; vertical-align: middle">{{$servicio->siguientekilometraje}}</td>
                    <td style="font-size: 12px; text-align: center; vertical-align: middle">{{$servicio->ultimoservicio}}</td>
                    <td style="font-size: 12px; text-align: center; vertical-align: middle">{{$servicio->siguienteservicio}}</td>
                    <td style="text-align: center;">
                        <div class="col">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('{{asset($servicio->factura)}}', 'Factura - {{$servicio->id_moto}} - {{$servicio->ultimoservicio}}', '1')">Ver</a>
                            <a type="button" class="btn btn-outline-success btn-block" href="{{route('descargarfacturaservicio',[$vehiculo[0]->numserie])}}" >Descargar</a>
                        </div>
                    </td>
                    <td style="font-size: 10px; text-align: center; vertical-align: middle">{{$servicio->descripcion}}</td>
                </tr>
            @endforeach
        @endif
        @if(count($servicios) == 0)
            <tr>
                <td align='center' colspan="7" style="font-size: 12px;">Sin registros</td>
            </tr>
        @endif
        </tbody>
    </table>

    <!--Ventana modal para vista previa -->
    <div class="modal fade" id="vistaprevia" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div id="aparienciaModal" class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" id="encabezadoVistaPrevia"> </div>
                <div class="modal-body">
                    <div id="vistacontenido"> </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ventana modal para nuevo servicio-->
    <div class="modal fade" id="modalnuevoservicio"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #0AA09E;">
                    <h5> Alta de nuevo servicio </h5>
                </div>
                <div class="modal-body">
                    <form id="frmNuevoServicio" action="{{route('registrarnuevoservicio',[$idFranquicia,$vehiculo[0]->numserie])}}" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                        @csrf
                        <div class="row">
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Kilometraje</label>
                                    <input type="number" name="kilometraje" id="kilometraje" class="form-control {!! $errors->first('kilometraje','is-invalid')!!}"  placeholder="100"  min="0">
                                    {!! $errors->first('kilometraje','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Siguiente Kilometraje</label>
                                    <input type="number" name="sigKilometraje" id="sigKilometraje" class="form-control {!! $errors->first('sigKilometraje','is-invalid')!!}"  placeholder="100" min="0">
                                    {!! $errors->first('sigKilometraje','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Ultimo Servicio</label>
                                    <input type="date" name="ultimoServicio" id="ultimoServicio"
                                           class="form-control {!! $errors->first('ultimoServicio','is-invalid')!!}" value="{{$ultimoServicio[0]->ultimoservicio}}">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Siguiente Servicio</label>
                                    <input type="date" name="sigServicio" id="sigServicio"
                                           class="form-control {!! $errors->first('sigServicio','is-invalid')!!}">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Factura (PDF)</label>
                                    <input type="file" name="factura" id="factura" class="form-control-file {!! $errors->first('factura','is-invalid')!!}" accept="application/pdf">
                                    {!! $errors->first('factura','<div class="invalid-feedback">La factura debera estar en formato pdf.</div>')!!}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <textarea  rows="5" name="descripcion" id="descripcion" class="form-control {!! $errors->first('descripcion','is-invalid')!!}"  placeholder="Descripcion"> </textarea>
                                {!! $errors->first('descripcion','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <div class="col">
                        <div class="row" style="justify-content: start">
                            <label><b> Numero de serie: </b> {{$vehiculo[0]->numserie}}</label>
                        </div>
                        <div class="row" style="padding-left: 10px;">
                            <div class="col-2">
                                <label><b> Marca: </b> {{$vehiculo[0]->marca}} </label>
                            </div>
                            <div class="col-4">
                                <label><b> Numero de cilindros: </b> {{$vehiculo[0]->cilindros}} </label>
                            </div>
                            <div class="col-3">
                                <label><b> Linea: </b> {{$vehiculo[0]->linea}}</label>
                            </div>
                            <div class="col-3">
                                <label><b> Modelo: </b> {{$vehiculo[0]->modelo}}</label>
                            </div>
                        </div>
                        <div class="row" style="padding-left: 10px; padding-top: 20px;">
                            <div style="padding-left: 15px;">
                                <label><b> Clase: </b> {{$vehiculo[0]->clase}} </label>
                                <label style="padding-left: 30px;"><b> Tipo: </b> {{$vehiculo[0]->tipo}} </label>
                                <label style="padding-left: 30px;"><b> Capacidad: </b> {{$vehiculo[0]->capacidad}} </label>
                                <label style="padding-left: 30px;"><b> Numero de motor: </b> {{$vehiculo[0]->nummotor}}</label>
                            </div>
                        </div>
                        <div class="row" style="justify-content: end; padding-top: 30px;">
                            <button class="btn btn-primary" type="button"
                                    data-dismiss="modal" style="margin-right: 20px;"> Cancelar </button>
                            <button class="btn btn-success" name="btnSubmit" type="submit"
                                    form="frmNuevoServicio"> Aceptar </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
