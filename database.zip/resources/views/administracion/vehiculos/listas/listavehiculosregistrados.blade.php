<table id="tablaVehiculos" class="table table-bordered">
    <tr>
        <th  style =" text-align:center;" scope="col">MOTO</th>
        <th  style =" text-align:center;" scope="col">CIUDAD</th>
        <th  style =" text-align:center;" scope="col">SERIE</th>
        <th  style =" text-align:center;" scope="col">MARCA</th>
        <th  style =" text-align:center;" scope="col">MODELO</th>
        <th  style =" text-align:center;" scope="col">ULTIMO SERVICIO</th>
        <th  style =" text-align:center;" scope="col">SIGUIENTE SERVICIO</th>
        <th  style =" text-align:center;" scope="col">VER</th>
    </tr>
    <tbody>
    @if(count($listavehiculos) > 0)

        @foreach($listavehiculos as $vehiculo)
            <tr>
                <th style="font-size: 11px; text-align: center; vertical-align: middle">{{$i = $i - 1}}</th>
                <td style="font-size: 11px; text-align: center; vertical-align: middle">{{$vehiculo->ciudadfranquicia}}</td>
                <td style="font-size: 11px; text-align: center; vertical-align: middle">{{$vehiculo->numserie}}</td>
                <td style="font-size: 11px; text-align: center; vertical-align: middle">{{$vehiculo->marca}}</td>
                <td style="font-size: 11px; text-align: center; vertical-align: middle">{{$vehiculo->modelo}}</td>
                <td style="font-size: 11px; text-align: center; vertical-align: middle">{{$vehiculo->ultimoservicio}}</td>
                <td style="font-size: 11px; text-align: center; vertical-align: middle">{{$vehiculo->siguienteservicio}}</td>
                <td style="font-size: 11px; text-align: center; vertical-align: middle"><a href="{{route('vervehiculo',[$vehiculo->id_franquicia, $vehiculo->numserie])}}" ><button type="button" class="btn btn-outline-success"><i class="fa-solid fa-motorcycle"></i></button></a> </td>
            </tr>
        @endforeach
    @endif
    @if(count($listavehiculos) == 0)
        <tr>
            <td align='center' colspan="7" style="font-size: 10px;">Sin registros</td>
        </tr>
    @endif
    </tbody>
</table>
