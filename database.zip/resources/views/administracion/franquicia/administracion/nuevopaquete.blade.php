@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')     
    @include('parciales.notificaciones')
    <div class="row">
      <div class="col-3">
        <div class="form-group">
            <label>Estado</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$franquiciaAdmin[0]->estado}}">
        </div>
      </div>
      <div class="col-3">
        <div class="form-group">
            <label>Ciudad</label>
            <input type="text" name="ciudad" class="form-control"  readonly value="{{$franquiciaAdmin[0]->ciudad}}">
        </div>
      </div>
      <div class="col-3">
        <div class="form-group">
            <label>Colonia</label>
            <input type="text" name="colonia" class="form-control"  readonly value="{{$franquiciaAdmin[0]->colonia}}">
        </div>
      </div>
      <div class="col-3">
        <div class="form-group">
            <label>Numero Interior/Exterior</label>
            <input type="text" name="numero" class="form-control"  readonly value="{{$franquiciaAdmin[0]->numero}}">
        </div>
      </div>
    </div> 
    <h2>@lang('mensajes.mensajenuevopaquete')</h2>  
    <form id="frmFranquiciaNueva" action="{{route('paquetecrear',$idFranquicia)}}" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
      @csrf    
      <div class="row">
        <div class="col-6">
          <div class="form-group">
            <label>Paquete</label>
            <input type="text" name="paquete" class="form-control {!! $errors->first('paquete','is-invalid')!!}"  placeholder="Nombre del paquete" value="{{ old('paquete') }}">
            {!! $errors->first('paquete','<div class="invalid-feedback">El nombre del paquete es obligatorio.</div>')!!}
          </div>
        </div>        
        <div class="col-6">
          <div class="form-group">
            <label>Precio</label>
            <input type="number" name="precio" class="form-control {!! $errors->first('precio','is-invalid')!!}" min="0" placeholder="Precio del paquete" value="{{ old('precio') }}">
            {!! $errors->first('precio','<div class="invalid-feedback">El precio es obligatorio y/o un numero positivo.</div>')!!}
          </div>
        </div>      
      </div>
      <div class="row">
        <div class="col-4">
            <a href="{{route('listasfranquicia',$idFranquicia)}}" class="btn btn-outline-success btn-block">@lang('mensajes.regresar')</a>
        </div>
        <div class="col">
          <button class="btn btn-outline-success btn-block"  name="btnSubmit" type="submit">@lang('mensajes.mensajecrearpaquete')</button>
        </div>
      </div>
    </form>
    
@endsection