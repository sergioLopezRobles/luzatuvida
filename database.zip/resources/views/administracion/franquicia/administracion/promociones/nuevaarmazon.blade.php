@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')     
    @include('parciales.notificaciones')
    <div class="row">
      <div class="col-3">
        <div class="form-group">
            <label>Estado</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$franquiciaAdmin[0]->estado}}">
        </div>
      </div>
      <div class="col-3">
        <div class="form-group">
            <label>Ciudad</label>
            <input type="text" name="ciudad" class="form-control"  readonly value="{{$franquiciaAdmin[0]->ciudad}}">
        </div>
      </div>
      <div class="col-3">
        <div class="form-group">
            <label>Colonia</label>
            <input type="text" name="colonia" class="form-control"  readonly value="{{$franquiciaAdmin[0]->colonia}}">
        </div>
      </div>
      <div class="col-3">
        <div class="form-group">
            <label>Numero Interior/Exterior</label>
            <input type="text" name="numero" class="form-control"  readonly value="{{$franquiciaAdmin[0]->numero}}">
        </div>
      </div>
    </div> 
    <h2>@lang('mensajes.mensajenuevapromocion')</h2>    
     <form  action="{{route('promocioncrear',$idFranquicia)}}" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;"> 
     @csrf
    <div class="row">
      <div class="col-12">
          <div class="form-group">
              <label>Titulo de la promoción</label>
              <input type="text" name="titulo" class="form-control {!! $errors->first('titulo','is-invalid')!!}" placeholder="Titulo de la promoción" value="{{ old('titulo') }}">
                {!! $errors->first('titulo','<div class="invalid-feedback">Campo obligatorio</div>')!!}
          </div>
      </div>
    </div>
    <div class="row">
    <div class="col-3">
            <div class="form-group">
                <label># Contratos: </label>
                <input type="number" name="armazones" class="form-control {!! $errors->first('armazones','is-invalid')!!}" min="1" placeholder="armazones" value="{{ old('armazones',1) }}">
                {!! $errors->first('armazones','<div class="invalid-feedback">Campo obligatorio no puede ser menor a 1</div>')!!}
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Descuento en % </label>
                <input type="number" name="cantidad" class="form-control {!! $errors->first('cantidad','is-invalid')!!}" min="1" max="100" placeholder="Cantidad" value="{{ old('cantidad') }}">
              @if($errors->has('cantidad'))
              <div class="invalid-feedback">{{$errors->first('cantidad')}}</div>
              @endif
              </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Descuento con precio $</label>
                <input type="number" name="preciouno" class="form-control {!! $errors->first('preciouno','is-invalid')!!}" min="1" placeholder="precio unico" value="{{ old('preciouno') }}">
                @if($errors->has('preciouno'))
              <div class="invalid-feedback">{{$errors->first('preciouno')}}</div>
              @endif
            </div>
        </div>
        <div class="col-2">
          <label>Promoción por precio</label>
          <div class="form-check">              
              <input type="checkbox" name="tipopromocion" id="tipopromocion" class="form-check-input" value="1"  style="transform: scale(1.5);">
              <label class="form-check-label" for="tipopromocion">por precio $</label>
          </div>
        </div>
</div>
    <hr>
    <div class="row">
      <div class="col-4">
          <div class="form-group">
              <label>Fecha de inicio de la promocion</label>
              <input type="date" name="inicio" class="form-control {!! $errors->first('inicio','is-invalid')!!}"  placeholder="Fecha de inicio" value="{{ old('inicio') }}">
              {!! $errors->first('inicio','<div class="invalid-feedback">La fecha inicial debe ser menor a la final</div>')!!}
          </div>
      </div>  
      <div class="col-4">
          <div class="form-group">
              <label>Fecha para finalizar la promocion</label>
              <input type="date" name="fin" class="form-control {!! $errors->first('fin','is-invalid')!!}"  placeholder="Fecha para finalizar" value="{{ old('fin') }}">
              {!! $errors->first('fin','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
          </div>
      </div> 
      <div class="col-3">
          <label>Tipo: </label>
          <div class="form-check">              
              <input type="checkbox" name="administrador" class="form-check-input" value="1" style="transform: scale(1.5);">
              <label class="form-check-label" for="administrador">Administrador</label>
          </div>
        </div> 
    </div>
    <div class="row">
        <div class="col-4">
            <a href="{{route('listasfranquicia',$idFranquicia)}}" class="btn btn-outline-success btn-block">@lang('mensajes.regresar')</a>
        </div>
        <div class="col">
          <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">@lang('mensajes.mensajecrearpromocion')</button>
        </div>
      </div>
    </div>
     </form>
@endsection