@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Estado</label>
                <input type="text" name="estado" class="form-control" readonly value="{{$franquiciaAdmin[0]->estado}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ciudad</label>
                <input type="text" name="ciudad" class="form-control" readonly value="{{$franquiciaAdmin[0]->ciudad}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="colonia" class="form-control" readonly
                       value="{{$franquiciaAdmin[0]->colonia}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Numero Interior/Exterior</label>
                <input type="text" name="numero" class="form-control" readonly value="{{$franquiciaAdmin[0]->numero}}">
            </div>
        </div>
    </div>
    <h2>@lang('mensajes.mensajeproductos')</h2>
    <form action="{{route('filtrarproducto',$idFranquicia)}}" enctype="multipart/form-data" method="POST"
          onsubmit="btnSubmit.disabled = true;">
        @csrf
        <div class="row">
            <div class="col-4">
                <input name="filtro" type="text" class="form-control" placeholder="Buscar producto..">
            </div>
            <div class="col-6">
                <button type="submit" name="btnSubmit" class="btn btn-outline-success">Filtrar</button>
            </div>
            <div class="col-2">
                <a type="button" class="btn btn-outline-success btn-block"
                   href="{{route('productonuevo',$idFranquicia)}}">Nuevo Producto</a>
            </div>
        </div>
    </form>
    <table id="tablaContratos" class="table table-bordered">
        @if(sizeof($productosGeneral)>0)
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">ESTADO</th>
                <th style=" text-align:center;" scope="col">PRODUCTO</th>
                <th style=" text-align:center;" scope="col">TIPO</th>
                <th style=" text-align:center;" scope="col">FOTO</th>
                <th style=" text-align:center;" scope="col">PIEZAS</th>
                <th style=" text-align:center;" scope="col">COLOR</th>
                <th style=" text-align:center;" scope="col">PRECIO</th>
                <th style=" text-align:center;" scope="col">EDITAR</th>
                <th style=" text-align:center;" scope="col">PROMOCION</th>
            </tr>
            </thead>
        @endif
        <tbody>
        <tr>
            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="9">ALMACEN SUCURSAL</th>
        </tr>
        @foreach($productosSucursal as $producto)
            <tr>
                @if($producto->estado  == 1)
                    <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                @else
                    <td align='center'><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                @endif
                <td align='center'>{{$producto->nombre}}</td>
                <td align='center'>{{$producto->tipo}}</td>
                @if(isset($producto->foto))
                    <td align='center'><img src="{{asset($producto->foto)}}" class="img-thumbnail"
                                            style="width:100px;height:65px;"></td>
                @else
                    <td align='center'>NA</td>
                @endif
                <td align='center'>{{$producto->piezas}}</td>
                <td align='center'>{{$producto->color}}</td>
                @if($producto->id_tipoproducto == 1)
                    <td align='center'>NA</td>
                @else
                    @if($producto->activo == 1)
                        <td align='center'>Normal:${{$producto->precio}}<br>Promocion:${{$producto->preciop}}</br></td>
                    @else
                        <td align='center'>${{$producto->precio}}</td>
                    @endif
                @endif
                <td align='center'><a href="{{route('productoactualizar',[$idFranquicia,$producto->id])}}">
                        <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                    </a></td>
                @if($producto->activo  == 1)
                    <td align='center'><a href="{{route('productodesactivarpromo',[$idFranquicia,$producto->id])}}"
                                          class="btn btn-danger">DESACTIVAR</a></td>
                @else
                    @if($producto->id_tipoproducto > 1)
                        <td align='center'><a class="btn btn-primary">DESACTIVADA</a></td>
                    @ELSE
                        <td align='center'><a class="btn btn-dark">NA</a></td>
                    @endif
                @endif
            </tr>
        @endforeach
        <tr>
            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF;" colspan="9">ALMACEN GENERAL</th>
        </tr>
        @foreach($productosGeneral as $producto)
            <tr>
                @if($producto->estado  == 1)
                    <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                @else
                    <td align='center'><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                @endif
                <td align='center'>{{$producto->nombre}}</td>
                <td align='center'>{{$producto->tipo}}</td>
                @if(isset($producto->foto))
                    <td align='center'><img src="{{asset($producto->foto)}}" class="img-thumbnail"
                                            style="width:100px;height:65px;"></td>
                @else
                    <td align='center'>NA</td>
                @endif
                <td align='center'>{{$producto->piezas}}</td>
                <td align='center'>{{$producto->color}}</td>
                @if($producto->id_tipoproducto == 1)
                    <td align='center'>NA</td>
                @else
                    @if($producto->activo == 1)
                        <td align='center'>Normal:${{$producto->precio}}<br>Promocion:${{$producto->preciop}}</br></td>
                    @else
                        <td align='center'>${{$producto->precio}}</td>
                    @endif
                @endif
                @if(Auth::user()->rol_id == 7)
                    <td align='center'><a href="{{route('productoactualizar',[$idFranquicia,$producto->id])}}">
                            <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                        </a></td>
                @else
                    <td align='center'><a class="btn btn-dark">NA</a></td>
                @endif
                <td align='center'><a class="btn btn-dark">NA</a></td>
            </tr>
        @endforeach
        </tbody>
    </table>
    @if($productosGeneral!=null)
        <div class="d-flex justify-content-center">
            {{$productosGeneral->links('pagination::bootstrap-4')}}
        </div>
    @endif
    <hr>
    <div class="row">
        <h2>@lang('mensajes.mensajetratamientos')</h2>
    <!-- <div class="col-2">
           <a type="button" class="btn btn-outline-primary btn-block" href="{{route('tratamientonuevo',$idFranquicia)}}">Nuevo Tratamiento</a>
        </div> -->
    </div>
    <table id="tablaTratamientos" class="table table-bordered">
        @if(sizeof($tratamientos)>0)
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">TRATAMIENTO</th>
                <th style=" text-align:center;" scope="col">PRECIO</th>
                <th style=" text-align:center;" scope="col">EDITAR</th>
            </tr>
            </thead>
        @endif
        <tbody>
        @foreach($tratamientos as $tratamiento)
            <tr>
                <td align='center'>{{$tratamiento->nombre}}</td>
                <td align='center'>${{$tratamiento->precio}}</td>
                <td align='center'><a href="{{route('tratamientoactualizar',[$idFranquicia,$tratamiento->id])}}">
                        <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                    </a></td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <hr>
    <div class="row">
        <div class="col-10"><h2>@lang('mensajes.mensajepaquetes')</h2></div>
    </div>
    <table id="tablaTratamientos" class="table table-bordered">
        @if(sizeof($paquetes)>0)
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">PAQUETE</th>
                <th style=" text-align:center;" scope="col">PRECIO</th>
                <th style=" text-align:center;" scope="col">EDITAR</th>
            </tr>
            </thead>
        @endif
        <tbody>
        @foreach($paquetes as $paquete)
            <tr>
                <td align='center'>{{$paquete->nombre}}</td>
                <td align='center'>${{$paquete->precio}}</td>
                <td align='center'><a href="{{route('paqueteactualizar',[$idFranquicia,$paquete->id])}}">
                        <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                    </a></td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <hr>
    <div class="row">
        <div class="col-10"><h2>@lang('mensajes.mensajepromociones')</h2></div>
        <div class="col-2">
            <a type="button" class="btn btn-outline-success btn-block"
               href="{{route('nuevaproarmazones',$idFranquicia)}}">Nueva Promoción</a>
        </div>
    </div>
    <table id="tablaPromociones" class="table table-bordered">
        @if(sizeof($promociones)>0)
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">ESTADO</th>
                <th style=" text-align:center;" scope="col">TITULO</th>
                <th style=" text-align:center;" scope="col">PRECIO</th>
                <th style=" text-align:center;" scope="col">INICIO</th>
                <th style=" text-align:center;" scope="col">FIN</th>
                <th style=" text-align:center;" scope="col">EDITAR</th>
                <th style=" text-align:center;" scope="col">ACTIVAR/DESACTIVAR</th>
                <!-- <th  style =" text-align:center;" scope="col">EDITAR</th>                                 -->
            </tr>
            </thead>
        @endif
        <tbody>
        @foreach($promociones as $promocion)
            <tr>
                @if($promocion->status  == 1)
                    <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                @else
                    <td align='center'><i class='fas fa-times' style="color:#ffaca6;font-size:25px;"></i></td>
                @endif
                <td align='center'>{{$promocion->titulo}}</td>
                @if($promocion->tipopromocion  == 1)
                    <td align='center'>$ {{$promocion->preciouno}}</td>
                @else
                    <td align='center'>% {{$promocion->precioP}}</td>
                @endif
                <td align='center'>{{$promocion->inicio}}</td>
                <td align='center'>{{$promocion->fin}}</td>
                <td align='center'><a href="{{route('promocionactualizar',[$idFranquicia,$promocion->id])}}">
                        <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                    </a></td>
                @if($promocion->status  == 1 )
                    <td align='center'><a href="{{route('estadoPromocionEditar',[$idFranquicia,$promocion->id])}}"
                                          class="btn btn-danger">DESACTIVAR</a></td>
                @else
                    <td align='center'><a href="{{route('promocionactualizar',[$idFranquicia,$promocion->id])}}"
                                          class="btn btn-primary">ACTIVAR</a></td>
                @endif
            </tr>
        @endforeach
        </tbody>
    </table>
    <hr>
    <div class="row">
        <div class="col-10">
            <h2>@lang('mensajes.mensajeMensajes')</h2>
        </div>
        <div class="col-2">
            <a type="button" class="btn btn-outline-success btn-block" href="{{route('mensajenuevo',$idFranquicia)}}">Nuevo
                Mensaje</a>
        </div>
    </div>
    <table id="tablaContratos" class="table table-bordered">
        <thead>
        <tr>
            <th style=" text-align:center;" scope="col">DESCRIPCION</th>
            <th style=" text-align:center;" scope="col">FECHA PARA DESACTIVAR</th>
            <th style=" text-align:center;" scope="col">INTENTOS</th>
            <th style=" text-align:center;" scope="col">FECHA CREACION</th>
            <th style=" text-align:center;" scope="col">ELIMINAR</th>
        </tr>
        </thead>
        <tbody>
        @foreach($mensajes as $mensaje)
            <tr>
                <td align='center'>{{$mensaje->descripcion}}</td>
                <td align='center'>{{$mensaje->fechalimite}}</td>
                <td align='center'>{{$mensaje->intentos}}</td>
                <td align='center'>{{$mensaje->created_at}}</td>
                <td align='center'><a href="{{route('eliminarmensaje',[$idFranquicia,$mensaje->id])}}"
                                      class="btn btn-danger">ELIMINAR</a></td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <hr>

    <div class="modal fade" id="AbrirPro" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <form action="" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ExampleAbrir">Promoción</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">¿Seguro desea desactivar la promoción?</div>
                    <div class="modal-footer">
                        <button class="btn btn-default" type="button" data-dismiss="modal">Cancelar</button>
                        <a class="btn btn btn-outline-danger btn-ok" name="btnSubmit" type="submit">Aceptar</a>
                    </div>
                </div>
            </div>
    </div>
@endsection
