@extends('layouts.app')
@section('titulo','Lista Franquicias'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <h2 style="text-align: left; color: #0AA09E">Informacion de {{$usuario[0]->name}} </h2>
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="editar-tab" data-toggle="tab" href="#editar" role="tab" aria-controls="editar"
               aria-selected="true">Editar</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="controlentradasalida-tab" data-toggle="tab" href="#controlentradasalida" role="tab" aria-controls="controlentradasalida"
               aria-selected="false">Control Entrada - Salida</a>
        </li>
        @if($usuario[0]->rol_id == 12 || $usuario[0]->rol_id == 13 ||  $usuario[0]->rol_id == 4)
            <li class="nav-item">
                <a class="nav-link" id="dispositivos-tab" data-toggle="tab" href="#dispositivos" role="tab"
                   aria-controls="dispositivos" aria-selected="false">Dispositivos</a>
            </li>
        @endif
    </ul>

    <div class="tab-content" style="margin-top:30px;">
        <div class="tab-pane active" id="editar" role="tabpanel" aria-labelledby="editar-tab">
            <form  action="{{route('actualizarUsuarioFranquicia',[$id,$idusuario])}}" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                @csrf
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Nombre</label>
                            <input type="text" name="nombre" class="form-control {!! $errors->first('nombre','is-invalid')!!}"  placeholder="Nombre"  value="{{$usuario[0]->name}}">
                            {!! $errors->first('nombre','<div class="invalid-feedback">Nombre no valido</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Numero de control</label>
                            <input type="text" class="form-control" readonly  value="{{$usuario[0]->codigoasistencia}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Correo</label>
                            <input type="text" name="correo" class="form-control {!! $errors->first('correo','is-invalid')!!}"  placeholder="Correo"  value="{{$usuario[0]->email}}">
                            {!! $errors->first('correo','<div class="invalid-feedback">El correo no es valido</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Contraseña</label>
                            <input type="password" name="contrasena" class="form-control {!! $errors->first('contrasena','is-invalid')!!}"  placeholder="Contraseña" id="contrasena">
                            {!! $errors->first('contrasena','<div class="invalid-feedback">La contraseña debe contener: Una letra mayuscula,una minuscula,un numero y al menos 8 caracteres.</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Confirmar contraseña</label>
                            <input type="password" name="ccontrasena" class="form-control {!! $errors->first('ccontrasena','is-invalid')!!}" id="contrasena2" placeholder="Confirmar contraseña" >
                            {!! $errors->first('ccontrasena','<div class="invalid-feedback">La contraseña no coincide</div>')!!}

                        </div>
                    </div>
                    <div class="col-2">
                            <a class="btn btn-outline-success btn-block" onclick="generarPassword()">Generar contraseña</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <label>Seleccionar el Rol</label>
                        <select name="rol" class="form-control form-control-sm {!! $errors->first('rol','is-invalid')!!}" required>
                            <option></option>
                            @foreach($roles as $rol)
                                @if($rol->id == $usuario[0]->rol_id)
                                    <option selected value="{{$rol->id}}">{{$rol->rol}}</option>
                                @else
                                    <option value="{{$rol->id}}">{{$rol->rol}}</option>
                                @endif

                            @endforeach
                        </select>
                        {!! $errors->first('rol','<div class="invalid-feedback">Selecciona un rol</div>')!!}
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Seleccionar la zona</label>
                            <select name="idzona" class="form-control  @error('idzona') is-invalid @enderror" >
                                <option value=""></option>
                                @foreach($zonas as $zona)
                                    @if($zona->id == $usuario[0]->id_zona)
                                        <option selected value="{{$zona->id}}">{{$zona->zona}}</option>
                                    @else
                                        <option value="{{$zona->id}}">{{$zona->zona}}</option>
                                    @endif
                                @endforeach
                            </select>
                            {!! $errors->first('idzona','<div class="invalid-feedback">Para el rol de cobranza es necesario seleccionar la zona.</div>')!!}
                        </div>
                    </div>
                    @if($usuario[0]->rol_id == 12 ||$usuario[0]->rol_id  == 4  || $usuario[0]->rol_id == 12 ||  $usuario[0]->rol_id  == 13 ||  $usuario[0]->rol_id  == 14)
                        <div class="col-2">
                            <div class="form-group">
                                <label>Sueldo</label>
                                <input type="number" name="sueldo" class="form-control {!! $errors->first('sueldo','is-invalid')!!}" min="0" placeholder="Sueldo"  value="{{$usuario[0]->sueldo}}">
                                {!! $errors->first('sueldo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                            </div>
                        </div>
                    @endif
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tarjeta</label>
                            <input type="text" name="tarjeta" class="form-control {!! $errors->first('tarjeta','is-invalid')!!}" min="16" maxlength="20" placeholder="Tarjeta" value="{{$usuario[0]->tarjeta}}">
                            {!! $errors->first('tarjeta','<div class="invalid-feedback">Campo obligatorio / Al menos 16 caracteres.</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Otra tarjeta</label>
                            <input type="text" name="otratarjeta" class="form-control {!! $errors->first('otratarjeta','is-invalid')!!}" min="16" maxlength="20" placeholder="Tarjeta" value="{{$usuario[0]->otratarjeta}}">
                            {!! $errors->first('otratarjeta','<div class="invalid-feedback">Campo obligatorio / Al menos 16 caracteres.</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1"  onclick="mostrarPassword()">
                            <label class="form-check-label" for="exampleCheck1">Mostrar contraseña</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Recordatorio</label>
                            <input type="date" name="fecharenovacion"
                                   class="form-control {!! $errors->first('fecharenovacion','is-invalid')!!}"
                                   placeholder="Fecha de renovación" value="@if($usuario[0]->renovacion != null){{ \Carbon\Carbon::parse($usuario[0]->renovacion)->format('Y-m-d')}}@endif">
                            @if($errors->has('fecharenovacion'))
                                <div class="invalid-feedback">{{$errors->first('fecharenovacion')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="sinrenovacion">
                            <label class="form-check-label" for="exampleCheck1">Sin renovacion</label>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-1">
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <img src="{{asset($usuario[0]->foto)}}"   width="210" height="280" style="border-radius: 10%">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1">
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto del usuario ( FOTO JPG)</label>
                            <input type="file" name="foto" class="form-control-file {!! $errors->first('foto','is-invalid')!!} @if($usuario[0]->foto != '') is-valid @endif"  accept="image/jpg" >
                            {!! $errors->first('foto','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Acta de nacimiento (PDF)</label>
                            <input type="file" name="actanacimiento" class="form-control-file {!! $errors->first('actanacimiento','is-invalid')!!}  @if($usuario[0]->actanacimiento != '') is-valid @endif"  accept="application/pdf" >
                            {!! $errors->first('actanacimiento','<div class="invalid-feedback">El acta de nacimiento debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Identificacion Oficial (PDF)</label>
                            <input type="file" name="identificacion" class="form-control-file  {!! $errors->first('identificacion','is-invalid')!!} @if($usuario[0]->identificacion != '') is-valid @endif" accept="application/pdf" >
                            {!! $errors->first('identificacion','<div class="invalid-feedback">La identificacion debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>CURP (FOTO JPG)</label>
                            <input type="file" name="curp" class="form-control-file {!! $errors->first('curp','is-invalid')!!} @if($usuario[0]->curp != '') is-valid @endif"  accept="image/jpg" >
                            {!! $errors->first('curp','<div class="invalid-feedback">El CURP debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Comprobante de domicilio (PDF)</label>
                            <input type="file" name="comprobante" class="form-control-file  {!! $errors->first('comprobante','is-invalid')!!} @if($usuario[0]->comprobantedomicilio != '') is-valid @endif"  accept="application/pdf" >
                            {!! $errors->first('comprobante','<div class="invalid-feedback">El comprobante debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-1"></div>
                </div>
                <div class="row">
                    <div class="col-1">
                    </div>
                    @if($usuario[0]->foto)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,0])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button"  class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('{{asset($usuario[0]->foto)}}', 'Foto - {{$usuario[0]->name}}', '0')">Ver </a>
                        </div>
                    @endif
                    @if($usuario[0]->actanacimiento != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,1])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->actanacimiento)}}', 'Acta de nacimiento - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->identificacion != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,2])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->identificacion)}}', 'Identificacion oficial - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->curp != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,3])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->curp)}}', 'CURP - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '0')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->comprobantedomicilio != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,4])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->comprobantedomicilio)}}', 'Comprobante de domicilio - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Seguro social (PDF)</label>
                            <input type="file" name="seguro" class="form-control-file {!! $errors->first('seguro','is-invalid')!!} @if($usuario[0]->segurosocial != '') is-valid @endif"  accept="application/pdf" >
                            {!! $errors->first('seguro','<div class="invalid-feedback">El seguro social debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Solicitud / Curriculum (PDF)</label>
                            <input type="file" name="solicitud" class="form-control-file {!! $errors->first('solicitud','is-invalid')!!} @if($usuario[0]->solicitud != '') is-valid @endif" accept="application/pdf" >
                            {!! $errors->first('solicitud','<div class="invalid-feedback">La solicitud debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tarjeta para pago (FOTO JPG)</label>
                            <input type="file" name="tarjetapago" class="form-control-file {!! $errors->first('tarjetapago','is-invalid')!!} @if($usuario[0]->tarjetapago != '') is-valid @endif"   accept="image/jpg" >
                            {!! $errors->first('tarjetapago','<div class="invalid-feedback">El numero de la tarjeta debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Otra tarjeta (FOTO JPG)</label>
                            <input type="file" name="otratarjetapago" class="form-control-file {!! $errors->first('otratarjetapago','is-invalid')!!} @if($usuario[0]->otratarjetapago != '') is-valid @endif"   accept="image/jpg" >
                            {!! $errors->first('otratarjetapago','<div class="invalid-feedback">El numero de la tarjeta debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Contacto de Emergencia (PDF)</label>
                            <input type="file" name="contactoemergencia" class="form-control-file {!! $errors->first('contactoemergencia','is-invalid')!!} @if($usuario[0]->contactoemergencia != '') is-valid @endif" accept="application/pdf" >
                            {!! $errors->first('contactoemergencia','<div class="invalid-feedback">El contacto de emergencia debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    @if($usuario[0]->segurosocial != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,5])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->segurosocial)}}', 'Seguro Social - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->solicitud != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,6])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->solicitud)}}', 'Solicitud / CV- {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->tarjetapago != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,7])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->tarjetapago)}}', 'Tarjeta para pago - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '0')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->otratarjetapago != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,11])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->otratarjetapago)}}', 'Otra tarjeta para pago - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '0')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->contactoemergencia != null)
                        @if($usuario[0]->otratarjetapago == null)
                            <div class="col-2"></div>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block"
                                   href="{{route('descargarArchivo',[$usuario[0]->id,8])}}">Descargar</a>
                            </div>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                                   onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->contactoemergencia)}}', 'Contacto de emergencia - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                            </div>
                        @else
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block"
                                   href="{{route('descargarArchivo',[$usuario[0]->id,8])}}">Descargar</a>
                            </div>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                                   onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->contactoemergencia)}}', 'Contacto de emergencia - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                            </div>
                        @endif
                    @endif
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Contrato laboral (FOTO JPG)</label>
                            <input type="file" name="contratolaboral" class="form-control-file {!! $errors->first('contratolaboral','is-invalid')!!} @if($usuario[0]->contratolaboral != '') is-valid @endif" accept="image/jpg" >
                            {!! $errors->first('contratolaboral','<div class="invalid-feedback">El contrato laboral debera estar en imagen JPG.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Pagare (PDF)</label>
                            <input type="file" name="pagare" class="form-control-file {!! $errors->first('pagare','is-invalid')!!} @if($usuario[0]->pagare != '') is-valid @endif" accept="application/pdf" >
                            {!! $errors->first('pagare','<div class="invalid-feedback">El pagare debera estar en formato PDF.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    @if($usuario[0]->contratolaboral != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,9])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->contratolaboral)}}', 'Contrato laboral - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '0')">Ver</a>
                        </div>
                    @endif
                    @if($usuario[0]->pagare != null)
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="{{route('descargarArchivo',[$usuario[0]->id,10])}}" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPreviaUsuarios('{{asset($usuario[0]->pagare)}}', 'Pagare - {{$usuario[0]->name}}', {{$usuario[0]->id}}, '1')">Ver</a>
                        </div>
                    @endif
                </div>
                @if(Auth::user()->rol_id == 7)
                    <hr>
                    <h2>@lang('mensajes.mensajesucursales')</h2>
                    <h5>@lang('mensajes.mensajesucursalesconfirmaciones')</h5>
                    <div class="row">
                        @php
                            $i = 0;
                        @endphp
                        @foreach($sucursales as $sucursal)
                            @php
                                $existe = false;
                            @endphp
                            @foreach($sucursalesSeleccionadas as $sucursalSeleccionada)
                                @if($sucursalSeleccionada->id_franquicia ==  $sucursal->id)
                                    @php
                                        $existe = true;
                                    @endphp
                                @endif
                            @endforeach
                            <div class="col-2">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input " name="{{$sucursal->id}}" id="{{$sucursal->id}}" @if($existe) checked @endif value="1">
                                    <label class="custom-control-label" for="{{$sucursal->id}}">{{$sucursal->colonia}} {{$sucursal->numero}},{{$sucursal->ciudad}} {{$sucursal->estado}}</label>
                                </div>
                            </div>
                            @php
                                $i = $i +2;
                            @endphp
                            @if($i==12)
                    </div>
                    <div class="row">
                        @php
                            $i = 0;
                        @endphp
                        @endif
                        @endforeach
                    </div>
                @endif
                <div class="row">
                    <div class="col-4">
                        <a href="{{route('usuariosFranquicia',$id)}}" class="btn btn-outline-success btn-block">@lang('mensajes.regresar')</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-success btn-block"  type="submit">@lang('mensajes.mensajeactualizarusuario')</button>
                    </div>
                </div>
            </form>

        </div>
        <div class="tab-pane" id="controlentradasalida" role="tabpanel" aria-labelledby="controlentradasalida-tab">
            <form  action="{{route('actualizarControlEntradaSalidaUsuarioFranquicia',[$id,$idusuario])}}" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                @csrf
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Hora para que comience a contar como retardo</label>
                            <input type="time" name="horaini" class="form-control" value="{{$usuario[0]->horaini}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Hora para que comience a contar como falta</label>
                            <input type="time" name="horafin" class="form-control" value="{{$usuario[0]->horafin}}">
                        </div>
                    </div>
                    <div class="col-2" style="margin-top: 25px;">
                        <button class="btn btn-outline-success btn-block" type="submit">Actualizar</button>
                    </div>
                </div>
            </form>
        </div>
        @if($usuario[0]->rol_id == 12 || $usuario[0]->rol_id == 13 || $usuario[0]->rol_id == 4)
            <div class="tab-pane" id="dispositivos" role="tabpanel" aria-labelledby="dispositivos-tab">
                <table id="tablaFranquicias" class="table table-bordered">
                    <thead>
                    <tr>
                        <th  style =" text-align:center;" scope="col">ESTATUS</th>
                        <th  style =" text-align:center;" scope="col">MODELO</th>
                        <th  style =" text-align:center;" scope="col">VERSION</th>
                        <th  style =" text-align:center;" scope="col">REGISTRO</th>
                        <th  style =" text-align:center;" scope="col">ACTIVAR/DESACTIVAR</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($dispositivosusuario as $dispositivo)
                        <tr>
                            @if($dispositivo->estatus  == 1)
                                <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                            @else
                                <td align='center' ><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                            @endif
                            <td align='center'>{{$dispositivo->modelo}}</td>
                            <td align='center'>{{$dispositivo->versionandroid}}</td>
                            <td align='center'>{{$dispositivo->created_at}}</td>
                            @if($dispositivo->estatus  == 1 )
                                <td align='center'> <a href="{{route('actualizarUsuarioFranquiciadispositivo',[$id,$idusuario,$dispositivo->id])}}" class="btn btn-danger">DESACTIVAR</a></td>
                            @else
                                <td align='center'> <a href="{{route('actualizarUsuarioFranquiciadispositivo',[$id,$idusuario,$dispositivo->id])}}" class="btn btn-primary">ACTIVAR</a></td>
                            @endif
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>

    <!--Ventana modal para vista previa -->
    <div class="modal fade" id="vistaprevia" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
        <div id="aparienciaModal" class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" id="encabezadoVistaPrevia"> </div>
                <div class="modal-body">
                    <div id="vistacontenido"> </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" id="btnCerrarVistaPrevia">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
