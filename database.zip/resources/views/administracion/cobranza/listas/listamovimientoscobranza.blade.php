@if($idUsuario != null)
    <input type="hidden" id="idUsuarioActual" value="{{$idUsuario[0]->id}}">
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Ultimo corte</label>
                <input type="text" name="ultimocorte" class="form-control"  readonly value="{{$ultimocorte}}">
            </div>
        </div>
        <div class="col-2" style="margin-top: 30px">
            <a href="#" data-href="" data-toggle="modal" data-target="#confirmacion"><button id="btnReiniciarCorte" type="button" class="btn btn-outline-danger">Reiniciar corte</button></a>
        </div>
    </div>
    <div class="modal fade" id="confirmacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <form action="{{route('cobranzamovimientosreiniciarcorte',$idUsuario[0]->id)}}" enctype="multipart/form-data"
              method="GET" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Reiniciar corte
                    </div>
                    <div class="modal-body">
                        ¿Estas seguro de reiniciar el corte para ({{$idUsuario[0]->name}})?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">No</button>
                        <button class="btn btn-outline-danger btn-ok" name="btnSubmit" type="submit">Si</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endif
<h4>Contratos</h4>
<div class="row">
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Semanal</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->semanal}}">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Quincenal</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->quincenal}}">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Mensual</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->mensual}}">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Contado</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->pagado}}">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Cancelados</label>
            <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->cancelado}}">
        </div>
    </div>
</div>
@if($semanal != null || $quincenal != null || $mensual != null || $contado != null)
    <h4>Cobrados en un lapso de tiempo </h4>
    <div class="row">
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Semanal</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$semanal}}">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Quincenal</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$quincenal}}">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Mensual</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$mensual}}">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Contado</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$contado}}">
            </div>
        </div>
        @isset($totalContadorContratosConAbonos)
            <div class="col-2">
                <div class="form-group">
                    <label>Total contratos</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContadorContratosConAbonos}}">
                </div>
            </div>
        @endisset
    </div>
@endif
@if($semanalC != null || $quincenalC != null || $mensualC != null || $contadoC != null)
    <h4>Cobrados en un lapso de tiempo (Solo cobrador)</h4>
    <div class="row">
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Semanal</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$semanalC}}">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Quincenal</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$quincenalC}}">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Mensual</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$mensualC}}">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Contado</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$contadoC}}">
            </div>
        </div>
        @isset($totalContadorContratosConAbonosC)
            <div class="col-2">
                <div class="form-group">
                    <label>Total contratos</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContadorContratosConAbonosC}}">
                </div>
            </div>
        @endisset
        <div class="col-2">
            <div class="form-group">
                <label>Ingresos</label>
                <input type="text" name="estado" class="form-control"  readonly value="$ {{$totalIngresosC}}">
            </div>
        </div>
    </div>
@endif

<h4>Abonos eliminados</h4>
<table  class="table table-bordered">
    <thead>
    <tr>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CONTRATO</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE CLIENTE</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">MOVIMIENTO</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">FECHA</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">LINK</th>
    </tr>
    </thead>
    <tbody>
    @if(sizeof($historialescontratos) > 0)
        @foreach($historialescontratos as $historialcontrato)
            <tr style="background-color: rgba(255,15,0,0.17)">
                <td align='center' style="border: #707070 solid 1px;">{{$historialcontrato->name}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialcontrato->id_contrato}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialcontrato->nombre}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialcontrato->cambios}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialcontrato->created_at}}</td>
                <td align='center' style="border: #707070 solid 1px;"><a href="{{route('vercontrato',[$idFranquicia,$historialcontrato->id_contrato])}}" target="_blank" class="btn btn-primary">ABRIR</a></td>
            </tr>
        @endforeach
    @else
        <td align='center' style="width: 20%; border: #707070 solid 1px;" colspan="6">Sin registros</td>
    @endif
    </tbody>
</table>

<h4>Abonos</h4>
<table  class="table table-bordered">
    <thead>
    <tr>
        <th  style =" text-align:center;" scope="col">NOMBRE</th>
        <th  style =" text-align:center;" scope="col">CONTRATO</th>
        <th  style =" text-align:center;" scope="col">NOMBRE CLIENTE</th>
        <th  style =" text-align:center;" scope="col">ABONO</th>
        <th  style =" text-align:center;" scope="col">FORMA DE PAGO</th>
        <th  style =" text-align:center;" scope="col">FOLIO</th>
        <th  style =" text-align:center;" scope="col">TIPO DE PAGO</th>
        <th  style =" text-align:center;" scope="col">FECHA</th>
        <th  style =" text-align:center;" scope="col">LINK</th>
    </tr>
    </thead>
    <tbody>
    @if(sizeof($movimientos) > 0)
        @foreach($movimientos as $movimiento)
            <tr>
                <td align='center'>{{$movimiento->name}}</td>
                <td align='center'>{{$movimiento->id_contrato}}</td>
                <td align='center'>{{$movimiento->nombre}}</td>
                <td align='center'>{{$movimiento->abono}}</td>
                @switch($movimiento->metodopago)
                    @case(0)
                    <td align='center'>EFECTIVO</td>
                    @break
                    @case(1)
                    <td align='center'>TARJETA</td>
                    @break
                    @case(2)
                    <td align='center'>TRANSFERENCIA</td>
                    @break
                @endswitch
                <td align='center'>{{$movimiento->folio}}</td>
                @switch($movimiento->pago)
                    @case(0)
                    <td align='center'>CONTADO</td>
                    @break
                    @case(1)
                    <td align='center'>SEMANAL</td>
                    @break
                    @case(2)
                    <td align='center'>QUINCENAL</td>
                    @break
                    @case(4)
                    <td align='center'>MENSUAL</td>
                    @break
                @endswitch
                <td align='center'>{{$movimiento->created_at}}</td>
                <td align='center'> <a href="{{route('vercontrato',[$idFranquicia,$movimiento->id_contrato])}}" target="_blank" class="btn btn-primary">ABRIR</a></td>
            </tr>
        @endforeach
    @else
        <td align='center' style="width: 20%;" colspan="9">Sin registros</td>
    @endif
    </tbody>
</table>

