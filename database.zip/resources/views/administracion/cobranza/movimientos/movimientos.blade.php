@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <div class="row">
        <input type="hidden" id="idFranquicia" value="{{$franquicia[0]->idFranquicia}}">
        @if($idUsuario != null)
            <input type="hidden" value="{{$idUsuario}}" id="idCobrador">
        @endif
        <div class="col-3">
          <div class="form-group">
              <label>Estado</label>
              <input type="text" name="estado" class="form-control"  readonly value="{{$franquicia[0]->estado}}">
          </div>
        </div>
        <div class="col-3">
          <div class="form-group">
              <label>Ciudad</label>
              <input type="text" name="ciudad" class="form-control"  readonly value="{{$franquicia[0]->ciudad}}">
          </div>
        </div>
        <div class="col-3">
          <div class="form-group">
              <label>Colonia</label>
              <input type="text" name="colonia" class="form-control"  readonly value="{{$franquicia[0]->colonia}}">
          </div>
        </div>
        <div class="col-3">
          <div class="form-group">
              <label>Numero Interior/Exterior</label>
              <input type="text" name="numero" class="form-control"  readonly value="{{$franquicia[0]->numero}}">
          </div>
        </div>
    </div>
    <div class="row">
        <div class="col-3">
            <label for="">Usuario</label>
            <select class="custom-select {!! $errors->first('usuario','is-invalid')!!}" id="usuario" name="usuario">
                @if(count($usuarios) > 0)
                    <option selected value="">Seleccionar</option>
                    @foreach($usuarios as $usuario)
                        <option value="{{$usuario->id}}">{{$usuario->zona}} - {{$usuario->name}}</option>
                    @endforeach
                @else
                    <option selected>No se encontro ningun usuario</option>
                @endif
            </select>
            {!! $errors->first('zona','<div class="invalid-feedback">Elegir una zona, campo obligatorio </div>')!!}
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Fecha inicial</label>
                <input type="date" name="inicio" id="inicio" class="form-control {!! $errors->first('inicio','is-invalid')!!}" value="{{$fechaInicial}}">
                @if($errors->has('inicio'))
                    <div class="invalid-feedback">{{$errors->first('inicio')}}</div>
                @endif
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Fecha final</label>
                <input type="date" name="fin" id="fin" class="form-control {!! $errors->first('fin','is-invalid')!!}" value="{{$fechaFinal}}">
                @if($errors->has('fin'))
                    <div class="invalid-feedback">{{$errors->first('fin')}}</div>
                @endif
            </div>
        </div>
        <div class="col-3">
            <label for="">Opciones</label>
            <select class="custom-select cargarTabla" id="opcion" name="opcion">
                <option value="0">Movimientos</option>
                @if($idUsuario != null)
                    <option value="1">Corte Actual</option>
                @endif
            </select>
        </div>
        <div class="col-1">
                <button class="btn btn-outline-success" id="btnFiltrosMovimientosCobranza">Aplicar </button>
        </div>
        <div class="col-1" id="spCargando">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" style="width: 2rem; height: 2rem; margin-top: 25px;" role="status">
                    <span class="visually-hidden"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group" id="listamovimientoscobranza">
        <h4>Contratos</h4>
        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <label>Forma de pago Semanal</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->semanal}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Forma de pago Quincenal</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->quincenal}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Forma de pago Mensual</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->mensual}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Forma de pago Contado</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->pagado}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Cancelados</label>
                    <input type="text" name="estado" class="form-control"  readonly value="{{$totalContratos[0]->cancelado}}">
                </div>
            </div>
        </div>
        <h4>Abonos eliminados</h4>
        <table  class="table table-bordered">
            <thead>
            <tr>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CONTRATO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE CLIENTE</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">MOVIMIENTO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">FECHA</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">LINK</th>
            </tr>
            </thead>
            <tbody>
                <td align='center' style="width: 20%; border: #707070 solid 1px;" colspan="6">Sin registros</td>
            </tbody>
        </table>
        <h4>Abonos</h4>
        <table  class="table table-bordered">
            <thead>
            <tr>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CONTRATO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE CLIENTE</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">ABONO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">FORMA DE PAGO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">FOLIO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">TIPO DE PAGO</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">FECHA</th>
                <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">LINK</th>
            </tr>
            </thead>
            <tbody>
                <td align='center' style="width: 20%; border: #707070 solid 1px;" colspan="10">Sin registros</td>
            </tbody>
        </table>
    </div>
@endsection
