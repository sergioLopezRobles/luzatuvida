<table class="table table-bordered table-striped" style="text-align: center; position: relative; border-collapse: collapse;" id="tblReporteAsistencia">
    <thead>
    <tr>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">NOMBRE</th>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LUNES</th>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">MARTES</th>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">MIERCOLES</th>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">JUEVES</th>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">VIERNES</th>
        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">SABADO</th>
    </tr>
    </thead>
    <tbody>
    @if($asistenciaUsuarios != null)
        @foreach($asistenciaUsuarios as $asistenciaUsuario)
            <tr>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->name}}</td>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->asistenciaLunes}}</td>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->asistenciaMartes}}</td>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->asistenciaMiercoles}}</td>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->asistenciaJueves}}</td>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->asistenciaViernes}}</td>
                <td align='center' style="font-size: 10px;">{{$asistenciaUsuario->asistenciaSabado}}</td>
            </tr>
        @endforeach
    @else
        <tr>
            <td align='center' style="font-size: 10px;" colspan="7">Sin registros</td>
        </tr>
    @endif
    </tbody>
</table>
