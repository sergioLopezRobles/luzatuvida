@if(sizeof($historialMovimientos) > 0)
    @foreach($historialMovimientos as $historialmovimiento)
        @if(str_contains($historialmovimiento->cambios, 'elimino'))
            <tr style="background-color: rgba(255,15,0,0.17)">
                <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->name}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->id_contrato}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->nombre}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->cambios}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->created_at}}</td>
                <td align='center' style="border: #707070 solid 1px;"><a href="{{route('vercontrato',[$idFranquicia,$historialmovimiento->id_contrato])}}" target="_blank" class="btn btn-primary">ABRIR</a></td>
            </tr>
        @else
        <tr>
            <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->name}}</td>
            <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->id_contrato}}</td>
            <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->nombre}}</td>
            <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->cambios}}</td>
            <td align='center' style="border: #707070 solid 1px;">{{$historialmovimiento->created_at}}</td>
            <td align='center' style="border: #707070 solid 1px;"><a href="{{route('vercontrato',[$idFranquicia,$historialmovimiento->id_contrato])}}" target="_blank" class="btn btn-primary">ABRIR</a></td>
        </tr>
        @endif
    @endforeach
@else
    <th style="font-size: 10px; text-align: center;" colspan="6">Sin registros</th>
@endif
