<table class="table table-bordered">
    <thead>
    <tr>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">COBRADOR</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CONTRATO</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CLIENTE</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col" colspan="4">MENSAJE</th>
    </tr>
    </thead>
    <tbody>
    @if($contratoscorte != null)

        @foreach($contratoscorte as $contratocorte)

            <tr @if($contratocorte->mensaje != null) style="background-color: #AAFAAA"
                @else style="background-color: #FACD73" @endif>
                <td align='center' style="border: #707070 solid 1px;">{{$contratocorte->nombrecobrador}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$contratocorte->id_contrato}}</td>
                <td align='center' style="border: #707070 solid 1px;">{{$contratocorte->nombrecliente}}</td>
                <td align='center' style="border: #707070 solid 1px;" colspan="4">{{$contratocorte->mensaje}}</td>
            </tr>
        @endforeach
    @else
        <td align='center' style="width: 20%; border: #707070 solid 1px;" colspan="7">Sin registros</td>
    @endif
    </tbody>
</table>
