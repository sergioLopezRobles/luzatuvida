@extends('layouts.app')
@section('titulo','Reporte paquetes'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <h2 style="text-align: left; color: #0AA09E">Paquetes</h2>
    <form action="{{route('listacontratospaquetes')}}"
          enctype="multipart/form-data" method="GET"
          onsubmit="btnSubmit.disabled = true;">
        @csrf
        <div class="row">
            <div class="col-2">
                <label for="idOpto">Optometristas</label>
                <select name="idOpto"
                        id="idOpto"
                        class="form-control">
                    @if(count($optometristas) > 0)
                        <option value="" selected>Seleccionar..</option>
                        @foreach($optometristas as $opto)
                            <option
                                value="{{$opto->id}}"  @if($idOpto != null && $idOpto == $opto->id)  selected @endif >{{$opto->nombre}}</option>
                        @endforeach
                    @else
                        <option selected>Sin registros</option>
                    @endif
                </select>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Fecha inicial</label>
                    <input type="date" name="fechaIni" id="fechaIni" class="form-control {!! $errors->first('fechaIni','is-invalid')!!}" @isset($fechaIni) value = "{{$fechaIni}}" @endisset>
                    @if($errors->has('fechaIni'))
                        <div class="invalid-feedback">{{$errors->first('fechaIni')}}</div>
                    @endif
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Fecha final</label>
                    <input type="date" name="fechaFin" id="fechaFin" class="form-control {!! $errors->first('fechaFin','is-invalid')!!}" @isset($fechaFin) value = "{{$fechaFin}}" @endisset>
                    @if($errors->has('fechaFin'))
                        <div class="invalid-feedback">{{$errors->first('fechaFin')}}</div>
                    @endif
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox" style="margin-top: 38px">
                    <input type="checkbox"
                           class="custom-control-input"
                           name="cbOrdenarPaquete" id="cbOrdenarPaquete">
                    <label class="custom-control-label" for="cbOrdenarPaquete">Ordenar por paquete</label>
                </div>
            </div>
            <div class="col-1" id="spCargando">
                <div class="d-flex justify-content-center">
                    <div class="spinner-border" style="width: 2rem; height: 2rem; margin-top: 30px;" role="status">
                        <span class="visually-hidden"></span>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                Lectura <span class="badge bg-secondary" id="lectura">0</span>
            </button>
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                Proteccion <span class="badge bg-secondary" id="proteccion">0</span>
            </button>
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                Eco JR <span class="badge bg-secondary" id="ecojr">0</span>
            </button>
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                JR <span class="badge bg-secondary" id="jr">0</span>
            </button>
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                Dorado 1 <span class="badge bg-secondary" id="dorado1">0</span>
            </button>
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                Dorado 2 <span class="badge bg-secondary" id="dorado2">0</span>
            </button>
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px; margin-right: 20px;">
                Platino <span class="badge bg-secondary" id="platino">0</span>
            </button>
            <button type="button" class="btn btn-danger" style="margin-bottom: 10px; margin-right: 20px; background-color: #FFACA6; border-color: #FFACA6;">
                Rechazado <span class="badge bg-secondary" id="rechazado">0</span>
            </button>
            <button type="button" class="btn btn-danger" style="margin-bottom: 10px; margin-right: 20px; background-color: #FFACA6; border-color: #FFACA6;">
                Cancelado/Lio/Fuga <span class="badge bg-secondary" id="cancelado_lio_fuga">0</span>
            </button>
        </div>
    </div>
    <div class="row" style="margin-top: 10px;" id="divBtnTotalRegistros">
        <button type="button" class="btn btn-primary" style="margin-bottom: 10px;">
            Total registros <span class="badge bg-secondary" id="totalContratos">0</span>
        </button>
        <a href="#" id="btnExportarExcel" onclick="exportarAExcel('Reporte Paquetes','tablaReportePaquetes');" style="text-decoration:none; color:black; padding-left: 15px;">
            <button type="button" class="btn btn-success"> Exportar </button>
        </a>
    </div>
    <table class="table table-bordered table-striped" style="text-align: left; position: relative; border-collapse: collapse;" id="tablaReportePaquetes">
        <thead>
            <tr>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">NOMBRE</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">SUCURSAL</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA DE CREACION</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CONTRATO</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ESTATUS</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">PAQUETE</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FOTOCROMATICO</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">AR</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TINTE</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">BLUERAY</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">OTRO</th>
                <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
            </tr>
        </thead>
        <tbody id="tblpaquetes">

        </tbody>
    </table>
@endsection
