<html>
<head>
    <title>Correo de prueba</title>
    <meta charset="utf-8">
</head>
<body>
<div>
    <table width="100%" style="box-shadow: 3px 3px 10px #AAA;max-width:900px;">
        <tr>
            <td style="text-align: justify;padding: 10px;">
                Aqui puede ir un mensaje
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <br>
                <h2 style="color: black;">Estimado(a): <b>{{$datos['usuario']}}</b></h2>
            </td>
        </tr>
    </table>
</div>
</body>

</html>
