<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
@if(Auth::user()->rol_id==7)
  <div class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sucursales</a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
      <a class="dropdown-item" href="{{route('nuevafranquicia')}}">Nueva</a>
      <a class="dropdown-item" href="{{route('listafranquicia')}}">Lista</a>
    </div>
</div>
@endif
@if(((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id==6 || Auth::user()->rol_id==8)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Polizas</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
          <a class="dropdown-item" href="{{route('listapoliza',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Lista</a>
        </div>
    </div>
@endif
@if(((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id==6 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 4)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                <a class="dropdown-item" href="{{route('listasolicitudautorizacion',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Autorizaciones</a>
            @endif
          <a class="dropdown-item" href="{{route('listacontrato',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Lista</a>
          @if(Auth::user()->rol_id == 7)
                <a class="dropdown-item" href="{{route('migrarcuentas',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Migrar cuentas</a>
          @endif
            <a class="dropdown-item" href="{{route('traspasarcontrato',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Traspasar</a>
            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                <a class="dropdown-item" href="{{route('reportecontratos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Reporte</a>
            @endif
        </div>
    </div>
@endif
@if(Auth::user()->rol_id==8)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('listasolicitudautorizacion',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Autorizaciones</a>
            <a class="dropdown-item" href="{{route('traspasarcontrato',$idSucursalGlobal)}}">Traspasar</a>
            <a class="dropdown-item" href="{{route('reportecontratos',$idSucursalGlobal)}}">Reporte</a>
        </div>
    </div>
@endif
@if(Auth::user()->rol_id==15)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('listasolicitudautorizacion',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Autorizaciones</a>
            <a class="dropdown-item" href="{{route('listaconfirmaciones')}}">Lista</a>
            <a class="dropdown-item" href="{{route('listagarantiasconfirmaciones')}}">Garantías</a>
            <a class="dropdown-item" href="{{route('traspasarcontrato',$idSucursalGlobal)}}">Traspasar</a>
            <a class="dropdown-item" href="{{route('reportecontratos',$idSucursalGlobal)}}">Reporte</a>
        </div>
    </div>
@endif
@if(Auth::user()->rol_id==16)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('listalaboratorio')}}">Lista</a>
        </div>
    </div>
@endif
@if(((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id==6  || Auth::user()->rol_id == 8)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Movimientos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('cobranzamovimientos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Cobranza</a>
            <div class="dropdown-item" aria-labelledby="dropdownMenu3">
                <a class="dropdown-item" href="{{route('llamadascobranza',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Llamadas</a>
            </div>
            <a class="dropdown-item" href="{{route('ventasmovimientos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Ventas</a>
        </div>
    </div>
@endif

@if(Auth::user()->rol_id==7 || Auth::user()->rol_id==6  || Auth::user()->rol_id == 8 || Auth::user()->rol_id==15)
    @if(Auth::user()->rol_id==15)
        <div class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Reportes</a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <a class="dropdown-item" href="{{route('listacontratosreportes')}}">Entrar</a>
            </div>
        </div>
    @else
        <div class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Reportes</a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <a class="dropdown-item" href="{{route('listareporteasistencia')}}" target="_blank">Asistencia</a>
                <a class="dropdown-item" href="{{route('listacontratoscancelados')}}" target="_blank">Cancelados</a>
                <a class="dropdown-item" href="{{route('listacontratoscuentasactivas')}}" target="_blank">Cuentas activas</a>
                <a class="dropdown-item" href="{{route('cuentasfisicas')}}" target="_blank">Cuentas fisicas</a>
                <a class="dropdown-item" href="{{route('listacontratosreportes')}}" target="_blank">Enviados</a>
                @if(Auth::user()->rol_id==6 || Auth::user()->rol_id==7  || Auth::user()->rol_id == 8)
                    <a class="dropdown-item" href="{{route('reportellamadas')}}" target="_blank">Llamadas</a>
                @endif
                <a class="dropdown-item" href="{{route('reportemovimientos')}}" target="_blank">Movimientos</a>
                <a class="dropdown-item" href="{{route('listacontratospagados')}}" target="_blank">Pagados</a>
                <a class="dropdown-item" href="{{route('listacontratospaquetes')}}" target="_blank">Paquetes</a>
                @if(Auth::user()->rol_id==7)
                    <a class="dropdown-item" href="{{route('reportegraficas')}}" target="_blank">Graficas</a>
                @endif
            </div>
        </div>
    @endif
@endif

@if(Auth::user()->rol_id==6 || ((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id == 8)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Vehículos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('listavehiculos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Lista</a>
        </div>
    </div>
@endif

@if(Auth::user()->rol_id==8 || Auth::user()->rol_id==6 || ((Auth::user()->rol_id == 7) && @isset($idFranquicia)))
    <hr style="background:white;">
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Administracion</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
          <a class="dropdown-item" href="{{route('listasfranquicia',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)}}">Lista</a>
        </div>
    </div>
@endif

@if(Auth::user()->rol_id == 7)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Laboratorio</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('listalaboratorio')}}">Principal</a>
            <a class="dropdown-item" href="{{route('auxiliarlaboratorio')}}">Auxiliar</a>
        </div>
    </div>
@endif

@if(Auth::user()->rol_id == 7)
  <div class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Insumos</a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
        <a class="dropdown-item" href="{{route('insumos')}}">Entrar</a>
      </div>
  </div>
@endif
@if(Auth::user()->rol_id == 7)
  <div class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Desarrollo</a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
        <a class="dropdown-item" href="{{route('general')}}">Entrar</a>
      </div>
  </div>
@endif
@if(Auth::user()->rol_id == 6)
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Usuarios</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="{{route('usuariosFranquicia',[$idSucursalGlobal])}}">Entrar</a>
        </div>
    </div>
@endif
