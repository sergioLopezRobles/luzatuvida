@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <h2>@lang('mensajes.mensajeconfirmacionestado')</h2>

    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Estado</label>
                <input type="text" name="estado" class="form-control"  readonly value="{{$infoFranquicia[0]->estado}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ciudad</label>
                <input type="text" name="ciudad" class="form-control"  readonly value="{{$infoFranquicia[0]->ciudad}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="colonia" class="form-control"  readonly value="{{$infoFranquicia[0]->colonia}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Numero Interior/Exterior</label>
                <input type="text" name="numero" class="form-control"  readonly value="{{$infoFranquicia[0]->numero}}">
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-2">
            <label for="contrato">Contrato</label>
            <input name="contrato" type="text" readonly class="form-control" placeholder="Contrato" value="{{$contrato[0]->id}}">
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Total</label>
                <input type="text" name="total" class="form-control" readonly value="$ {{$contrato[0]->totalreal}}">
            </div>
        </div>
        @if($contrato[0]->promocion != null)
            <div class="col-2">
                <div class="form-group">
                    <label>Total promocion</label>
                    <input type="text" name="totalpromocion" class="form-control" readonly value="$ {{$contrato[0]->totalpromocion}}">
                </div>
            </div>
        @endif
        <div class="col-2">
            <div class="form-group">
                <label>Total productos</label>
                @if($contrato[0]->totalproductos != null)
                    <input type="text" name="totalproductos" class="form-control" readonly value="$ {{$contrato[0]->totalproductos}}">
                @else
                    <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                @endif
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Total abonos</label>
                @if($contrato[0]->totalabonos != null)
                    <input type="text" name="totalabonos" class="form-control" readonly value="$ {{$contrato[0]->totalabonos}}">
                @else
                    <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                @endif
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Saldo</label>
                <input type="text" name="saldo" class="form-control" readonly value="$ {{$contrato[0]->total}}">
            </div>
        </div>
    </div>
    <form action="{{route('estadoconfirmacionactualizar',[$idContrato])}}" method="POST">
        @csrf
        <div class="row">
            @if($contrato[0]->promocion != null)
                <div class="col-5">
                    <div class="form-group">
                        <label>Promocion</label>
                            <input type="text" class="form-control" readonly value="{{$contrato[0]->titulopromocion}}">
                    </div>
                </div>
            @else
                <div class="col-5"></div>
            @endif
            <div class="col-2">
                <label for="estatusactual">Estatus actual</label>
                @switch($contrato[0]->estatus_estadocontrato)
                    @case(1)
                        <button name="estatusactual" type="button" class="btn btn-success btn-block terminados" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button>
                    @break
                    @case(7)
                        <button name="estatusactual"  type="button" class="btn btn-primary btn-block aprobado" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button>
                    @break
                    @case(9)
                        <button name="estatusactual"  type="button" class="btn btn-danger btn-block enprocesodeaprobacion" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button>
                    @break
                    @case(10)
                        <button name="estatusactual"  type="button" class="btn btn-warning btn-block manofactura" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button>
                    @break
                    @case(11)
                        <button name="estatusactual"  type="button" class="btn btn-info btn-block enprocesodeenvio" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button>
                    @break
                    @default
                        <button name="estatusactual"  type="button" class="btn btn-info btn-block noterminados" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button>
                @endswitch
            </div>
            <div class="col-3">
                <label for="estatus">Estatus del contrato</label>
                <select class="custom-select {!! $errors->first('estatus','is-invalid')!!}" name="estatus" @if($contrato[0]->estatus_estadocontrato != 1
                                    && $contrato[0]->estatus_estadocontrato != 7
                                    && $contrato[0]->estatus_estadocontrato != 9) disabled @endif>
                    <option value="a" selected>Seleccionar</option>
                    @if($tieneHistorialGarantia != null)
                        <option value="1">Editable</option>
                    @else
                        <option value="0">No terminado</option>
                    @endif
                    <option value="9">En proceso de aprobacion</option>
                    <option value="7">Aprobado</option>
                </select>
                {!! $errors->first('estatus','<div class="invalid-feedback">Por favor, selecciona un estatus valido.</div>')!!}
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>&nbsp;</label>
                    <button class="btn btn-outline-success btn-block" type="submit" @if($contrato[0]->estatus_estadocontrato != 1
                                    && $contrato[0]->estatus_estadocontrato != 7
                                    && $contrato[0]->estatus_estadocontrato != 9) disabled @endif>@lang('mensajes.mensajebotonconfirmacionestado')</button>
                </div>
            </div>
        </div>
    </form>
    @if(($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $contrato[0]->subscripcion == null)
        <form  action="{{route('actualizarTotalContratoConfirmaciones',$contrato[0]->id)}}"
               enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="row">
                <div class="col-2"></div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Actualizar total:</label>
                        <input type="text" name="totalActualizado"
                               class="form-control {!! $errors->first('totalActualizado','is-invalid')!!}" placeholder="Total">
                        {!! $errors->first('totalActualizado','<div class="invalid-feedback">El nombre es obligatorio.</div>')!!}
                    </div>
                </div>
                <div class="col-1">
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button class="btn btn-outline-success btn-block" type="submit">@lang('mensajes.actualizar')</button>
                    </div>
                </div>
            </div>
        </form>
    @endif
    <div class="row">
        {{--        Formulario para actualizar fecha --}}
        <div class="col-6">
            <form action="{{route('actualizarfechaentregaconfirmaciones',[$idContrato])}}" method="POST">
                @csrf
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Fecha entrega</label>
                            <input @if($contrato[0]->estatus_estadocontrato != 1
                                    && $contrato[0]->estatus_estadocontrato != 7
                                    && $contrato[0]->estatus_estadocontrato != 9) disabled @endif
                            type="date" name="fechaentrega" class="form-control {!! $errors->first('fechaentrega','is-invalid')!!}" @isset($contrato[0]->fechaentrega) value = "{{$contrato[0]->fechaentrega}}" @endisset>
                            @if($errors->has('fechaentrega'))
                                <div class="invalid-feedback">{{$errors->first('fechaentrega')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button class="btn btn-outline-success btn-block" type="submit"
                                    @if($contrato[0]->estatus_estadocontrato != 1
                                            && $contrato[0]->estatus_estadocontrato != 7
                                            && $contrato[0]->estatus_estadocontrato != 9) disabled @endif>Actualizar fecha</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        {{--        Formulario para actualizar forma de pago--}}
        <div class="col-6">
            <form action="{{route('actualizarformapagoconfirmaciones',[$idFranquicia,$contrato[0]->id])}}" method="POST">
                @csrf
                <div class="row">
                    <div class="col-2"></div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="formapago">Forma de pago</label>
                            <select class="custom-select {!! $errors->first('formapago','is-invalid')!!}" name="formapago" id="formapago">
                                <option value="nada" selected>Todas las formas de pago</option>
                                <option value="0" {{ isset($contrato[0]->pago) ? ($contrato[0]->pago == 0 ? 'selected' : '' ) : '' }}>Contado</option>
                                <option value="1" {{ isset($contrato[0]->pago) ? ($contrato[0]->pago == 1 ? 'selected' : '' ) : '' }}>Semanal</option>
                                <option value="2" {{ isset($contrato[0]->pago) ? ($contrato[0]->pago == 2 ? 'selected' : '' ) : '' }}>Quincenal</option>
                                <option value="4" {{ isset($contrato[0]->pago) ? ($contrato[0]->pago == 4 ? 'selected' : '' ) : '' }}>Mensual</option>
                            </select>
                            {!! $errors->first('formapago','<div class="invalid-feedback">Por favor, selecciona la forma de pago.</div>')!!}
                            @if($contrato[0]->pago == 4)
                                <p style="color: #ea9999">Al cambiar a MENSUAL aceptas que actualizaste las fotos de tarjetas de pensión.</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button class="btn btn-outline-success btn-block" type="submit"
                                    @if($contrato[0]->estatus_estadocontrato != 1
                                            && $contrato[0]->estatus_estadocontrato != 7
                                            && $contrato[0]->estatus_estadocontrato != 9) disabled @endif>Actualizar forma pago</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    @if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9)
        <form id="frmagregarproductoconfirmaciones" action="{{route('agregarproductoconfirmaciones',[$idContrato])}}" method="POST">
            @csrf
            <div class="row">
                <div class="col-3">
                    <label>Producto</label>
                    <select name="producto"
                            class="form-control">
                        <option selected value=''>Seleccionar</option>
                        @foreach($productos as $pro)
                            @if ($pro->piezas >= 10)
                                @if($pro->preciop == null)
                                    <option value="{{$pro->id}}">{{$pro->nombre}} | $ {{ $pro->precio }}
                                        | {{$pro->piezas}}pza.
                                    </option>
                                @else
                                    <option value="{{$pro->id}}">{{$pro->nombre}} | Normal :
                                        $ {{ $pro->precio }} | Con
                                        descuento: $ {{ $pro->preciop }} | {{$pro->piezas}}pza.
                                    </option>
                                @endif
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <a type="button" href="" class="btn btn-block btn-outline-success" data-toggle="modal" style="margin-top: 30px"
                           data-target="#modalagregarproductoconfirmaciones">Agregar</a>
                    </div>
                </div>
            </div>
        </form>

        <!-- modal para agregarproductoconfirmaciones contratos -->
        <div class="modal fade" id="modalagregarproductoconfirmaciones" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Solicitud de confirmación
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-12" style="color: #ea9999">
                                Esta accion no se podra revertir, al aceptar confirmas que se te entrego la evidencia de la adquisición del producto.
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit" form="frmagregarproductoconfirmaciones">Aceptar</button>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <table id="tablaCP" class="table table-bordered">
        @if(sizeof($contratoproducto)>0)
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">PRODUCTO</th>
                <th style=" text-align:center;" scope="col">PRECIO</th>
                <th style=" text-align:center;" scope="col">PIEZAS</th>
                <th style=" text-align:center;" scope="col">TOTAL</th>
            </tr>
            </thead>
        @endif
        <tbody>
        @foreach($contratoproducto as $CP)
            <tr>
                <td align='center'>{{$CP->nombre}}</td>
                @if($CP->preciop == null)
                    <td align='center'>$ {{$CP->precio}}</td>
                @else
                    <td align='center'>$ {{$CP->preciop}}</td>
                @endif
                <td align='center'>{{$CP->piezas}}</td>
                <td align='center'>$ {{$CP->total}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <hr>
    <form  action="{{route('actualizarContratoConfirmaciones',$contrato[0]->id)}}"
          enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
        @csrf
        <div class="row">
            <div class="col-1">
                <label for="">Zona</label>
                @if($tieneHistorialGarantia == null)
                    <select class="custom-select {!! $errors->first('zona','is-invalid')!!}" name="zona">
                        @if(count($zonas) > 0)
                            <option selected value="{{$contrato[0]->id_zona}}">{{$contrato[0]->zona}}</option>
                            @foreach($zonas as $zona)
                                @if($zona->id == $contrato[0]->id_zona)
                                    @continue
                                @else
                                    <option value="{{$zona->id}}">{{$zona->zona}}</option>
                                @endif
                            @endforeach
                        @else
                            <option selected>Sin registros</option>
                        @endif
                    </select>
                    {!! $errors->first('zona','<div class="invalid-feedback">Elegir una zona, campo obligatorio </div>
                    ')!!}
                @else
                    <input type="text" class="form-control" readonly value="{{$contrato[0]->zona}}">
                @endif
            </div>
            <div class="col-2">
                <label >Optometrista</label>
                @if(($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $tieneHistorialGarantia == null)
                    <select class="custom-select" name="optometrista">
                        <option selected value="{{$contrato[0]->id_optometrista}}">{{$contrato[0]->opto}}</option>
                        @foreach($optometristas as $optometrista)
                            @if($optometrista->ID == $contrato[0]->id_optometrista)
                                @continue
                            @else
                                <option value="{{$optometrista->ID}}">{{$optometrista->NAME}}</option>
                            @endif
                        @endforeach
                    </select>
                @else
                    <input type="text" class="form-control" readonly value="{{$contrato[0]->opto}}">
                @endif
                <input hidden id="nombreoptometristaoculto" value="{{$contrato[0]->opto}}">
                <a class="btn btn-outline-success btn-sm mt-1" onclick="copiarNombreOptometristaOAsistente(0);">Copiar</a>
            </div>
            <div class="col-2">
                <label for="">Asistente</label>
                @if(($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $tieneHistorialGarantia == null)
                    <select class="custom-select" name="asistente">
                        <option selected value="{{$contrato[0]->id_usuariocreacion}}">{{$contrato[0]->nombreasistente}}</option>
                        @foreach($asistentes as $asistente)
                            @if($asistente->ID == $contrato[0]->id_usuariocreacion)
                                @continue
                            @else
                                <option value="{{$asistente->ID}}">{{$asistente->NAME}}</option>
                            @endif
                        @endforeach
                    </select>
                @else
                    <input type="text" class="form-control" readonly value="{{$contrato[0]->nombreasistente}}">
                @endif
                <input hidden id="nombreasistenteoculto" value="{{$contrato[0]->nombreasistente}}">
                <a class="btn btn-outline-success btn-sm mt-1" onclick="copiarNombreOptometristaOAsistente(1);">Copiar</a>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Nombre del cliente</label>
                    <input type="text" name="nombre"
                           class="form-control {!! $errors->first('nombre','is-invalid')!!}" placeholder="Nombre"
                           value="{{$contrato[0]->nombre}}">
                    {!! $errors->first('nombre','<div class="invalid-feedback">El nombre es obligatorio.</div>')!!}
                </div>
            </div>
            <div class="col-1">
                <div class="form-group">
                    <label>Edad</label>
                    <input type="text" name="edad"
                           class="form-control {!! $errors->first('edad','is-invalid')!!}" placeholder="Edad"
                           value="{{$contrato[0]->edad}}">
                    {!! $errors->first('edad','<div class="invalid-feedback">La edad es obligatoria.</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Calle</label>
                    <input type="text" name="calle" class="form-control {!! $errors->first('calle','is-invalid')!!}"
                           placeholder="Calle" value="{{$contrato[0]->calle}}">
                    {!! $errors->first('calle','<div class="invalid-feedback">La calle es obligatoria.</div>')!!}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-1">
                <div class="form-group">
                    <label>Numero</label>
                    <input type="text" name="numero"
                           class="form-control {!! $errors->first('numero','is-invalid')!!}" placeholder="Numero"
                           value="{{$contrato[0]->numero}}">
                    {!! $errors->first('numero','<div class="invalid-feedback">El numero es obligatorio.</div>')!!}
                </div>
            </div>
            <div class="col-1">
                <div class="form-group">
                    <label>Departamento</label>
                    <input type="text" name="departamento"
                           class="form-control {!! $errors->first('departamento','is-invalid')!!}"
                           placeholder="Departamento" value="{{$contrato[0]->depto}}">
                    {!! $errors->first('departamento','<div class="invalid-feedback">El numero es obligatorio.</div>
                    ')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label id="alladode">Al lado de</label>
                    <input type="text" name="alladode"
                           class="form-control {!! $errors->first('alladode','is-invalid')!!}" placeholder="Al lado de"
                           value="{{$contrato[0]->alladode}}">
                    {!! $errors->first('alladode','<div class="invalid-feedback">Campo obligatorio</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Frente a</label>
                    <input type="text" name="frentea"
                           class="form-control {!! $errors->first('frentea','is-invalid')!!}" placeholder="Frente a"
                           value="{{$contrato[0]->frentea}}">
                    {!! $errors->first('frentea','<div class="invalid-feedback">Campo obligatorio</div>')!!}
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Ubicacion</label>
                    <input type="text" name="coordenadas"
                           class="form-control {!! $errors->first('coordenadas','is-invalid')!!}" placeholder="Coordenadas"
                           value="{{$contrato[0]->coordenadas}}">
                    {!! $errors->first('coordenadas','<div class="invalid-feedback">Campo obligatorio</div>')!!}
                </div>
            </div>
            <div class="col-2" style="margin-top: 30px">
                <a href="{{url('https://www.google.com/maps/place?key=AIzaSyC4wzK36yxyLG6yzpqUPnV4j8Y74aKkq-M&q=' . $contrato[0]->coordenadas)}}" target="_blank"><button type="button" class="btn btn-outline-success">Ver ubicación</button></a>
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <div class="form-group">
                    <label>Entre calles</label>
                    <input type="text" name="entrecalles"
                           class="form-control {!! $errors->first('entrecalles','is-invalid')!!}"
                           placeholder="Entre calles" value="{{$contrato[0]->entrecalles}}">
                    {!! $errors->first('entrecalles','<div class="invalid-feedback">El campo es obligatorio.</div>
                    ')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Colonia</label>
                    <input type="text" name="colonia"
                           class="form-control {!! $errors->first('colonia','is-invalid')!!}" placeholder="Colonia"
                           value="{{$contrato[0]->colonia}}">
                    {!! $errors->first('colonia','<div class="invalid-feedback">La colonia es obligatoria.</div>
                    ')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Localidad</label>
                    <input type="text" name="localidad"
                           class="form-control {!! $errors->first('localidad','is-invalid')!!}" placeholder="Localidad"
                           value="{{$contrato[0]->localidad}}">
                    {!! $errors->first('localidad','<div class="invalid-feedback">La localidad es obligatoria.</div>
                    ')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Telefono del paciente</label>
                    <input type="text" name="telefono"
                           class="form-control {!! $errors->first('telefono','is-invalid')!!}" placeholder="Telefono"
                           value="{{$contrato[0]->telefono}}">
                    {!! $errors->first('telefono','<div class="invalid-feedback">El telefono debe contener 10
                        numeros.</div>')!!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <label>Tipo Casa</label>
                    <input type="text" name="casatipo"
                           class="form-control {!! $errors->first('casatipo','is-invalid')!!}" placeholder="Tipo Casa"
                           value="{{$contrato[0]->casatipo}}">
                    {!! $errors->first('casatipo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Casa color</label>
                    <input type="text" name="casacolor"
                           class="form-control {!! $errors->first('casacolor','is-invalid')!!}"
                           placeholder="Casa color" value="{{$contrato[0]->casacolor}}">
                    {!! $errors->first('casacolor','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Nombre referencia</label>
                    <input type="text" name="nr" class="form-control {!! $errors->first('nr','is-invalid')!!}"
                           placeholder="Nombre de referencia" value="{{$contrato[0]->nombrereferencia}}">
                    {!! $errors->first('nr','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Telefono referencia</label>
                    <input type="text" name="tr" class="form-control {!! $errors->first('tr','is-invalid')!!}"
                           placeholder="Telefono de referencia" value="{{$contrato[0]->telefonoreferencia}}">
                    {!! $errors->first('tr','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Correo electronico</label>
                    <input type="text" class="form-control" readonly value="{{$contrato[0]->correo}}">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-10"></div>
            <div class="col-2">
                <button class="btn btn-outline-success btn-block"
                        name="btnSubmit" type="submit" @if($contrato[0]->estatus_estadocontrato != 1
                                    && $contrato[0]->estatus_estadocontrato != 7
                                    && $contrato[0]->estatus_estadocontrato != 9
                                    && $contrato[0]->estatus_estadocontrato != 10) disabled @endif>@lang('mensajes.mensajeactuzalizarcontrato')</button>
            </div>
        </div>
    </form>
    <hr>
    <div class="row">
       <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img1" style="cursor: pointer">
           <img src="{{asset($contrato[0]->fotoine)}}" style="width:250px;height:250px;"  class="img-thumbnail" >
       </div>
        <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img2" style="cursor: pointer">
            <img src="{{asset($contrato[0]->fotoineatras)}}" style="width:250px;height:250px;" class="img-thumbnail" >
        </div>
        <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img3" style="cursor: pointer">
            <img src="{{asset($contrato[0]->fotocasa)}}" style="width:250px;height:250px;" class="img-thumbnail" >
        </div>
        <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img4" style="cursor: pointer">
            <img src="{{asset($contrato[0]->comprobantedomicilio)}}" style="width:250px;height:250px;" class="img-thumbnail" >
        </div>
    </div>
    <div class="row" style="margin-top: 10px;">
        <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img5" style="cursor: pointer">
            <img src="{{asset($contrato[0]->pagare)}}" style="width:250px;height:250px;" class="img-thumbnail" >
        </div>
        @if($contrato[0]->fotootros != null && strlen($contrato[0]->fotootros)>0)
            <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img6" style="cursor: pointer">
                <img src="{{asset($contrato[0]->fotootros)}}" style="width:250px;height:250px;" class="img-thumbnail" >
            </div>
        @endif
        @if($contrato[0]->tarjeta != null && strlen($contrato[0]->tarjeta)>0)
            <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img7" style="cursor: pointer">
                <img src="{{asset($contrato[0]->tarjeta)}}" style="width:250px;height:250px;" class="img-thumbnail" >
            </div>
        @endif
        @if( $contrato[0]->tarjeta != null && strlen($contrato[0]->tarjetapensionatras)>0)
            <div class="col-3" data-toggle="modal" data-target="#imagemodal" id="img8" style="cursor: pointer">
                <img src="{{asset($contrato[0]->tarjetapensionatras)}}" style="width:250px;height:250px;" class="img-thumbnail" >
            </div>
        @endif
    </div>
    <hr>
    <form action="{{route('confirmacionesagregardocumentos',[$idContrato])}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-3">
                <div class="form-group">
                    <label>Foto INE Frente</label>
                    <input type="file" name="fotoine"
                           class="form-control-file  {!! $errors->first('fotoine','is-invalid')!!}" accept="image/jpg">
                    {!! $errors->first('fotoine','<div class="invalid-feedback">La foto debera estar en formato jpg.
                    </div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Foto INE Atrás</label>
                    <input type="file" name="fotoineatras"
                           class="form-control-file  {!! $errors->first('fotoineatras','is-invalid')!!}"
                           accept="image/jpg">
                    {!! $errors->first('fotoineatras','<div class="invalid-feedback">Llenar ambos campos del INE
                    </div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Pagare:</label>
                    <input type="file" name="pagare"
                           class="form-control-file  {!! $errors->first('pagare','is-invalid')!!}" accept="image/jpg">
                    {!! $errors->first('pagare','<div class="invalid-feedback">La foto debera estar en formato jpg.
                    </div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Foto de la casa</label>
                    <input type="file" name="fotocasa"
                           class="form-control-file  {!! $errors->first('fotocasa','is-invalid')!!}"
                           accept="image/jpg">
                    {!! $errors->first('fotocasa','<div class="invalid-feedback">La foto debera estar en formato
                        jpg.</div>')!!}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <div class="form-group">
                    <label>Comprobante de domicilio</label>
                    <input type="file" name="comprobantedomicilio"
                           class="form-control-file  {!! $errors->first('comprobantedomicilio','is-invalid')!!}"
                           accept="image/jpg">
                    {!! $errors->first('comprobantedomicilio','<div class="invalid-feedback">La foto debera estar en
                        formato jpg.</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Tarjeta de pensión frente:</label>
                    <input type="file" name="tarjetapension"
                           class="form-control-file  {!! $errors->first('tarjetapension','is-invalid')!!}"
                           accept="image/jpg">
                    {!! $errors->first('tarjetapension','<div class="invalid-feedback">La foto debera estar en
                        formato jpg.</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Tarjeta de pensión Atras:</label>
                    <input type="file" name="tarjetapensionatras"
                           class="form-control-file  {!! $errors->first('tarjetapensionatras','is-invalid')!!}"
                           accept="image/jpg">
                    {!! $errors->first('tarjetapensionatras','<div class="invalid-feedback">La foto debera estar en
                        formato jpg.</div>')!!}
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Otros:</label>
                    <input type="file" name="fotootros"
                           class="form-control-file  {!! $errors->first('fotootros','is-invalid')!!}"
                           accept="image/jpg">
                    {!! $errors->first('fotootros','<div class="invalid-feedback">La foto debera estar en
                        formato jpg.</div>')!!}
                </div>
            </div>
        </div>
            <div class="col-12">
                <div class="form-group">
                    <label>&nbsp;</label>
                    <button class="btn btn-outline-success btn-block" type="submit" @if($contrato[0]->estatus_estadocontrato != 1
                                    && $contrato[0]->estatus_estadocontrato != 7
                                    && $contrato[0]->estatus_estadocontrato != 9
                                    && $contrato[0]->estatus_estadocontrato != 10) disabled @endif>@lang('mensajes.mensajebotonconfirmacionestado')</button>
                </div>
            </div>
    </form>
    <hr>
    <h2>Información diagnóstico</h2>
    <form id="frmDiagnostico" action="{{route('actualizardiagnosticoconfirmaciones',[$idContrato])}}" method="POST">
        @csrf
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Edad</label>
                <input type="text" name="edad" id="edad" class="form-control" @if($datosDiagnosticoHistorial[0]->edad != null) value="{{$datosDiagnosticoHistorial[0]->edad}}"
                       @else value="{{old('edad')}}" @endif>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Diagnóstico</label>
                <input type="text" name="diagnostico" id="diagnostico" class="form-control" @if($datosDiagnosticoHistorial[0]->diagnostico != null)
                value="{{$datosDiagnosticoHistorial[0]->diagnostico}}" @else value="{{old('diagnostico')}}" @endif>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ocupación</label>
                <input type="text" name="ocupacion" id="ocupacion" class="form-control" @if($datosDiagnosticoHistorial[0]->ocupacion != null) value="{{$datosDiagnosticoHistorial[0]->ocupacion}}"
                @else value="{{old('ocupacion')}}" @endif>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Diabetes</label>
                <input type="text" name="diabetes" id="diabetes" class="form-control" @if($datosDiagnosticoHistorial[0]->diabetes != null) value="{{$datosDiagnosticoHistorial[0]->diabetes}}"
                       @else value="{{old('diabetes')}}" @endif>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-4">
            <div class="form-group">
                <label>Hipertensión</label>
                <input type="text" name="hipertension" id="hipertension" class="form-control" @if($datosDiagnosticoHistorial[0]->hipertension != null)
                value="{{$datosDiagnosticoHistorial[0]->hipertension}}" @else value="{{old('hipertension')}}"@endif>
            </div>
        </div>
        <div class="col-4">
            <div class="form-group">
                <label>¿Se encuentra embarazada?</label>
                <input type="text" name="embarazada" id="embarazada" class="form-control" @if($datosDiagnosticoHistorial[0]->embarazada != null) value="{{$datosDiagnosticoHistorial[0]->embarazada}}"
                @else value="{{old('embarazada')}}"@endif>
            </div>
        </div>
        <div class="col-4">
            <div class="form-group">
                <label>¿Durmió de 6 a 8 horas?</label>
                <input type="text" name="durmioseisochohoras" id="durmioseisochohoras" class="form-control" @if($datosDiagnosticoHistorial[0]->durmioseisochohoras != null)
                value="{{$datosDiagnosticoHistorial[0]->durmioseisochohoras}}" @else value="{{old('durmioseisochohoras')}}"@endif>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label>Principal actividad en el día</label>
                <input type="text" name="actividaddia" id="actividaddia" class="form-control" @if($datosDiagnosticoHistorial[0]->actividaddia != null)
                value="{{$datosDiagnosticoHistorial[0]->actividaddia}}" @else value = "{{old('actividaddia')}}" @endif>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label>Principal problema que padece en sus ojos</label>
                <input type="text" name="problemasojos" id="problemasojos" class="form-control" @if($datosDiagnosticoHistorial[0]->problemasojos != null)
                value="{{$datosDiagnosticoHistorial[0]->problemasojos}}" @else value="{{old('problemasojos')}}" @endif>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-10">
            <h6>Molestia</h6>
        </div>
        <div class="col-2">
            <h6>Último examen</h6>
        </div>
    </div>
    <div class="row">
        <div class="col-2">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input " name="dolor" id="dolor"  @if($datosDiagnosticoHistorial[0]->dolor == 1) checked @endif>
                <label class="custom-control-label" for="dolor">Dolor de cabeza</label>
            </div>
        </div>
        <div class="col-2">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input " name="ardor" id="ardor" @if($datosDiagnosticoHistorial[0]->ardor == 1) checked @endif>
                <label class="custom-control-label" for="ardor">Ardor en los ojos</label>
            </div>
        </div>
        <div class="col-2">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" name="golpeojos"  id="golpeojos" @if($datosDiagnosticoHistorial[0]->golpeojos == 1) checked @endif>
                <label class="custom-control-label" for="golpeojos">Golpe en cabeza</label>
            </div>
        </div>
        <div class="col-2">
            <div class="custom-control custom-checkbox">
                <input  class="custom-control-input " type="checkbox" name="otroM" id="otroM" @if($datosDiagnosticoHistorial[0]->otroM == 1) checked @endif {{old('otroM')}}>
                <label class="custom-control-label" for="otroM">Otro</label>
            </div>
        </div>
        <div class="col-2">
            <div class="custom-control custom-checkbox">
                <input type="text" name="molestiaotro" id="molestiaotro" class="form-control {!! $errors->first('molestiaotro','is-invalid')!!}" min="0"  placeholder="Otro"
                       @if($datosDiagnosticoHistorial[0]->molestiaotro != null) value="{{$datosDiagnosticoHistorial[0]->molestiaotro}}" @else value="{{old('molestiaotro')}}"@endif>
                {!! $errors->first('molestiaotro','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <input type="date" name="ultimoexamen" id="ultimoexamen" class="form-control" min="0"  placeholder="" @if($datosDiagnosticoHistorial[0]->ultimoexamen != null)
                value="{{$datosDiagnosticoHistorial[0]->ultimoexamen}}" @else value="{{old('ultimoexamen')}}"@endif>
            </div>
        </div>
    </div>
        <div class="col-12">
            <div class="form-group">
                <button class="btn btn-outline-success btn-block" form="frmDiagnostico" type="submit">Actualizar diagnostico</button>
            </div>
        </div>
    </form>
    <hr>
    @if(isset($historiales))
        @php($contador = 1)
        @foreach($historiales as $historial)
            <div class="row">
                <div class="col-2">
                    <h3 style="margin-top: 10px;">@lang('mensajes.mensajetituloreceta') {{$loop->iteration}} ({{$historial->id}}) |{{ \Carbon\Carbon::parse($historial->created_at)->format('Y-m-d')}}| @if($historial->garantia != null) Garantía - {{$historial->optogarantia}}@endif</h3>
                </div>
                <div class="col-2">
                    <h3 style="margin-top: 10px;">Modelo: {{$historial->armazon}}</h3>
                </div>
                <div class="col-2">
                    <h3 style="margin-top: 10px;">Color: {{$historial->colorarmazon}}</h3>
                </div>
                @if($loop->iteration == 1)
                    <div class="col-2">
                        <h3 style="margin-top: 10px;">Paquete: {{$historial->paquete}}</h3>
                    </div>
                @endif
            </div>
            @if($historial->paquete == 'DORADO 2' || $historial->paquete == 'LECTURA')
                <h5 style="color: #0AA09E;">Sin conversión</h5>
                @if($historial->hscesfericoder != null)
                    <div id="mostrarvision"></div>
                    <h6>Ojo derecho</h6>
                    <div class="row">
                        <div class="col-2">
                            <div class="form-group">
                                <label>Esferico</label>
                                <input type="text" name="esfericod" class="form-control" readonly value="{{$historial->hscesfericoder}}">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Cilindro</label>
                                <input type="text" name="cilindrod" class="form-control" readonly value="{{$historial->hsccilindroder}}">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Eje</label>
                                <input type="text" name="ejed" class="form-control" readonly value="{{$historial->hscejeder}}">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Add</label>
                                <input type="text" name="addd" class="form-control" readonly value="{{$historial->hscaddder}}">
                            </div>
                        </div>
                    </div>
                    <h6>Ojo Izquierdo</h6>
                    <div class="row">
                        <div class="col-2">
                            <div class="form-group">
                                <label>Esferico</label>
                                <input type="text" name="esfericod2" class="form-control" readonly value="{{$historial->hscesfericoizq}}">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Cilindro</label>
                                <input type="text" name="cilindrod2" class="form-control" readonly value="{{$historial->hsccilindroizq}}">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Eje</label>
                                <input type="text" name="ejed2" class="form-control" readonly value="{{$historial->hscejeizq}}">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Add</label>
                                <input type="text" name="addd2" class="form-control" readonly value="{{$historial->hscaddizq}}">
                            </div>
                        </div>
                    </div>
                @else
                    <h6 style="color: #0AA09E; margin-left: 30px">Sin capturar</h6>
                @endif
                <h5 style="color: #0AA09E;">Con conversión</h5>
            @endif
            <div id="mostrarvision"></div>
            <h6>Ojo derecho</h6>
            <div class="row">
                <div class="col-2">
                    <div class="form-group">
                        <label>Esferico</label>
                        <input type="text" name="esfericod" class="form-control" readonly value="{{$historial->esfericoder}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Cilindro</label>
                        <input type="text" name="cilindrod" class="form-control" readonly value="{{$historial->cilindroder}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Eje</label>
                        <input type="text" name="ejed" class="form-control" readonly value="{{$historial->ejeder}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Add</label>
                        <input type="text" name="addd" class="form-control" readonly value="{{$historial->addder}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>ALT</label>
                        <input type="text" name="altd" class="form-control" readonly value="{{$historial->altder}}">
                    </div>
                </div>
            </div>
            <h6>Ojo Izquierdo</h6>
            <div class="row">
                <div class="col-2">
                    <div class="form-group">
                        <label>Esferico</label>
                        <input type="text" name="esfericod2" class="form-control" readonly value="{{$historial->esfericoizq}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Cilindro</label>
                        <input type="text" name="cilindrod2" class="form-control" readonly value="{{$historial->cilindroizq}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Eje</label>
                        <input type="text" name="ejed2" class="form-control" readonly value="{{$historial->ejeizq}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Add</label>
                        <input type="text" name="addd2" class="form-control" readonly value="{{$historial->addizq}}">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>ALT</label>
                        <input type="text" name="altd2" class="form-control" readonly value="{{$historial->altizq}}">
                    </div>
                </div>
            </div>
            <h6>Material</h6>
            <div class="row">
                <div class="col-2">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="material{{$loop->iteration}}" id="material{{$loop->iteration}}" @if($historial->material == 0) checked @endif onclick="return false;">
                        <label class="form-check-label" for="material{{$loop->iteration}}">Hi Index</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="material{{$loop->iteration}}" id="material{{$loop->iteration}}" @if($historial->material == 1) checked @endif onclick="return false;">
                        <label class="form-check-label" for="material{{$loop->iteration}}">CR</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="material{{$loop->iteration}}" id="material{{$loop->iteration}}" @if($historial->material == 2) checked @endif onclick="return false;">
                        <label class="form-check-label" for="material{{$loop->iteration}}">Policarbonato</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check">
                        <input  class="form-check-input" type="radio" name="material{{$loop->iteration}}" id="material{{$loop->iteration}}" @if($historial->material == 3) checked @endif onclick="return false;">
                        <label class="form-check-label" for="material{{$loop->iteration}}">Otro</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check">
                        <input type="text" name="motro" class="form-control" placeholder="Otro" value="{{$historial->materialotro}}" readonly>
                    </div>
                </div>
            </div>
            <h6>Tipo de bifocal</h6>
            <div class="row">
                <div class="col-2">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}" id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 0) checked @endif onclick="return false;">
                        <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                            FT
                        </label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}" id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 1) checked @endif onclick="return false;">
                        <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                            Blend
                        </label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}" id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 2) checked @endif onclick="return false;">
                        <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                            Progresivo
                        </label>
                    </div>
                </div>
                <div class="col-1">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}" id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 3) checked @endif onclick="return false;">
                        <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                            N/A
                        </label>
                    </div>
                </div>
                <div class="col-1">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}" id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 4) checked @endif onclick="return false;">
                        <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                            Otro
                        </label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="custom-control custom-checkbox">
                        <input type="text" name="otroB" class="form-control" min="0"  placeholder="Otro" value="{{$historial->bifocalotro}}" readonly>
                    </div>
                </div>
            </div>
            <h6>Tratamiento</h6>
            <div class="row">
                <div class="col-2">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input " name="fotocromatico" id="customCheck9"  @if($historial->fotocromatico == 1) checked @endif onclick="return false;">
                        <label class="custom-control-label" for="customCheck9">Fotocromatico</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input " name="ar" id="customCheck10" @if($historial->ar == 1) checked @endif onclick="return false;">
                        <label class="custom-control-label" for="customCheck10">A/R</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" name="tinte"  id="customCheck11" @if($historial->tinte == 1) checked @endif onclick="return false;">
                        <label class="custom-control-label" for="customCheck11">Tinte</label>
                    </div>
                </div>
                <div class="col-1">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" name="blueray" id="customCheck12"  @if($historial->blueray == 1) checked @endif onclick="return false;">
                        <label class="custom-control-label" for="customCheck12">BlueRay</label>
                    </div>
                </div>
                <div class="col-1">
                    <div class="custom-control custom-checkbox">
                        <input  class="custom-control-input " type="checkbox" name="otroTra" id="customCheck13" @if($historial->otroT == 1) checked @endif onclick="return false;">
                        <label class="custom-control-label" for="customCheck13">Otro</label>
                    </div>
                </div>
                <div class="col-2">
                    <div class="custom-control custom-checkbox">
                        <input type="text" name="otroT" class="form-control" min="0"  placeholder="Otro" value="{{$historial->tratamientootro}}" readonly>
                    </div>
                </div>
            </div>
            <form action="{{route('observacioninternalaboratoriohistorial',[$idContrato,$historial->id,0])}}" method="POST">
                @csrf
                <div class="row">
                    <div class="@if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9 || $contrato[0]->estatus_estadocontrato == 7)col-10 @else col-12 @endif">
                        <div class="form-group">
                            <label>Observaciones laboratorio</label>
                            <input type="text" name="observacionlaboratorio" class="form-control" value="{{$historial->observaciones}}"
                                   @if($contrato[0]->estatus_estadocontrato != 1 && $contrato[0]->estatus_estadocontrato != 9 && $contrato[0]->estatus_estadocontrato != 7) readonly @endif>
                        </div>
                    </div>
                    @if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9 || $contrato[0]->estatus_estadocontrato == 7)
                        <div class="col-2">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button class="btn btn-outline-success btn-block" type="submit">@lang('mensajes.mensajeobservacioninternaconfirmaciones')</button>
                            </div>
                        </div>
                    @endif
                </div>
            </form>
            <form action="{{route('observacioninternalaboratoriohistorial',[$idContrato,$historial->id,1])}}" method="POST">
                @csrf
                <div class="row">
                    <div class="@if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9 || $contrato[0]->estatus_estadocontrato == 7)col-10 @else col-12 @endif">
                        <div class="form-group">
                            <label>Observaciones interno</label>
                            <input type="text" name="observacioninterna" class="form-control" value="{{$historial->observacionesinterno}}"
                                   @if($contrato[0]->estatus_estadocontrato != 1 && $contrato[0]->estatus_estadocontrato != 9 && $contrato[0]->estatus_estadocontrato != 7) readonly @endif>
                        </div>
                    </div>
                    @if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9 || $contrato[0]->estatus_estadocontrato == 7)
                        <div class="col-2">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button class="btn btn-outline-success btn-block" type="submit">@lang('mensajes.mensajeobservacioninternaconfirmaciones')</button>
                            </div>
                        </div>
                    @endif
                </div>
            </form>
            @if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 9)
                @if($historial->cancelargarantia != null)
                    <form id="frmcancelargarantia"
                          action="{{route('cancelarGarantiaHistorialConfirmaciones', [$idContrato,$historial->id])}}"
                          enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                        @csrf
                        <div class="row">
                            <div class="col-4">

                                <button class="btn btn-outline-danger btn-block" name="btnSubmit"
                                        type="submit">Cancelar garantia
                                </button>

                            </div>
                        </div>
                    </form>
                @endif
            @endif
            <hr>
        @endforeach
    @else
        <div class="row">
            <div class="col-3">
                <h3 style="margin-top: 10px;">(Sin resultados)</h3>
            </div>
        </div>
        <hr>
    @endif
    @if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 9
            || $contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11)
        <form action="{{route('comentarioconfirmacion',[$idContrato])}}" method="GET">
            @csrf
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label>Comentario</label>
                        <textarea name="comentario" style="max-height: 100px;" class="form-control {!! $errors->first('comentario','is-invalid')!!}"
                                  rows="10" cols="60"></textarea>
                        {!! $errors->first('comentario','<div class="invalid-feedback">campo
                            obligatorio.</div>')!!}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12"> <button class="btn btn-outline-success btn-block" type="submit">@lang('mensajes.mensajebotonconfirmacionestadocomentario')</button></div>
            </div>
        </form>
    @endif
    <table class="table table-bordered" style="margin-top: 20px;">
        <thead>
            <tr>
                <th style =" text-align:center;" scope="col">USUARIO</th>
                <th style =" text-align:center;" scope="col">COMENTARIO</th>
                <th style =" text-align:center;" scope="col">FECHA</th>
            </tr>
        </thead>
        <tbody>
            @if(sizeof($comentarios) > 0)
                @foreach($comentarios as $comentario)
                    <tr>
                        <td align='center' style="width: 20%;">{{$comentario->name}}</td>
                        <td align='center' style="width: 60%;">{{$comentario->comentario}}</td>
                        <td align='center' style="width: 20%;">{{$comentario->fecha}}</td>
                    </tr>
                @endforeach
            @else
                <td align='center' style="width: 20%;" colspan="3">Sin registros</td>
            @endif
        </tbody>
    </table>
    <h2>Historial de movimientos de confirmaciones</h2>
    <table id="tablaHistorialC" class="table table-bordered" style="margin-bottom: 5%;">

        <thead>
        <tr>
            <th style=" text-align:center;" scope="col">Usuario</th>
            <th style=" text-align:center;" scope="col">Cambios</th>
            <th style=" text-align:center;" scope="col">Fecha</th>
        </tr>
        </thead>

        <tbody>
        @if(sizeof($historialcontrato) > 0)
            @foreach($historialcontrato as $hc)
                <tr>
                    <td align='center'>{{$hc->name}}</td>
                    <td align='center'>{{$hc->cambios}}</td>
                    <td align='center'>{{$hc->created_at}}</td>
                </tr>
            @endforeach
        @else
            <td align='center' colspan="3">Sin registros</td>
        @endif
        </tbody>
    </table>
    @if($garantia == null)
        @if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9)
            <div class="row">
                <div class="col-12">
                    <a class="btn btn-outline-danger btn-block" data-toggle="modal" data-target="#rechazarContrato">RECHAZAR
                        CONTRATO</a>
                </div>
            </div>
            <!-- modal para Rechazar contratos -->
            <div class="modal fade" id="rechazarContrato" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                 aria-hidden="true">
                <form action="{{route('rechazarContratoConfirmaciones',[$idContrato])}}" enctype="multipart/form-data"
                      method="POST" onsubmit="btnSubmit.disabled = true;">
                    @csrf
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                Solicitud de confirmación
                            </div>
                            <div class="modal-body">
                                ¿Deseas rechazar este contrato?
                                <br>
                                <br>
                                Especifique sus razones:
                                <textarea name="comentarios"
                                          class="form-control {!! $errors->first('comentarios','is-invalid')!!}" rows="10"
                                          cols="60"></textarea>
                                {!! $errors->first('comentarios','<div class="invalid-feedback">Campo
                                    obligatorio</div>')!!}
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                                <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        @endif
    @endif

    <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <img src="" class="imagepreview" style="width: 100%; margin-top: 60px; margin-bottom: 60px; cursor: grabbing">
                </div>
            </div>
        </div>
    </div>

@endsection
