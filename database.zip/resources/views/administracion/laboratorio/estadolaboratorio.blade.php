@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <div class="row">
        <div class="col-2">
            <h2>@lang('mensajes.mensajecontrato')</h2>
        </div>
        <div class="col-3">
            <img hidden style="display: block;" id="imgImprimir" src="data:image/png;base64,{{DNS1D::getBarcodePNG($idContrato, 'C39')}}" alt="barcode" onclick="imprimir();"/><br><br>
        </div>
    </div>
    <form action="{{route('estadolaboratorioactualizar',[$idContrato])}}" method="POST" onsubmit="btnSubmit.disabled = true;" >
        @csrf
        <div class="row">
            <div class="col-2">
                <label for="contrato">Contrato</label>
                <input name="contrato" type="text" readonly class="form-control" placeholder="Contrato" value="{{$contrato[0]->id}}">
            </div>
            <div class="col-2">
                <label for="contrato">Sucursal</label>
                <input name="contrato" type="text" readonly class="form-control" placeholder="Contrato" value="{{$contrato[0]->ciudad}}">
            </div>
            <div class="col-2">
                <label for="contrato">Fecha</label>
                <input name="contrato" type="text" readonly class="form-control" placeholder="Contrato" value="{{$contrato[0]->fecha}}">
            </div>
            <div class="col-2">
                <label for="estatusactual">Estatus actual</label>
                @if($contrato[0]->estatus_estadocontrato == 7)
                    <td align='center'><button type="button" class="btn btn-primary btn-block aprobado" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button></td>
                @endif
                @if($contrato[0]->estatus_estadocontrato == 10)
                    <td align='center'> <button type="button" class="btn btn-warning btn-block manofactura" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button></td>
                @endif
                @if($contrato[0]->estatus_estadocontrato == 11)
                    <td align='center'> <button type="button" class="btn btn-info btn-block enprocesodeenvio" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button></td>
                @endif
                @if(($contrato[0]->estatus_estadocontrato != 7) && ($contrato[0]->estatus_estadocontrato != 10) && ($contrato[0]->estatus_estadocontrato != 11))
                    <td align='center'><button type="button" class="btn btn-secondary btn-block" style="color:#FEFEFE;">{{$contrato[0]->descripcion}}</button></td>
                @endif
            </div>
            @if($contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11)
            <div class="col-2">
                <label for="estatus">Estatus del contrato</label>
                <select class="custom-select {!! $errors->first('estatus','is-invalid')!!}" name="estatus">
                    <option value="a" selected>Seleccionar</option>
                    @if($contrato[0]->estatus_estadocontrato == 7)
                        <option value="10" >Manofactura</option>
                        <option value="11" >En proceso de envio</option>
                        <option value="12" >Enviado</option>
                    @endif
                    @if($contrato[0]->estatus_estadocontrato == 10)
                        <option value="11" >En proceso de envio</option>
                        <option value="12" >Enviado</option>
                    @endif
                    @if($contrato[0]->estatus_estadocontrato == 11)
                        <option value="12" >Enviado</option>
                    @endif
                </select>
                {!! $errors->first('estatus','<div class="invalid-feedback">Por favor, selecciona un estatus valido.</div>')!!}
            </div>
            <div class="col-2"><label>&nbsp;</label><button class="btn btn-outline-success" name="btnSubmit" type="submit">@lang('mensajes.mensajebotonconfirmacionestado')</button></div>
            @endif
        </div>
    </form>
    @php($contador = 1)
    @foreach($historialClinico as $historial)
        <div class="row" style="margin-top: 20px;">
            <div class="col-2">
                <h3>@lang('mensajes.mensajetituloreceta') {{$loop->iteration}} ({{$historial->id}})</h3>
                <h5 style="color: #0AA09E;"><br>
                    @if($historial->garantia != null)" Garantía - {{$historial->optogarantia}} " @endif
                    @if($historial->garantia == null) " Optometrista - {{$historial->optocontrato}} " @endif </br> </h5>
            </div>
            <div class="col-2">
                <h3> Modelo: {{$historial->armazon}}</h3>
            </div>
            <div class="col-2">
                <h3>Color: {{$historial->colorarmazon}}</h3>
            </div>
            <div class="col-2">
                <h3>Piezas restantes: {{$historial->piezasr}}</h3>
            </div>
            <div class="col-2">
                <button class="btn btn-outline-success btn-block" id="idhistorial{{$historial->id}}"
                   onclick="imprimir('{{$historial->id}}');">Imprimir ticket</button>
            </div>
            <div class="col-2">
                <button class="btn btn-outline-success btn-block" id="idhistorial{{$historial->id}}"
                        onclick="imprimirEtiqueta();">Imprimir etiqueta</button>
            </div>
        </div>
        <div id="mostrarvision"></div>
        <h6>Ojo derecho</h6>
        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <label>Esferico</label>
                    <input type="text" name="esfericod" class="form-control" readonly value="{{$historial->esfericoder}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Cilindro</label>
                    <input type="text" name="cilindrod" class="form-control" readonly value="{{$historial->cilindroder}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Eje</label>
                    <input type="text" name="ejed" class="form-control" readonly value="{{$historial->ejeder}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Add</label>
                    <input type="text" name="addd" class="form-control" readonly value="{{$historial->addder}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>ALT</label>
                    <input type="text" name="altd" class="form-control" readonly value="{{$historial->altder}}">
                </div>
            </div>
        </div>
        <h6>Ojo Izquierdo</h6>
        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <label>Esferico</label>
                    <input type="text" name="esfericod2" class="form-control" readonly value="{{$historial->esfericoizq}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Cilindro</label>
                    <input type="text" name="cilindrod2" class="form-control" readonly value="{{$historial->cilindroizq}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Eje</label>
                    <input type="text" name="ejed2" class="form-control" readonly value="{{$historial->ejeizq}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Add</label>
                    <input type="text" name="addd2" class="form-control" readonly value="{{$historial->addizq}}">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>ALT</label>
                    <input type="text" name="altd2" class="form-control" readonly value="{{$historial->altizq}}">
                </div>
            </div>
        </div>
        <h6>Material</h6>
        <div class="row">
            <div class="col-2">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="material{{$historial->id}}" @if($historial->material == 0) checked @endif onclick="return false;">
                    <label class="form-check-label" for="material{{$historial->id}}">Hi Index</label>
                </div>
            </div>
            <div class="col-2">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="material{{$historial->id}}" @if($historial->material == 1) checked @endif onclick="return false;">
                    <label class="form-check-label" for="material{{$historial->id}}">CR</label>
                </div>
            </div>
            <div class="col-2">
                <div class="form-check">
                    <input  class="form-check-input" type="radio" name="material{{$historial->id}}" @if($historial->material == 3) checked @endif onclick="return false;">
                    <label class="form-check-label" for="material{{$historial->id}}">Otro</label>
                </div>
            </div>
            <div class="col-2">
                <div class="form-check">
                    <input type="text" name="motro" class="form-control" placeholder="Otro" value="{{$historial->materialotro}}" readonly>
                </div>
            </div>
        </div>
        <h6>Tipo de bifocal</h6>
        <div class="row">
            <div class="col-2">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bifocal" id="exampleRadios1" @if($historial->bifocal == 0) checked @endif onclick="return false;">
                    <label class="form-check-label" for="exampleRadios1">
                        FT
                    </label>
                </div>
            </div>
            <div class="col-2">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bifocal" id="exampleRadios1" @if($historial->bifocal == 1) checked @endif onclick="return false;">
                    <label class="form-check-label" for="exampleRadios1">
                        Blend
                    </label>
                </div>
            </div>
            <div class="col-2">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bifocal" id="exampleRadios1" @if($historial->bifocal == 2) checked @endif onclick="return false;">
                    <label class="form-check-label" for="exampleRadios1">
                        Progresivo
                    </label>
                </div>
            </div>
            <div class="col-1">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bifocal" id="exampleRadios1" @if($historial->bifocal == 3) checked @endif onclick="return false;">
                    <label class="form-check-label" for="exampleRadios1">
                        N/A
                    </label>
                </div>
            </div>
            <div class="col-1">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bifocal" id="exampleRadios1" @if($historial->bifocal == 4) checked @endif onclick="return false;">
                    <label class="form-check-label" for="exampleRadios1">
                        Otro
                    </label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="text" name="otroB" class="form-control" min="0"  placeholder="Otro" value="{{$historial->bifocalotro}}" readonly>
                </div>
            </div>
        </div>
        <h6>Tratamiento</h6>
        <div class="row">
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input " name="fotocromatico" id="customCheck9"  @if($historial->fotocromatico == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="customCheck9">Fotocromatico</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input " name="ar" id="customCheck10" @if($historial->ar == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="customCheck10">A/R</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" name="tinte"  id="customCheck11" @if($historial->tinte == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="customCheck11">Tinte</label>
                </div>
            </div>
            <div class="col-1">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" name="blueray" id="customCheck12"  @if($historial->blueray == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="customCheck12">BlueRay</label>
                </div>
            </div>
            <div class="col-1">
                <div class="custom-control custom-checkbox">
                    <input  class="custom-control-input " type="checkbox" name="otroTra" id="customCheck13" @if($historial->otroT == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="customCheck13">Otro</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="text" name="otroT" class="form-control" min="0"  placeholder="Otro" value="{{$historial->tratamientootro}}" readonly>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label>Observaciones</label>
                    <input type="text" name="cilindrod2" class="form-control" readonly value="{{$historial->observaciones}}">
                </div>
            </div>
        </div>
        <hr>
        @if($historial->garantia != null)
        <form id="frmcancelargarantia"
              action="{{route('cancelarGarantiaHistorialLaboratorio',[$idContrato, $historial->id])}}"
              enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="row">
                <div class="col-4">

                    <button class="btn btn-outline-danger btn-block" name="btnSubmit"
                            type="submit">Cancelar garantia
                    </button>

                </div>
            </div>
        </form>
        @endif
    @endforeach
    <form action="{{route('comentariolaboratorio',[$idContrato])}}" method="GET" onsubmit="btnSubmit.disabled = true;" >
        @csrf
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label>Comentario</label>
                    <textarea name="comentario" style="max-height: 100px;" class="form-control {!! $errors->first('comentario','is-invalid')!!}"
                              rows="10" cols="60"></textarea>
                    {!! $errors->first('comentario','<div class="invalid-feedback">campo
                        obligatorio.</div>')!!}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12"> <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">@lang('mensajes.mensajebotonconfirmacionestadocomentario')</button></div>
        </div>
    </form>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th style =" text-align:center;" scope="col">USUARIO</th>
            <th style =" text-align:center;" scope="col">COMENTARIO</th>
            <th style =" text-align:center;" scope="col">FECHA</th>
        </tr>
        </thead>
        <tbody>
        @foreach($comentarios as $comentario)
            <tr>
                <td align='center' style="width: 20%;">{{$comentario->name}}</td>
                <td align='center' style="width: 60%;">{{$comentario->comentario}}</td>
                <td align='center' style="width: 20%;">{{$comentario->fecha}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <h2>@lang('mensajes.mensajehistoriallaboratorio')</h2>
    <table id="tablaHistorialC" class="table table-bordered" style="margin-bottom: 5%;">

            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">Usuario</th>
                <th style=" text-align:center;" scope="col">Cambios</th>
                <th style=" text-align:center;" scope="col">Fecha</th>
            </tr>
            </thead>

        <tbody>
        @foreach($historialcontrato as $hc)
            <tr>
                <td align='center'>{{$hc->name}}</td>
                <td align='center'>{{$hc->cambios}}</td>
                <td align='center'>{{$hc->created_at}}</td>
            </tr>
        @endforeach
        @if(sizeof($historialcontrato) == 0)
            <td align='center' colspan="3">Sin registros</td>
        @endif
        </tbody>
    </table>
    @if($garantia == null)
    <div class="row">
        <div class="col-12">
            <a class="btn btn-outline-danger btn-block" data-toggle="modal" data-target="#rechazarContrato">RECHAZAR
                CONTRATO</a>
        </div>
    </div>
    @endif

    <!-- modal para Rechazar contratos -->
    <div class="modal fade" id="rechazarContrato" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="{{route('rechazarContratoLaboratorio',[$idContrato])}}" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Solicitud de confirmación
                    </div>
                    <div class="modal-body">
                        ¿Deseas rechazar este contrato?
                        <br>
                        <br>
                        Especifique sus razones:
                        <textarea name="comentarios"
                                  class="form-control {!! $errors->first('comentarios','is-invalid')!!}" rows="10"
                                  cols="60"></textarea>
                        {!! $errors->first('comentarios','<div class="invalid-feedback">Campo
                            obligatorio</div>')!!}
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <hr>
    <img hidden id="logo" src="/imagenes/general/administracion/logo.png" alt="">
@endsection
<script>
    {{-- Datos para imprimir historial ticket --}}
    var cuidad = "{{$contrato[0]->ciudad}}";
    var zona = "{{$contrato[0]->zona}}";
    var idHistorial1 = "{{$idHistorial1}}";
    var fechaEntregaHistorial1 = "{{$fechaEntregaHistorial1}}";
    var nombreProducto1 = "{{$nombreProducto1}}";
    var colorProducto1 = "{{$colorProducto1}}";
    var observacionesHistorial1 = "{{$observacionesHistorial1}}";
    var esfericoder1 = "{{$esfericoder1}}";
    var cilindroder1 = "{{$cilindroder1}}";
    var ejeder1 = "{{$ejeder1}}";
    var addder1 = "{{$addder1}}";
    var altder1 = "{{$altder1}}";
    var esfericoizq1 = "{{$esfericoizq1}}";
    var cilindroizq1 = "{{$cilindroizq1}}";
    var ejeizq1 = "{{$ejeizq1}}";
    var addizq1 = "{{$addizq1}}";
    var altizq1 = "{{$altizq1}}";
    var material1 = "{{$material1}}";
    var bifocal1 = "{{$bifocal1}}";
    var tratamientos1 = "{{$tratamientos1}}";
    var idHistorial2 = "{{$idHistorial2}}";
    var fechaEntregaHistorial2 = "{{$fechaEntregaHistorial2}}";
    var nombreProducto2 = "{{$nombreProducto2}}";
    var colorProducto2 = "{{$colorProducto2}}";
    var observacionesHistorial2 = "{{$observacionesHistorial2}}";
    var esfericoder2 = "{{$esfericoder2}}";
    var cilindroder2 = "{{$cilindroder2}}";
    var ejeder2 = "{{$ejeder2}}";
    var addder2 = "{{$addder2}}";
    var altder2 = "{{$altder2}}";
    var esfericoizq2 = "{{$esfericoizq2}}";
    var cilindroizq2 = "{{$cilindroizq2}}";
    var ejeizq2 = "{{$ejeizq2}}";
    var addizq2 = "{{$addizq2}}";
    var altizq2 = "{{$altizq2}}";
    var material2 = "{{$material2}}";
    var bifocal2 = "{{$bifocal2}}";
    var tratamientos2 = "{{$tratamientos2}}";
    var idcontrato = "{{$idContrato}}";
    var estadoGarantia = "{{$estadoGarantia}}";

    {{-- Datos para imprimir etiqueta --}}
    var localidadcontrato = "{{$contrato[0]->localidad}}";
    var coloniacontrato = "{{$contrato[0]->colonia}}";
    var callecontrato = "{{$contrato[0]->calle}}";
    var entrecallescontrato = "{{$contrato[0]->entrecalles}}";
    var numerocontrato = "{{$contrato[0]->numero}}";
    var departamentocontrato = "{{$contrato[0]->depto}}";
    var telefonocontrato = "{{$contrato[0]->telefono}}";
    var nombrecontrato = "{{$contrato[0]->nombre}}";
    var comentarioscontrato = "{{$comentariosContrato}}";
</script>

