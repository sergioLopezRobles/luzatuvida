@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <div class="row">
        <div class="col-8">
            <h2 style="text-align: left; color: #0AA09E">@lang('mensajes.mensajedispositivos')</h2>
        </div>
        <div class="col-2">
            <a type="button" class="btn btn-outline-success btn-block" href="{{route('configuracion')}}">Configuración</a>
        </div>
        <div class="col-2">
            <a type="button" class="btn btn-outline-success btn-block" href="{{route('dispositivonuevo')}}">Nuevo dispositivo</a>
        </div>
    </div>
    <table id="tablaContratos" class="table table-bordered">
        <thead>
            <tr>
                <th  style =" text-align:center;" scope="col">ESTATUS</th>
                <th  style =" text-align:center;" scope="col">IDENTIFICADOR</th>
                <th  style =" text-align:center;" scope="col">TITULO</th>
                <th  style =" text-align:center;" scope="col">DESCRIPCION</th>
                <th  style =" text-align:center;" scope="col">VERSION</th>
                <th  style =" text-align:center;" scope="col">APLICACION</th>
                <th  style =" text-align:center;" scope="col">ACTIVAR/DESACTIVAR</th>
            </tr>
        </thead>
        <tbody>
            @foreach($dispositivos as $dispositivo)
            <tr>
                @if($dispositivo->estatus  == 1)
                    <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                @else
                    <td align='center' ><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                @endif
                <td align='center'>{{$dispositivo->id}}</td>
                <td align='center'>{{$dispositivo->titulo}}</td>
                <td align='center'>{{$dispositivo->descripcion}}</td>
                <td align='center'>{{$dispositivo->version}}</td>
                <td align='center'><a href="{{$dispositivo->apk}}" class="btn btn-outline-primary w-100" role="button" aria-pressed="true" style="font-size: 15px;">DESCARGAR APLICACION</a></td>
                @if($dispositivo->estatus  == 1 )
                    <td align='center'> <a href="{{route('dispositivoestatus',[$dispositivo->id,$dispositivo->estatus])}}" class="btn btn-danger">DESACTIVAR</a></td>
                @else
                    <td align='center'> <a href="{{route('dispositivoestatus',[$dispositivo->id,$dispositivo->estatus])}}" class="btn btn-primary">ACTIVAR</a></td>
                @endif
            </tr>
            @endforeach
        </tbody>
    </table>
@endsection
