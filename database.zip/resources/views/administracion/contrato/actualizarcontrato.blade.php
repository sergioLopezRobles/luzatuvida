@extends('layouts.app')
@section('titulo','Actualizar contrato'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    <!-- {{isset($errors)? var_dump($errors) : ''}} -->
    <div class="contenedor">
        <h2>@lang('mensajes.mensajeactuzalizarcontrato')</h2>
        <form id="frmFranquiciaNueva" action="{{route('contratoeditar',[$idFranquicia,$contrato[0]->id])}}"
              enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="franquicia">
                <div class="row">
                    <div class="col-1">
                        <div class="form-group">
                            <label>Contrato</label>
                            <input type="text" name="id"
                                   class="form-control"
                                   placeholder="Contrato" readonly value="{{$contrato[0]->id}}">
                        </div>
                    </div>
                    <div class="col-1">
                        <label for="">Zona</label>
                        <select class="custom-select" name="zona">
                            @if(count($zonas) > 0)
                                <option selected>Seleccionar</option>
                                @foreach($zonas as $zona)
                                    <option
                                        value="{{$zona->id}}" {{ isset($contrato) ? ($contrato[0]->id_zona== $zona->id ? 'selected' : '' ) : '' }}>{{$zona->zona}}</option>
                                @endforeach
                            @else
                                <option selected>Sin registros</option>
                            @endif
                        </select>
                    </div>
                    <div class="col-2">
                        <label for="">Optometrista</label>
                        @if(($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $numTotalGarantias[0]->numTotalGarantias == 0)
                            <select class="custom-select" name="optometrista">
                                <option selected
                                        value="{{$contrato[0]->id_optometrista}}">{{$contrato[0]->nombreopto}}</option>
                                @foreach($optometristas as $optometrista)
                                    @if($optometrista->ID == $contrato[0]->id_optometrista)
                                        @continue
                                    @else
                                        <option value="{{$optometrista->ID}}">{{$optometrista->NAME}}</option>
                                @endif
                            @endforeach
                            <!-- <option selected>Sin registros</option> -->
                            </select>
                        @else
                            <input type="text" class="form-control" readonly value="{{$contrato[0]->nombreopto}}">
                        @endif
                    </div>
                    <div class="col-2">
                        <label for="">Asistente</label>
                        @if(($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $numTotalGarantias[0]->numTotalGarantias == 0)
                            <select class="custom-select" name="asistente">
                                <option selected
                                        value="{{$contrato[0]->id_usuariocreacion}}">{{$contrato[0]->nombre_usuariocreacion}}</option>
                                @foreach($asistentes as $asistente)
                                    @if($asistente->ID == $contrato[0]->id_usuariocreacion)
                                        @continue
                                    @else
                                        <option value="{{$asistente->ID}}">{{$asistente->NAME}}</option>
                                    @endif
                                @endforeach
                            <!-- <option selected>Sin registros</option> -->
                            </select>
                        @else
                            <input type="text" class="form-control" readonly value="{{$contrato[0]->nombre_usuariocreacion}}">
                        @endif
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Nombre del paciente</label>
                            <input type="text" name="nombre"
                                   class="form-control {!! $errors->first('nombre','is-invalid')!!}"
                                   placeholder="Nombre" value="{{$contrato[0]->nombre}}">
                            {!! $errors->first('nombre','<div class="invalid-feedback">El nombre es obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Calle</label>
                            <input type="text" name="calle"
                                   class="form-control {!! $errors->first('calle','is-invalid')!!}" placeholder="Calle"
                                   value="{{$contrato[0]->calle}}">
                            {!! $errors->first('calle','<div class="invalid-feedback">La calle es obligatoria.</div>')!!}
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-1">
                        <div class="form-group">
                            <label>Numero</label>
                            <input type="text" name="numero"
                                   class="form-control {!! $errors->first('numero','is-invalid')!!}"
                                   placeholder="Numero" value="{{$contrato[0]->numero}}">
                            {!! $errors->first('numero','<div class="invalid-feedback">El numero es obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Departamento</label>
                            <input type="text" name="departamento" class="form-control" placeholder="Departamento"
                                   value="{{$contrato[0]->depto}}">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label id="alladode">Al lado de</label>
                            <input type="text" name="alladode"
                                   class="form-control {!! $errors->first('alladode','is-invalid')!!}"
                                   placeholder="Al lado de" value="{{$contrato[0]->alladode}}">
                            {!! $errors->first('alladode','<div class="invalid-feedback">Campo obligatorio</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Frente a</label>
                            <input type="text" name="frentea"
                                   class="form-control {!! $errors->first('frentea','is-invalid')!!}"
                                   placeholder="Frente a" value="{{$contrato[0]->frentea}}">
                            {!! $errors->first('frentea','<div class="invalid-feedback">Campo obligatorio</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Ubicacion</label>
                            <input type="text" name="coordenadas"
                                   class="form-control {!! $errors->first('coordenadas','is-invalid')!!}"
                                   placeholder="Coordenadas"
                                   value="{{$contrato[0]->coordenadas}}">
                            {!! $errors->first('coordenadas','<div class="invalid-feedback">Campo obligatorio</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <a href="{{url('https://www.google.com/maps/place?key=AIzaSyC4wzK36yxyLG6yzpqUPnV4j8Y74aKkq-M&q=' . $contrato[0]->coordenadas)}}"
                           target="_blank">
                            <button type="button" class="btn btn-outline-success">Ver ubicación</button>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label>Entre calles</label>
                            <input type="text" name="entrecalles"
                                   class="form-control {!! $errors->first('entrecalles','is-invalid')!!}"
                                   placeholder="Entre calles" value="{{$contrato[0]->entrecalles}}">
                            {!! $errors->first('entrecalles','<div class="invalid-feedback">El campo es obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Colonia</label>
                            <input type="text" name="colonia"
                                   class="form-control {!! $errors->first('colonia','is-invalid')!!}"
                                   placeholder="Colonia" value="{{$contrato[0]->colonia}}">
                            {!! $errors->first('colonia','<div class="invalid-feedback">La colonia es obligatoria.</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Localidad</label>
                            <input type="text" name="localidad"
                                   class="form-control {!! $errors->first('localidad','is-invalid')!!}"
                                   placeholder="Localidad" value="{{$contrato[0]->localidad}}">
                            {!! $errors->first('localidad','<div class="invalid-feedback">La localidad es obligatoria.</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Telefono</label>
                            <input type="text" name="telefono"
                                   class="form-control {!! $errors->first('telefono','is-invalid')!!}"
                                   placeholder="Telefono" value="{{$contrato[0]->telefono}}">
                            {!! $errors->first('telefono','<div class="invalid-feedback">El telefono debe contener 10 numeros.</div>')!!}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tipo Casa</label>
                            <input type="text" name="casatipo"
                                   class="form-control {!! $errors->first('casatipo','is-invalid')!!}"
                                   placeholder="Tipo Casa" value="{{$contrato[0]->casatipo}}">
                            {!! $errors->first('casatipo','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Casa color</label>
                            <input type="text" name="casacolor"
                                   class="form-control {!! $errors->first('casacolor','is-invalid')!!}"
                                   placeholder="Casa color" value="{{$contrato[0]->casacolor}}">
                            {!! $errors->first('casacolor','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Nombre referencia</label>
                            <input type="text" name="nr" class="form-control {!! $errors->first('nr','is-invalid')!!}"
                                   placeholder="Nombre de referencia" value="{{$contrato[0]->nombrereferencia}}">
                            {!! $errors->first('nr','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Telefono referencia</label>
                            <input type="text" name="tr" class="form-control {!! $errors->first('tr','is-invalid')!!}"
                                   placeholder="Telefono de referencia" value="{{$contrato[0]->telefonoreferencia}}">
                            {!! $errors->first('tr','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Correo electronico</label>
                            <input type="text" name="correo"
                                   class="form-control {!! $errors->first('correo','is-invalid')!!}"
                                   placeholder="Correo electronico" value="{{$contrato[0]->correo}}">
                            {!! $errors->first('correo','<div class="invalid-feedback">Ingresar un corrreo electronico valido</div>')!!}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto INE Frente:</label>
                            <input type="file" name="fotoine"
                                   class="form-control-file {!! $errors->first('fotoine','is-invalid')!!} @if($contrato[0]->fotoine != '') is-valid @endif"
                                   accept="image/jpg">
                            {!! $errors->first('fotoine','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto INE Atrás</label>
                            <input type="file" name="fotoineatras"
                                   class="form-control-file  {!! $errors->first('fotoineatras','is-invalid')!!} @if($contrato[0]->fotoineatras != '') is-valid @endif"
                                   accept="image/jpg">
                            {!! $errors->first('fotoineatras','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Pagare:</label>
                            <input type="file" name="pagare"
                                   class="form-control-file  {!! $errors->first('pagare','is-invalid')!!} @if($contrato[0]->pagare != '') is-valid @endif"
                                   accept="image/jpg">
                            {!! $errors->first('pagare','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto de la casa</label>
                            <input type="file" name="fotocasa"
                                   class="form-control-file {!! $errors->first('fotocasa','is-invalid')!!} @if($contrato[0]->fotocasa != '') is-valid @endif"
                                   accept="image/jpg">
                            {!! $errors->first('fotocasa','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Comprobante de domicilio</label>
                            <input type="file" name="comprobantedomicilio"
                                   class="form-control-file {!! $errors->first('comprobantedomicilio','is-invalid')!!} @if($contrato[0]->comprobantedomicilio != '') is-valid @endif"
                                   accept="image/jpg">
                            {!! $errors->first('comprobantedomicilio','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tarjeta de pension frente</label>
                            <input type="file" name="tarjeta"
                                   class="form-control-file {!! $errors->first('tarjeta','is-invalid')!!} @if($contrato[0]->tarjeta != '') is-valid @endif"
                                   accept="image/jpg">
                            {!! $errors->first('tarjeta','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img1" style="cursor: pointer">
                    <img src="{{asset($contrato[0]->fotoine)}}" style="width:250px;height:250px;" class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img2" style="cursor: pointer">
                    <img src="{{asset($contrato[0]->fotoineatras)}}" style="width:250px;height:250px;"
                         class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img3" style="cursor: pointer">
                    <img src="{{asset($contrato[0]->pagare)}}" style="width:250px;height:250px;" class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img4" style="cursor: pointer">
                    <img src="{{asset($contrato[0]->fotocasa)}}" style="width:250px;height:250px;"
                         class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img5" style="cursor: pointer">
                    <img src="{{asset($contrato[0]->comprobantedomicilio)}}" style="width:250px;height:250px;"
                         class="img-thumbnail">
                </div>
                @if($contrato[0]->tarjeta != '')
                    <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img6" style="cursor: pointer">
                        <img src="{{asset($contrato[0]->tarjeta)}}" style="width:250px;height:250px;"
                             class="img-thumbnail">
                    </div>
                @endif
            </div>
            <div class="row" style="margin-top: 10px;">
                <div class="col-2">
                    <div class="form-group">
                        <label>Tarjeta de pension atras</label>
                        <input type="file" name="tarjetapensionatras"
                               class="form-control-file {!! $errors->first('tarjetapensionatras','is-invalid')!!} @if($contrato[0]->tarjetapensionatras != '') is-valid @endif"
                               accept="image/jpg">
                        {!! $errors->first('tarjetapensionatras','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                        <div class="valid-feedback"><a class='fas fa-check'></a></div>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Otros</label>
                        <input type="file" name="fotootros"
                               class="form-control-file {!! $errors->first('fotootros','is-invalid')!!} @if($contrato[0]->fotootros != '') is-valid @endif"
                               accept="image/jpg">
                        {!! $errors->first('fotootros','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>')!!}
                        <div class="valid-feedback"><a class='fas fa-check'></a></div>
                    </div>
                </div>
            </div>
            <div class="row" style="padding-bottom: 10px;">
                @if($contrato[0]->tarjetapensionatras != '' || $contrato[0]->fotootros != '')
                    @if($contrato[0]->tarjetapensionatras != '' && $contrato[0]->fotootros != '')
                        <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img7"
                             style="cursor: pointer">
                            <img src="{{asset($contrato[0]->tarjetapensionatras)}}" style="width:250px;height:250px;"
                                 class="img-thumbnail">
                        </div>
                        <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img8"
                             style="cursor: pointer">
                            <img src="{{asset($contrato[0]->fotootros)}}" style="width:250px;height:250px;"
                                 class="img-thumbnail">
                        </div>
                    @else
                        @if($contrato[0]->tarjetapensionatras != '')
                            <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img7"
                                 style="cursor: pointer">
                                <img src="{{asset($contrato[0]->tarjetapensionatras)}}"
                                     style="width:250px;height:250px;" class="img-thumbnail">
                            </div>
                        @else
                            <div class="col-2"></div>
                            <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img8"
                                 style="cursor: pointer">
                                <img src="{{asset($contrato[0]->fotootros)}}" style="width:250px;height:250px;"
                                     class="img-thumbnail">
                            </div>
                        @endif
                    @endif
                @endif
            </div>
            <div class="row">
                <div class="col">
                    <button class="btn btn-outline-success btn-block" name="btnSubmit"
                            type="submit">@lang('mensajes.mensajeactuzalizarcontrato')</button>
                </div>
            </div>
        </form>
        <form action="{{route('agregarnota',[$idFranquicia,$contrato[0]->id])}}"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="row">
                <div class="col-10">
                    <div class="form-group">
                        <label>Nota del cobrador</label>
                        <input type="text" name="nota" maxlength="255"
                               class="form-control {!! $errors->first('nota','is-invalid')!!}"
                               placeholder="Nota del cobrador" value="{{$contrato[0]->nota}}">
                        {!! $errors->first('nota','<div class="invalid-feedback">No puede superar los 255 caracteres.</div>')!!}
                    </div>
                </div>
                <div class="col-2">
                    <button class="btn btn-outline-success btn-block" name="btnSubmit"
                            type="submit">@lang('mensajes.mensajeactualizarnota')</button>
                </div>
            </div>
        </form>
        <hr>
        <h2>Información diagnóstico</h2>
        <div class="row">
            <div class="col-3">
                <div class="form-group">
                    <label>Edad</label>
                    <input type="text" name="edad" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->edad}}">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Diagnóstico</label>
                    <input type="text" name="diagnostico" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->diagnostico}}">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Ocupación</label>
                    <input type="text" name="ocupacion" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->ocupacion}}">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Diabetes</label>
                    <input type="text" name="diabetes" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->diabetes}}">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <label>Hipertensión</label>
                    <input type="text" name="hipertension" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->hipertension}}">
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label>¿Se encuentra embarazada?</label>
                    <input type="text" name="embarazada" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->embarazada}}">
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label>¿Durmió de 6 a 8 horas?</label>
                    <input type="text" name="durmioseisochohoras" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->durmioseisochohoras}}">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label>Principal actividad en el día</label>
                    <input type="text" name="actividaddia" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->actividaddia}}">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label>Principal problema que padece en sus ojos</label>
                    <input type="text" name="problemasojos" class="form-control" readonly value="{{$datosDiagnosticoHistorial[0]->problemasojos}}">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-10">
                <h6>Molestia</h6>
            </div>
            <div class="col-2">
                <h6>Último examen</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input " name="dolor" id="dolor"  @if($datosDiagnosticoHistorial[0]->dolor == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="dolor">Dolor de cabeza</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input " name="ardor" id="ardor" @if($datosDiagnosticoHistorial[0]->ardor == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="ardor">Ardor en los ojos</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" name="golpeojos"  id="golpeojos" @if($datosDiagnosticoHistorial[0]->golpeojos == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="golpeojos">Golpe en cabeza</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input  class="custom-control-input " type="checkbox" name="otroM" id="otroM" @if($datosDiagnosticoHistorial[0]->otroM == 1) checked @endif onclick="return false;">
                    <label class="custom-control-label" for="otroM">Otro</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="text" name="molestiaotro" class="form-control" min="0"  placeholder="Otro" value="{{$datosDiagnosticoHistorial[0]->molestiaotro}}" readonly>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <input type="text" name="ultimoexamen" class="form-control" min="0"  placeholder="" value="{{$datosDiagnosticoHistorial[0]->ultimoexamen}}" readonly>
                </div>
            </div>
        </div>
        <hr>
        <h4 style="margin-top: 10px">Total garantias: {{$numTotalGarantias[0]->numTotalGarantias}}</h4>
        @php($contador = 1)
        @if(isset($historiales))
            @foreach($historiales as $historial)
                @if($historial->tipo == 0)
                    <h4 style="margin-top: 10px">Garantias: {{$historial->numGarantias}}</h4>
                @endif
                <div class="row">
                    <div class="col-2">
                        @switch($historial->tipo)
                            @case(0)
                            <h4 style="margin-top: 10px;">@lang('mensajes.mensajetituloreceta') {{$loop->iteration}}
                                ({{$historial->id}})</h4>
                            @break
                            @case(1)
                            <h4 style="margin-top: 10px;">@lang('mensajes.mensajetituloreceta') {{$loop->iteration}}
                                ({{$historial->id}}) "Garantía de {{$historial->idhistorialpadre}}"</h4>
                            @break
                            @case(2)
                            <h4 style="margin-top: 10px;">@lang('mensajes.mensajetituloreceta') {{$loop->iteration}}
                                ({{$historial->id}}) "Cambio paquete"</h4>
                            @break
                        @endswitch
                    </div>
                    <div class="col-2">
                        <h4 style="margin-top: 10px;">Modelo: {{$historial->armazon}}</h4>
                    </div>
                    <div class="col-4">
                        <h4 style="margin-top: 10px;">Color: {{$historial->colorarmazon}}</h4>
                    </div>
                    @if($loop->iteration == 1)
                        <div class="col-2">
                            <h4 style="margin-top: 10px;">Paquete: {{$historial->paquete}}</h4>
                        </div>
                    @endif
                </div>
                @if($contrato[0]->estatus_estadocontrato <= 1 || $contrato[0]->estatus_estadocontrato == 9)
                    <form id="frmarmazon" action="{{route('editarHistorialArmazon',[$idFranquicia,$idContrato,$historial->id])}}"
                          enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                        @csrf
                        <div class="row">
                            <div class="col-4">
                                <label for="">Armazón</label>
                                <select class="custom-select {!! $errors->first('producto','is-invalid')!!}"
                                        name="producto">
                                    @if(count($armazones) > 0)
                                        <option selected value='nada'>Seleccionar</option>
                                        @foreach($armazones as $armazon)
                                            @if($armazon->id_tipoproducto == 1 && $armazon->estado == 1 && $armazon->piezas > 0)
                                                @if($armazon->id == $historial->id_producto)
                                                    <option selected value="{{$armazon->id}}">
                                                        {{$armazon->nombre}} | {{$armazon->color}}
                                                        | {{$armazon->piezas}}pza.
                                                    </option>
                                                @else
                                                    <option
                                                        value="{{$armazon->id}}" {{old('producto') == $armazon->id ? 'selected' : ''}}>
                                                        {{$armazon->nombre}} | {{$armazon->color}}
                                                        | {{$armazon->piezas}}pza.
                                                    </option>
                                                @endif
                                            @endif
                                        @endforeach
                                    @else
                                        <option selected>Sin registros</option>
                                    @endif
                                </select>
                                {!! $errors->first('producto','<div class="invalid-feedback">Elegir un producto , campo obligatorio
                                </div>')!!}
                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-success btn-block" name="btnSubmit"
                                        type="submit">Actualizar armazón
                                </button>
                            </div>
                        </div>
                    </form>
                @endif
                @if(($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 4) && $historial->tipo == 0)
                    <div class="row">
                        @if($contrato[0]->cuentaregresivafechaentrega >= 0
                                || $contrato[0]->garantiacanceladaelmismodia
                                || !$bandera
                                || $contrato[0]->estatus_estadocontrato == 12)
                            <div class="col-6">
                                <form id="frmgarantia"
                                      action="{{route('agregarGarantiaHistorial',[$idFranquicia,$contrato[0]->id,$historial->id])}}"
                                      enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                                    @csrf
                                    @if($historial->optometristaasignado == null)
                                        <div class="row">
                                            <div class="col-6">
                                                <label for="">Optometrista</label>
                                                <select
                                                    class="custom-select {!! $errors->first('optometristagarantia','is-invalid')!!}"
                                                    name="optometristagarantia">
                                                    @if(count($optometristas) > 0)
                                                        <option selected value='nada'>Seleccionar</option>
                                                        @foreach($optometristas as $optometrista)
                                                            <option
                                                                value="{{$optometrista->ID}}">
                                                                {{$optometrista->NAME}}
                                                            </option>
                                                        @endforeach
                                                    @else
                                                        <option selected>Sin registros</option>
                                                    @endif
                                                </select>
                                                {!! $errors->first('optometristagarantia','<div class="invalid-feedback">Elegir un optometrista , campo obligatorio
                                                </div>')!!}
                                            </div>
                                            <div class="col-6">
                                                <button class="btn btn-outline-success btn-block" name="btnSubmit"
                                                        type="submit">Nueva garantia
                                                </button>
                                            </div>
                                        </div>
                                        @if($contrato[0]->cuentaregresivafechaentrega >= 0)
                                            <div style="color: #ea9999; font-weight: bold;">Quedan {{$contrato[0]->cuentaregresivafechaentrega}} días para bloquear o deshabilitar garantias a este contrato</div>
                                        @else
                                            @if($contrato[0]->fechaentrega != null)
                                                <div style="color: #ea9999; font-weight: bold;">Fecha limite para garantias ya expiró</div>
                                            @endif
                                        @endif
                                    @endif
                                </form>
                            </div>
                        @else
                            @if($contrato[0]->fechaentrega != null && $bandera)
                                <div class="col col-6">
                                    @if($solicitudAutorizacion != null)
                                        @if($solicitudAutorizacion[0]->estatus == 0)
                                            <div style="color: #0AA09E; font-weight: bold;"> Solicitud de autorización generada.</div>
                                        @endif
                                        @if($solicitudAutorizacion[0]->estatus == 2)
                                                <div style="margin-bottom: 5px;">
                                                    <a type="button" href="" class="btn btn-outline-success"
                                                       data-toggle="modal"
                                                       data-target="#modalsolicitarautorizacion">Solicitar autorización</a>
                                                </div>
                                            <div style="color: #ea9999; font-weight: bold;"> Ultima solicitud de autorización rechazada.</div>
                                        @endif
                                    @else
                                        <div style="margin-bottom: 5px;">
                                            <a type="button" href="" class="btn btn-outline-success"
                                               data-toggle="modal"
                                               data-target="#modalsolicitarautorizacion">Solicitar autorización</a>
                                        </div>
                                    @endif
                                    <div style="color: #ea9999; font-weight: bold;">
                                        Fecha limite para garantias ya expiró
                                    </div>
                                </div>
                            @else
                                <div class="col-6"></div>
                            @endif
                        @endif

                        @if((Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6) && $contrato[0]->estadogarantia != 2)
                            <div class="col-6">
                                <form id="frmpaquetes{{$historial->id}}"
                                      action="{{route('actualizarpaquetehistorial',[$idFranquicia,$idContrato,$historial->id])}}"
                                      enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                                    @csrf
                                    <div class="row">
                                        @if($solicitudCambioPaquete == null || ($solicitudCambioPaquete != null && ($solicitudCambioPaquete[0]->estatus == 1
                                            && $solicitudCambioPaquete[0]->tipo ==5)))
                                            <div class="col-5">
                                                <label for="">Paquetes</label>
                                                <select
                                                    class="custom-select {!! $errors->first('paquetehistorialeditar','is-invalid')!!}"
                                                    name="paquetehistorialeditar{{$historial->id}}" disabled>
                                                    @if(count($paquetes) > 0)
                                                        <option selected value=''>Seleccionar</option>
                                                        @foreach($paquetes as $paquete)
                                                            <option
                                                                value="{{$paquete->id}}">
                                                                {{$paquete->nombre}}
                                                            </option>
                                                        @endforeach
                                                    @else
                                                        <option selected>Sin registros</option>
                                                    @endif
                                                </select>
                                                {!! $errors->first('paquetehistorialeditar','<div class="invalid-feedback">Elegir un paquete , campo obligatorio
                                                </div>')!!}
                                            </div>
                                            <div class="col-7">
                                                <div class="form-group">
                                                    <a type="button" class="btn btn-outline-success btn-block"
                                                       data-toggle="modal"
                                                       data-target="#modalsolicitarcambiopaquete">Solicitar cambio paquete</a>
                                                </div>
                                            </div>
                                        @endif
                                        @if($solicitudCambioPaquete != null)
                                            @if($solicitudCambioPaquete[0]->estatus == 0 && $solicitudCambioPaquete[0]->tipo == 4)
                                                <div class="col-6">
                                                    <label for="">Paquetes</label>
                                                    <select
                                                        class="custom-select {!! $errors->first('paquetehistorialeditar','is-invalid')!!}"
                                                        name="paquetehistorialeditar{{$historial->id}}" disabled>
                                                        @if(count($paquetes) > 0)
                                                            <option selected value=''>Seleccionar</option>
                                                            @foreach($paquetes as $paquete)
                                                                <option
                                                                    value="{{$paquete->id}}">
                                                                    {{$paquete->nombre}}
                                                                </option>
                                                            @endforeach
                                                        @else
                                                            <option selected>Sin registros</option>
                                                        @endif
                                                    </select>
                                                    {!! $errors->first('paquetehistorialeditar','<div class="invalid-feedback">Elegir un paquete , campo obligatorio
                                                    </div>')!!}
                                                </div>
                                                <div class="col-6">
                                                    <div class="row" style="color: #0AA09E; font-weight: bold; padding-top:10px; padding-left: 15px;">
                                                        Solicitud de cambio de paquete pendiente.</div>
                                                </div>
                                            @endif
                                            @if($solicitudCambioPaquete[0]->estatus == 1 && $solicitudCambioPaquete[0]->tipo == 4)
                                                <div class="col-6">
                                                    <label for="">Paquetes</label>
                                                    <select
                                                        class="custom-select {!! $errors->first('paquetehistorialeditar','is-invalid')!!}"
                                                        name="paquetehistorialeditar{{$historial->id}}">
                                                        @if(count($paquetes) > 0)
                                                            <option selected value=''>Seleccionar</option>
                                                            @foreach($paquetes as $paquete)
                                                                <option
                                                                    value="{{$paquete->id}}">
                                                                    {{$paquete->nombre}}
                                                                </option>
                                                            @endforeach
                                                        @else
                                                            <option selected>Sin registros</option>
                                                        @endif
                                                    </select>
                                                    {!! $errors->first('paquetehistorialeditar','<div class="invalid-feedback">Elegir un paquete , campo obligatorio
                                                    </div>')!!}
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <a type="button" href="" class="btn btn-outline-success"
                                                           data-toggle="modal"
                                                           data-target="#modalactualizarpaquetehistorial{{$historial->id}}">Actualizar
                                                            paquete</a>
                                                    </div>
                                                </div>
                                            @endif
                                            @if($solicitudCambioPaquete[0]->estatus == 2 && $solicitudCambioPaquete[0]->tipo == 4)
                                                <div class="col-6">
                                                    <label for="">Paquetes</label>
                                                    <select
                                                        class="custom-select {!! $errors->first('paquetehistorialeditar','is-invalid')!!}"
                                                        name="paquetehistorialeditar{{$historial->id}}" disabled>
                                                        @if(count($paquetes) > 0)
                                                            <option selected value=''>Seleccionar</option>
                                                            @foreach($paquetes as $paquete)
                                                                <option
                                                                    value="{{$paquete->id}}">
                                                                    {{$paquete->nombre}}
                                                                </option>
                                                            @endforeach
                                                        @else
                                                            <option selected>Sin registros</option>
                                                        @endif
                                                    </select>
                                                    {!! $errors->first('paquetehistorialeditar','<div class="invalid-feedback">Elegir un paquete , campo obligatorio
                                                    </div>')!!}
                                                    <div class="row" style="color: #ea9999; font-weight: bold; margin-left: 5px; padding-top: 5px;">
                                                        Ultima solicitud de cambio de paquete rechazada.</div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <a type="button" class="btn btn-outline-success btn-block"
                                                           data-toggle="modal"
                                                           data-target="#modalsolicitarcambiopaquete">Solicitar cambio paquete</a>
                                                    </div>
                                                </div>
                                            @endif
                                        @endif

                                        <div class="modal fade" id="modalactualizarpaquetehistorial{{$historial->id}}"
                                             tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                                             aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        Solicitud de confirmación
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                ¿Estas seguro de cambiar el paquete?
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-primary" type="button"
                                                                data-dismiss="modal">Cancelar
                                                        </button>
                                                        <button class="btn btn-success" name="btnSubmit" type="submit"
                                                                form="frmpaquetes{{$historial->id}}">Aceptar
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        @endif
                    </div>
                @endif
                @if(($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 4) && $historial->tipo == 0)
                    @if(!$bandera)
                        <form id="frmcancelargarantia"
                              action="{{route('cancelarGarantiaHistorial',[$idFranquicia,$contrato[0]->id,$historial->id])}}"
                              enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                            @csrf
                            <div class="row">
                                <div class="col-3">

                                    <button class="btn btn-outline-danger btn-block" name="btnSubmit"
                                            type="submit">Cancelar garantia
                                    </button>

                                </div>
                            </div>
                        </form>
                    @else
                        @if($historial->cancelargarantia != null)
                            <form id="frmcancelargarantia"
                                  action="{{route('cancelarGarantiaHistorial',[$idFranquicia,$contrato[0]->id,$historial->id])}}"
                                  enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                                @csrf
                                <div class="row">
                                    @if($historial->optometristaasignado != null)
                                        <div class="col-3">
                                            <label for="">Optometrista
                                                asignado {{$historial->optometristaasignado}}</label>
                                        </div>
                                    @endif
                                    <div class="col-3">

                                        <button class="btn btn-outline-danger btn-block" name="btnSubmit"
                                                type="submit">Cancelar garantia
                                        </button>

                                    </div>
                                </div>
                            </form>
                            @if($contrato[0]->cuentaregresivafechaentrega >= 0)
                                <div style="color: #ea9999; font-weight: bold;">Quedan {{$contrato[0]->cuentaregresivafechaentrega}} días para bloquear o deshabilitar garantias a este contrato</div>
                            @endif
                        @endif
                    @endif
                @endif
                @if($historial->paquete == 'DORADO 2' || $historial->paquete == 'LECTURA')
                    <h5 style="color: #0AA09E;">Sin conversión</h5>
                    @if($historial->hscesfericoder != null)
                        <div id="mostrarvision"></div>
                        <h6>Ojo derecho</h6>
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Esferico</label>
                                    <input type="text" name="esfericod" class="form-control" readonly
                                           value="{{$historial->hscesfericoder}}">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Cilindro</label>
                                    <input type="text" name="cilindrod" class="form-control" readonly
                                           value="{{$historial->hsccilindroder}}">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Eje</label>
                                    <input type="text" name="ejed" class="form-control" readonly
                                           value="{{$historial->hscejeder}}">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Add</label>
                                    <input type="text" name="addd" class="form-control" readonly
                                           value="{{$historial->hscaddder}}">
                                </div>
                            </div>
                        </div>
                        <h6>Ojo Izquierdo</h6>
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Esferico</label>
                                    <input type="text" name="esfericod2" class="form-control" readonly
                                           value="{{$historial->hscesfericoizq}}">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Cilindro</label>
                                    <input type="text" name="cilindrod2" class="form-control" readonly
                                           value="{{$historial->hsccilindroizq}}">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Eje</label>
                                    <input type="text" name="ejed2" class="form-control" readonly
                                           value="{{$historial->hscejeizq}}">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Add</label>
                                    <input type="text" name="addd2" class="form-control" readonly
                                           value="{{$historial->hscaddizq}}">
                                </div>
                            </div>
                        </div>
                    @else
                        <h6 style="color: #0AA09E; margin-left: 30px">Sin capturar</h6>
                    @endif
                    <h5 style="color: #0AA09E;">Con conversión</h5>
                @endif
                <div id="mostrarvision"></div>
                <h6>Ojo derecho</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Esferico</label>
                            <input type="text" name="esfericod" class="form-control" readonly
                                   value="{{$historial->esfericoder}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Cilindro</label>
                            <input type="text" name="cilindrod" class="form-control" readonly
                                   value="{{$historial->cilindroder}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Eje</label>
                            <input type="text" name="ejed" class="form-control" readonly value="{{$historial->ejeder}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Add</label>
                            <input type="text" name="addd" class="form-control" readonly value="{{$historial->addder}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>ALT</label>
                            <input type="text" name="altd" class="form-control" readonly value="{{$historial->altder}}">
                        </div>
                    </div>
                </div>
                <h6>Ojo Izquierdo</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Esferico</label>
                            <input type="text" name="esfericod2" class="form-control" readonly
                                   value="{{$historial->esfericoizq}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Cilindro</label>
                            <input type="text" name="cilindrod2" class="form-control" readonly
                                   value="{{$historial->cilindroizq}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Eje</label>
                            <input type="text" name="ejed2" class="form-control" readonly
                                   value="{{$historial->ejeizq}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Add</label>
                            <input type="text" name="addd2" class="form-control" readonly
                                   value="{{$historial->addizq}}">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>ALT</label>
                            <input type="text" name="altd2" class="form-control" readonly
                                   value="{{$historial->altizq}}">
                        </div>
                    </div>
                </div>
                <h6>Material</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material{{$loop->iteration}}"
                                   id="material{{$loop->iteration}}" @if($historial->material == 0) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="material{{$loop->iteration}}">Hi Index</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material{{$loop->iteration}}"
                                   id="material{{$loop->iteration}}" @if($historial->material == 1) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="material{{$loop->iteration}}">CR</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material{{$loop->iteration}}"
                                   id="material{{$loop->iteration}}" @if($historial->material == 2) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="material{{$loop->iteration}}">Policarbonato</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material{{$loop->iteration}}"
                                   id="material{{$loop->iteration}}" @if($historial->material == 3) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="material{{$loop->iteration}}">Otro</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input type="text" name="motro" class="form-control" placeholder="Otro"
                                   value="{{$historial->materialotro}}" readonly>
                        </div>
                    </div>
                </div>
                <h6>Tipo de bifocal</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}"
                                   id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 0) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                                FT
                            </label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}"
                                   id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 1) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                                Blend
                            </label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}"
                                   id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 2) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                                Progresivo
                            </label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}"
                                   id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 3) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                                N/A
                            </label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal{{$loop->iteration}}"
                                   id="exampleRadios{{$loop->iteration}}" @if($historial->bifocal == 4) checked
                                   @endif onclick="return false;">
                            <label class="form-check-label" for="exampleRadios{{$loop->iteration}}">
                                Otro
                            </label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="text" name="otroB" class="form-control" min="0" placeholder="Otro"
                                   value="{{$historial->bifocalotro}}" readonly>
                        </div>
                    </div>
                </div>
                <h6>Tratamiento</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input " name="fotocromatico" id="customCheck9"
                                   @if($historial->fotocromatico == 1) checked @endif onclick="return false;">
                            <label class="custom-control-label" for="customCheck9">Fotocromatico</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input " name="ar" id="customCheck10"
                                   @if($historial->ar == 1) checked @endif onclick="return false;">
                            <label class="custom-control-label" for="customCheck10">A/R</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="tinte" id="customCheck11"
                                   @if($historial->tinte == 1) checked @endif onclick="return false;">
                            <label class="custom-control-label" for="customCheck11">Tinte</label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="blueray" id="customCheck12"
                                   @if($historial->blueray == 1) checked @endif onclick="return false;">
                            <label class="custom-control-label" for="customCheck12">BlueRay</label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="custom-control custom-checkbox">
                            <input class="custom-control-input " type="checkbox" name="otroTra" id="customCheck13"
                                   @if($historial->otroT == 1) checked @endif onclick="return false;">
                            <label class="custom-control-label" for="customCheck13">Otro</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="text" name="otroT" class="form-control" min="0" placeholder="Otro"
                                   value="{{$historial->tratamientootro}}" readonly>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Observaciones laboratorio</label>
                            <input type="text" name="cilindrod2" class="form-control" readonly
                                   value="{{$historial->observaciones}}">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Observaciones interno</label>
                            <input type="text" name="cilindrod2" class="form-control" readonly
                                   value="{{$historial->observacionesinterno}}">
                        </div>
                    </div>
                </div>
                <hr>
            @endforeach
        @else
            <div class="row">
                <div class="col-3">
                    <h3 style="margin-top: 10px;">(Sin resultados)</h3>
                </div>
            </div>
        @endif
        <div class="row">
            <div class="col">
                <a href="{{route('listacontrato',$idFranquicia)}}"
                   class="btn btn-outline-success btn-block">@lang('mensajes.regresar')</a>
            </div>
        </div>
    </div>

    <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <img src="" class="imagepreview"
                         style="width: 100%; margin-top: 60px; margin-bottom: 60px; cursor: grabbing">
                </div>
            </div>
        </div>
    </div>

    <!--Modal para Solicitar Autorizacion Garantia-->
    <div class="modal fade" id="modalsolicitarautorizacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="{{route('solicitarautorizaciongarantia',[$idFranquicia,$contrato[0]->id])}}" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Solicitud para autorización de garantia.
                    </div>
                    <div class="modal-body">Describa la solicitud de garantia.
                        <textarea name="mensaje"
                                  id = "mensaje"
                                  class="form-control {!! $errors->first('mensaje','is-invalid')!!}" rows="10"
                                  cols="60" >
                        </textarea>
                        {!! $errors->first('mensaje','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!--Modal para Solicitar Autorizacion Cambiar paquete-->
    <div class="modal fade" id="modalsolicitarcambiopaquete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="{{route('solicitarautorizacioncambiopaquete',[$idFranquicia,$contrato[0]->id])}}" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            @csrf
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Solicitud para autorización de Cambiar paquete.
                    </div>
                    <div class="modal-body">Describa la solicitud cambio de paquete.
                        <textarea name="mensaje"
                                  id = "mensaje"
                                  class="form-control {!! $errors->first('mensaje','is-invalid')!!}" rows="10"
                                  cols="60" >
                        </textarea>
                        {!! $errors->first('mensaje','<div class="invalid-feedback">Campo obligatorio.</div>')!!}
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

@endsection
