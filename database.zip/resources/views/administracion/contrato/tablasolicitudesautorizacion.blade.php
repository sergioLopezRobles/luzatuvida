@extends('layouts.app')
@section('titulo','Solicitudes'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
        <h2>Solicitud de autorización garantía y cancelación contrato</h2>
    @else
        <h2>Solicitud de autorización garantía</h2>
    @endif

    <table id="tablaContratos" class="table table-bordered" style="margin-top: 10px; margin-top: 25px;">
        <thead>
        <tr>
            <th  style =" text-align:center;" scope="col">SUCURSAL</th>
            <th  style =" text-align:center;" scope="col">TIPO SOLICITUD</th>
            <th  style =" text-align:center;" scope="col">CONTRATO</th>
            <th  style =" text-align:center;" scope="col">FECHA CREACIÓN CONTRATO</th>
            <th  style =" text-align:center;" scope="col">FECHA CREACIÓN SOLICITUD</th>
            <th  style =" text-align:center;" scope="col">ESTADO CONTRATO</th>
            <th  style =" text-align:center;" scope="col">USUARIO DE SOLICITUD</th>
            <th  style =" text-align:center;" scope="col">MENSAJE</th>
            <th  style =" text-align:center;" scope="col">ACCIÓN</th>
        </tr>
        </thead>
        <tbody>
        @if(!is_null($solicitudesAutorizacion) && count($solicitudesAutorizacion)>0)
            @foreach($solicitudesAutorizacion as $solicitud)
                <tr>
                    <td align='center'>{{$solicitud->sucursal}}</td>
                    @switch($solicitud->tipo)
                        @case(0)
                        <td align='center'>GARANTIA</td>
                        @break
                        @case(1)
                        <td align='center'>CANCELAR CONTRATO</td>
                        @break
                        @case(2)
                        <td align='center'>AUMENTAR/DESCONTAR</td>
                        @break
                        @case(4)
                        <td align='center'>CAMBIAR PAQUETE</td>
                        @break
                    @endswitch
                    <td align='center'>{{$solicitud->id_contrato}}</td>
                    <td align='center'>{{\Carbon\Carbon::parse($solicitud->fecha_contrato)->format('Y-m-d')}}</td>
                    <td align='center'>{{$solicitud->fecha_solicitud}}</td>
                    @switch($solicitud->estado_contrato)
                        @case(0)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">No terminado</button>
                        </td>
                        @break
                        @case(1)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">Terminado</button>
                        </td>
                        @break
                        @case(2)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">Entregado</button>
                        </td>
                        @break
                        @case(3)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">Pre-cancelado</button>
                        </td>
                        @break
                        @case(4)
                        <td align='center'>
                            <button name="estatusactual"  type="button" class="btn btn-secondary" style="color:#FEFEFE;">Abono atrasado</button>
                        </td>
                        @break
                        @case(5)
                        <td align='center'>
                            <button name="estatusactual"  type="button" class="btn btn-secondary" style="color:#FEFEFE;">Pagado</button>
                        </td>
                        @break
                        @case(12)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">Enviado</button>
                        </td>
                        @break
                        @case(14)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">Lio/Fuga</button>
                        </td>
                        @break
                        @case(15)
                        <td align='center'>
                            <button name="estatusactual" type="button" class="btn btn-secondary" style="color:#FEFEFE;">Supervision</button>
                        </td>
                        @break
                    @endswitch
                    <td align='center'>{{$solicitud->usuario_solicitud}}</td>
                    <td align='center'>{{$solicitud->mensaje}}</td>
                    <td align='center'>
                        <div style="padding-bottom: 10px;"><a class="btn btn-outline-success" href="{{route('autorizarcontrato',[$solicitud->id_contrato,$solicitud->indice])}}">AUTORIZAR</a></div>
                        <div><a class="btn btn-outline-danger" href="{{route('rechazarcontrato',[$solicitud->id_contrato,$solicitud->indice])}}">RECHAZAR</a></div>
                    </td>
                </tr>
            @endforeach
        @else
            <tr>
                <td align='center' colspan="8">Sin registros</td>
            </tr>
        @endif
        </tbody>
    </table>

@endsection
