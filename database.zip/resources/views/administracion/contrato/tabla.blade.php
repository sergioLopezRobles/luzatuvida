@extends('layouts.app')
@section('titulo','Contratos'){{-- Corresponde al Titulo de la pestaña--}}
@section('content')
    @include('parciales.notificaciones')
    @if(Auth::user()->rol_id == 13 || Auth::user()->rol_id == 12)
        <h2>@lang('mensajes.mensajemiscontratosfranquicia')</h2>
    @else
        <h2>Contratos de la sucursal</h2>
    @endif
    <form action="{{route('filtrarlistacontrato',$idFranquicia)}}" enctype="multipart/form-data" method="POST"
          onsubmit="btnSubmit.disabled = true;">
        @csrf
        <div class="row">
            <div class="col-4">
                <input name="filtro" type="text" class="form-control" placeholder="Buscar..">
            </div>
            <div class="col-5">
                <button type="submit" name="btnSubmit" class="btn btn-outline-success">Buscar</button>
            </div>
        </div>
    </form>

    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Estado</label>
                <input type="text" name="estado" class="form-control" readonly
                       value="{{$franquiciaContratos[0]->estado}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ciudad</label>
                <input type="text" name="ciudad" class="form-control" readonly
                       value="{{$franquiciaContratos[0]->ciudad}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="colonia" class="form-control" readonly
                       value="{{$franquiciaContratos[0]->colonia}}">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Numero Interior/Exterior</label>
                <input type="text" name="numero" class="form-control" readonly
                       value="{{$franquiciaContratos[0]->numero}}">
            </div>
        </div>
    </div>
    @if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
        <button type="button" class="btn btn-primary" style="margin-bottom: 10px;">
            Total registros <span class="badge bg-secondary" id="totalContratos">{{$totalRegistros}}</span>
        </button>
        <div id="accordion">
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne"
                                aria-expanded="true"
                                aria-controls="collapseOne">
                            Filtros
                        </button>
                    </h5>
                </div>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <form action="{{route('filtrarlistacontratocheckbox',$idFranquicia)}}"
                              enctype="multipart/form-data" method="POST"
                              onsubmit="btnSubmit.disabled = true;">
                            @csrf
                            <div class="row" id="divFiltrosContratos">
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbGarantias" id="customCheck1"
                                               value="1" @if($cbGarantias != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck1">Garantias</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbSupervision" id="customCheck2"
                                               value="1" @if($cbSupervision != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck2">Supervision</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbAtrasado" id="customCheck3"
                                               value="1" @if($cbAtrasado != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck3">Atrasados</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbEntrega" id="customCheck4"
                                               value="1" @if($cbEntrega != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck4">Entrega</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbLaboratorio" id="customCheck5"
                                               value="1" @if($cbLaboratorio != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck5">Laboratorio</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbConfirmacion" id="customCheck6"
                                               value="1" @if($cbConfirmacion != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck6">Confirmación</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbTodos" id="customCheck7"
                                               value="1" @if($cbTodos != null) checked @endif>
                                        <label class="custom-control-label" for="customCheck7">Todos</label>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="form-group">
                                        <select name="zonaU"
                                                id="zonaU"
                                                class="form-control">
                                            @if(count($zonas) > 0)
                                                <option value="">Todas las zonas</option>
                                                @foreach($zonas as $zona)
                                                    <option
                                                        value="{{$zona->id}}" {{ isset($zonaU) ? ($zonaU == $zona->id ? 'selected' : '' ) : '' }}>{{$zona->zona}}</option>
                                                @endforeach
                                            @else
                                                <option selected>Sin registros</option>
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col">
                                    <button class="btn btn-outline-success" name="btnSubmit"
                                            type="submit">Aplicar
                                    </button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label>Fecha inicial</label>
                                        <input type="date" name="fechainibuscar" class="form-control {!! $errors->first('fechainibuscar','is-invalid')!!}" @isset($fechainibuscar) value = "{{$fechainibuscar}}" @endisset>
                                        @if($errors->has('fechainibuscar'))
                                            <div class="invalid-feedback">{{$errors->first('fechainibuscar')}}</div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label>Fecha final</label>
                                        <input type="date" name="fechafinbuscar" class="form-control {!! $errors->first('fechafinbuscar','is-invalid')!!}" @isset($fechafinbuscar) value = "{{$fechafinbuscar}}" @endisset>
                                        @if($errors->has('fechafinbuscar'))
                                            <div class="invalid-feedback">{{$errors->first('fechafinbuscar')}}</div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-6">
                                    <label style="font-size: 17px; margin-top: 35px; color: #ea9999; font-weight: bold">Seleccionar mas de 3 filtros puede demorar varios minutos</label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endif
    <div class="contenedortblContratos">
        <table id="tablaContratos" class="table table-bordered">
            @if($contratosgeneral != null && sizeof($contratosgeneral)>0)
                <thead>
                <tr>
                    @if( Auth::user()->rol_id == 4 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8  ||  Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 6)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            CONTRATO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ESTATUS
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            RELACIÓN
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 4)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LOCALIDAD
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">COLONIA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CALLE
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA
                            CREACIÓN
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA
                            ENTREGA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            FECHA GARANTIA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ASISTENTE
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ZONA</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LOCALIDAD
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">COLONIA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CALLE
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">NUMERO
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CLIENTE
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            TELEFONO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ABONO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">SALDO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ULTIMO
                            ABONO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">PROMOCION
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ATRASO
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 12)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">PAQUETE
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">EDITAR
                        </th>
                    @endif
                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">VER</th>
                    @endif
                </tr>
                </thead>
            @endif
            <tbody>
            @if(Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                @if($contratos != null)
                    @foreach($contratos as $contrato)
                        <tr>
                            @if($contrato->estatus_estadocontrato >= 1)
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                            @else
                                <td align='center' style="font-size: 10px;"><p style="color:#c9c9c9">{{$contrato->id}}</p></td>
                            @endif
                            @switch($contrato->estatus_estadocontrato)
                                @case(0)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-secondary noterminados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(1)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-success terminados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                            @endswitch
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                            @endif
                            @if(Auth::user()->rol_id == 12)
                                <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                        </tr>
                    @endforeach
                @endif
            @endif
            @if(Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
                @if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
                    @if($cbGarantias == 1)
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">GARANTIAS (REPORTADAS/ASIGNADAS)
                            </th>
                        </tr>
                        @if($contratosreportesgarantia != null)
                            @foreach($contratosreportesgarantia as $contrato)
                                <tr>
                                    <td align='center' @if($contrato->estadogarantia == 0) style="font-size: 10px; background-color:#ea9999;" @else style="font-size: 10px; background-color:#5bc0de;" @endif><p style="color:#FFFFFF">{{$contrato->id}}</p></td>
                                    @switch($contrato->estatus_estadocontrato)
                                        @case(2)
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-primary entregados"
                                                    style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                        </td>
                                        @break
                                        @case(5)
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-info pagados"
                                                    style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                        </td>
                                        @break
                                        @case(12)
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-success terminados"
                                                    style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                        </td>
                                        @break
                                        @case(4)
                                        @if($contrato->dias <= 10)
                                            <td align='center' style="font-size: 10px;">
                                                <button type="button" class="btn btn-light atrasados"
                                                        style="color:#000000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                            </td>
                                        @endif
                                        @if($contrato->dias >= 11 && $contrato->dias <= 20)
                                            <td align='center' style="font-size: 10px;">
                                                <button type="button" class="btn btn-light prueba2"
                                                        style="color:#000000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                            </td>
                                        @endif
                                        @if($contrato->dias > 20)
                                            <td align='center' style="font-size: 10px;">
                                                <button type="button" class="btn btn-light ahora3"
                                                        style="color:#000000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                            </td>
                                        @endif
                                        @break
                                    @endswitch
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                        <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechagarantia)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                        <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                        @if($contrato->totalabono != null)
                                            <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                        <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                        @if($contrato->idcontratorelacion == null)
                                            @if($contrato->promo == 0)
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @else
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @endif
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12)
                                        <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;"><a
                                                href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                        <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                </tr>
                            @endforeach
                        @endif
                    @endif
                    @if($cbGarantias == 1)
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">GARANTIAS
                            </th>
                        </tr>
                        @if($contratosgarantiascreadas != null)
                            @foreach($contratosgarantiascreadas as $contrato)
                                <tr>
                                    <td align='center' @if($contrato->estadogarantia == 2) style="font-size: 10px; background-color:#5cb85c;" @else style="font-size: 10px; background-color:#5bc0de;" @endif><p style="color:#FFFFFF">{{$contrato->id}}</p></td>
                                    @switch($contrato->estatus_estadocontrato)
                                        @case(1)
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-success terminados"
                                                    style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                        </td>
                                        @break
                                    @endswitch
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                        <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechagarantia)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                        <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                        @if($contrato->totalabono != null)
                                            <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                        <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                        @if($contrato->idcontratorelacion == null)
                                            @if($contrato->promo == 0)
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @else
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @endif
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12)
                                        <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;"><a
                                                href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                        <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                </tr>
                            @endforeach
                        @endif
                    @endif
                    @if($cbSupervision == 1)
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">SUPERVISION
                            </th>
                        </tr>
                        @if($contratossupervision != null)
                            @foreach($contratossupervision as $contrato)
                                <tr>
                                    <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn"
                                                style="background-color:#F88F32;color:#FFFFFF;text-align:center;font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                        <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                        <td align='center'></td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                        <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                        @if($contrato->totalabono != null)
                                            <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                        <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                        @if($contrato->idcontratorelacion == null)
                                            @if($contrato->promo == 0)
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @else
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @endif
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12)
                                        <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;"><a
                                                href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                        <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                </tr>
                            @endforeach
                        @endif
                    @endif
                    @if($cbEntrega == 1)
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">NO ENTREGADOS
                            </th>
                        </tr>
                        @if($contratosnoenviados != null)
                            @foreach($contratosnoenviados as $contrato)
                                <tr>
                                    <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-success terminados"
                                                style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                        <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                        <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                        <td align='center'></td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                        <td align='center' style="font-size: 10px;">{{$contrato->nombre}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                        <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                        @if($contrato->totalabono != null)
                                            <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                        <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                        <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                        @if($contrato->idcontratorelacion == null)
                                            @if($contrato->promo == 0)
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @else
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            @endif
                                        @else
                                            <td align='center' style="font-size: 10px;"></td>
                                        @endif
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12)
                                        <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                        <td align='center' style="font-size: 10px;"><a
                                                href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                        <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                    @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    @endif
                                </tr>
                            @endforeach
                        @endif
                    @endif
                @endif
                @if((Auth::user()->rol_id == 4 && $cbAtrasado == null) || (Auth::user()->rol_id != 4 && $cbAtrasado == 1))
                    <tr>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">ATRASADOS
                        </th>
                    </tr>
                @endif
                @if($contratosatrasados != null)
                    @foreach($contratosatrasados as $contrato)
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                            @switch($contrato->estatus_estadocontrato)
                                @case(4)
                                @if($contrato->dias <= 10)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-light atrasados"
                                                style="color:#000000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                @endif
                                @if($contrato->dias >= 11 && $contrato->dias <= 20)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-light prueba2"
                                                style="color:#000000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                @endif
                                @if($contrato->dias > 20)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-light ahora3"
                                                style="color:#000000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                @endif
                                @break
                            @endswitch
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                @if($contrato->totalabono != null)
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                                <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                @if($contrato->idcontratorelacion == null)
                                    @if($contrato->promo == 0)
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @else
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @endif
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 12)
                                <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;"><a
                                        href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                        </tr>
                    @endforeach
                @endif
                @if((Auth::user()->rol_id == 4))
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">
                            PRIORITARIOS
                        </th>
                    </tr>
                @endif
                @if($contratosprioritarios != null)
                    @foreach($contratosprioritarios as $contrato)
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                            @switch($contrato->estatus_estadocontrato)
                                @case(2)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-primary entregados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(5)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info pagados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                            @endswitch
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                @if($contrato->totalabono != null)
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                                <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                @if($contrato->idcontratorelacion == null)
                                    @if($contrato->promo == 0)
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @else
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @endif
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 12)
                                <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;"><a
                                        href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                        </tr>
                    @endforeach
                @endif
                @if((Auth::user()->rol_id == 4))
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">PERIODO
                        </th>
                    </tr>
                @endif
                @if($contratosperiodo != null)
                    @foreach($contratosperiodo as $contrato)
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                            @switch($contrato->estatus_estadocontrato)
                                @case(2)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-primary entregados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(5)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info pagados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                            @endswitch
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                @if($contrato->totalabono != null)
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                                <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                @if($contrato->idcontratorelacion == null)
                                    @if($contrato->promo == 0)
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @else
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @endif
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 12)
                                <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;"><a
                                        href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                        </tr>
                    @endforeach
                @endif
                @if((Auth::user()->rol_id == 4 && $cbEntrega == null) || (Auth::user()->rol_id != 4 && $cbEntrega == 1))
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">POR
                            ENTREGAR
                        </th>
                    </tr>
                @endif
                @if($contratosentregar != null)
                    @foreach($contratosentregar as $contrato)
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                            @switch($contrato->estatus_estadocontrato)
                                @case(12)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-success terminados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                            @endswitch
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                @if($contrato->totalabono != null)
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                                <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                @if($contrato->idcontratorelacion == null)
                                    @if($contrato->promo == 0)
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @else
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @endif
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 12)
                                <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;"><a
                                        href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                        </tr>
                    @endforeach
                @endif
                @if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
                    @if($cbLaboratorio == 1)
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">
                                LABORATORIO
                            </th>
                        </tr>
                    @endif
                    @if($contratoslaboratorio != null)
                        @foreach($contratoslaboratorio as $contrato)
                            <tr>
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                                @switch($contrato->estatus_estadocontrato)
                                    @case(7)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-primary aprobado"
                                                style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @break
                                    @case(10)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-warning manofactura"
                                                style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @break
                                    @case(11)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-info enprocesodeenvio"
                                                style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @break
                                @endswitch
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                    <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 4)
                                    <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                    <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                    <td align='center'></td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                    <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                    <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                    @if($contrato->totalabono != null)
                                        <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                    @else
                                        <td align='center' style="font-size: 10px;"></td>
                                    @endif
                                    <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                    @if($contrato->idcontratorelacion == null)
                                        @if($contrato->promo == 0)
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#ffaca6; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        @else
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#0AA09E; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        @endif
                                    @else
                                        <td align='center' style="font-size: 10px;"></td>
                                    @endif
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 12)
                                    <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;"><a
                                            href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                            </button>
                                        </a></td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                    <td align='center' style="font-size: 10px;"><a
                                            href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                @endif
                                @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                    <td align='center' style="font-size: 10px;"><a href="">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                @endif
                            </tr>
                        @endforeach
                    @endif
                @endif
                @if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
                    @if($cbConfirmacion == 1)
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">
                                CONFIRMACIONES
                            </th>
                        </tr>
                    @endif
                    @if($contratosconfirmaciones != null)
                        @foreach($contratosconfirmaciones as $contrato)
                            <tr>
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                                @switch($contrato->estatus_estadocontrato)
                                    @case(1)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-success terminados"
                                                style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @break
                                    @case(9)
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-warning manofactura"
                                                style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                    </td>
                                    @break
                                @endswitch
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                    <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 4)
                                    <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                    <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                    <td align='center'></td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                    <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                    <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                    @if($contrato->totalabono != null)
                                        <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                    @else
                                        <td align='center' style="font-size: 10px;"></td>
                                    @endif
                                    <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                    <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                    @if($contrato->idcontratorelacion == null)
                                        @if($contrato->promo == 0)
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#ffaca6; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        @else
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#0AA09E; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        @endif
                                    @else
                                        <td align='center' style="font-size: 10px;"></td>
                                    @endif
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 12)
                                    <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                    <td align='center' style="font-size: 10px;"><a
                                            href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                            </button>
                                        </a></td>
                                @endif
                                @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                    <td align='center' style="font-size: 10px;"><a
                                            href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                @endif
                                @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                    <td align='center' style="font-size: 10px;"><a href="">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                @endif
                            </tr>
                        @endforeach
                    @endif
                @endif
                @if((Auth::user()->rol_id == 4 && $cbTodos == null) || (Auth::user()->rol_id != 4 && $cbTodos == 1))
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; @if(Auth::user()->rol_id == 4) top: 30px; @else top: 57px; @endif box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">TODOS</th>
                    </tr>
                @endif
                @if($contratos != null)
                    @foreach($contratos as $contrato)
                        <tr>
                            @if($contrato->estatus_estadocontrato != 1 && Auth::user()->rol_id == 4)
                                @if(strlen($contrato->fechacobroini) > 0)
                                    @php
                                        $continuar = false;
                                    @endphp
                                    @if((\Carbon\Carbon::parse($now)->format('Y-m-d') >= \Carbon\Carbon::parse($contrato->fechacobroini)->format('Y-m-d')) && (\Carbon\Carbon::parse($now)->format('Y-m-d') <= \Carbon\Carbon::parse($contrato->fechacobrofin)->format('Y-m-d')))
                                        @php
                                            $continuar = true;
                                        @endphp
                                    @endif
                                    @if($continuar)
                                        @continue
                                    @endif
                                @endif
                            @endif
                            @if($contrato->estatus_estadocontrato >= 1)
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E">{{$contrato->id}}</p></td>
                            @else
                                <td align='center' style="font-size: 10px;"><p style="color:#c9c9c9">{{$contrato->id}}</p></td>
                            @endif
                            @switch($contrato->estatus_estadocontrato)
                                @case(0)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-secondary noterminados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(2)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-primary entregados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(3)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-danger precancelados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(5)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info pagados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(6)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info cancelados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(8)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-danger precancelados"
                                            style="color:#ff0000; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                                @case(14)
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info cancelados"
                                            style="color:#FEFEFE; font-size: 10px;">{{$contrato->descripcion}}</button>
                                </td>
                                @break
                            @endswitch
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)
                                <td align='center' style="font-size: 10px;">{{$contrato->idcontratorelacion}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')}}</td>
                                <td align='center' style="font-size: 10px;">{{\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')}}</td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;">{{$contrato->nombre_usuariocreacion}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->zona}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->localidad}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->colonia}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->calle}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;">{{$contrato->numero}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4)
                                <td align='center' style="font-size: 10px;"><b>{{$contrato->nombre}}</b></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->telefono}}</td>
                                <td align='center' style="font-size: 10px;">${{$contrato->totalreal}}</td>
                                @if($contrato->totalabono != null)
                                    <td align='center' style="font-size: 10px;">${{$contrato->totalabono}}</td>
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                                <td align='center' style="font-size: 10px;">${{$contrato->total}}</td>
                                <td align='center' style="font-size: 10px;">{{$contrato->ultimoabono}}</td>
                                @if($contrato->idcontratorelacion == null)
                                    @if($contrato->promo == 0)
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @else
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    @endif
                                @else
                                    <td align='center' style="font-size: 10px;"></td>
                                @endif
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;">{{$contrato->dias}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 12)
                                <td align='center' style="font-size: 10px;">{{$contrato->paquete}}</td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6)
                                <td align='center' style="font-size: 10px;"><a
                                        href="{{route('contratoactualizar',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0)
                                <td align='center' style="font-size: 10px;"><a href="{{route('vercontrato',[$idFranquicia,$contrato->id])}}" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                            @if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 )
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            @endif
                        </tr>
                    @endforeach
                @endif
            @endif
            </tbody>
        </table>
    </div>
@endsection
