<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/all.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/global.js')); ?>" defer></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://js.stripe.com/v3/"></script>


<?php if(Route::is('nuevafranquicia') && Auth::user()->rol_id == 7): ?>
<script src="<?php echo e(asset('js/administracion/franquicias/nueva.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listafranquicia') && Auth::user()->rol_id == 7): ?>
  <script src="<?php echo e(asset('js/administracion/franquicias/lista.js')); ?>" defer></script>
<?php endif; ?>
<?php if((Route::is('usuariosFranquicia') || Route::is('cobranzamovimientos') || Route::is('usuariosfiltrosucursal') || Route::is('vercontrato'))
    && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/franquicias/usuarios.js')); ?>" defer></script>
<?php endif; ?>
<?php if(Route::is('payment')): ?>
  <script src="<?php echo e(asset('js/card.js')); ?>" defer></script>
<?php endif; ?>
<?php if(Route::is('editarUsuarioFranquicia') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
  <script src="<?php echo e(asset('js/administracion/franquicias/editarusuario.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('estadolaboratorio') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 16)): ?>
    <script src="<?php echo e(asset('js/administracion/laboratorio/estadolaboratorio.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('nuevohistorialclinico') || Route::is('vercontrato') || Route::is('nuevohistorialclinico2') || Route::is('nuevocontrato2') || Route::is('contratoHijos') || Route::is('nuevohistorialclinico2') || Route::is('crearhistorialclinico2')): ?>
    <script src="<?php echo e(asset('js/administracion/contratos/nuevocontrato.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listacontratoscuentasactivas') || Route::is('filtrarlistacontratoscuentasactivas') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8 || Auth::user()->rol_id == 6)): ?>
    <script src="<?php echo e(asset('js/administracion/googlemaps/marcadoresContratos.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/administracion/reportes/cuentasactivas.js')); ?>" defer></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('googlemap')['map_apikey']); ?>&v=3"></script>
    <script src="https://kit.fontawesome.com/3ddf490e9c.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/administracion/exportardocumento/exportarExcel.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('cobranzamovimientos') || Route::is('llamadascobranza') || Route::is('cobranzamovimientosvalidacioncorte')) && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/movimientos/cobranza.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('usuariosFranquicia') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/franquicias/usuariosinfranquicia.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listacontratospaquetes') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/reportes/paquetes.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/administracion/exportardocumento/exportarExcel.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listaconfirmaciones') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 15 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/confirmaciones/confirmacioneslaboratorio.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listalaboratorio') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 16)): ?>
    <script src="<?php echo e(asset('js/administracion/laboratorio/contratosenviadostiemporeal.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('estadoconfirmacion') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 15 || Auth::user()->rol_id == 8))
    || (Route::is('contratoactualizar') && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8))): ?>
    <script src="<?php echo e(asset('js/administracion/confirmaciones/estadoconfirmacion.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listacontratospagados') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8 || Auth::user()->rol_id == 6)): ?>
    <script src="<?php echo e(asset('js/administracion/googlemaps/marcadoresContratos.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/administracion/reportes/pagados.js')); ?>" defer></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('googlemap')['map_apikey']); ?>&v=3"></script>
    <script src="https://kit.fontawesome.com/3ddf490e9c.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/administracion/exportardocumento/exportarExcel.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('listacontratoscancelados') && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8 || Auth::user()->rol_id == 6)): ?>
    <script src="<?php echo e(asset('js/administracion/googlemaps/marcadoresContratos.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/administracion/reportes/cancelados.js')); ?>" defer></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('googlemap')['map_apikey']); ?>&v=3"></script>
    <script src="https://kit.fontawesome.com/3ddf490e9c.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/administracion/exportardocumento/exportarExcel.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('editarUsuarioFranquicia')): ?>
    <script src="<?php echo e(asset('js/administracion/franquicias/vistaprevia.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('filtrarlistacontratosreportes') || Route::is('listacontratosreportes')) && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 15)): ?>
    <script src="<?php echo e(asset('js/administracion/exportardocumento/exportarExcel.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('crearpoliza') || Route::is('verpoliza')) && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/poliza/crearcargarpoliza.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('reportemovimientos') || Route::is('usuariosreportemovimiento')) && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/reportes/movimientos.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('reportegraficas')) && (Auth::user()->rol_id == 7)): ?>
    <script src="<?php echo e(asset('js/administracion/reportes/graficas.js')); ?>" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.8.0/dist/chart.min.js"></script>
<?php endif; ?>

<?php if((Route::is('listavehiculos')) && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 ||Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/vehiculos/vehiculos.js')); ?>" defer></script>
    <script src="https://kit.fontawesome.com/3ddf490e9c.js" crossorigin="anonymous"></script>
<?php endif; ?>

<?php if((Route::is('vervehiculo')) && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 ||Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/franquicias/vistaprevia.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('reportellamadas')) && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 ||Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/reportes/llamadas.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('traspasarcontrato') || Route::is('buscarcontratotraspasar') || Route::is('obtenercontratotraspasar')) && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 ||Auth::user()->rol_id == 8 || Auth::user()->rol_id == 15)): ?>
    <script src="<?php echo e(asset('js/administracion/contratos/traspasarcontratos.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('reportecontratos')) && (Auth::user()->rol_id == 7)): ?>
    <script src="<?php echo e(asset('js/administracion/contratos/reportecontratos.js')); ?>" defer></script>
<?php endif; ?>

<?php if((Route::is('listareporteasistencia')) && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 ||Auth::user()->rol_id == 8)): ?>
    <script src="<?php echo e(asset('js/administracion/reportes/asistencia.js')); ?>" defer></script>
<?php endif; ?>

<?php if(Route::is('login')): ?>
    <script src="<?php echo e(asset('js/administracion/login.js')); ?>" defer></script>
<?php endif; ?>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/parciales/script.blade.php ENDPATH**/ ?>