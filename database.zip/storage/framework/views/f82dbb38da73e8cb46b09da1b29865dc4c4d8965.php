
<?php $__env->startSection('titulo','Contratos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-8">
            <h2 style="text-align: left; color: #0AA09E"><?php echo app('translator')->get('mensajes.mensajedispositivos'); ?></h2>
        </div>
        <div class="col-2">
            <a type="button" class="btn btn-outline-success btn-block" href="<?php echo e(route('configuracion')); ?>">Configuración</a>
        </div>
        <div class="col-2">
            <a type="button" class="btn btn-outline-success btn-block" href="<?php echo e(route('dispositivonuevo')); ?>">Nuevo dispositivo</a>
        </div>
    </div>
    <table id="tablaContratos" class="table table-bordered">
        <thead>
            <tr>
                <th  style =" text-align:center;" scope="col">ESTATUS</th>
                <th  style =" text-align:center;" scope="col">IDENTIFICADOR</th>
                <th  style =" text-align:center;" scope="col">TITULO</th>
                <th  style =" text-align:center;" scope="col">DESCRIPCION</th>
                <th  style =" text-align:center;" scope="col">VERSION</th>
                <th  style =" text-align:center;" scope="col">APLICACION</th>
                <th  style =" text-align:center;" scope="col">ACTIVAR/DESACTIVAR</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dispositivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php if($dispositivo->estatus  == 1): ?>
                    <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                <?php else: ?>
                    <td align='center' ><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                <?php endif; ?>
                <td align='center'><?php echo e($dispositivo->id); ?></td>
                <td align='center'><?php echo e($dispositivo->titulo); ?></td>
                <td align='center'><?php echo e($dispositivo->descripcion); ?></td>
                <td align='center'><?php echo e($dispositivo->version); ?></td>
                <td align='center'><a href="<?php echo e($dispositivo->apk); ?>" class="btn btn-outline-primary w-100" role="button" aria-pressed="true" style="font-size: 15px;">DESCARGAR APLICACION</a></td>
                <?php if($dispositivo->estatus  == 1 ): ?>
                    <td align='center'> <a href="<?php echo e(route('dispositivoestatus',[$dispositivo->id,$dispositivo->estatus])); ?>" class="btn btn-danger">DESACTIVAR</a></td>
                <?php else: ?>
                    <td align='center'> <a href="<?php echo e(route('dispositivoestatus',[$dispositivo->id,$dispositivo->estatus])); ?>" class="btn btn-primary">ACTIVAR</a></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/general/listas.blade.php ENDPATH**/ ?>