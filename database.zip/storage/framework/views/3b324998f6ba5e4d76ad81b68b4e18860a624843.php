
<?php $__env->startSection('titulo','Lista Franquicias'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2 >Informacion de <?php echo e($usuario[0]->name); ?> </h2>
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="editar-tab" data-toggle="tab" href="#editar" role="tab" aria-controls="editar"
               aria-selected="true">Editar</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="controlentradasalida-tab" data-toggle="tab" href="#controlentradasalida" role="tab" aria-controls="controlentradasalida"
               aria-selected="false">Control Entrada - Salida</a>
        </li>
        <?php if($usuario[0]->rol_id == 12 || $usuario[0]->rol_id == 13 ||  $usuario[0]->rol_id == 4): ?>
            <li class="nav-item">
                <a class="nav-link" id="dispositivos-tab" data-toggle="tab" href="#dispositivos" role="tab"
                   aria-controls="dispositivos" aria-selected="false">Dispositivos</a>
            </li>
        <?php endif; ?>
    </ul>

    <div class="tab-content" style="margin-top:30px;">
        <div class="tab-pane active" id="editar" role="tabpanel" aria-labelledby="editar-tab">
            <form  action="<?php echo e(route('actualizarUsuarioFranquicia',[$id,$idusuario])); ?>" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Nombre</label>
                            <input type="text" name="nombre" class="form-control <?php echo $errors->first('nombre','is-invalid'); ?>"  placeholder="Nombre"  value="<?php echo e($usuario[0]->name); ?>">
                            <?php echo $errors->first('nombre','<div class="invalid-feedback">Nombre no valido</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Numero de control</label>
                            <input type="text" class="form-control" readonly  value="<?php echo e($usuario[0]->codigoasistencia); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Correo</label>
                            <input type="text" name="correo" class="form-control <?php echo $errors->first('correo','is-invalid'); ?>"  placeholder="Correo"  value="<?php echo e($usuario[0]->email); ?>">
                            <?php echo $errors->first('correo','<div class="invalid-feedback">El correo no es valido</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Contraseña</label>
                            <input type="password" name="contrasena" class="form-control <?php echo $errors->first('contrasena','is-invalid'); ?>"  placeholder="Contraseña" id="contrasena">
                            <?php echo $errors->first('contrasena','<div class="invalid-feedback">La contraseña debe contener: Una letra mayuscula,una minuscula,un numero y al menos 8 caracteres.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Confirmar contraseña</label>
                            <input type="password" name="ccontrasena" class="form-control <?php echo $errors->first('ccontrasena','is-invalid'); ?>" id="contrasena2" placeholder="Confirmar contraseña" >
                            <?php echo $errors->first('ccontrasena','<div class="invalid-feedback">La contraseña no coincide</div>'); ?>


                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <label>Seleccionar el Rol</label>
                        <select name="rol" class="form-control form-control-sm <?php echo $errors->first('rol','is-invalid'); ?>" required>
                            <option></option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($rol->id == $usuario[0]->rol_id): ?>
                                    <option selected value="<?php echo e($rol->id); ?>"><?php echo e($rol->rol); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->rol); ?></option>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $errors->first('rol','<div class="invalid-feedback">Selecciona un rol</div>'); ?>

                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Seleccionar la zona</label>
                            <select name="idzona" class="form-control  <?php $__errorArgs = ['idzona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                <option value=""></option>
                                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($zona->id == $usuario[0]->id_zona): ?>
                                        <option selected value="<?php echo e($zona->id); ?>"><?php echo e($zona->zona); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($zona->id); ?>"><?php echo e($zona->zona); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('idzona','<div class="invalid-feedback">Para el rol de cobranza es necesario seleccionar la zona.</div>'); ?>

                        </div>
                    </div>
                    <?php if($usuario[0]->rol_id == 12 ||$usuario[0]->rol_id  == 4  || $usuario[0]->rol_id == 12 ||  $usuario[0]->rol_id  == 13 ||  $usuario[0]->rol_id  == 14): ?>
                        <div class="col-2">
                            <div class="form-group">
                                <label>Sueldo</label>
                                <input type="number" name="sueldo" class="form-control <?php echo $errors->first('sueldo','is-invalid'); ?>" min="0" placeholder="Sueldo"  value="<?php echo e($usuario[0]->sueldo); ?>">
                                <?php echo $errors->first('sueldo','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tarjeta</label>
                            <input type="text" name="tarjeta" class="form-control <?php echo $errors->first('tarjeta','is-invalid'); ?>" min="16" maxlength="20" placeholder="Tarjeta" value="<?php echo e($usuario[0]->tarjeta); ?>">
                            <?php echo $errors->first('tarjeta','<div class="invalid-feedback">Campo obligatorio / Al menos 16 caracteres.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Otra tarjeta</label>
                            <input type="text" name="otratarjeta" class="form-control <?php echo $errors->first('otratarjeta','is-invalid'); ?>" min="16" maxlength="20" placeholder="Tarjeta" value="<?php echo e($usuario[0]->otratarjeta); ?>">
                            <?php echo $errors->first('otratarjeta','<div class="invalid-feedback">Campo obligatorio / Al menos 16 caracteres.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1"  onclick="mostrarPassword()">
                            <label class="form-check-label" for="exampleCheck1">Mostrar contraseña</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Recordatorio</label>
                            <input type="date" name="fecharenovacion"
                                   class="form-control <?php echo $errors->first('fecharenovacion','is-invalid'); ?>"
                                   placeholder="Fecha de renovación" value="<?php if($usuario[0]->renovacion != null): ?><?php echo e(\Carbon\Carbon::parse($usuario[0]->renovacion)->format('Y-m-d')); ?><?php endif; ?>">
                            <?php if($errors->has('fecharenovacion')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('fecharenovacion')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="sinrenovacion">
                            <label class="form-check-label" for="exampleCheck1">Sin renovacion</label>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-1">
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <img src="<?php echo e(asset($usuario[0]->foto)); ?>"   width="210" height="280" style="border-radius: 10%">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1">
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto del usuario ( FOTO JPG)</label>
                            <input type="file" name="foto" class="form-control-file <?php echo $errors->first('foto','is-invalid'); ?> <?php if($usuario[0]->foto != ''): ?> is-valid <?php endif; ?>"  accept="image/jpg" >
                            <?php echo $errors->first('foto','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Acta de nacimiento (PDF)</label>
                            <input type="file" name="actanacimiento" class="form-control-file <?php echo $errors->first('actanacimiento','is-invalid'); ?>  <?php if($usuario[0]->actanacimiento != ''): ?> is-valid <?php endif; ?>"  accept="application/pdf" >
                            <?php echo $errors->first('actanacimiento','<div class="invalid-feedback">El acta de nacimiento debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Identificacion Oficial (PDF)</label>
                            <input type="file" name="identificacion" class="form-control-file  <?php echo $errors->first('identificacion','is-invalid'); ?> <?php if($usuario[0]->identificacion != ''): ?> is-valid <?php endif; ?>" accept="application/pdf" >
                            <?php echo $errors->first('identificacion','<div class="invalid-feedback">La identificacion debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>CURP (FOTO JPG)</label>
                            <input type="file" name="curp" class="form-control-file <?php echo $errors->first('curp','is-invalid'); ?> <?php if($usuario[0]->curp != ''): ?> is-valid <?php endif; ?>"  accept="image/jpg" >
                            <?php echo $errors->first('curp','<div class="invalid-feedback">El CURP debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Comprobante de domicilio (PDF)</label>
                            <input type="file" name="comprobante" class="form-control-file  <?php echo $errors->first('comprobante','is-invalid'); ?> <?php if($usuario[0]->comprobantedomicilio != ''): ?> is-valid <?php endif; ?>"  accept="application/pdf" >
                            <?php echo $errors->first('comprobante','<div class="invalid-feedback">El comprobante debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-1"></div>
                </div>
                <div class="row">
                    <div class="col-1">
                    </div>
                    <?php if($usuario[0]->foto): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,0])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button"  class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->foto)); ?>', 'Foto - <?php echo e($usuario[0]->name); ?>', '0')">Ver </a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->actanacimiento != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,1])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->actanacimiento)); ?>', 'Acta de nacimiento - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->identificacion != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,2])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->identificacion)); ?>', 'Identificacion oficial - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->curp != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,3])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->curp)); ?>', 'CURP - <?php echo e($usuario[0]->name); ?>', '0')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->comprobantedomicilio != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,4])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->comprobantedomicilio)); ?>', 'Comprobante de domicilio - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Seguro social (PDF)</label>
                            <input type="file" name="seguro" class="form-control-file <?php echo $errors->first('seguro','is-invalid'); ?> <?php if($usuario[0]->segurosocial != ''): ?> is-valid <?php endif; ?>"  accept="application/pdf" >
                            <?php echo $errors->first('seguro','<div class="invalid-feedback">El seguro social debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Solicitud / Curriculum (PDF)</label>
                            <input type="file" name="solicitud" class="form-control-file <?php echo $errors->first('solicitud','is-invalid'); ?> <?php if($usuario[0]->solicitud != ''): ?> is-valid <?php endif; ?>" accept="application/pdf" >
                            <?php echo $errors->first('solicitud','<div class="invalid-feedback">La solicitud debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tarjeta para pago (FOTO JPG)</label>
                            <input type="file" name="tarjetapago" class="form-control-file <?php echo $errors->first('tarjetapago','is-invalid'); ?> <?php if($usuario[0]->tarjetapago != ''): ?> is-valid <?php endif; ?>"   accept="image/jpg" >
                            <?php echo $errors->first('tarjetapago','<div class="invalid-feedback">El numero de la tarjeta debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Otra tarjeta (FOTO JPG)</label>
                            <input type="file" name="otratarjetapago" class="form-control-file <?php echo $errors->first('otratarjetapago','is-invalid'); ?> <?php if($usuario[0]->otratarjetapago != ''): ?> is-valid <?php endif; ?>"   accept="image/jpg" >
                            <?php echo $errors->first('otratarjetapago','<div class="invalid-feedback">El numero de la tarjeta debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Contacto de Emergencia (PDF)</label>
                            <input type="file" name="contactoemergencia" class="form-control-file <?php echo $errors->first('contactoemergencia','is-invalid'); ?> <?php if($usuario[0]->contactoemergencia != ''): ?> is-valid <?php endif; ?>" accept="application/pdf" >
                            <?php echo $errors->first('contactoemergencia','<div class="invalid-feedback">El contacto de emergencia debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <?php if($usuario[0]->segurosocial != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,5])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->segurosocial)); ?>', 'Seguro Social - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->solicitud != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,6])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->solicitud)); ?>', 'Solicitud / CV- <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->tarjetapago != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,7])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->tarjetapago)); ?>', 'Tarjeta para pago - <?php echo e($usuario[0]->name); ?>', '0')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->otratarjetapago != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,11])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->otratarjetapago)); ?>', 'Otra tarjeta para pago - <?php echo e($usuario[0]->name); ?>', '0')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->contactoemergencia != null): ?>
                        <?php if($usuario[0]->otratarjetapago == null): ?>
                            <div class="col-2"></div>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block"
                                   href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,8])); ?>">Descargar</a>
                            </div>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                                   onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->contactoemergencia)); ?>', 'Contacto de emergencia - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                            </div>
                        <?php else: ?>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block"
                                   href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,8])); ?>">Descargar</a>
                            </div>
                            <div class="col-1">
                                <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                                   onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->contactoemergencia)); ?>', 'Contacto de emergencia - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Contrato laboral (FOTO JPG)</label>
                            <input type="file" name="contratolaboral" class="form-control-file <?php echo $errors->first('contratolaboral','is-invalid'); ?> <?php if($usuario[0]->contratolaboral != ''): ?> is-valid <?php endif; ?>" accept="image/jpg" >
                            <?php echo $errors->first('contratolaboral','<div class="invalid-feedback">El contrato laboral debera estar en imagen JPG.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Pagare (PDF)</label>
                            <input type="file" name="pagare" class="form-control-file <?php echo $errors->first('pagare','is-invalid'); ?> <?php if($usuario[0]->pagare != ''): ?> is-valid <?php endif; ?>" accept="application/pdf" >
                            <?php echo $errors->first('pagare','<div class="invalid-feedback">El pagare debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check' ></a></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <?php if($usuario[0]->contratolaboral != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,9])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->contratolaboral)); ?>', 'Contrato laboral - <?php echo e($usuario[0]->name); ?>', '0')">Ver</a>
                        </div>
                    <?php endif; ?>
                    <?php if($usuario[0]->pagare != null): ?>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block"
                               href="<?php echo e(route('descargarArchivo',[$usuario[0]->id,10])); ?>" >Descargar</a>
                        </div>
                        <div class="col-1">
                            <a type="button" class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#vistaprevia"
                               onclick="crearVistaPrevia('<?php echo e(asset($usuario[0]->pagare)); ?>', 'Pagare - <?php echo e($usuario[0]->name); ?>', '1')">Ver</a>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(Auth::user()->rol_id == 7): ?>
                    <hr>
                    <h2><?php echo app('translator')->get('mensajes.mensajesucursales'); ?></h2>
                    <h5><?php echo app('translator')->get('mensajes.mensajesucursalesconfirmaciones'); ?></h5>
                    <div class="row">
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $existe = false;
                            ?>
                            <?php $__currentLoopData = $sucursalesSeleccionadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursalSeleccionada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($sucursalSeleccionada->id_franquicia ==  $sucursal->id): ?>
                                    <?php
                                        $existe = true;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-2">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input " name="<?php echo e($sucursal->id); ?>" id="<?php echo e($sucursal->id); ?>" <?php if($existe): ?> checked <?php endif; ?> value="1">
                                    <label class="custom-control-label" for="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->colonia); ?> <?php echo e($sucursal->numero); ?>,<?php echo e($sucursal->ciudad); ?> <?php echo e($sucursal->estado); ?></label>
                                </div>
                            </div>
                            <?php
                                $i = $i +2;
                            ?>
                            <?php if($i==12): ?>
                    </div>
                    <div class="row">
                        <?php
                            $i = 0;
                        ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-4">
                        <a href="<?php echo e(route('usuariosFranquicia',$id)); ?>" class="btn btn-outline-success btn-block"><?php echo app('translator')->get('mensajes.regresar'); ?></a>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-success btn-block"  type="submit"><?php echo app('translator')->get('mensajes.mensajeactualizarusuario'); ?></button>
                    </div>
                </div>
            </form>

        </div>
        <div class="tab-pane" id="controlentradasalida" role="tabpanel" aria-labelledby="controlentradasalida-tab">
            <form  action="<?php echo e(route('actualizarControlEntradaSalidaUsuarioFranquicia',[$id,$idusuario])); ?>" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Hora para que comience a contar como retardo</label>
                            <input type="time" name="horaini" class="form-control" value="<?php echo e($usuario[0]->horaini); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Hora para que comience a contar como falta</label>
                            <input type="time" name="horafin" class="form-control" value="<?php echo e($usuario[0]->horafin); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <button class="btn btn-outline-success btn-block" type="submit">Actualizar</button>
                    </div>
                </div>
            </form>
        </div>
        <?php if($usuario[0]->rol_id == 12 || $usuario[0]->rol_id == 13 || $usuario[0]->rol_id == 4): ?>
            <div class="tab-pane" id="dispositivos" role="tabpanel" aria-labelledby="dispositivos-tab">
                <table id="tablaFranquicias" class="table table-bordered">
                    <thead>
                    <tr>
                        <th  style =" text-align:center;" scope="col">ESTATUS</th>
                        <th  style =" text-align:center;" scope="col">MODELO</th>
                        <th  style =" text-align:center;" scope="col">VERSION</th>
                        <th  style =" text-align:center;" scope="col">REGISTRO</th>
                        <th  style =" text-align:center;" scope="col">ACTIVAR/DESACTIVAR</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dispositivosusuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($dispositivo->estatus  == 1): ?>
                                <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                            <?php else: ?>
                                <td align='center' ><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                            <?php endif; ?>
                            <td align='center'><?php echo e($dispositivo->modelo); ?></td>
                            <td align='center'><?php echo e($dispositivo->versionandroid); ?></td>
                            <td align='center'><?php echo e($dispositivo->created_at); ?></td>
                            <?php if($dispositivo->estatus  == 1 ): ?>
                                <td align='center'> <a href="<?php echo e(route('actualizarUsuarioFranquiciadispositivo',[$id,$idusuario,$dispositivo->id])); ?>" class="btn btn-danger">DESACTIVAR</a></td>
                            <?php else: ?>
                                <td align='center'> <a href="<?php echo e(route('actualizarUsuarioFranquiciadispositivo',[$id,$idusuario,$dispositivo->id])); ?>" class="btn btn-primary">ACTIVAR</a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!--Ventana modal para vista previa -->
    <div class="modal fade" id="vistaprevia" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div id="aparienciaModal" class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" id="encabezadoVistaPrevia"> </div>
                <div class="modal-body">
                    <div id="vistacontenido"> </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/franquicia/editarusuario.blade.php ENDPATH**/ ?>