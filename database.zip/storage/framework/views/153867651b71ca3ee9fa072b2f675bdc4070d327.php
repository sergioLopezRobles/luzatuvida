
<?php $__env->startSection('titulo','Contratos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(Auth::user()->rol_id == 13 || Auth::user()->rol_id == 12): ?>
        <h2><?php echo app('translator')->get('mensajes.mensajemiscontratosfranquicia'); ?></h2>
    <?php else: ?>
        <h2>Contratos de la sucursal</h2>
    <?php endif; ?>
    <form action="<?php echo e(route('filtrarlistacontrato',$idFranquicia)); ?>" enctype="multipart/form-data" method="POST"
          onsubmit="btnSubmit.disabled = true;">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-4">
                <input name="filtro" type="text" class="form-control" placeholder="Buscar..">
            </div>
            <div class="col-5">
                <button type="submit" name="btnSubmit" class="btn btn-outline-success">Buscar</button>
            </div>
        </div>
    </form>

    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Estado</label>
                <input type="text" name="estado" class="form-control" readonly
                       value="<?php echo e($franquiciaContratos[0]->estado); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ciudad</label>
                <input type="text" name="ciudad" class="form-control" readonly
                       value="<?php echo e($franquiciaContratos[0]->ciudad); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="colonia" class="form-control" readonly
                       value="<?php echo e($franquiciaContratos[0]->colonia); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Numero Interior/Exterior</label>
                <input type="text" name="numero" class="form-control" readonly
                       value="<?php echo e($franquiciaContratos[0]->numero); ?>">
            </div>
        </div>
    </div>
    <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
        <div id="accordion">
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne"
                                aria-expanded="true"
                                aria-controls="collapseOne">
                            Filtros
                        </button>
                    </h5>
                </div>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <form action="<?php echo e(route('filtrarlistacontratocheckbox',$idFranquicia)); ?>"
                              enctype="multipart/form-data" method="POST"
                              onsubmit="btnSubmit.disabled = true;">
                            <?php echo csrf_field(); ?>
                            <div class="row" id="divFiltrosContratos">
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbGarantias" id="customCheck1"
                                               value="1" <?php if($cbGarantias != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck1">Garantias</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbSupervision" id="customCheck2"
                                               value="1" <?php if($cbSupervision != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck2">Supervision</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbAtrasado" id="customCheck3"
                                               value="1" <?php if($cbAtrasado != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck3">Atrasados</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbEntrega" id="customCheck4"
                                               value="1" <?php if($cbEntrega != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck4">Entrega</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbLaboratorio" id="customCheck5"
                                               value="1" <?php if($cbLaboratorio != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck5">Laboratorio</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbConfirmacion" id="customCheck6"
                                               value="1" <?php if($cbConfirmacion != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck6">Confirmación</label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbTodos" id="customCheck7"
                                               value="1" <?php if($cbTodos != null): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="customCheck7">Todos</label>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="form-group">
                                        <select name="zonaU"
                                                id="zonaU"
                                                class="form-control">
                                            <?php if(count($zonas) > 0): ?>
                                                <option value="">Todas las zonas</option>
                                                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($zona->id); ?>" <?php echo e(isset($zonaU) ? ($zonaU == $zona->id ? 'selected' : '' ) : ''); ?>><?php echo e($zona->zona); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option selected>Sin registros</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col">
                                    <button class="btn btn-outline-success" name="btnSubmit"
                                            type="submit">Aplicar
                                    </button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label>Fecha inicial</label>
                                        <input type="date" name="fechainibuscar" class="form-control <?php echo $errors->first('fechainibuscar','is-invalid'); ?>" <?php if(isset($fechainibuscar)): ?> value = "<?php echo e($fechainibuscar); ?>" <?php endif; ?>>
                                        <?php if($errors->has('fechainibuscar')): ?>
                                            <div class="invalid-feedback"><?php echo e($errors->first('fechainibuscar')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label>Fecha final</label>
                                        <input type="date" name="fechafinbuscar" class="form-control <?php echo $errors->first('fechafinbuscar','is-invalid'); ?>" <?php if(isset($fechafinbuscar)): ?> value = "<?php echo e($fechafinbuscar); ?>" <?php endif; ?>>
                                        <?php if($errors->has('fechafinbuscar')): ?>
                                            <div class="invalid-feedback"><?php echo e($errors->first('fechafinbuscar')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <label style="font-size: 17px; margin-top: 35px; color: #ea9999; font-weight: bold">Seleccionar mas de 3 filtros puede demorar varios minutos</label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="contenedortblContratos">
        <table id="tablaContratos" class="table table-bordered">
            <?php if($contratosgeneral != null && sizeof($contratosgeneral)>0): ?>
                <thead>
                <tr>
                    <?php if( Auth::user()->rol_id == 4 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8  ||  Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 6): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            CONTRATO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ESTATUS
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            RELACIÓN
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 4): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LOCALIDAD
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">COLONIA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CALLE
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA
                            CREACIÓN
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA
                            ENTREGA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            FECHA GARANTIA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ASISTENTE
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ZONA</th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LOCALIDAD
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">COLONIA
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CALLE
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">NUMERO
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CLIENTE
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">
                            TELEFONO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ABONO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">SALDO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ULTIMO
                            ABONO
                        </th>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">PROMOCION
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ATRASO
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 12): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">PAQUETE
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">EDITAR
                        </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">VER</th>
                    <?php endif; ?>
                </tr>
                </thead>
            <?php endif; ?>
            <tbody>
            <?php if(Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                <?php if($contratos != null): ?>
                    <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($contrato->estatus_estadocontrato >= 1): ?>
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                            <?php else: ?>
                                <td align='center' style="font-size: 10px;"><p style="color:#c9c9c9"><?php echo e($contrato->id); ?></p></td>
                            <?php endif; ?>
                            <?php switch($contrato->estatus_estadocontrato):
                                case (0): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-secondary noterminados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (1): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-success terminados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                    <?php if($cbGarantias == 1): ?>
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">GARANTIAS (REPORTADAS/ASIGNADAS)
                            </th>
                        </tr>
                        <?php if($contratosreportesgarantia != null): ?>
                            <?php $__currentLoopData = $contratosreportesgarantia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align='center' <?php if($contrato->estadogarantia == 0): ?> style="font-size: 10px; background-color:#ea9999;" <?php else: ?> style="font-size: 10px; background-color:#5bc0de;" <?php endif; ?>><p style="color:#FFFFFF"><?php echo e($contrato->id); ?></p></td>
                                    <?php switch($contrato->estatus_estadocontrato):
                                        case (2): ?>
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-primary entregados"
                                                    style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                        </td>
                                        <?php break; ?>
                                        <?php case (5): ?>
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-info pagados"
                                                    style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                        </td>
                                        <?php break; ?>
                                        <?php case (12): ?>
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-success terminados"
                                                    style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                        </td>
                                        <?php break; ?>
                                        <?php case (4): ?>
                                        <?php if($contrato->dias <= 10): ?>
                                            <td align='center' style="font-size: 10px;">
                                                <button type="button" class="btn btn-light atrasados"
                                                        style="color:#000000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                            </td>
                                        <?php endif; ?>
                                        <?php if($contrato->dias >= 11 && $contrato->dias <= 20): ?>
                                            <td align='center' style="font-size: 10px;">
                                                <button type="button" class="btn btn-light prueba2"
                                                        style="color:#000000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                            </td>
                                        <?php endif; ?>
                                        <?php if($contrato->dias > 20): ?>
                                            <td align='center' style="font-size: 10px;">
                                                <button type="button" class="btn btn-light ahora3"
                                                        style="color:#000000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                            </td>
                                        <?php endif; ?>
                                        <?php break; ?>
                                    <?php endswitch; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechagarantia)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                        <?php if($contrato->totalabono != null): ?>
                                            <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                        <?php if($contrato->idcontratorelacion == null): ?>
                                            <?php if($contrato->promo == 0): ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php else: ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><a
                                                href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                        <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($cbGarantias == 1): ?>
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">GARANTIAS
                            </th>
                        </tr>
                        <?php if($contratosgarantiascreadas != null): ?>
                            <?php $__currentLoopData = $contratosgarantiascreadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align='center' <?php if($contrato->estadogarantia == 2): ?> style="font-size: 10px; background-color:#5cb85c;" <?php else: ?> style="font-size: 10px; background-color:#5bc0de;" <?php endif; ?>><p style="color:#FFFFFF"><?php echo e($contrato->id); ?></p></td>
                                    <?php switch($contrato->estatus_estadocontrato):
                                        case (1): ?>
                                        <td align='center' style="font-size: 10px;">
                                            <button type="button" class="btn btn-success terminados"
                                                    style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                        </td>
                                        <?php break; ?>
                                    <?php endswitch; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechagarantia)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                        <?php if($contrato->totalabono != null): ?>
                                            <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                        <?php if($contrato->idcontratorelacion == null): ?>
                                            <?php if($contrato->promo == 0): ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php else: ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><a
                                                href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                        <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($cbSupervision == 1): ?>
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">SUPERVISION
                            </th>
                        </tr>
                        <?php if($contratossupervision != null): ?>
                            <?php $__currentLoopData = $contratossupervision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn"
                                                style="background-color:#F88F32;color:#FFFFFF;text-align:center;font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                        <td align='center'></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                        <?php if($contrato->totalabono != null): ?>
                                            <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                        <?php if($contrato->idcontratorelacion == null): ?>
                                            <?php if($contrato->promo == 0): ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php else: ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><a
                                                href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                        <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($cbEntrega == 1): ?>
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">NO ENTREGADOS
                            </th>
                        </tr>
                        <?php if($contratosnoenviados != null): ?>
                            <?php $__currentLoopData = $contratosnoenviados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-success terminados"
                                                style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                        <td align='center'></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                        <?php if($contrato->totalabono != null): ?>
                                            <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                        <?php if($contrato->idcontratorelacion == null): ?>
                                            <?php if($contrato->promo == 0): ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php else: ?>
                                                <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                               aria-hidden="true"></i></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12): ?>
                                        <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                        <td align='center' style="font-size: 10px;"><a
                                                href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                                </button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                        <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                        <td align='center' style="font-size: 10px;"><a href="">
                                                <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                        class="fas fa-book-open"></i></button>
                                            </a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if((Auth::user()->rol_id == 4 && $cbAtrasado == null) || (Auth::user()->rol_id != 4 && $cbAtrasado == 1)): ?>
                    <tr>
                        <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">ATRASADOS
                        </th>
                    </tr>
                <?php endif; ?>
                <?php if($contratosatrasados != null): ?>
                    <?php $__currentLoopData = $contratosatrasados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                            <?php switch($contrato->estatus_estadocontrato):
                                case (4): ?>
                                <?php if($contrato->dias <= 10): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-light atrasados"
                                                style="color:#000000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                <?php endif; ?>
                                <?php if($contrato->dias >= 11 && $contrato->dias <= 20): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-light prueba2"
                                                style="color:#000000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                <?php endif; ?>
                                <?php if($contrato->dias > 20): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-light ahora3"
                                                style="color:#000000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                <?php endif; ?>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                <?php if($contrato->totalabono != null): ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                <?php if($contrato->idcontratorelacion == null): ?>
                                    <?php if($contrato->promo == 0): ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><a
                                        href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if((Auth::user()->rol_id == 4)): ?>
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">
                            PRIORITARIOS
                        </th>
                    </tr>
                <?php endif; ?>
                <?php if($contratosprioritarios != null): ?>
                    <?php $__currentLoopData = $contratosprioritarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                            <?php switch($contrato->estatus_estadocontrato):
                                case (2): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-primary entregados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (5): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info pagados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                <?php if($contrato->totalabono != null): ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                <?php if($contrato->idcontratorelacion == null): ?>
                                    <?php if($contrato->promo == 0): ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><a
                                        href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if((Auth::user()->rol_id == 4)): ?>
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">PERIODO
                        </th>
                    </tr>
                <?php endif; ?>
                <?php if($contratosperiodo != null): ?>
                    <?php $__currentLoopData = $contratosperiodo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                            <?php switch($contrato->estatus_estadocontrato):
                                case (2): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-primary entregados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (5): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info pagados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                <?php if($contrato->totalabono != null): ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                <?php if($contrato->idcontratorelacion == null): ?>
                                    <?php if($contrato->promo == 0): ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><a
                                        href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if((Auth::user()->rol_id == 4 && $cbEntrega == null) || (Auth::user()->rol_id != 4 && $cbEntrega == 1)): ?>
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">POR
                            ENTREGAR
                        </th>
                    </tr>
                <?php endif; ?>
                <?php if($contratosentregar != null): ?>
                    <?php $__currentLoopData = $contratosentregar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                            <?php switch($contrato->estatus_estadocontrato):
                                case (12): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-success terminados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                <?php if($contrato->totalabono != null): ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                <?php if($contrato->idcontratorelacion == null): ?>
                                    <?php if($contrato->promo == 0): ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><a
                                        href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                    <?php if($cbLaboratorio == 1): ?>
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">
                                LABORATORIO
                            </th>
                        </tr>
                    <?php endif; ?>
                    <?php if($contratoslaboratorio != null): ?>
                        <?php $__currentLoopData = $contratoslaboratorio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                                <?php switch($contrato->estatus_estadocontrato):
                                    case (7): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-primary aprobado"
                                                style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php break; ?>
                                    <?php case (10): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-warning manofactura"
                                                style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php break; ?>
                                    <?php case (11): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-info enprocesodeenvio"
                                                style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php break; ?>
                                <?php endswitch; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 4): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                    <td align='center'></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                    <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                    <?php if($contrato->totalabono != null): ?>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"></td>
                                    <?php endif; ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                    <?php if($contrato->idcontratorelacion == null): ?>
                                        <?php if($contrato->promo == 0): ?>
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#ffaca6; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#0AA09E; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 12): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><a
                                            href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                            </button>
                                        </a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                    <td align='center' style="font-size: 10px;"><a
                                            href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                    <td align='center' style="font-size: 10px;"><a href="">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                    <?php if($cbConfirmacion == 1): ?>
                        <tr>
                            <th style=" text-align:center;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">
                                CONFIRMACIONES
                            </th>
                        </tr>
                    <?php endif; ?>
                    <?php if($contratosconfirmaciones != null): ?>
                        <?php $__currentLoopData = $contratosconfirmaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                                <?php switch($contrato->estatus_estadocontrato):
                                    case (1): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-success terminados"
                                                style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php break; ?>
                                    <?php case (9): ?>
                                    <td align='center' style="font-size: 10px;">
                                        <button type="button" class="btn btn-warning manofactura"
                                                style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                    </td>
                                    <?php break; ?>
                                <?php endswitch; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 4): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                    <td align='center'></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                    <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                    <?php if($contrato->totalabono != null): ?>
                                        <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"></td>
                                    <?php endif; ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                    <?php if($contrato->idcontratorelacion == null): ?>
                                        <?php if($contrato->promo == 0): ?>
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#ffaca6; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        <?php else: ?>
                                            <td align='center' style="font-size: 10px;"><i class="fas fa-tag"
                                                                                           style="color:#0AA09E; font-size: 18px;"
                                                                                           aria-hidden="true"></i></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 12): ?>
                                    <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                    <td align='center' style="font-size: 10px;"><a
                                            href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                            </button>
                                        </a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                    <td align='center' style="font-size: 10px;"><a
                                            href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                    <td align='center' style="font-size: 10px;"><a href="">
                                            <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                    class="fas fa-book-open"></i></button>
                                        </a></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if((Auth::user()->rol_id == 4 && $cbTodos == null) || (Auth::user()->rol_id != 4 && $cbTodos == 1)): ?>
                    <tr>
                        <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF; font-size: 10px; position: sticky; <?php if(Auth::user()->rol_id == 4): ?> top: 30px; <?php else: ?> top: 57px; <?php endif; ?> box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="22">TODOS</th>
                    </tr>
                <?php endif; ?>
                <?php if($contratos != null): ?>
                    <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($contrato->estatus_estadocontrato != 1 && Auth::user()->rol_id == 4): ?>
                                <?php if(strlen($contrato->fechacobroini) > 0): ?>
                                    <?php
                                        $continuar = false;
                                    ?>
                                    <?php if((\Carbon\Carbon::parse($now)->format('Y-m-d') >= \Carbon\Carbon::parse($contrato->fechacobroini)->format('Y-m-d')) && (\Carbon\Carbon::parse($now)->format('Y-m-d') <= \Carbon\Carbon::parse($contrato->fechacobrofin)->format('Y-m-d'))): ?>
                                        <?php
                                            $continuar = true;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($continuar): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($contrato->estatus_estadocontrato >= 1): ?>
                                <td align='center' style="font-size: 10px;"><p style="color:#0AA09E"><?php echo e($contrato->id); ?></p></td>
                            <?php else: ?>
                                <td align='center' style="font-size: 10px;"><p style="color:#c9c9c9"><?php echo e($contrato->id); ?></p></td>
                            <?php endif; ?>
                            <?php switch($contrato->estatus_estadocontrato):
                                case (0): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-secondary noterminados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (2): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-primary entregados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (3): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-danger precancelados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (5): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info pagados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (6): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info cancelados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (8): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-danger precancelados"
                                            style="color:#ff0000; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                                <?php case (14): ?>
                                <td align='center' style="font-size: 10px;">
                                    <button type="button" class="btn btn-info cancelados"
                                            style="color:#FEFEFE; font-size: 10px;"><?php echo e($contrato->descripcion); ?></button>
                                </td>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->idcontratorelacion); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->created_at)->format('Y-m-d')); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e(\Carbon\Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')); ?></td>
                                <td align='center'></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->nombre_usuariocreacion); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->zona); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->localidad); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->colonia); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->calle); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->numero); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 4): ?>
                                <td align='center' style="font-size: 10px;"><b><?php echo e($contrato->nombre); ?></b></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->telefono); ?></td>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalreal); ?></td>
                                <?php if($contrato->totalabono != null): ?>
                                    <td align='center' style="font-size: 10px;">$<?php echo e($contrato->totalabono); ?></td>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                                <td align='center' style="font-size: 10px;">$<?php echo e($contrato->total); ?></td>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->ultimoabono); ?></td>
                                <?php if($contrato->idcontratorelacion == null): ?>
                                    <?php if($contrato->promo == 0): ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#ffaca6; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php else: ?>
                                        <td align='center' style="font-size: 10px;"><i class="fas fa-tag" style="color:#0AA09E; font-size: 18px;"
                                                                                       aria-hidden="true"></i></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td align='center' style="font-size: 10px;"></td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->dias); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12): ?>
                                <td align='center' style="font-size: 10px;"><?php echo e($contrato->paquete); ?></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                                <td align='center' style="font-size: 10px;"><a
                                        href="<?php echo e(route('contratoactualizar',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i class="fas fa-pen"></i>
                                        </button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 4 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato == 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato == 0): ?>
                                <td align='center' style="font-size: 10px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contrato->id])); ?>" target="_blank">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                            <?php if(Auth::user()->rol_id == 12 && $contrato->estatus_estadocontrato > 0 || Auth::user()->rol_id == 13 && $contrato->estatus_estadocontrato > 0 ): ?>
                                <td align='center' style="font-size: 10px;"><a href="">
                                        <button type="button" class="btn btn-outline-success" style="font-size: 10px;"><i
                                                class="fas fa-book-open"></i></button>
                                    </a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/contrato/tabla.blade.php ENDPATH**/ ?>