<?php if(Session::has('bien')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Bien!</strong>  <?php echo Session::get('bien'); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>
<?php if(Session::has('alerta')): ?>
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    <strong>Alerta!</strong> <?php echo Session::get('alerta'); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Opps!</strong> <?php echo Session::get('error'); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>
<?php if(Session::has('mensaje')): ?>
    <div class="alert alert-secondary alert-dismissible fade show" role="alert">
        <strong>Mensaje:</strong>  <?php echo Session::get('mensaje'); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/parciales/notificaciones.blade.php ENDPATH**/ ?>