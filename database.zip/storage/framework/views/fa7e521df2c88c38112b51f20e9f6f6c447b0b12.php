<?php
    $i = 0;
?>

<?php $__currentLoopData = $franquicias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franquicia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="row" style="margin-top: 20px;">
        <div class="col-12" style="text-align: center; margin-bottom: 10px;"><h5><b>REPORTE DE VENTAS <?php echo e($franquicia->ciudad); ?></b></h5></div>
        <div class="col-1"></div>
        <div class="col-10">
            <table class="table table-bordered table-striped" style="text-align: center; position: relative; border-collapse: collapse;">
                <thead>
                <tr>
                    <th style=" text-align:center; font-size: 12px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col" colspan="9"><b>VENTAS DE OPTOMETRISTA</b></th>
                </tr>
                <tr>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">OPTOMETRISTA</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LUNES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">MARTES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">MIERCOLES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">JUEVES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">VIERNES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">SABADO</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">RECHAZADOS/<br>CANCELADOS</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ventasPorFranquiciaOptometrsitas[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventasPorFranquiciaOptometrsita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($ventasPorFranquiciaOptometrsita->totalVentas) > 0): ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita-> name); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita->ventasLunes); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita->ventasMartes); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita->ventasMiercoles); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita->ventasJueves); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita->ventasViernes); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaOptometrsita->ventasSabado); ?></td>
                            <th align='center' style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($ventasPorFranquiciaOptometrsita->totalVentas); ?></th>
                            <td align='center' style="font-size: 10px; background:#ea9999"><?php echo e($ventasPorFranquiciaOptometrsita->ventasRechazadas); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][0]); ?></th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][1]); ?></th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][2]); ?></th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][3]); ?></th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][4]); ?></th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][5]); ?></th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"></th>
                        <th style=" text-align:center; font-size: 10px; background:#ea9999; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasOptometristas[$i][6]); ?></th>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-1"> </div>
        <div class="col-1"></div>
        <div class="col-10">
            <table class="table table-bordered table-striped" style="text-align: center; position: relative; border-collapse: collapse;">
                <thead>
                <tr>
                    <th style=" text-align:center; font-size: 12px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col" colspan="9"><b>VENTAS DE ASISTENTE</b></th>
                </tr>
                <tr>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ASISTENTE</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LUNES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">MARTES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">MIERCOLES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">JUEVES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">VIERNES</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">SABADO</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">RECHAZADOS/<br>CANCELADOS</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ventasPorFranquiciaAsistentes[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventasPorFranquiciaAsistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($ventasPorFranquiciaAsistente -> totalVentas) > 0): ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente-> name); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente->ventasLunes); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente->ventasMartes); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente->ventasMiercoles); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente->ventasJueves); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente->ventasViernes); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($ventasPorFranquiciaAsistente->ventasSabado); ?></td>
                            <th align='center' style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($ventasPorFranquiciaAsistente->totalVentas); ?></th>
                            <td align='center' style="font-size: 10px; background:#ea9999"><?php echo e($ventasPorFranquiciaAsistente->ventasRechazadas); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][0]); ?></th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][1]); ?></th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][2]); ?></th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][3]); ?></th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][4]); ?></th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][5]); ?></th>
                    <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"></th>
                    <th style=" text-align:center; font-size: 10px; background:#ea9999; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col"><?php echo e($totalVentasAsistentes[$i][6]); ?></th>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php
        $i = $i + 1;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/contrato/listas/listareportecontratosdirector.blade.php ENDPATH**/ ?>