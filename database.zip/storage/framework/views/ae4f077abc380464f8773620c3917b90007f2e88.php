
<?php $__env->startSection('titulo','Inicio'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="contenedor">
        <h2><?php echo app('translator')->get('mensajes.mensajeeditarfranquicia'); ?></h2>
        <h4><?php echo app('translator')->get('mensajes.documentos'); ?></h4>
        <form id="frmFranquiciaNueva" action="<?php echo e(route('actualizarFranquicia',$franquicia[0]->id)); ?>"
              enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="franquicia">
                <div class="row">
                    <div class="col-4">
                        <img src="<?php echo e(asset($franquicia[0]->foto)); ?>" class="img-thumbnail"
                             style="width:100px;height:100px;">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label>Foto actual</label>
                            <input type="file" name="foto"
                                   class="form-control-file  <?php echo $errors->first('foto','is-invalid'); ?> <?php if($franquicia[0]->foto != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/png">
                            <?php echo $errors->first('foto','<div class="invalid-feedback">La foto debera estar en formato png.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label>CURP</label>
                            <input type="file" name="curp"
                                   class="form-control-file <?php echo $errors->first('curp','is-invalid'); ?> <?php if($franquicia[0]->curp != ''): ?> is-valid <?php endif; ?>"
                                   accept="application/pdf">
                            <?php echo $errors->first('curp','<div class="invalid-feedback">El CURP debera estar en formato png.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label>RFC</label>
                            <input type="file" name="rfc"
                                   class="form-control-file <?php echo $errors->first('rfc','is-invalid'); ?> <?php if($franquicia[0]->rfc != ''): ?> is-valid <?php endif; ?>"
                                   accept="application/pdf">
                            <?php echo $errors->first('rfc','<div class="invalid-feedback">El RFC debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label>Alta en Hacienda</label>
                            <input type="file" name="hacienda"
                                   class="form-control-file <?php echo $errors->first('hacienda','is-invalid'); ?> <?php if($franquicia[0]->hacienda != ''): ?> is-valid <?php endif; ?>"
                                   accept="application/pdf">
                            <?php echo $errors->first('hacienda','<div class="invalid-feedback">La alta en hacienda debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label>Acta de Nacimiento</label>
                            <input type="file" name="actanacimiento"
                                   class="form-control-file <?php echo $errors->first('actanacimiento','is-invalid'); ?> <?php if($franquicia[0]->actanacimiento != ''): ?> is-valid <?php endif; ?>"
                                   accept="application/pdf">
                            <?php echo $errors->first('actanacimiento','<div class="invalid-feedback">El acta de nacimiento debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label>Identificacion Oficial</label>
                            <input type="file" name="identificacion"
                                   class="form-control-file <?php echo $errors->first('identificacion','is-invalid'); ?> <?php if($franquicia[0]->identificacion != ''): ?> is-valid <?php endif; ?>"
                                   accept="application/pdf">
                            <?php echo $errors->first('identificacion','<div class="invalid-feedback">La identificacion debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                </div>
                <hr>
                <h4><?php echo app('translator')->get('mensajes.direccion'); ?></h4>
                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label>Estado</label>
                            <input type="text" name="estado"
                                   class="form-control <?php echo $errors->first('estado','is-invalid'); ?> <?php if($franquicia[0]->estado != ''): ?> is-valid <?php endif; ?>"
                                   placeholder="Estado" value="<?php echo e($franquicia[0]->estado); ?>">
                            <?php echo $errors->first('estado','<div class="invalid-feedback">El nombre del estado es demasiado largo.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Ciudad</label>
                            <input type="text" name="ciudad" id="link"
                                   class="form-control <?php echo $errors->first('ciudad','is-invalid'); ?> <?php if($franquicia[0]->ciudad != ''): ?> is-valid <?php endif; ?>"
                                   placeholder="Ciudad" value="<?php echo e($franquicia[0]->ciudad); ?>">
                            <?php echo $errors->first('ciudad','<div class="invalid-feedback">El nombre de la ciudad es demasiado largo.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Colonia</label>
                            <input type="text" name="colonia" id="link"
                                   class="form-control <?php echo $errors->first('colonia','is-invalid'); ?> <?php if($franquicia[0]->colonia != ''): ?> is-valid <?php endif; ?>"
                                   placeholder="Colonia" value="<?php echo e($franquicia[0]->colonia); ?>">
                            <?php echo $errors->first('colonia','<div class="invalid-feedback">El nombre de la colonia es demasiado largo.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Numero Interior/Exterior</label>
                            <input type="number" min="0" name="numero" id="link"
                                   class="form-control <?php echo $errors->first('numero','is-invalid'); ?> <?php if($franquicia[0]->numero != ''): ?> is-valid <?php endif; ?>"
                                   placeholder="Numero Interior/Exterior" value="<?php echo e($franquicia[0]->numero); ?>">
                            <?php echo $errors->first('numero','<div class="invalid-feedback">El numero es demasiado grande.</div>'); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label>Comprobante de domicilio</label>
                            <input type="file" name="comprobante"
                                   class="form-control-file <?php echo $errors->first('comprobante','is-invalid'); ?> <?php if($franquicia[0]->comprobante != ''): ?> is-valid <?php endif; ?>"
                                   accept="application/pdf">
                            <?php echo $errors->first('comprobante','<div class="invalid-feedback">El comprobante debera estar en formato PDF.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <?php
                        $rol_id = Auth::user()->rol_id;
                    ?>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Teléfono:</label>
                            <input type="text" name="telefonofranquicia"
                                   class="form-control <?php echo $errors->first('telefonofranquicia','is-invalid'); ?>"
                                   placeholder="Teléfono" value="<?php echo e($franquicia[0]->telefonofranquicia); ?>">
                            <?php echo $errors->first('telefonofranquicia','<div class="invalid-feedback">El teléfono debe contener 10 numeros.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Teléfono atención clientes:</label>
                            <input type="text" name="telefonoatencionclientes"
                                   class="form-control <?php echo $errors->first('telefonoatencionclientes','is-invalid'); ?>"
                                   placeholder="Ej: 000-000-00-00" value="<?php echo e($franquicia[0]->telefonoatencionclientes); ?>">
                            <?php echo $errors->first('telefonoatencionclientes','<div class="invalid-feedback">El teléfono debe contener al menos 10 dígitos. Ej: 000-000-00-00.</div>'); ?>

                        </div>
                    </div>
                    <?php if($rol_id==7): ?>
                        <div class="col-2">
                            <label> Estado franquicia</label>
                            <div class="form-check">
                                <input type="checkbox" name="activo" id="activo" class="form-check-input"
                                       <?php if($estado[0]->estado == 1): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="activo">Activo/Inactivo</label>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Observaciones</label>
                            <input type="text" name="observaciones" id="link"
                                   class="form-control <?php echo $errors->first('observaciones','is-invalid'); ?>"
                                   placeholder="Observaciones" maxlength="300"
                                   value="<?php echo e($franquicia[0]->observaciones); ?>">
                            <?php echo $errors->first('observaciones','<div class="invalid-feedback">Se supero el numero maximo de caracteres.</div>'); ?>

                        </div>
                    </div>
                </div>
                <hr>
                <h4>Stripe</h4>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Clave publicable</label>
                            <input type="text" name="claveP"
                                   class="form-control"
                                   placeholder="Clave publicable" value="<?php echo e($franquicia[0]->clavepublicablestripe); ?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Clave secreta</label>
                            <input type="text" name="claveS" id="link"
                                   class="form-control"
                                   placeholder="Clave secreta" value="<?php echo e($franquicia[0]->clavesecretastripe); ?>">
                        </div>
                    </div>
                </div>
                <div>
                    <div class="row">
                        <div class="col-4">
                            <a href="<?php echo e(route('listafranquicia')); ?>"
                               class="btn btn-outline-success btn-block"><?php echo app('translator')->get('mensajes.volverlistafranquicia'); ?></a>
                        </div>
                        <div class="col-8">
                            <button class="btn btn-outline-success btn-block" name="btnSubmit"
                                    type="submit"><?php echo app('translator')->get('mensajes.actualizar'); ?></button>
                        </div>
                    </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/franquicia/editar.blade.php ENDPATH**/ ?>