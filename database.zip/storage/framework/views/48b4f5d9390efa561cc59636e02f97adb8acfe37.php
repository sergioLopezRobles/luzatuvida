<div class="row" style="margin-left: 5px; margin-top: 30px; margin-right: 5px;">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">COBRADOR</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CONTRATO</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CLIENTE</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">ULTIMO ABONO</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">SALDO</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">TELEFONO</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">TELEFONO REFERENCIA</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">MENSAJE</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">ACCION</th>
            <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">LINK</th>
        </tr>
        </thead>
        <tbody>
        <?php if($contratoscortellamada != null && sizeof($contratoscortellamada) > 0): ?>

            <?php $__currentLoopData = $contratoscortellamada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratocortellamada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr <?php if($contratocortellamada->mensaje != null): ?> style="background-color: #AAFAAA"
                    <?php else: ?> style="background-color: #FACD73" <?php endif; ?>>
                    <td align='center' style="border: #707070 solid 1px;"><?php echo e($contratocortellamada->nombrecobrador); ?></td>
                    <td align='center' style="border: #707070 solid 1px;"><?php echo e($contratocortellamada->id_contrato); ?></td>
                    <td align='center' style="border: #707070 solid 1px;"><?php echo e($contratocortellamada->nombrecliente); ?></td>
                    <td align='center' style="border: #707070 solid 1px;">$<?php echo e($contratocortellamada->ultimoabono); ?></td>
                    <td align='center' style="border: #707070 solid 1px;">$<?php echo e($contratocortellamada->total); ?></td>
                    <td align='center' style="border: #707070 solid 1px;"><?php echo e($contratocortellamada->telefono); ?></td>
                    <td align='center' style="border: #707070 solid 1px;"><?php echo e($contratocortellamada->telefonoreferencia); ?></td>
                    <td align='center' style="border: #707070 solid 1px;"><?php echo e($contratocortellamada->mensaje); ?></td>
                    <td align='center' style="border: #707070 solid 1px;">
                        <a class="btn btn-primary btnmarcarcontratocortellamada" href="#" data-toggle="modal"
                           data-target="#modalmarcarcontratocortellamada"
                           data_parametros_modal="
                                        <?php echo e($contratocortellamada->indice .
                                            "," . $contratocortellamada->id_contrato .
                                            "," . $contratocortellamada->mensaje .
                                            "," . $contratocortellamada->telefono .
                                            "," . $contratocortellamada->telefonoreferencia .
                                            "," . $contratocortellamada->nombrecliente .
                                            "," . $contratocortellamada->ultimoabono .
                                            "," . $contratocortellamada->total); ?>">MARCAR
                        </a>
                    </td>
                    <td align='center' style="border: #707070 solid 1px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$contratocortellamada->id_contrato])); ?>" target="_blank" class="btn btn-primary">ABRIR</a></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>
            <td align='center' style="width: 20%; border: #707070 solid 1px;" colspan="10">Sin registros</td>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- modal para confirmar cortellamada -->
<div class="modal fade" id="modalmarcarcontratocortellamada" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <form action="<?php echo e(route('marcarcontratocortellamada')); ?>" enctype="multipart/form-data"
          method="GET" onsubmit="btnSubmit.disabled = true;">
        <?php echo csrf_field(); ?>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Solicitud de confirmación
                </div>
                <div class="modal-body">
                    <div class="col-12" style="color: #ea9999">
                        Al presionar "aceptar" aceptas que se le realizo la llamada al cliente
                    </div>
                    <input type="hidden" name="indice" />
                    <input type="hidden" name="id_contrato" />
                    <br>
                    Describa lo que se comento durante la llamada.
                    <textarea name="mensaje"
                              class="form-control" rows="10"
                              cols="60"></textarea>
                    <br>
                    <div class="row">
                        <div class="col-5"><p id="codigocontrato"></p></div>
                        <div class="col-7" style="text-align: right"><p id="nombrecliente"></p></div>
                    </div>
                    <div class="row">
                        <div class="col-6"><p id="telefono"></p></div>
                        <div class="col-6" style="text-align: right"><p id="telefonoreferencia"></p></div>
                    </div>
                    <div class="row">
                        <div class="col-8"><p id="ultimoabono"></p></div>
                        <div class="col-4" style="text-align: right"><p id="total"></p></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                    <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/cobranza/listas/listallamadascobranza.blade.php ENDPATH**/ ?>