<?php if($numTotalContratos != null): ?>
    <div class="row" style="margin-top: 5px; margin-bottom: 5px;">
        <div class="col-6">
            <div <?php if(sizeof($cuentasLocalidad) < 6): ?> style="margin-right: 10px;" <?php else: ?> style="margin-right: 10px; max-height: 300px; overflow-y: scroll;" <?php endif; ?>>
                <table class="table table-bordered table-striped" style="text-align: center; position: relative; border-collapse: collapse;" id="tablaCuentasLocalidad">
                    <thead>
                    <tr>
                        <th style=" text-align:center; font-size: 12px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col" colspan="2"><b>CUENTAS ACTIVAS POR LOCALIDAD</b></th>
                    </tr>
                    <tr>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LOCALIDAD</th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $cuentasLocalidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuentaLocalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><?php echo e($cuentaLocalidad->LOCALIDAD); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($cuentaLocalidad->TOTALCUENTAS); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-6">
            <div <?php if(sizeof($cuentasColonia) < 5): ?> style="margin-left: 10px;" <?php else: ?> style="margin-left: 10px; max-height: 300px; overflow-y: scroll;" <?php endif; ?>>
                <table class="table table-bordered table-striped" style="text-align: center; position: relative; border-collapse: collapse;" id="tablaCuentasColonia">
                    <thead>
                    <tr>
                        <th style=" text-align:center; font-size: 12px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col" colspan="2"><b>CUENTAS ACTIVAS POR COLONIA</b></th>
                    </tr>
                    <tr>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">COLONIA</th>
                        <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $cuentasColonia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuentaColonia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align='center' style="font-size: 10px;"><?php echo e($cuentaColonia->COLONIA); ?></td>
                            <td align='center' style="font-size: 10px;"><?php echo e($cuentaColonia->TOTALCUENTAS); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            </div>
    </div>
    <div class="row">
        <div class="col-4">
            <button type="button" class="btn btn-primary" style="margin-bottom: 10px;">
                Total registros <span class="badge bg-secondary"><?php echo e($numTotalContratos); ?></span>
            </button>
            <a href="#" id="btnExportarExcel" onclick="exportarAExcel('Tabla Cuentas Activas','tablaCuentasActivas');" style="text-decoration:none; color:black; padding-left: 15px;">
                <button type="button" class="btn btn-success" style="margin-bottom: 10px;" > Exportar </button>
            </a>
        </div>
        <div class="col-6"></div>
        <div class="col-2">
            <i class="fa-solid fa-location-dot" data-toggle="modal" data-target="#modalgooglemaps" style="cursor: pointer" id="btnCrearMarcadores" onclick="crearMarcadoresGoogleMaps('<?php echo e(json_encode($contratosaprobados)); ?>', '<?php echo e(json_encode($contratosmanofactura)); ?>', '<?php echo e(json_encode($contratosprocesoaprobacion)); ?>', '<?php echo e(json_encode($contratosenviados)); ?>', '<?php echo e(json_encode($contratosentregados)); ?>', '<?php echo e(json_encode($contratosatrasados)); ?>');">Ver Mapa</i>
        </div>
    </div>
    <div class="modal fade" id="modalgooglemaps" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    Marcadores
                </div>
                <div class="modal-body">
                    <div id="map" style="border: black 3px solid; width:100%; height: 500px;">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<div class="contenedortblReportes">
    <table class="table table-bordered table-striped" style="text-align: left; position: relative; border-collapse: collapse;" id="tablaCuentasActivas">
        <thead>
        <tr>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA VENTA</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FECHA ENTREGA PREVISTA</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CONTRATO</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ESTADO</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">LOCALIDAD</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ENTRE CALLES</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">COLONIA</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">CALLE</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">NUMERO</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">NOMBRE</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TELEFONO</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ZONA</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">TOTAL</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">ULTIMO ABONO</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">FORMA PAGO</th>
            <th style=" text-align:center; font-size: 10px; background: white; position: sticky; top: 0; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" scope="col">UBICACIÓN</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th style="text-align:center; background-color:#0AA09E; color:#FFFFFF; font-size: 10px; position: sticky; top: 70px; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="16">APROBADOS
            </th>
        </tr>
        <?php $__currentLoopData = $contratosaprobados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoaprobado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->FECHAVENTA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->FECHAENTREGA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->CONTRATO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->ESTATUS); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->LOCALIDAD); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->ENTRECALLES); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->COLONIA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->CALLE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->NUMERO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->NOMBRE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->TELEFONO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->ZONA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->TOTAL); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->ULTIMOABONO); ?></td>
                <?php switch($contratoaprobado->FORMAPAGO):
                    case (0): ?>
                    <td align='center' style="font-size: 10px;">CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center' style="font-size: 10px;">SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center' style="font-size: 10px;">QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center' style="font-size: 10px;">MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <?php if(($contratoaprobado->COORDENADAS)!= null): ?>
                    <td align='center' style="font-size: 10px;"><?php echo e($contratoaprobado->COORDENADAS); ?></td>
                <?php else: ?>
                    <td align='center' style="font-size: 10px;">Sin Capturar</td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th style="text-align:center; background-color:#0AA09E; color:#FFFFFF; font-size: 10px; position: sticky; top: 70px; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="16">MANOFACTURA/EN PROCESO DE ENVIO
            </th>
        </tr>
        <?php $__currentLoopData = $contratosmanofactura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratomanofactura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->FECHAVENTA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->FECHAENTREGA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->CONTRATO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->ESTATUS); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->LOCALIDAD); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->ENTRECALLES); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->COLONIA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->CALLE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->NUMERO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->NOMBRE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->TELEFONO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->ZONA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->TOTAL); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->ULTIMOABONO); ?></td>
                <?php switch($contratomanofactura->FORMAPAGO):
                    case (0): ?>
                    <td align='center' style="font-size: 10px;">CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center' style="font-size: 10px;">SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center' style="font-size: 10px;">QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center' style="font-size: 10px;">MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <?php if(($contratomanofactura->COORDENADAS)!= null): ?>
                    <td align='center' style="font-size: 10px;"><?php echo e($contratomanofactura->COORDENADAS); ?></td>
                <?php else: ?>
                    <td align='center' style="font-size: 10px;">Sin Capturar</td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th style="text-align:center; background-color:#0AA09E; color:#FFFFFF; font-size: 10px; position: sticky; top: 70px; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="16">EN PROCESO DE APROBACION
            </th>
        </tr>
        <?php $__currentLoopData = $contratosprocesoaprobacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoprocesoaprobacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->FECHAVENTA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->FECHAENTREGA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->CONTRATO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->ESTATUS); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->LOCALIDAD); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->ENTRECALLES); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->COLONIA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->CALLE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->NUMERO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->NOMBRE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->TELEFONO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->ZONA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->TOTAL); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->ULTIMOABONO); ?></td>
                <?php switch($contratoprocesoaprobacion->FORMAPAGO):
                    case (0): ?>
                    <td align='center' style="font-size: 10px;">CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center' style="font-size: 10px;">SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center' style="font-size: 10px;">QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center' style="font-size: 10px;">MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <?php if(($contratoprocesoaprobacion->COORDENADAS)!= null): ?>
                    <td align='center' style="font-size: 10px;"><?php echo e($contratoprocesoaprobacion->COORDENADAS); ?></td>
                <?php else: ?>
                    <td align='center' style="font-size: 10px;">Sin Capturar</td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th style="text-align:center; background-color:#0AA09E; color:#FFFFFF; font-size: 10px; position: sticky; top: 70px; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="16">ENVIADOS
            </th>
        </tr>
        <?php $__currentLoopData = $contratosenviados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoenviado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->FECHAVENTA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->FECHAENTREGA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->CONTRATO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->ESTATUS); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->LOCALIDAD); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->ENTRECALLES); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->COLONIA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->CALLE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->NUMERO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->NOMBRE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->TELEFONO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->ZONA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->TOTAL); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->ULTIMOABONO); ?></td>
                <?php switch($contratoenviado->FORMAPAGO):
                    case (0): ?>
                    <td align='center' style="font-size: 10px;">CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center' style="font-size: 10px;">SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center' style="font-size: 10px;">QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center' style="font-size: 10px;">MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <?php if(($contratoenviado->COORDENADAS)!= null): ?>
                    <td align='center' style="font-size: 10px;"><?php echo e($contratoenviado->COORDENADAS); ?></td>
                <?php else: ?>
                    <td align='center' style="font-size: 10px;">Sin Capturar</td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th style="text-align:center; background-color:#0AA09E; color:#FFFFFF; font-size: 10px; position: sticky; top: 70px; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="16">ENTREGADOS
            </th>
        </tr>
        <?php $__currentLoopData = $contratosentregados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoentregado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->FECHAVENTA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->FECHAENTREGA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->CONTRATO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->ESTATUS); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->LOCALIDAD); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->ENTRECALLES); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->COLONIA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->CALLE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->NUMERO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->NOMBRE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->TELEFONO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->ZONA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->TOTAL); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->ULTIMOABONO); ?></td>
                <?php switch($contratoentregado->FORMAPAGO):
                    case (0): ?>
                    <td align='center' style="font-size: 10px;">CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center' style="font-size: 10px;">SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center' style="font-size: 10px;">QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center' style="font-size: 10px;">MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <?php if(($contratoentregado->COORDENADAS)!= null): ?>
                    <td align='center' style="font-size: 10px;"><?php echo e($contratoentregado->COORDENADAS); ?></td>
                <?php else: ?>
                    <td align='center' style="font-size: 10px;">Sin Capturar</td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th style="text-align:center; background-color:#0AA09E; color:#FFFFFF; font-size: 10px; position: sticky; top: 70px; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);" colspan="16">ATRASADOS
            </th>
        </tr>
        <?php $__currentLoopData = $contratosatrasados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoatrasado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->FECHAVENTA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->FECHAENTREGA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->CONTRATO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->ESTATUS); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->LOCALIDAD); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->ENTRECALLES); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->COLONIA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->CALLE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->NUMERO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->NOMBRE); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->TELEFONO); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->ZONA); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->TOTAL); ?></td>
                <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->ULTIMOABONO); ?></td>
                <?php switch($contratoatrasado->FORMAPAGO):
                    case (0): ?>
                    <td align='center' style="font-size: 10px;">CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center' style="font-size: 10px;">SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center' style="font-size: 10px;">QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center' style="font-size: 10px;">MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <?php if(($contratoatrasado->COORDENADAS)!= null): ?>
                    <td align='center' style="font-size: 10px;"><?php echo e($contratoatrasado->COORDENADAS); ?></td>
                <?php else: ?>
                    <td align='center' style="font-size: 10px;">Sin Capturar</td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/reportes/listas/listacuentasactivas.blade.php ENDPATH**/ ?>