
<?php $__env->startSection('titulo','Lista Franquicias'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2 style="text-align: left; color: #0AA09E"><?php echo app('translator')->get('mensajes.mensajeusuariosfranquicia'); ?></h2>
    <div class="row">
        <div class="col-3">
        <div class="form-group">
            <label>Estado</label>
            <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($franquicia[0]->estado); ?>">
        </div>
        </div>
        <div class="col-3">
        <div class="form-group">
            <label>Ciudad</label>
            <input type="text" name="ciudad" class="form-control"  readonly value="<?php echo e($franquicia[0]->ciudad); ?>">
        </div>
        </div>
        <div class="col-3">
        <div class="form-group">
            <label>Colonia</label>
            <input type="text" name="colonia" class="form-control"  readonly value="<?php echo e($franquicia[0]->colonia); ?>">
        </div>
        </div>
        <div class="col-3">
        <div class="form-group">
            <label>Numero Interior/Exterior</label>
            <input type="text" name="numero" class="form-control"  readonly value="<?php echo e($franquicia[0]->numero); ?>">
        </div>
        </div>
    </div>

    <div id="accordion">
        <div class="card">
            <div class="card-header" id="headingOne">
            <h5 class="mb-0">
                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                Nuevo usuario
                </button>
            </h5>
            </div>
            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                    <form  action="<?php echo e(route('nuevoUsuarioFranquicia',$id)); ?>" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;" name="btnSubmit">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Nombre</label>
                                    <input type="text" name="nombre" class="form-control <?php echo $errors->first('nombre','is-invalid'); ?>"  placeholder="Nombre" value="<?php echo e(old('nombre')); ?>">
                                    <?php echo $errors->first('nombre','<div class="invalid-feedback">Nombre no valido</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Correo</label>
                                    <input type="text" name="correo" class="form-control <?php echo $errors->first('correo','is-invalid'); ?>"  placeholder="Correo" value="<?php echo e(old('correo')); ?>">
                                    <?php echo $errors->first('correo','<div class="invalid-feedback">El correo no es valido</div>'); ?>

                                </div>
                            </div>
                            <div class="col-1">
                                <div class="form-group">
                                    <label>Sueldo</label>
                                    <input type="number" name="sueldo" class="form-control <?php echo $errors->first('sueldo','is-invalid'); ?>" min="0" placeholder="Sueldo"  value="<?php echo e(old('sueldo')); ?>">
                                    <?php echo $errors->first('sueldo','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Contraseña</label>
                                    <input type="password" name="contrasena" class="form-control <?php echo $errors->first('contrasena','is-invalid'); ?>"  placeholder="Contraseña"  id="password" >
                                    <?php echo $errors->first('contrasena','<div class="invalid-feedback">La contraseña debe contener: Una letra mayuscula,una minuscula,un numero y al menos 8 caracteres.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Confirmar contraseña</label>
                                    <input type="password" name="ccontrasena" class="form-control <?php echo $errors->first('ccontrasena','is-invalid'); ?>" id="password2"  placeholder="Confirmar contraseña">
                                    <?php echo $errors->first('ccontrasena','<div class="invalid-feedback">Confirma la contraseña</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div style="margin-left: 5px; margin-right: 5px; margin-top: 30px;">
                                    <a class="btn btn-outline-success btn-block" onclick="generarPassword()">Generar contraseña</a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Seleccionar el Rol</label>
                                    <select name="rol" class=" form-control  <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value=""></option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($rol->id != 7): ?>
                                                <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->rol); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('rol','<div class="invalid-feedback">Selecciona un rol</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Seleccionar la zona</label>
                                    <select name="idzona" class="form-control  <?php $__errorArgs = ['idzona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                        <option value=""></option>
                                        <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zona->id); ?>"><?php echo e($zona->zona); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('idzona','<div class="invalid-feedback">Para el rol de cobranza es necesario seleccionar la zona.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Tarjeta</label>
                                    <input type="text" name="tarjeta" class="form-control <?php echo $errors->first('tarjeta','is-invalid'); ?>" min="0" placeholder="Tarjeta"  value="<?php echo e(old('tarjeta')); ?>">
                                    <?php echo $errors->first('tarjeta','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Otra tarjeta</label>
                                    <input type="text" name="otratarjeta" class="form-control <?php echo $errors->first('otratarjeta','is-invalid'); ?>" min="0" placeholder="Tarjeta"  value="<?php echo e(old('otratarjeta')); ?>">
                                    <?php echo $errors->first('otratarjeta','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Recordatorio </label>
                                    <input type="date" name="fecharenovacion"
                                           class="form-control <?php echo $errors->first('fecharenovacion','is-invalid'); ?>"
                                           placeholder="Fecha de renovación" value="<?php echo e(old('fecharenovacion')); ?>">
                                    <?php if($errors->has('fecharenovacion')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('fecharenovacion')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" onclick="mostrarPassword()">
                                    <label class="form-check-label" for="exampleCheck1">Mostrar contraseña</label>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Foto del usuario ( FOTO JPG)</label>
                                    <input type="file" name="foto" class="form-control-file <?php echo $errors->first('foto','is-invalid'); ?>" accept="image/jpg">
                                    <?php echo $errors->first('foto','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Acta de nacimiento (PDF)</label>
                                    <input type="file" name="actanacimiento" class="form-control-file <?php echo $errors->first('actanacimiento','is-invalid'); ?>"  accept="application/pdf" >
                                    <?php echo $errors->first('actanacimiento','<div class="invalid-feedback">El acta de nacimiento debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Identificacion Oficial (PDF)</label>
                                    <input type="file" name="identificacion" class="form-control-file  <?php echo $errors->first('identificacion','is-invalid'); ?>" accept="application/pdf" >
                                    <?php echo $errors->first('identificacion','<div class="invalid-feedback">La identificacion debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>CURP (FOTO JPG)</label>
                                    <input type="file" name="curp" class="form-control-file <?php echo $errors->first('curp','is-invalid'); ?>"  accept="image/jpg" >
                                    <?php echo $errors->first('curp','<div class="invalid-feedback">El CURP debera estar en formato jpg.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Comprobante de domicilio (PDF)</label>
                                    <input type="file" name="comprobante" class="form-control-file  <?php echo $errors->first('comprobante','is-invalid'); ?>"  accept="application/pdf" >
                                    <?php echo $errors->first('comprobante','<div class="invalid-feedback">El comprobante debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Seguro social (PDF)</label>
                                    <input type="file" name="seguro" class="form-control-file <?php echo $errors->first('seguro','is-invalid'); ?>"  accept="application/pdf" >
                                    <?php echo $errors->first('seguro','<div class="invalid-feedback">El seguro social debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Solicitud / Curriculum (PDF)</label>
                                    <input type="file" name="solicitud" class="form-control-file <?php echo $errors->first('solicitud','is-invalid'); ?>" accept="application/pdf" >
                                    <?php echo $errors->first('solicitud','<div class="invalid-feedback">La solicitud debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Tarjeta para pago (FOTO JPG)</label>
                                    <input type="file" name="tarjetapago" class="form-control-file <?php echo $errors->first('tarjetapago','is-invalid'); ?>"   accept="image/jpg" >
                                    <?php echo $errors->first('tarjetapago','<div class="invalid-feedback">El numero de la tarjeta debera estar en formato jpg.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Otra tarjeta (FOTO JPG)</label>
                                    <input type="file" name="otratarjetapago" class="form-control-file <?php echo $errors->first('otratarjetapago','is-invalid'); ?>"   accept="image/jpg" >
                                    <?php echo $errors->first('otratarjetapago','<div class="invalid-feedback">El numero de la tarjeta debera estar en formato jpg.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Contacto de Emergencia (PDF)</label>
                                    <input type="file" name="contactoemergencia" class="form-control-file <?php echo $errors->first('contactoemergencia','is-invalid'); ?>" accept="application/pdf" >
                                    <?php echo $errors->first('contactoemergencia','<div class="invalid-feedback">El contacto de emergencia debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Contrato laboral (FOTO JPG)</label>
                                    <input type="file" name="contratolaboral" class="form-control-file <?php echo $errors->first('contratolaboral','is-invalid'); ?>" accept="image/jpg" >
                                    <?php echo $errors->first('contratolaboral','<div class="invalid-feedback">El contrato laboral debera estar en imagen JPG.</div>'); ?>

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Pagare (PDF)</label>
                                    <input type="file" name="pagare" class="form-control-file <?php echo $errors->first('pagare','is-invalid'); ?>" accept="application/pdf" >
                                    <?php echo $errors->first('pagare','<div class="invalid-feedback">El pagare debera estar en formato PDF.</div>'); ?>

                                </div>
                            </div>
                        </div>
                        <?php if(Auth::user()->rol_id == 7): ?>
                            <hr>
                            <h5><?php echo app('translator')->get('mensajes.mensajesucursalesconfirmaciones'); ?></h5>
                            <div class="row">
                                <?php
                                    $i = 0;
                                ?>
                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-2">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input " name="<?php echo e($sucursal->id); ?>" id="<?php echo e($sucursal->id); ?>" value="1">
                                            <label class="custom-control-label" for="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->colonia); ?> <?php echo e($sucursal->numero); ?>,<?php echo e($sucursal->ciudad); ?> <?php echo e($sucursal->estado); ?></label>
                                        </div>
                                    </div>
                                    <?php
                                        $i = $i +2;
                                    ?>
                                    <?php if($i==12): ?>
                                        </div>
                                        <div class="row">
                                        <?php
                                            $i = 0;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit"><?php echo app('translator')->get('mensajes.agregarusuario'); ?></button>
                    </form>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header" id="headingTwo">
            <h5 class="mb-0">
                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                Usuario existente
                </button>
            </h5>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                <div class="card-body">

                        <div class="row">
                            <div class="col-4">
                                <label >Filtrar usuarios</label>
                                <input name="filtro" id="filtro" type="text" class="form-control" placeholder="Buscar..">
                            </div>
                            <div class="col-2">
                                <button type="button" id="btnFiltrar" class="btn btn-outline-success btn-ca">Filtrar</button>
                            </div>

                            <div class="col-1" id="spCargando">
                                <div class="d-flex justify-content-center">
                                    <div class="spinner-border" style="width: 2rem; height: 2rem; margin-top: 30px;" role="status">
                                        <span class="visually-hidden"></span>
                                    </div>
                                </div>
                            </div>

                        </div>

                    <form  action="<?php echo e(route('nuevoUsuarioFranquicia',$id)); ?>" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;" >
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-4">
                                <label>Seleciona el usuario existente</label>
                                <select class="custom-select" name="usuarioP" id="usuariosFranquicia">

                                </select>
                            </div>
                            <div class="col-2">
                                <button type="submit" id="btnAsignar" name="btnSubmit" class="btn btn-outline-success btn-ca">Asignar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php if(Auth::user()->rol_id == 7): ?>
        <form action="<?php echo e(route('usuariosfiltrosucursal',$id)); ?>" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;" >
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-2">
                    <div class="form-group">
                        <label>Ver usuarios de:</label>
                        <select name="sucursalSeleccionada"
                                class="form-control">
                            <?php if(count($sucursales) > 0): ?>
                                <option value="">Todas las sucursales</option>
                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($sucursal->id); ?>" <?php echo e(isset($sucursalSeleccionada) ? ($sucursalSeleccionada == $sucursal->id ? 'selected' : '' ) : ''); ?>><?php echo e($sucursal->ciudad); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option selected>Sin registros</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="col-2">
                    <button type="submit" name="btnSubmit" class="btn btn-outline-success btn-ca">Aplicar</button>
                </div>
            </div>
        </form>
    <?php endif; ?>
    <?php if($totalRenovacion != null): ?>
        <button type="button" class="btn btn-primary" style="margin-bottom: 10px;">
            Contratos a renovar <span class="badge bg-secondary"><?php echo e($totalRenovacion[0]->total); ?></span>
        </button>
    <?php endif; ?>
    <div class="contenedortblUsuarios">
        <table id="tablaFranquicias" class="table table-bordered">
            <?php if(sizeof($usuariosfranquicia)>0): ?>
                <thead>
                <tr>
                    <th  style =" text-align:center;" scope="col">SUCURSAL</th>
                    <th  style =" text-align:center;" scope="col">FOTO</th>
                    <th  style =" text-align:center;" scope="col">NOMBRE</th>
                    <th  style =" text-align:center;" scope="col">CORREO</th>
                    <th  style =" text-align:center;" scope="col">ROL</th>
                    <th  style =" text-align:center;" scope="col">RENOVACION</th>
                    <th  style =" text-align:center;" scope="col">NO. CONTROL</th>
                    <th  style =" text-align:center;" scope="col">ELIMINAR</th>
                    <th  style =" text-align:center;" scope="col">VER</th>
                </tr>
                </thead>
            <?php endif; ?>
            <tbody>
            <?php $__currentLoopData = $usuariosfranquicia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuariof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr <?php if(($usuariof->renovacion != null) &&(\Carbon\Carbon::parse($usuariof->renovacion)->format('Y-m-d') <= \Carbon\Carbon::now())): ?> style="background-color: rgba(255,15,0,0.17) " <?php endif; ?>>
                    <td align='center' style="vertical-align: middle;"><?php echo e($usuariof->CIUDADFRANQUICIA); ?></td>
                    <td align='center'> <img src="<?php echo e(asset($usuariof->FOTO)); ?>" style="width:100px;height:100px;" class="img-thumbnail" > </td>
                    <td align='center' style="vertical-align: middle;"><?php echo e($usuariof->NOMBRE); ?></td>
                    <td align='center' style="vertical-align: middle;"><?php echo e($usuariof->CORREO); ?></td>
                    <td align='center' style="vertical-align: middle;"><?php echo e($usuariof->ROL); ?></td>
                    <?php if($usuariof->renovacion != null): ?>
                        <td align='center' style="vertical-align: middle;"><?php echo e($usuariof->renovacion); ?></td>
                    <?php else: ?>
                        <td align='center' style="vertical-align: middle;">SIN RENOVAR</td>
                    <?php endif; ?>
                    <td align='center' style="vertical-align: middle;"><?php echo e($usuariof->NOCONTROL); ?></td>
                    <td align='center'><a href="#" data-href="<?php echo e(route('eliminarUsuarioFranquicia',[$id,$usuariof->ID_FRANQUICIA,$usuariof->ID])); ?>" data-toggle="modal" data-target="#confirmacion"><button type="button" class="btn btn-outline-success"><i  class="fas fa-user-times"></i></button></a> </td>
                    <td align='center'><a href="<?php echo e(route('editarUsuarioFranquicia',[$usuariof->ID_FRANQUICIA,$usuariof->ID])); ?>" ><button type="button" class="btn btn-outline-success"><i  class="fas fa-user-edit"></i></button></a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="confirmacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Solicitud de confirmacion
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            ¿Estas seguro que quieres eliminar el usuario de esta franquicia?
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-12" style="color: #ea9999">
                            Para cambio de sucursal es recomendable que el usuario haya cerrado sesion
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-success" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-outline-danger btn-ok">Eliminar</a>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/franquicia/usuarios.blade.php ENDPATH**/ ?>