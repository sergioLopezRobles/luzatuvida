
<?php $__env->startSection('titulo','Contratos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2 style="text-align: left; color: #0AA09E">Contratos para llamar</h2>
    <input type="hidden" id="idFranquicia" value="<?php echo e($idFranquicia); ?>">
    <div class="row">
        <div class="col-4">
            <label for="">Usuario</label>
            <select class="custom-select <?php echo $errors->first('usuario','is-invalid'); ?> cargarTabla" id="usuarioCobranza" name="usuario">
                <?php if(count($usuarios) > 0): ?>
                    <option selected value="">Seleccionar</option>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->zona); ?> - <?php echo e($usuario->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <option selected>No se encontro ningun usuario</option>
                <?php endif; ?>
            </select>
            <?php echo $errors->first('zona','<div class="invalid-feedback">Elegir una zona, campo obligatorio </div>'); ?>

        </div>
        <div class="col-4">
            <label for="">Opciones</label>
            <select class="custom-select cargarTabla" id="opcionCorte" name="opcion">
                <option value="">Seleccionar corte</option>
            </select>
        </div>
        <div class="col-2" id="spCargandoLlamadas">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" style="width: 2rem; height: 2rem; margin-top: 25px;" role="status">
                    <span class="visually-hidden"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group" id="listallamadascobranza">

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/cobranza/movimientos/llamadascobranza.blade.php ENDPATH**/ ?>