
<?php $__env->startSection('titulo','Actualizar contrato'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <?php echo e(isset($errors)? var_dump($errors) : ''); ?> -->
    <div class="contenedor">
        <h2><?php echo app('translator')->get('mensajes.mensajeactuzalizarcontrato'); ?></h2>
        <form id="frmFranquiciaNueva" action="<?php echo e(route('contratoeditar',[$idFranquicia,$contrato[0]->id])); ?>"
              enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="franquicia">
                <div class="row">
                    <div class="col-1">
                        <div class="form-group">
                            <label>Contrato</label>
                            <input type="text" name="id"
                                   class="form-control"
                                   placeholder="Contrato" readonly value="<?php echo e($contrato[0]->id); ?>">
                        </div>
                    </div>
                    <div class="col-1">
                        <label for="">Zona</label>
                        <select class="custom-select" name="zona">
                            <?php if(count($zonas) > 0): ?>
                                <option selected>Seleccionar</option>
                                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($zona->id); ?>" <?php echo e(isset($contrato) ? ($contrato[0]->id_zona== $zona->id ? 'selected' : '' ) : ''); ?>><?php echo e($zona->zona); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option selected>Sin registros</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-2">
                        <label for="">Optometrista</label>
                        <?php if(($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $numTotalGarantias[0]->numTotalGarantias == 0): ?>
                            <select class="custom-select" name="optometrista">
                                <option selected
                                        value="<?php echo e($contrato[0]->id_optometrista); ?>"><?php echo e($contrato[0]->nombreopto); ?></option>
                                <?php $__currentLoopData = $optometristas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optometrista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($optometrista->ID == $contrato[0]->id_optometrista): ?>
                                        <?php continue; ?>
                                    <?php else: ?>
                                        <option value="<?php echo e($optometrista->ID); ?>"><?php echo e($optometrista->NAME); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <option selected>Sin registros</option> -->
                            </select>
                        <?php else: ?>
                            <input type="text" class="form-control" readonly value="<?php echo e($contrato[0]->nombreopto); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="col-2">
                        <label for="">Asistente</label>
                        <?php if(($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) && $numTotalGarantias[0]->numTotalGarantias == 0): ?>
                            <select class="custom-select" name="asistente">
                                <option selected
                                        value="<?php echo e($contrato[0]->id_usuariocreacion); ?>"><?php echo e($contrato[0]->nombre_usuariocreacion); ?></option>
                                <?php $__currentLoopData = $asistentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($asistente->ID == $contrato[0]->id_usuariocreacion): ?>
                                        <?php continue; ?>
                                    <?php else: ?>
                                        <option value="<?php echo e($asistente->ID); ?>"><?php echo e($asistente->NAME); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <option selected>Sin registros</option> -->
                            </select>
                        <?php else: ?>
                            <input type="text" class="form-control" readonly value="<?php echo e($contrato[0]->nombre_usuariocreacion); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Nombre del paciente</label>
                            <input type="text" name="nombre"
                                   class="form-control <?php echo $errors->first('nombre','is-invalid'); ?>"
                                   placeholder="Nombre" value="<?php echo e($contrato[0]->nombre); ?>">
                            <?php echo $errors->first('nombre','<div class="invalid-feedback">El nombre es obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Calle</label>
                            <input type="text" name="calle"
                                   class="form-control <?php echo $errors->first('calle','is-invalid'); ?>" placeholder="Calle"
                                   value="<?php echo e($contrato[0]->calle); ?>">
                            <?php echo $errors->first('calle','<div class="invalid-feedback">La calle es obligatoria.</div>'); ?>

                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-1">
                        <div class="form-group">
                            <label>Numero</label>
                            <input type="text" name="numero"
                                   class="form-control <?php echo $errors->first('numero','is-invalid'); ?>"
                                   placeholder="Numero" value="<?php echo e($contrato[0]->numero); ?>">
                            <?php echo $errors->first('numero','<div class="invalid-feedback">El numero es obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Departamento</label>
                            <input type="text" name="departamento" class="form-control" placeholder="Departamento"
                                   value="<?php echo e($contrato[0]->depto); ?>">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label id="alladode">Al lado de</label>
                            <input type="text" name="alladode"
                                   class="form-control <?php echo $errors->first('alladode','is-invalid'); ?>"
                                   placeholder="Al lado de" value="<?php echo e($contrato[0]->alladode); ?>">
                            <?php echo $errors->first('alladode','<div class="invalid-feedback">Campo obligatorio</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Frente a</label>
                            <input type="text" name="frentea"
                                   class="form-control <?php echo $errors->first('frentea','is-invalid'); ?>"
                                   placeholder="Frente a" value="<?php echo e($contrato[0]->frentea); ?>">
                            <?php echo $errors->first('frentea','<div class="invalid-feedback">Campo obligatorio</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Ubicacion</label>
                            <input type="text" name="coordenadas"
                                   class="form-control <?php echo $errors->first('coordenadas','is-invalid'); ?>"
                                   placeholder="Coordenadas"
                                   value="<?php echo e($contrato[0]->coordenadas); ?>">
                            <?php echo $errors->first('coordenadas','<div class="invalid-feedback">Campo obligatorio</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <a href="<?php echo e(url('https://www.google.com/maps/place?key=AIzaSyC4wzK36yxyLG6yzpqUPnV4j8Y74aKkq-M&q=' . $contrato[0]->coordenadas)); ?>"
                           target="_blank">
                            <button type="button" class="btn btn-outline-success">Ver ubicación</button>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label>Entre calles</label>
                            <input type="text" name="entrecalles"
                                   class="form-control <?php echo $errors->first('entrecalles','is-invalid'); ?>"
                                   placeholder="Entre calles" value="<?php echo e($contrato[0]->entrecalles); ?>">
                            <?php echo $errors->first('entrecalles','<div class="invalid-feedback">El campo es obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Colonia</label>
                            <input type="text" name="colonia"
                                   class="form-control <?php echo $errors->first('colonia','is-invalid'); ?>"
                                   placeholder="Colonia" value="<?php echo e($contrato[0]->colonia); ?>">
                            <?php echo $errors->first('colonia','<div class="invalid-feedback">La colonia es obligatoria.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Localidad</label>
                            <input type="text" name="localidad"
                                   class="form-control <?php echo $errors->first('localidad','is-invalid'); ?>"
                                   placeholder="Localidad" value="<?php echo e($contrato[0]->localidad); ?>">
                            <?php echo $errors->first('localidad','<div class="invalid-feedback">La localidad es obligatoria.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Telefono</label>
                            <input type="text" name="telefono"
                                   class="form-control <?php echo $errors->first('telefono','is-invalid'); ?>"
                                   placeholder="Telefono" value="<?php echo e($contrato[0]->telefono); ?>">
                            <?php echo $errors->first('telefono','<div class="invalid-feedback">El telefono debe contener 10 numeros.</div>'); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tipo Casa</label>
                            <input type="text" name="casatipo"
                                   class="form-control <?php echo $errors->first('casatipo','is-invalid'); ?>"
                                   placeholder="Tipo Casa" value="<?php echo e($contrato[0]->casatipo); ?>">
                            <?php echo $errors->first('casatipo','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Casa color</label>
                            <input type="text" name="casacolor"
                                   class="form-control <?php echo $errors->first('casacolor','is-invalid'); ?>"
                                   placeholder="Casa color" value="<?php echo e($contrato[0]->casacolor); ?>">
                            <?php echo $errors->first('casacolor','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Nombre referencia</label>
                            <input type="text" name="nr" class="form-control <?php echo $errors->first('nr','is-invalid'); ?>"
                                   placeholder="Nombre de referencia" value="<?php echo e($contrato[0]->nombrereferencia); ?>">
                            <?php echo $errors->first('nr','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Telefono referencia</label>
                            <input type="text" name="tr" class="form-control <?php echo $errors->first('tr','is-invalid'); ?>"
                                   placeholder="Telefono de referencia" value="<?php echo e($contrato[0]->telefonoreferencia); ?>">
                            <?php echo $errors->first('tr','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label>Correo electronico</label>
                            <input type="text" name="correo"
                                   class="form-control <?php echo $errors->first('correo','is-invalid'); ?>"
                                   placeholder="Correo electronico" value="<?php echo e($contrato[0]->correo); ?>">
                            <?php echo $errors->first('correo','<div class="invalid-feedback">Ingresar un corrreo electronico valido</div>'); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto INE Frente:</label>
                            <input type="file" name="fotoine"
                                   class="form-control-file <?php echo $errors->first('fotoine','is-invalid'); ?> <?php if($contrato[0]->fotoine != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/jpg">
                            <?php echo $errors->first('fotoine','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto INE Atrás</label>
                            <input type="file" name="fotoineatras"
                                   class="form-control-file  <?php echo $errors->first('fotoineatras','is-invalid'); ?> <?php if($contrato[0]->fotoineatras != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/jpg">
                            <?php echo $errors->first('fotoineatras','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Pagare:</label>
                            <input type="file" name="pagare"
                                   class="form-control-file  <?php echo $errors->first('pagare','is-invalid'); ?> <?php if($contrato[0]->pagare != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/jpg">
                            <?php echo $errors->first('pagare','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Foto de la casa</label>
                            <input type="file" name="fotocasa"
                                   class="form-control-file <?php echo $errors->first('fotocasa','is-invalid'); ?> <?php if($contrato[0]->fotocasa != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/jpg">
                            <?php echo $errors->first('fotocasa','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Comprobante de domicilio</label>
                            <input type="file" name="comprobantedomicilio"
                                   class="form-control-file <?php echo $errors->first('comprobantedomicilio','is-invalid'); ?> <?php if($contrato[0]->comprobantedomicilio != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/jpg">
                            <?php echo $errors->first('comprobantedomicilio','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Tarjeta de pension frente</label>
                            <input type="file" name="tarjeta"
                                   class="form-control-file <?php echo $errors->first('tarjeta','is-invalid'); ?> <?php if($contrato[0]->tarjeta != ''): ?> is-valid <?php endif; ?>"
                                   accept="image/jpg">
                            <?php echo $errors->first('tarjeta','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                            <div class="valid-feedback"><a class='fas fa-check'></a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img1" style="cursor: pointer">
                    <img src="<?php echo e(asset($contrato[0]->fotoine)); ?>" style="width:250px;height:250px;" class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img2" style="cursor: pointer">
                    <img src="<?php echo e(asset($contrato[0]->fotoineatras)); ?>" style="width:250px;height:250px;"
                         class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img3" style="cursor: pointer">
                    <img src="<?php echo e(asset($contrato[0]->pagare)); ?>" style="width:250px;height:250px;" class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img4" style="cursor: pointer">
                    <img src="<?php echo e(asset($contrato[0]->fotocasa)); ?>" style="width:250px;height:250px;"
                         class="img-thumbnail">
                </div>
                <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img5" style="cursor: pointer">
                    <img src="<?php echo e(asset($contrato[0]->comprobantedomicilio)); ?>" style="width:250px;height:250px;"
                         class="img-thumbnail">
                </div>
                <?php if($contrato[0]->tarjeta != ''): ?>
                    <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img6" style="cursor: pointer">
                        <img src="<?php echo e(asset($contrato[0]->tarjeta)); ?>" style="width:250px;height:250px;"
                             class="img-thumbnail">
                    </div>
                <?php endif; ?>
            </div>
            <div class="row" style="margin-top: 10px;">
                <div class="col-2">
                    <div class="form-group">
                        <label>Tarjeta de pension atras</label>
                        <input type="file" name="tarjetapensionatras"
                               class="form-control-file <?php echo $errors->first('tarjetapensionatras','is-invalid'); ?> <?php if($contrato[0]->tarjetapensionatras != ''): ?> is-valid <?php endif; ?>"
                               accept="image/jpg">
                        <?php echo $errors->first('tarjetapensionatras','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                        <div class="valid-feedback"><a class='fas fa-check'></a></div>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Otros</label>
                        <input type="file" name="fotootros"
                               class="form-control-file <?php echo $errors->first('fotootros','is-invalid'); ?> <?php if($contrato[0]->fotootros != ''): ?> is-valid <?php endif; ?>"
                               accept="image/jpg">
                        <?php echo $errors->first('fotootros','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

                        <div class="valid-feedback"><a class='fas fa-check'></a></div>
                    </div>
                </div>
            </div>
            <div class="row" style="padding-bottom: 10px;">
                <?php if($contrato[0]->tarjetapensionatras != '' || $contrato[0]->fotootros != ''): ?>
                    <?php if($contrato[0]->tarjetapensionatras != '' && $contrato[0]->fotootros != ''): ?>
                        <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img7"
                             style="cursor: pointer">
                            <img src="<?php echo e(asset($contrato[0]->tarjetapensionatras)); ?>" style="width:250px;height:250px;"
                                 class="img-thumbnail">
                        </div>
                        <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img8"
                             style="cursor: pointer">
                            <img src="<?php echo e(asset($contrato[0]->fotootros)); ?>" style="width:250px;height:250px;"
                                 class="img-thumbnail">
                        </div>
                    <?php else: ?>
                        <?php if($contrato[0]->tarjetapensionatras != ''): ?>
                            <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img7"
                                 style="cursor: pointer">
                                <img src="<?php echo e(asset($contrato[0]->tarjetapensionatras)); ?>"
                                     style="width:250px;height:250px;" class="img-thumbnail">
                            </div>
                        <?php else: ?>
                            <div class="col-2"></div>
                            <div class="col-2" data-toggle="modal" data-target="#imagemodal" id="img8"
                                 style="cursor: pointer">
                                <img src="<?php echo e(asset($contrato[0]->fotootros)); ?>" style="width:250px;height:250px;"
                                     class="img-thumbnail">
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col">
                    <button class="btn btn-outline-success btn-block" name="btnSubmit"
                            type="submit"><?php echo app('translator')->get('mensajes.mensajeactuzalizarcontrato'); ?></button>
                </div>
            </div>
        </form>
        <form action="<?php echo e(route('agregarnota',[$idFranquicia,$contrato[0]->id])); ?>"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-10">
                    <div class="form-group">
                        <label>Nota del cobrador</label>
                        <input type="text" name="nota" maxlength="255"
                               class="form-control <?php echo $errors->first('nota','is-invalid'); ?>"
                               placeholder="Nota del cobrador" value="<?php echo e($contrato[0]->nota); ?>">
                        <?php echo $errors->first('nota','<div class="invalid-feedback">No puede superar los 255 caracteres.</div>'); ?>

                    </div>
                </div>
                <div class="col-2">
                    <button class="btn btn-outline-success btn-block" name="btnSubmit"
                            type="submit"><?php echo app('translator')->get('mensajes.mensajeactualizarnota'); ?></button>
                </div>
            </div>
        </form>
        <hr>
        <h2>Información diagnóstico</h2>
        <div class="row">
            <div class="col-3">
                <div class="form-group">
                    <label>Edad</label>
                    <input type="text" name="edad" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->edad); ?>">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Diagnóstico</label>
                    <input type="text" name="diagnostico" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->diagnostico); ?>">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Ocupación</label>
                    <input type="text" name="ocupacion" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->ocupacion); ?>">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Diabetes</label>
                    <input type="text" name="diabetes" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->diabetes); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <label>Hipertensión</label>
                    <input type="text" name="hipertension" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->hipertension); ?>">
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label>¿Se encuentra embarazada?</label>
                    <input type="text" name="embarazada" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->embarazada); ?>">
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label>¿Durmió de 6 a 8 horas?</label>
                    <input type="text" name="durmioseisochohoras" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->durmioseisochohoras); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label>Principal actividad en el día</label>
                    <input type="text" name="actividaddia" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->actividaddia); ?>">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label>Principal problema que padece en sus ojos</label>
                    <input type="text" name="problemasojos" class="form-control" readonly value="<?php echo e($datosDiagnosticoHistorial[0]->problemasojos); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-10">
                <h6>Molestia</h6>
            </div>
            <div class="col-2">
                <h6>Último examen</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input " name="dolor" id="dolor"  <?php if($datosDiagnosticoHistorial[0]->dolor == 1): ?> checked <?php endif; ?> onclick="return false;">
                    <label class="custom-control-label" for="dolor">Dolor de cabeza</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input " name="ardor" id="ardor" <?php if($datosDiagnosticoHistorial[0]->ardor == 1): ?> checked <?php endif; ?> onclick="return false;">
                    <label class="custom-control-label" for="ardor">Ardor en los ojos</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" name="golpeojos"  id="golpeojos" <?php if($datosDiagnosticoHistorial[0]->golpeojos == 1): ?> checked <?php endif; ?> onclick="return false;">
                    <label class="custom-control-label" for="golpeojos">Golpe en cabeza</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input  class="custom-control-input " type="checkbox" name="otroM" id="otroM" <?php if($datosDiagnosticoHistorial[0]->otroM == 1): ?> checked <?php endif; ?> onclick="return false;">
                    <label class="custom-control-label" for="otroM">Otro</label>
                </div>
            </div>
            <div class="col-2">
                <div class="custom-control custom-checkbox">
                    <input type="text" name="molestiaotro" class="form-control" min="0"  placeholder="Otro" value="<?php echo e($datosDiagnosticoHistorial[0]->molestiaotro); ?>" readonly>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <input type="text" name="ultimoexamen" class="form-control" min="0"  placeholder="" value="<?php echo e($datosDiagnosticoHistorial[0]->ultimoexamen); ?>" readonly>
                </div>
            </div>
        </div>
        <hr>
        <h4 style="margin-top: 10px">Total garantias: <?php echo e($numTotalGarantias[0]->numTotalGarantias); ?></h4>
        <?php ($contador = 1); ?>
        <?php if(isset($historiales)): ?>
            <?php $__currentLoopData = $historiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($historial->tipo == 0): ?>
                    <h4 style="margin-top: 10px">Garantias: <?php echo e($historial->numGarantias); ?></h4>
                <?php endif; ?>
                <div class="row">
                    <div class="col-2">
                        <?php switch($historial->tipo):
                            case (0): ?>
                            <h4 style="margin-top: 10px;"><?php echo app('translator')->get('mensajes.mensajetituloreceta'); ?> <?php echo e($loop->iteration); ?>

                                (<?php echo e($historial->id); ?>)</h4>
                            <?php break; ?>
                            <?php case (1): ?>
                            <h4 style="margin-top: 10px;"><?php echo app('translator')->get('mensajes.mensajetituloreceta'); ?> <?php echo e($loop->iteration); ?>

                                (<?php echo e($historial->id); ?>) "Garantía de <?php echo e($historial->idhistorialpadre); ?>"</h4>
                            <?php break; ?>
                            <?php case (2): ?>
                            <h4 style="margin-top: 10px;"><?php echo app('translator')->get('mensajes.mensajetituloreceta'); ?> <?php echo e($loop->iteration); ?>

                                (<?php echo e($historial->id); ?>) "Cambio paquete"</h4>
                            <?php break; ?>
                        <?php endswitch; ?>
                    </div>
                    <div class="col-2">
                        <h4 style="margin-top: 10px;">Modelo: <?php echo e($historial->armazon); ?></h4>
                    </div>
                    <div class="col-4">
                        <h4 style="margin-top: 10px;">Color: <?php echo e($historial->colorarmazon); ?></h4>
                    </div>
                    <?php if($loop->iteration == 1): ?>
                        <div class="col-2">
                            <h4 style="margin-top: 10px;">Paquete: <?php echo e($historial->paquete); ?></h4>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($contrato[0]->estatus_estadocontrato <= 1 || $contrato[0]->estatus_estadocontrato == 9): ?>
                    <form id="frmarmazon" action="<?php echo e(route('editarHistorialArmazon',[$idFranquicia,$idContrato,$historial->id])); ?>"
                          enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-4">
                                <label for="">Armazón</label>
                                <select class="custom-select <?php echo $errors->first('producto','is-invalid'); ?>"
                                        name="producto">
                                    <?php if(count($armazones) > 0): ?>
                                        <option selected value='nada'>Seleccionar</option>
                                        <?php $__currentLoopData = $armazones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $armazon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($armazon->id_tipoproducto == 1 && $armazon->estado == 1 && $armazon->piezas > 0): ?>
                                                <?php if($armazon->id == $historial->id_producto): ?>
                                                    <option selected value="<?php echo e($armazon->id); ?>">
                                                        <?php echo e($armazon->nombre); ?> | <?php echo e($armazon->color); ?>

                                                        | <?php echo e($armazon->piezas); ?>pza.
                                                    </option>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($armazon->id); ?>" <?php echo e(old('producto') == $armazon->id ? 'selected' : ''); ?>>
                                                        <?php echo e($armazon->nombre); ?> | <?php echo e($armazon->color); ?>

                                                        | <?php echo e($armazon->piezas); ?>pza.
                                                    </option>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option selected>Sin registros</option>
                                    <?php endif; ?>
                                </select>
                                <?php echo $errors->first('producto','<div class="invalid-feedback">Elegir un producto , campo obligatorio
                                </div>'); ?>

                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-success btn-block" name="btnSubmit"
                                        type="submit">Actualizar armazón
                                </button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
                <?php if(($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 4) && $historial->tipo == 0): ?>
                    <div class="row">
                        <?php if($contrato[0]->cuentaregresivafechaentrega >= 0
                                || $contrato[0]->garantiacanceladaelmismodia
                                || !$bandera
                                || $contrato[0]->estatus_estadocontrato == 12): ?>
                            <div class="col-6">
                                <form id="frmgarantia"
                                      action="<?php echo e(route('agregarGarantiaHistorial',[$idFranquicia,$contrato[0]->id,$historial->id])); ?>"
                                      enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                                    <?php echo csrf_field(); ?>
                                    <?php if($historial->optometristaasignado == null): ?>
                                        <div class="row">
                                            <div class="col-6">
                                                <label for="">Optometrista</label>
                                                <select
                                                    class="custom-select <?php echo $errors->first('optometristagarantia','is-invalid'); ?>"
                                                    name="optometristagarantia">
                                                    <?php if(count($optometristas) > 0): ?>
                                                        <option selected value='nada'>Seleccionar</option>
                                                        <?php $__currentLoopData = $optometristas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optometrista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                value="<?php echo e($optometrista->ID); ?>">
                                                                <?php echo e($optometrista->NAME); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <option selected>Sin registros</option>
                                                    <?php endif; ?>
                                                </select>
                                                <?php echo $errors->first('optometristagarantia','<div class="invalid-feedback">Elegir un optometrista , campo obligatorio
                                                </div>'); ?>

                                            </div>
                                            <div class="col-6">
                                                <button class="btn btn-outline-success btn-block" name="btnSubmit"
                                                        type="submit">Nueva garantia
                                                </button>
                                            </div>
                                        </div>
                                        <?php if($contrato[0]->cuentaregresivafechaentrega >= 0): ?>
                                            <div style="color: #ea9999; font-weight: bold;">Quedan <?php echo e($contrato[0]->cuentaregresivafechaentrega); ?> días para bloquear o deshabilitar garantias a este contrato</div>
                                        <?php else: ?>
                                            <?php if($contrato[0]->fechaentrega != null): ?>
                                                <div style="color: #ea9999; font-weight: bold;">Fecha limite para garantias ya expiró</div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </form>
                            </div>
                        <?php else: ?>
                            <?php if($contrato[0]->fechaentrega != null && $bandera): ?>
                                <div class="col col-6">
                                    <?php if($solicitudAutorizacion != null): ?>
                                        <?php if($solicitudAutorizacion[0]->estatus == 0): ?>
                                            <div style="color: #0AA09E; font-weight: bold;"> Solicitud de autorización generada.</div>
                                        <?php endif; ?>
                                        <?php if($solicitudAutorizacion[0]->estatus == 2): ?>
                                                <div style="margin-bottom: 5px;">
                                                    <a type="button" href="" class="btn btn-outline-success"
                                                       data-toggle="modal"
                                                       data-target="#modalsolicitarautorizacion">Solicitar autorización</a>
                                                </div>
                                            <div style="color: #ea9999; font-weight: bold;"> Ultima solicitud de autorización rechazada.</div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div style="margin-bottom: 5px;">
                                            <a type="button" href="" class="btn btn-outline-success"
                                               data-toggle="modal"
                                               data-target="#modalsolicitarautorizacion">Solicitar autorización</a>
                                        </div>
                                    <?php endif; ?>
                                    <div style="color: #ea9999; font-weight: bold;">
                                        Fecha limite para garantias ya expiró
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-6"></div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if(Auth::user()->rol_id == 7 && $contrato[0]->estadogarantia != 2): ?>
                            <div class="col-6">
                                <form id="frmpaquetes<?php echo e($historial->id); ?>"
                                      action="<?php echo e(route('actualizarpaquetehistorial',[$idFranquicia,$idContrato,$historial->id])); ?>"
                                      enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Paquetes</label>
                                            <select
                                                class="custom-select <?php echo $errors->first('paquetehistorialeditar','is-invalid'); ?>"
                                                name="paquetehistorialeditar<?php echo e($historial->id); ?>">
                                                <?php if(count($paquetes) > 0): ?>
                                                    <option selected value=''>Seleccionar</option>
                                                    <?php $__currentLoopData = $paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                            value="<?php echo e($paquete->id); ?>">
                                                            <?php echo e($paquete->nombre); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <option selected>Sin registros</option>
                                                <?php endif; ?>
                                            </select>
                                            <?php echo $errors->first('paquetehistorialeditar','<div class="invalid-feedback">Elegir un paquete , campo obligatorio
                                            </div>'); ?>

                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <a type="button" href="" class="btn btn-outline-success"
                                                   data-toggle="modal"
                                                   data-target="#modalactualizarpaquetehistorial<?php echo e($historial->id); ?>">Actualizar
                                                    paquete</a>
                                            </div>
                                        </div>

                                        <div class="modal fade" id="modalactualizarpaquetehistorial<?php echo e($historial->id); ?>"
                                             tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                                             aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        Solicitud de confirmación
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                ¿Estas seguro de cambiar el paquete?
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-primary" type="button"
                                                                data-dismiss="modal">Cancelar
                                                        </button>
                                                        <button class="btn btn-success" name="btnSubmit" type="submit"
                                                                form="frmpaquetes<?php echo e($historial->id); ?>">Aceptar
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="modal fade" id="modalactualizarpaquetehistorial<?php echo e($historial->id); ?>"
                                             tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                                             aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        Solicitud de confirmación
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                ¿Estas seguro de cambiar el paquete?
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-primary" type="button"
                                                                data-dismiss="modal">Cancelar
                                                        </button>
                                                        <button class="btn btn-success" name="btnSubmit" type="submit"
                                                                form="frmpaquetes<?php echo e($historial->id); ?>">Aceptar
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if(($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 4) && $historial->tipo == 0): ?>
                    <?php if(!$bandera): ?>
                        <form id="frmcancelargarantia"
                              action="<?php echo e(route('cancelarGarantiaHistorial',[$idFranquicia,$contrato[0]->id,$historial->id])); ?>"
                              enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-3">

                                    <button class="btn btn-outline-danger btn-block" name="btnSubmit"
                                            type="submit">Cancelar garantia
                                    </button>

                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        <?php if($historial->cancelargarantia != null): ?>
                            <form id="frmcancelargarantia"
                                  action="<?php echo e(route('cancelarGarantiaHistorial',[$idFranquicia,$contrato[0]->id,$historial->id])); ?>"
                                  enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <?php if($historial->optometristaasignado != null): ?>
                                        <div class="col-3">
                                            <label for="">Optometrista
                                                asignado <?php echo e($historial->optometristaasignado); ?></label>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-3">

                                        <button class="btn btn-outline-danger btn-block" name="btnSubmit"
                                                type="submit">Cancelar garantia
                                        </button>

                                    </div>
                                </div>
                            </form>
                            <?php if($contrato[0]->cuentaregresivafechaentrega >= 0): ?>
                                <div style="color: #ea9999; font-weight: bold;">Quedan <?php echo e($contrato[0]->cuentaregresivafechaentrega); ?> días para bloquear o deshabilitar garantias a este contrato</div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if($historial->paquete == 'DORADO 2' || $historial->paquete == 'LECTURA'): ?>
                    <h5 style="color: #0AA09E;">Sin conversión</h5>
                    <?php if($historial->hscesfericoder != null): ?>
                        <div id="mostrarvision"></div>
                        <h6>Ojo derecho</h6>
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Esferico</label>
                                    <input type="text" name="esfericod" class="form-control" readonly
                                           value="<?php echo e($historial->hscesfericoder); ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Cilindro</label>
                                    <input type="text" name="cilindrod" class="form-control" readonly
                                           value="<?php echo e($historial->hsccilindroder); ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Eje</label>
                                    <input type="text" name="ejed" class="form-control" readonly
                                           value="<?php echo e($historial->hscejeder); ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Add</label>
                                    <input type="text" name="addd" class="form-control" readonly
                                           value="<?php echo e($historial->hscaddder); ?>">
                                </div>
                            </div>
                        </div>
                        <h6>Ojo Izquierdo</h6>
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Esferico</label>
                                    <input type="text" name="esfericod2" class="form-control" readonly
                                           value="<?php echo e($historial->hscesfericoizq); ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Cilindro</label>
                                    <input type="text" name="cilindrod2" class="form-control" readonly
                                           value="<?php echo e($historial->hsccilindroizq); ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Eje</label>
                                    <input type="text" name="ejed2" class="form-control" readonly
                                           value="<?php echo e($historial->hscejeizq); ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Add</label>
                                    <input type="text" name="addd2" class="form-control" readonly
                                           value="<?php echo e($historial->hscaddizq); ?>">
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <h6 style="color: #0AA09E; margin-left: 30px">Sin capturar</h6>
                    <?php endif; ?>
                    <h5 style="color: #0AA09E;">Con conversión</h5>
                <?php endif; ?>
                <div id="mostrarvision"></div>
                <h6>Ojo derecho</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Esferico</label>
                            <input type="text" name="esfericod" class="form-control" readonly
                                   value="<?php echo e($historial->esfericoder); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Cilindro</label>
                            <input type="text" name="cilindrod" class="form-control" readonly
                                   value="<?php echo e($historial->cilindroder); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Eje</label>
                            <input type="text" name="ejed" class="form-control" readonly value="<?php echo e($historial->ejeder); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Add</label>
                            <input type="text" name="addd" class="form-control" readonly value="<?php echo e($historial->addder); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>ALT</label>
                            <input type="text" name="altd" class="form-control" readonly value="<?php echo e($historial->altder); ?>">
                        </div>
                    </div>
                </div>
                <h6>Ojo Izquierdo</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-group">
                            <label>Esferico</label>
                            <input type="text" name="esfericod2" class="form-control" readonly
                                   value="<?php echo e($historial->esfericoizq); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Cilindro</label>
                            <input type="text" name="cilindrod2" class="form-control" readonly
                                   value="<?php echo e($historial->cilindroizq); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Eje</label>
                            <input type="text" name="ejed2" class="form-control" readonly
                                   value="<?php echo e($historial->ejeizq); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Add</label>
                            <input type="text" name="addd2" class="form-control" readonly
                                   value="<?php echo e($historial->addizq); ?>">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>ALT</label>
                            <input type="text" name="altd2" class="form-control" readonly
                                   value="<?php echo e($historial->altizq); ?>">
                        </div>
                    </div>
                </div>
                <h6>Material</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material<?php echo e($loop->iteration); ?>"
                                   id="material<?php echo e($loop->iteration); ?>" <?php if($historial->material == 0): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="material<?php echo e($loop->iteration); ?>">Hi Index</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material<?php echo e($loop->iteration); ?>"
                                   id="material<?php echo e($loop->iteration); ?>" <?php if($historial->material == 1): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="material<?php echo e($loop->iteration); ?>">CR</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material<?php echo e($loop->iteration); ?>"
                                   id="material<?php echo e($loop->iteration); ?>" <?php if($historial->material == 2): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="material<?php echo e($loop->iteration); ?>">Policarbonato</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="material<?php echo e($loop->iteration); ?>"
                                   id="material<?php echo e($loop->iteration); ?>" <?php if($historial->material == 3): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="material<?php echo e($loop->iteration); ?>">Otro</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input type="text" name="motro" class="form-control" placeholder="Otro"
                                   value="<?php echo e($historial->materialotro); ?>" readonly>
                        </div>
                    </div>
                </div>
                <h6>Tipo de bifocal</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal<?php echo e($loop->iteration); ?>"
                                   id="exampleRadios<?php echo e($loop->iteration); ?>" <?php if($historial->bifocal == 0): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="exampleRadios<?php echo e($loop->iteration); ?>">
                                FT
                            </label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal<?php echo e($loop->iteration); ?>"
                                   id="exampleRadios<?php echo e($loop->iteration); ?>" <?php if($historial->bifocal == 1): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="exampleRadios<?php echo e($loop->iteration); ?>">
                                Blend
                            </label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal<?php echo e($loop->iteration); ?>"
                                   id="exampleRadios<?php echo e($loop->iteration); ?>" <?php if($historial->bifocal == 2): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="exampleRadios<?php echo e($loop->iteration); ?>">
                                Progresivo
                            </label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal<?php echo e($loop->iteration); ?>"
                                   id="exampleRadios<?php echo e($loop->iteration); ?>" <?php if($historial->bifocal == 3): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="exampleRadios<?php echo e($loop->iteration); ?>">
                                N/A
                            </label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="bifocal<?php echo e($loop->iteration); ?>"
                                   id="exampleRadios<?php echo e($loop->iteration); ?>" <?php if($historial->bifocal == 4): ?> checked
                                   <?php endif; ?> onclick="return false;">
                            <label class="form-check-label" for="exampleRadios<?php echo e($loop->iteration); ?>">
                                Otro
                            </label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="text" name="otroB" class="form-control" min="0" placeholder="Otro"
                                   value="<?php echo e($historial->bifocalotro); ?>" readonly>
                        </div>
                    </div>
                </div>
                <h6>Tratamiento</h6>
                <div class="row">
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input " name="fotocromatico" id="customCheck9"
                                   <?php if($historial->fotocromatico == 1): ?> checked <?php endif; ?> onclick="return false;">
                            <label class="custom-control-label" for="customCheck9">Fotocromatico</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input " name="ar" id="customCheck10"
                                   <?php if($historial->ar == 1): ?> checked <?php endif; ?> onclick="return false;">
                            <label class="custom-control-label" for="customCheck10">A/R</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="tinte" id="customCheck11"
                                   <?php if($historial->tinte == 1): ?> checked <?php endif; ?> onclick="return false;">
                            <label class="custom-control-label" for="customCheck11">Tinte</label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="blueray" id="customCheck12"
                                   <?php if($historial->blueray == 1): ?> checked <?php endif; ?> onclick="return false;">
                            <label class="custom-control-label" for="customCheck12">BlueRay</label>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="custom-control custom-checkbox">
                            <input class="custom-control-input " type="checkbox" name="otroTra" id="customCheck13"
                                   <?php if($historial->otroT == 1): ?> checked <?php endif; ?> onclick="return false;">
                            <label class="custom-control-label" for="customCheck13">Otro</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="custom-control custom-checkbox">
                            <input type="text" name="otroT" class="form-control" min="0" placeholder="Otro"
                                   value="<?php echo e($historial->tratamientootro); ?>" readonly>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Observaciones laboratorio</label>
                            <input type="text" name="cilindrod2" class="form-control" readonly
                                   value="<?php echo e($historial->observaciones); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Observaciones interno</label>
                            <input type="text" name="cilindrod2" class="form-control" readonly
                                   value="<?php echo e($historial->observacionesinterno); ?>">
                        </div>
                    </div>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="row">
                <div class="col-3">
                    <h3 style="margin-top: 10px;">(Sin resultados)</h3>
                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <a href="<?php echo e(route('listacontrato',$idFranquicia)); ?>"
                   class="btn btn-outline-success btn-block"><?php echo app('translator')->get('mensajes.regresar'); ?></a>
            </div>
        </div>
    </div>

    <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <img src="" class="imagepreview"
                         style="width: 100%; margin-top: 60px; margin-bottom: 60px; cursor: grabbing">
                </div>
            </div>
        </div>
    </div>

    <!--Modal para Solicitar Autorizacion Garantia-->
    <div class="modal fade" id="modalsolicitarautorizacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="<?php echo e(route('solicitarautorizaciongarantia',[$idFranquicia,$contrato[0]->id])); ?>" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Solicitud para autorización de garantia.
                    </div>
                    <div class="modal-body">
                        <b>Describa la solicitus de garantia.</b>
                        <textarea name="mensaje"
                                  id = "mensaje"
                                  class="form-control <?php echo $errors->first('mensaje','is-invalid'); ?>" rows="10"
                                  cols="60" >
                        </textarea>
                        <?php echo $errors->first('mensaje','<div class="invalid-feedback">Campo obligatorio.</div>'); ?>

                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/contrato/actualizarcontrato.blade.php ENDPATH**/ ?>