
<?php $__env->startSection('titulo','Contratos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h2><?php echo app('translator')->get('mensajes.mensajetitulotablalaboratorio'); ?></h2>

    <form action="<?php echo e(route('listalaboratorio')); ?>" enctype="multipart/form-data" method="GET"
          onsubmit="btnSubmit.disabled = true;">
        <div class="row">
            <div class="col-4">
                <input name="filtro" id="filtro" type="text" class="form-control" placeholder="Buscar.." value="<?php echo e($filtro); ?>">
            </div>
            <div class="col-5">
                <button type="submit" name="btnSubmit" class="btn btn-outline-success">Filtrar</button>
            </div>
        </div>
    </form>

    <form action="<?php echo e(route('actualizarestadoenviado')); ?>" enctype="multipart/form-data" method="GET"
          onsubmit="btnSubmit.disabled = true;">
        <div class="row">
            <div class="col-9"></div>
            <div class="col-3">
                <button type="submit" name="btnSubmit" class="btn btn-outline-success btn-block">ENVIAR TODOS</button>
            </div>
        </div>
        <table id="tablaContratos" class="table table-bordered" style="margin-top: 10px;">
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">CREADO EL</th>
                <th style=" text-align:center;" scope="col">FECHA DE ENTREGA</th>
                <th style=" text-align:center;" scope="col">CONTRATO</th>
                <th style=" text-align:center;" scope="col">SUCURSAL</th>
                <th style=" text-align:center;" scope="col">ESTATUS</th>
                <th style=" text-align:center;" scope="col">VER</th>
                <th style=" text-align:center;" scope="col">SELECCIONAR</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF;" colspan="17">CON COMENTARIOS (LABORATORIO)
                </th>
            </tr>
            <?php $__currentLoopData = $contratosComentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoComentarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoComentarios->created_at); ?></td>
                    <td align='center'><?php echo e($contratoComentarios->fechaentrega); ?></td>
                    <td align='center'><?php echo e($contratoComentarios->id); ?></td>
                    <td align='center'><?php echo e($contratoComentarios->ciudad); ?></td>

                    <?php if($contratoComentarios->estatus_estadocontrato == 7): ?>
                        <td align='center'>
                            <button type="button" class="btn btn-primary aprobado"
                                    style="color:#FEFEFE;"><?php echo e($contratoComentarios->descripcion); ?></button>
                        </td>
                    <?php endif; ?>
                    <?php if($contratoComentarios->estatus_estadocontrato == 10): ?>
                        <td align='center'>
                            <button type="button" class="btn btn-warning manofactura"
                                    style="color:#FEFEFE;"><?php echo e($contratoComentarios->descripcion); ?></button>
                        </td>
                    <?php endif; ?>
                    <?php if($contratoComentarios->estatus_estadocontrato == 11): ?>
                        <td align='center'>
                            <button type="button" class="btn btn-info enprocesodeenvio"
                                    style="color:#FEFEFE;"><?php echo e($contratoComentarios->descripcion); ?></button>
                        </td>
                    <?php endif; ?>
                    <td align='center'><a href="<?php echo e(route('estadolaboratorio',$contratoComentarios->id)); ?>">
                            <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                        </a></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF;" colspan="17">TODOS (LABORATORIO)</th>
            </tr>
            <?php $__currentLoopData = $contratosSComentariosLabo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoSComentariosLabo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoSComentariosLabo->created_at); ?></td>
                    <td align='center'><?php echo e($contratoSComentariosLabo->fechaentrega); ?></td>
                    <td align='center'><?php echo e($contratoSComentariosLabo->id); ?></td>
                    <td align='center'><?php echo e($contratoSComentariosLabo->ciudad); ?></td>

                    <?php if($contratoSComentariosLabo->estatus_estadocontrato == 7): ?>
                        <td align='center'>
                            <button type="button" class="btn btn-primary aprobado"
                                    style="color:#FEFEFE;"><?php echo e($contratoSComentariosLabo->descripcion); ?></button>
                        </td>
                    <?php endif; ?>
                    <?php if($contratoSComentariosLabo->estatus_estadocontrato == 10): ?>
                        <td align='center'>
                            <button type="button" class="btn btn-warning manofactura"
                                    style="color:#FEFEFE;"><?php echo e($contratoSComentariosLabo->descripcion); ?></button>
                        </td>
                    <?php endif; ?>
                    <?php if($contratoSComentariosLabo->estatus_estadocontrato == 11): ?>
                        <td align='center'>
                            <button type="button" class="btn btn-info enprocesodeenvio"
                                    style="color:#FEFEFE;"><?php echo e($contratoSComentariosLabo->descripcion); ?></button>
                        </td>
                    <?php endif; ?>
                    <td align='center'><a href="<?php echo e(route('estadolaboratorio',$contratoSComentariosLabo->id)); ?>">
                            <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                        </a></td>

                    <?php if($contratoSComentariosLabo->estatus_estadocontrato == 11): ?>
                        <td align='center'>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox"
                                       class="custom-control-input"
                                       name="check<?php echo e($contratoSComentariosLabo->id); ?>"
                                       id="customCheck<?php echo e($contratoSComentariosLabo->id); ?>">
                                <label class="custom-control-label"
                                       for="customCheck<?php echo e($contratoSComentariosLabo->id); ?>"></label>
                            </div>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if((!is_null($otrosContratos) && count($otrosContratos)>0) || (!is_null($contratosSTerminar) && count($contratosSTerminar)>0) || (!is_null($contratosPendientes) && count($contratosPendientes)>0)): ?>
                <tr>
                    <th style=" text-align:center;;background-color:#0AA09E;color:#FFFFFF;" colspan="17"> CONTRATOS FUERA DE LABORATORIO </th>
                </tr>
            <?php endif; ?>
            <?php if(!is_null($otrosContratos) && count($otrosContratos)>0): ?>
                <?php $__currentLoopData = $otrosContratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otroContrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align='center'><?php echo e($otroContrato->created_at); ?></td>
                        <td align='center'><?php echo e($otroContrato->fechaentrega); ?></td>
                        <td align='center'><?php echo e($otroContrato->id); ?></td>
                        <td align='center'><?php echo e($otroContrato->ciudad); ?></td>
                        <td align='center'>
                                <button type="button" class="btn btn-secondary"
                                        style="color:#FEFEFE;"><?php echo e($otroContrato->descripcion); ?></button>
                        </td>
                        <td align='center'><a href="<?php echo e(route('estadolaboratorio',$otroContrato->id)); ?>">
                                <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(!is_null($contratosSTerminar) && count($contratosSTerminar)>0): ?>
                <?php $__currentLoopData = $contratosSTerminar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoSTerminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align='center'><?php echo e($contratoSTerminar->created_at); ?></td>
                        <td align='center'>SIN CAPTURAR</td>
                        <td align='center'><?php echo e($contratoSTerminar->id); ?></td>
                        <td align='center'><?php echo e($contratoSTerminar->ciudad); ?></td>
                        <td align='center'>
                            <button type="button" class="btn btn-secondary"
                                    style="color:#FEFEFE;"><?php echo e($contratoSTerminar->descripcion); ?></button>
                        </td>
                        <td align='center'>
                            <button type="button" class="btn btn-outline-success" disabled="disabled"><i class="fas fa-pen"></i></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(!is_null($contratosPendientes) && count($contratosPendientes)>0): ?>
                <?php $__currentLoopData = $contratosPendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoPendiente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align='center'>SIN CAPTURAR</td>
                        <td align='center'>SIN CAPTURAR</td>
                        <td align='center'><?php echo e($contratoPendiente->id); ?></td>
                        <td align='center'><?php echo e($contratoPendiente->ciudad); ?></td>
                        <td align='center'>
                            <button type="button" class="btn btn-secondary"
                                    style="color:#FEFEFE;">SIN CAPTURAR</button>
                        </td>
                        <td align='center'>
                            <button type="button" class="btn btn-outline-success" disabled="disabled"><i class="fas fa-pen"></i></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </form>
    <div id="accordion">
        <div class="card">
            <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne"
                            aria-expanded="true"
                            aria-controls="collapseOne">
                        Filtros
                    </button>
                </h5>
            </div>
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Fecha inicial</label>
                                    <input type="date" name="fechainibuscar" id="fechainibuscar" class="form-control <?php echo $errors->first('fechainibuscar','is-invalid'); ?>" <?php if(isset($fechainibuscar)): ?> value = "<?php echo e($fechainibuscar); ?>" <?php endif; ?>>
                                    <?php if($errors->has('fechainibuscar')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('fechainibuscar')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Fecha final</label>
                                    <input type="date" name="fechafinbuscar" id="fechafinbuscar" class="form-control <?php echo $errors->first('fechafinbuscar','is-invalid'); ?>" <?php if(isset($fechafinbuscar)): ?> value = "<?php echo e($fechafinbuscar); ?>" <?php endif; ?>>
                                    <?php if($errors->has('fechafinbuscar')): ?>
                                        <div class="invalid-feedback"><?php echo e($errors->first('fechafinbuscar')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-3">
                                <label for="franquiciaSeleccionada">Sucursal</label>
                                <div class="form-group">
                                    <select name="franquiciaSeleccionada"
                                            id="franquiciaSeleccionada"
                                            class="form-control">
                                        <?php if(count($franquicias) > 0): ?>
                                            <option value="" selected>Todas las sucursales</option>
                                            <?php $__currentLoopData = $franquicias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franquicia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($franquicia->id); ?>" <?php echo e(isset($franquiciaSeleccionada) ? ($franquiciaSeleccionada == $franquicia->id ? 'selected' : '' ) : ''); ?>><?php echo e($franquicia->ciudad); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option selected>Sin registros</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-3" id="spCargando">
                                <div class="d-flex justify-content-center">
                                    <div class="spinner-border" style="width: 2rem; height: 2rem; margin-top: 30px;" role="status">
                                        <span class="visually-hidden"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>

    <table id="tablaContratos" class="table table-bordered" style="margin-top: 10px;">
        <thead>
        <tr>
            <th style=" text-align:center;" scope="col">CREADO EL</th>
            <th style=" text-align:center;" scope="col">FECHA DE ENTREGA</th>
            <th style=" text-align:center;" scope="col">FECHA DE ENVIO</th>
            <th style=" text-align:center;" scope="col">CONTRATO</th>
            <th style=" text-align:center;" scope="col">SUCURSAL</th>
            <th style=" text-align:center;" scope="col">ESTATUS</th>
            <th style=" text-align:center;" scope="col">VER</th>
        </tr>
        </thead>
        <tbody id="tablaContratosEnviados">
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/laboratorio/tabla.blade.php ENDPATH**/ ?>