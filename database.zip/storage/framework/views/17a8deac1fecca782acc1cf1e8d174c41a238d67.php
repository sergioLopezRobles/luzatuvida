<!-- Fonts -->
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"><!-- Styles -->
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/spinner.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(asset('css/global.css')); ?>" rel="stylesheet" media="all">
<link href="<?php echo e(asset('css/estiloAdaptable.css')); ?>" rel="stylesheet" media="all">

<?php if(Route::is('login')): ?>
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('editarFranquicia')): ?>
  <link href="<?php echo e(asset('css/franquicias/editar.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('nuevafranquicia') || Route::is('insumos')): ?>
  <link href="<?php echo e(asset('css/franquicias/nueva.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet" media="all">
  <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('listafranquicia')): ?>
  <link href="<?php echo e(asset('css/franquicias/lista.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet" media="all">
  <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('listapoliza') || Route::is('verpoliza') || Route::is('crearpoliza')): ?>
    <link href="<?php echo e(asset('css/franquicias/polizas/poliza.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('usuariosFranquicia') || Route::is('usuariosfiltrosucursal')): ?>
  <link href="<?php echo e(asset('css/franquicias/usuarios.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('listacontratospaquetes')): ?>
    <link href="<?php echo e(asset('css/franquicias/usuarios.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('editarUsuarioFranquicia')): ?>
  <link href="<?php echo e(asset('css/franquicias/editarusuario.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('nuevocontrato')): ?>
  <link href="<?php echo e(asset('css/contratos/nuevo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('payment')): ?>
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('nuevocontrato2' || 'contratoHijos')): ?>
  <link href="<?php echo e(asset('css/contratos/nuevo.css')); ?>" rel="stylesheet" media="all">
  <link href="<?php echo e(asset('css/historialclinico/nuevo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('contratoactualizar')): ?>
  <link href="<?php echo e(asset('css/contratos/actualizarcontrato.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('listacontrato') || Route::is('filtrarlistacontrato') || Route::is('filtrarlistacontratocheckbox') || Route::is('listaconfirmaciones') || Route::is('listalaboratorio') || Route::is('estadoconfirmacion')
 || Route::is('listagarantiasconfirmaciones') || Route::is('vercontratogarantiaconfirmaciones')
        || Route::is('estadolaboratorio') ||  Route::is('auxiliarlaboratorio') || Route::is('actualizarestadoenviado') || Route::is('filtrarcontratosenviados')): ?>
  <link href="<?php echo e(asset('css/contratos/tabla.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('nuevohistorialclinico')): ?>
  <link href="<?php echo e(asset('css/historialclinico/nuevo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('nuevohijo')): ?>
  <link href="<?php echo e(asset('css/historialclinico/nuevo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('nuevohistorialclinico2')): ?>
  <link href="<?php echo e(asset('css/historialclinico/nuevo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('actualizarhistorial')): ?>
  <link href="<?php echo e(asset('css/historialclinico/nuevo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('listasfranquicia') || Route::is('filtrarproducto')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/tablas.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('productonuevo')): ?>
  <link href="<?php echo e(asset('css/franquicias/productos/nuevoproducto.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('tratamientonuevo')): ?>
  <link href="<?php echo e(asset('css/franquicias/tratamientos/nuevotratamiento.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('productoactualizar')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/editarproducto.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('tratamientoactualizar')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/editartratamiento.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('paquetenuevo')): ?>
  <link href="<?php echo e(asset('css/franquicias/paquetes/nuevopaquete.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('paqueteactualizar')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/editarpaquete.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('promocionnueva')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/nuevapromocion.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('nuevaproarmazones')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/nuevapromoarmazon.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('promocionactualizar')): ?>
  <link href="<?php echo e(asset('css/adminfranquicia/nuevapromoarmazon.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php if(Route::is('vercontrato')): ?>
  <link href="<?php echo e(asset('css/historialclinico/nuevo.css')); ?>" rel="stylesheet" media="all">
  <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet" media="all">
  <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('register')): ?>
    <link href="<?php echo e(asset('css/registro.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('traspasarcontrato') || Route::is('obtenercontratotraspasar') || Route::is('listasolicitudautorizacion')): ?>
    <link href="<?php echo e(asset('css/contratos/tabla.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('listareporteasistencia')): ?>
    <link href="<?php echo e(asset('css/reportes/reporteasistencia.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('cobranzamovimientos') || Route::is('ventasmovimientos') || Route::is('filtrarventasmovimientos')): ?>
    <link href="<?php echo e(asset('css/movimientos/movimientos.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>

<?php if(Route::is('general') || Route::is('configuracion')): ?>
    <link href="<?php echo e(asset('css/desarrollo.css')); ?>" rel="stylesheet" media="all">
<?php endif; ?>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/parciales/link.blade.php ENDPATH**/ ?>