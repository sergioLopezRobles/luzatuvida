<?php if($idUsuario != null): ?>
    <input type="hidden" id="idUsuarioActual" value="<?php echo e($idUsuario[0]->id); ?>">
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Ultimo corte</label>
                <input type="text" name="ultimocorte" class="form-control"  readonly value="<?php echo e($ultimocorte); ?>">
            </div>
        </div>
        <div class="col-2" style="margin-top: 30px">
            <a href="#" data-href="" data-toggle="modal" data-target="#confirmacion"><button id="btnReiniciarCorte" type="button" class="btn btn-outline-danger">Reiniciar corte</button></a>
        </div>
    </div>
    <div class="modal fade" id="confirmacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <form action="<?php echo e(route('cobranzamovimientosreiniciarcorte',$idUsuario[0]->id)); ?>" enctype="multipart/form-data"
              method="GET" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Reiniciar corte
                    </div>
                    <div class="modal-body">
                        ¿Estas seguro de reiniciar el corte para (<?php echo e($idUsuario[0]->name); ?>)?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">No</button>
                        <button class="btn btn-outline-danger btn-ok" name="btnSubmit" type="submit">Si</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php endif; ?>
<h4>Contratos</h4>
<div class="row">
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Semanal</label>
            <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContratos[0]->semanal); ?>">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Quincenal</label>
            <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContratos[0]->quincenal); ?>">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Mensual</label>
            <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContratos[0]->mensual); ?>">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Forma de pago Contado</label>
            <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContratos[0]->pagado); ?>">
        </div>
    </div>
    <div class="col-2">
        <div class="form-group">
            <label>Cancelados</label>
            <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContratos[0]->cancelado); ?>">
        </div>
    </div>
</div>
<?php if($semanal != null || $quincenal != null || $mensual != null || $contado != null): ?>
    <h4>Cobrados en un lapso de tiempo </h4>
    <div class="row">
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Semanal</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($semanal); ?>">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Quincenal</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($quincenal); ?>">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Mensual</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($mensual); ?>">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Contado</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($contado); ?>">
            </div>
        </div>
        <?php if(isset($totalContadorContratosConAbonos)): ?>
            <div class="col-2">
                <div class="form-group">
                    <label>Total contratos</label>
                    <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContadorContratosConAbonos); ?>">
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php if($semanalC != null || $quincenalC != null || $mensualC != null || $contadoC != null): ?>
    <h4>Cobrados en un lapso de tiempo (Solo cobrador)</h4>
    <div class="row">
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Semanal</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($semanalC); ?>">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Quincenal</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($quincenalC); ?>">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Mensual</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($mensualC); ?>">
            </div>
        </div>
        <div class="col-2">
            <div class="form-group">
                <label>Forma de pago Contado</label>
                <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($contadoC); ?>">
            </div>
        </div>
        <?php if(isset($totalContadorContratosConAbonosC)): ?>
            <div class="col-2">
                <div class="form-group">
                    <label>Total contratos</label>
                    <input type="text" name="estado" class="form-control"  readonly value="<?php echo e($totalContadorContratosConAbonosC); ?>">
                </div>
            </div>
        <?php endif; ?>
        <div class="col-2">
            <div class="form-group">
                <label>Ingresos</label>
                <input type="text" name="estado" class="form-control"  readonly value="$ <?php echo e($totalIngresosC); ?>">
            </div>
        </div>
    </div>
<?php endif; ?>

<h4>Abonos eliminados</h4>
<table  class="table table-bordered">
    <thead>
    <tr>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">CONTRATO</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">NOMBRE CLIENTE</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">MOVIMIENTO</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">FECHA</th>
        <th  style =" text-align:center; border: #707070 solid 1px;" scope="col">LINK</th>
    </tr>
    </thead>
    <tbody>
    <?php if(sizeof($historialescontratos) > 0): ?>
        <?php $__currentLoopData = $historialescontratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historialcontrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="background-color: rgba(255,15,0,0.17)">
                <td align='center' style="border: #707070 solid 1px;"><?php echo e($historialcontrato->name); ?></td>
                <td align='center' style="border: #707070 solid 1px;"><?php echo e($historialcontrato->id_contrato); ?></td>
                <td align='center' style="border: #707070 solid 1px;"><?php echo e($historialcontrato->nombre); ?></td>
                <td align='center' style="border: #707070 solid 1px;"><?php echo e($historialcontrato->cambios); ?></td>
                <td align='center' style="border: #707070 solid 1px;"><?php echo e($historialcontrato->created_at); ?></td>
                <td align='center' style="border: #707070 solid 1px;"><a href="<?php echo e(route('vercontrato',[$idFranquicia,$historialcontrato->id_contrato])); ?>" target="_blank" class="btn btn-primary">ABRIR</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <td align='center' style="width: 20%; border: #707070 solid 1px;" colspan="6">Sin registros</td>
    <?php endif; ?>
    </tbody>
</table>

<h4>Abonos</h4>
<table  class="table table-bordered">
    <thead>
    <tr>
        <th  style =" text-align:center;" scope="col">NOMBRE</th>
        <th  style =" text-align:center;" scope="col">CONTRATO</th>
        <th  style =" text-align:center;" scope="col">NOMBRE CLIENTE</th>
        <th  style =" text-align:center;" scope="col">ABONO</th>
        <th  style =" text-align:center;" scope="col">FORMA DE PAGO</th>
        <th  style =" text-align:center;" scope="col">FOLIO</th>
        <th  style =" text-align:center;" scope="col">TIPO DE PAGO</th>
        <th  style =" text-align:center;" scope="col">FECHA</th>
        <th  style =" text-align:center;" scope="col">LINK</th>
    </tr>
    </thead>
    <tbody>
    <?php if(sizeof($movimientos) > 0): ?>
        <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center'><?php echo e($movimiento->name); ?></td>
                <td align='center'><?php echo e($movimiento->id_contrato); ?></td>
                <td align='center'><?php echo e($movimiento->nombre); ?></td>
                <td align='center'><?php echo e($movimiento->abono); ?></td>
                <?php switch($movimiento->metodopago):
                    case (0): ?>
                    <td align='center'>EFECTIVO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center'>TARJETA</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center'>TRANSFERENCIA</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <td align='center'><?php echo e($movimiento->folio); ?></td>
                <?php switch($movimiento->pago):
                    case (0): ?>
                    <td align='center'>CONTADO</td>
                    <?php break; ?>
                    <?php case (1): ?>
                    <td align='center'>SEMANAL</td>
                    <?php break; ?>
                    <?php case (2): ?>
                    <td align='center'>QUINCENAL</td>
                    <?php break; ?>
                    <?php case (4): ?>
                    <td align='center'>MENSUAL</td>
                    <?php break; ?>
                <?php endswitch; ?>
                <td align='center'><?php echo e($movimiento->created_at); ?></td>
                <td align='center'> <a href="<?php echo e(route('vercontrato',[$idFranquicia,$movimiento->id_contrato])); ?>" target="_blank" class="btn btn-primary">ABRIR</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <td align='center' style="width: 20%;" colspan="9">Sin registros</td>
    <?php endif; ?>
    </tbody>
</table>

<?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/cobranza/listas/listamovimientoscobranza.blade.php ENDPATH**/ ?>