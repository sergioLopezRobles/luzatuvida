<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">


    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('titulo','Luz a tu vida'); ?></title>

    <?php echo $__env->make('parciales.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('parciales.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('parciales.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body >
    <div id="app">
        <nav id="navbar" class="navbar navbar-expand-md shadow-sm navbar-custom" style="width:100%;">
            <?php if(Auth::check()): ?>
                <i id="botonsidebar" class="fas fa-bars" onclick="openNav()"></i>
            <?php endif; ?>
          <div class="container">
               <a  href="<?php echo e(url('/')); ?>"><img id="logo" src="/imagenes/general/administracion/logo.png" alt=""></a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                  <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <!-- Left Side Of Navbar -->
                  <ul class="navbar-nav mr-auto">

                  </ul>

                  <!-- Right Side Of Navbar -->
                  <ul class="navbar-nav ml-auto" style="margin-left:10%;">
                      <!-- Authentication Links -->
                      <?php if(auth()->guard()->guest()): ?>
                      <?php else: ?>
                          <li class="dropdown">
                              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" v-pre>
                                  <?php echo e(Auth::user()->name); ?>

                              </a>

                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                        <?php echo app('translator')->get('mensajes.cerrarsesion'); ?>
                                    </a>
                                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                      <?php echo csrf_field(); ?>
                                  </form>
                              </div>
                          </li>
                      <?php endif; ?>
                  </ul>
              </div>
          </div>
        </nav>
        <main class="py-4 principal" >
            <?php if(Auth::check()): ?>
            <div id="mySidenav" class="sidenav">
                <?php echo $__env->make('administracion.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            </div>
            <?php endif; ?>
            <div id="main">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
        <footer class="page-footer font-small blue">
          <div class="footer-copyright text-center py-3">
            © Todos los derechos reservados | Luz a tu vida
          </div>
        </footer>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/layouts/app.blade.php ENDPATH**/ ?>