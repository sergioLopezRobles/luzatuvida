<?php if(sizeof($contratosEnviadosSComentarios) > 0): ?>
    <?php $__currentLoopData = $contratosEnviadosSComentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoEnviadoSComentarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td align='center'><?php echo e($contratoEnviadoSComentarios->created_at); ?></td>
            <td align='center'><?php echo e($contratoEnviadoSComentarios->fechaentrega); ?></td>
            <td align='center'><?php echo e($contratoEnviadoSComentarios->fechaenvio); ?></td>
            <td align='center'><?php echo e($contratoEnviadoSComentarios->id); ?></td>
            <td align='center'><?php echo e($contratoEnviadoSComentarios->ciudad); ?></td>

            <?php if($contratoEnviadoSComentarios->estatus_estadocontrato == 12): ?>
                <td align='center'>
                    <button type="button" class="btn btn-info enviado"
                            style="color:#FEFEFE;"><?php echo e($contratoEnviadoSComentarios->descripcion); ?></button>
                </td>
            <?php endif; ?>
            <td align='center'><a href="<?php echo e(route('estadolaboratorio',$contratoEnviadoSComentarios->id)); ?>">
                    <button type="button" class="btn btn-outline-success"><i class="fas fa-pen"></i></button>
                </a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <td align='center' colspan="6">Sin registros</td>
<?php endif; ?>

<?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/laboratorio/contratosenviados/tablacontratosenviados.blade.php ENDPATH**/ ?>