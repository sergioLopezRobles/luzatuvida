
<?php $__env->startSection('titulo','Contratos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h2><?php echo app('translator')->get('mensajes.mensajetitulotablalaboratorio'); ?></h2>

    <form action="<?php echo e(route('listaconfirmaciones')); ?>" enctype="multipart/form-data" method="GET">
        <div class="row">
            <div class="col-4">
                <input name="filtro" type="text" class="form-control" placeholder="Buscar.." id="txtfiltro" value="<?php echo e($filtro); ?>">
            </div>
            <div class="col-5">
                <button type="submit" class="btn btn-outline-success">Filtrar</button>
            </div>
        </div>
    </form>
    <table id="tablaContratos" class="table table-bordered" style="margin-top: 10px;">
        <thead>
        <tr>
            <th  style =" text-align:center;" scope="col">SUCURSAL</th>
            <th  style =" text-align:center;" scope="col">CONTRATO</th>
            <th  style =" text-align:center;" scope="col">USUARIOCREACION</th>
            <th  style =" text-align:center;" scope="col">OPTOMETRISTA</th>
            <th  style =" text-align:center;" scope="col">FECHA CREACIÓN</th>
            <th  style =" text-align:center;" scope="col">ESTATUS</th>
            <th  style =" text-align:center;" scope="col">VER</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th  style =" text-align:center;;background-color:#0AA09E;color:#FFFFFF;" colspan="17">CON COMENTARIOS (CONFIRMACIONES)</th>
        </tr>
        <?php if(!is_null($contratosConComentarios) && count($contratosConComentarios)>0): ?>
            <?php $__currentLoopData = $contratosConComentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoConComentarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoConComentarios->sucursal); ?></td>
                    <td align='center'><?php echo e($contratoConComentarios->id); ?></td>
                    <td align='center'><?php echo e($contratoConComentarios->usuariocreacion); ?></td>
                    <td align='center'><?php echo e($contratoConComentarios->name); ?></td>
                    <td align='center'><?php echo e(\Carbon\Carbon::parse($contratoConComentarios->created_at)->format('Y-m-d')); ?></td>
                    <?php if($contratoConComentarios->estatus_estadocontrato == 1): ?>
                        <td align='center'><button type="button" class="btn btn-success terminados" style="color:#FEFEFE;"><?php echo e($contratoConComentarios->descripcion); ?></button></td>
                    <?php endif; ?>
                    <?php if($contratoConComentarios->estatus_estadocontrato == 9): ?>
                        <td align='center'> <button type="button" class="btn btn-danger enprocesodeaprobacion" style="color:#FEFEFE;"><?php echo e($contratoConComentarios->descripcion); ?></button></td>
                    <?php endif; ?>
                    <td align='center'> <a href="<?php echo e(route('estadoconfirmacion',[$contratoConComentarios->id])); ?>" ><button type="button" class="btn btn-outline-success"><i  class="fas fa-pen"></i></button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <tr>
            <th  style =" text-align:center;;background-color:#0AA09E;color:#FFFFFF;" colspan="17">TODOS (CONFIRMACIONES)</th>
        </tr>

        <?php if(!is_null($contratosScomentarios) && count($contratosScomentarios)>0): ?>
            <?php $__currentLoopData = $contratosScomentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoScomentarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoScomentarios->sucursal); ?></td>
                    <td align='center'><?php echo e($contratoScomentarios->id); ?></td>
                    <td align='center'><?php echo e($contratoScomentarios->usuariocreacion); ?></td>
                    <td align='center'><?php echo e($contratoScomentarios->name); ?></td>
                    <td align='center'><?php echo e(\Carbon\Carbon::parse($contratoScomentarios->created_at)->format('Y-m-d')); ?></td>
                    <?php if($contratoScomentarios->estatus_estadocontrato == 1): ?>
                        <td align='center'><button type="button" class="btn btn-success terminados" style="color:#FEFEFE;"><?php echo e($contratoScomentarios->descripcion); ?></button></td>
                    <?php endif; ?>
                    <?php if($contratoScomentarios->estatus_estadocontrato == 9): ?>
                        <td align='center'> <button type="button" class="btn btn-danger enprocesodeaprobacion" style="color:#FEFEFE;"><?php echo e($contratoScomentarios->descripcion); ?></button></td>
                    <?php endif; ?>
                    <td align='center'> <a href="<?php echo e(route('estadoconfirmacion',[$contratoScomentarios->id])); ?>" ><button type="button" class="btn btn-outline-success"><i  class="fas fa-pen"></i></button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(!is_null($contratosFueraConfimaciones) && count($contratosFueraConfimaciones)>0): ?>
            <tr>
                <th  style =" text-align:center;;background-color:#0AA09E;color:#FFFFFF;" colspan="17">CONTRATOS FUERA DE CONFIRMACIONES</th>
            </tr>
            <?php $__currentLoopData = $contratosFueraConfimaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoFueraConfimaciones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoFueraConfimaciones->sucursal); ?></td>
                    <td align='center'><?php echo e($contratoFueraConfimaciones->id); ?></td>
                    <td align='center'><?php echo e($contratoFueraConfimaciones->usuariocreacion); ?></td>
                    <td align='center'><?php echo e($contratoFueraConfimaciones->name); ?></td>
                    <td align='center'><?php echo e(\Carbon\Carbon::parse($contratoFueraConfimaciones->created_at)->format('Y-m-d')); ?></td>
                    <td align='center'><button type="button" class="btn btn-secondary" style="color:#FEFEFE;"><?php echo e($contratoFueraConfimaciones->descripcion); ?> </button></td>
                    <td align='center'> <a href="<?php echo e(route('estadoconfirmacion',[$contratoFueraConfimaciones->id])); ?>" ><button type="button" class="btn btn-outline-success"><i  class="fas fa-pen"></i></button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(!is_null($contratosSTerminar) && count($contratosSTerminar)>0): ?>
            <?php $__currentLoopData = $contratosSTerminar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoSTerminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoSTerminar->sucursal); ?></td>
                    <td align='center'><?php echo e($contratoSTerminar->id); ?></td>
                    <td align='center'><?php echo e($contratoSTerminar->usuariocreacion); ?></td>
                    <td align='center'><?php echo e($contratoSTerminar->optometrista); ?></td>
                    <td align='center'><?php echo e(\Carbon\Carbon::parse($contratoSTerminar->created_at)->format('Y-m-d')); ?> </td>
                    <td align='center'><button type="button" class="btn btn-secondary" style="color:#FEFEFE;"><?php echo e($contratoSTerminar->descripcion); ?> </button></td>
                    <td align='center'> <a href="<?php echo e(route('estadoconfirmacion',[$contratoSTerminar->id])); ?>" ><button type="button" class="btn btn-outline-success"><i  class="fas fa-pen"></i></button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(!is_null($contratosPendientes) && count($contratosPendientes)>0): ?>
            <?php $__currentLoopData = $contratosPendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratoPendiente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($contratoPendiente->sucursal); ?></td>
                    <td align='center'><?php echo e($contratoPendiente->id); ?></td>
                    <td align='center'><?php echo e($contratoPendiente->usuariocreacion); ?></td>
                    <td align='center'>SIN CAPTURAR</td>
                    <td align='center'>SIN CAPTURAR</td>
                    <td align='center'><button type="button" class="btn btn-secondary" style="color:#FEFEFE;">SIN CAPTURAR </button></td>
                    <td align='center'> <a href="<?php echo e(route('estadoconfirmacion',[$contratoPendiente->id])); ?>" ><button type="button" class="btn btn-outline-success"><i  class="fas fa-pen"></i></button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
    <hr>
    <div class="row" style="margin-top: 30px;">
        <div class="col-3">
            <button name="btnLaboratorio" id="btnLaboratorio" class="btn btn-primary"></button>
        </div>
        <div class="row col-6" style="margin-top: 5px;">
            <div class="custom-control custom-checkbox" style="margin-right: 30px;">
                <input type="checkbox"
                       class="custom-control-input"
                       name="cbAprobados" id="cbAprobados"
                       value="1" checked>
                <label class="custom-control-label" for="cbAprobados">Aprobados</label>
            </div>
            <div class="custom-control custom-checkbox" style="margin-right: 30px;">
                <input type="checkbox"
                       class="custom-control-input"
                       name="cbManofactura" id="cbManofactura">
                <label class="custom-control-label" for="cbManofactura">Manofactura</label>
            </div>
            <div class="custom-control custom-checkbox" style="margin-right: 30px;">
                <input type="checkbox"
                       class="custom-control-input"
                       name="cbProcesoEnvio" id="cbProcesoEnvio">
                <label class="custom-control-label" for="cbProcesoEnvio">Proceso de envio</label>
            </div>
            <div class="custom-control custom-checkbox">
                <input type="checkbox"
                       class="custom-control-input"
                       name="cbComentarios" id="cbComentario">
                <label class="custom-control-label" for="cbComentario">Con Comentarios</label>
            </div>
        </div>
        <div class="col-1" id="spCargando">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" style="width: 2rem; height: 2rem;" role="status">
                    <span class="visually-hidden"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group" id="tablalaboratorio">

    </div>

    <hr>
    <div class="row" style="margin-top: 30px;">
        <div class="col-3">
            <button name="btnGarantias" id="btnGarantias" class="btn btn-primary"></button>
        </div>
        <div class="col-1" id="spCargando2">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" style="width: 2rem; height: 2rem;" role="status">
                    <span class="visually-hidden"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group" id="tablagarantias">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/confirmaciones/tabla.blade.php ENDPATH**/ ?>