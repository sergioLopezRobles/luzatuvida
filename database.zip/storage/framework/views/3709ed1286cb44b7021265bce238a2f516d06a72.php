
<?php $__env->startSection('titulo','Inicio'); ?>
<?php $__env->startSection('content'); ?>     
  <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="contenedor">     
    <h2><?php echo app('translator')->get('mensajes.mensajenuevafranquicia'); ?></h2>
    <h4><?php echo app('translator')->get('mensajes.documentos'); ?></h4>

    <form id="frmFranquiciaNueva" action="<?php echo e(route('crearfranquicia')); ?>" enctype="multipart/form-data" method="POST" onsubmit="btnSubmit.disabled = true;">
      <?php echo csrf_field(); ?>
      <div class="franquicia">
        <div class="row">
          <div class="col-4">
            <div class="form-group">
              <label>Subir foto</label>
              <input type="file" name="foto" class="form-control-file  <?php echo $errors->first('foto','is-invalid'); ?>" accept="image/jpg">
              <?php echo $errors->first('foto','<div class="invalid-feedback">La foto debera estar en formato jpg.</div>'); ?>

            </div>
          </div>
          <div class="col-4">
            <div class="form-group">
              <label>CURP</label>
              <input type="file" name="curp" class="form-control-file <?php echo $errors->first('curp','is-invalid'); ?>" accept="application/pdf">
              <?php echo $errors->first('curp','<div class="invalid-feedback">El CURP debera estar en formato PDF.</div>'); ?>

            </div>
          </div>
          <div class="col-4">
            <div class="form-group">
              <label>RFC</label>
              <input type="file" name="rfc" class="form-control-file <?php echo $errors->first('rfc','is-invalid'); ?>" accept="application/pdf">
              <?php echo $errors->first('rfc','<div class="invalid-feedback">El RFC debera estar en formato PDF.</div>'); ?>

            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-4">
            <div class="form-group">
              <label>Alta en Hacienda</label>
              <input type="file" name="hacienda" class="form-control-file <?php echo $errors->first('hacienda','is-invalid'); ?>" accept="application/pdf">
              <?php echo $errors->first('hacienda','<div class="invalid-feedback">La alta en hacienda debera estar en formato PDF.</div>'); ?>

            </div>
          </div>
          <div class="col-4">
            <div class="form-group">
              <label>Acta de Nacimiento</label>
              <input type="file" name="actanacimiento" class="form-control-file <?php echo $errors->first('actanacimiento','is-invalid'); ?>" accept="application/pdf">
              <?php echo $errors->first('actanacimiento','<div class="invalid-feedback">El acta de nacimiento debera estar en formato PDF.</div>'); ?>

            </div>
          </div>
          <div class="col-4">
            <div class="form-group">
              <label>Identificacion Oficial</label>
              <input type="file" name="identificacion" class="form-control-file <?php echo $errors->first('identificacion','is-invalid'); ?>" accept="application/pdf">
              <?php echo $errors->first('identificacion','<div class="invalid-feedback">La identificacion debera estar en formato PDF.</div>'); ?>

            </div>
          </div>
        </div>
        <hr>
        <h4><?php echo app('translator')->get('mensajes.direccion'); ?></h4>
        <div class="row">
          <div class="col-3">
            <div class="form-group">
              <label>Estado</label>
              <input type="text" name="estado" class="form-control <?php echo $errors->first('estado','is-invalid'); ?>"  placeholder="Estado">
              <?php echo $errors->first('estado','<div class="invalid-feedback">Campo vacio o nombre muy largo.</div>'); ?>

            </div>
          </div>
          <div class="col-3">
            <div class="form-group">
              <label>Ciudad</label>
              <input type="text" name="ciudad" id="link" class="form-control <?php echo $errors->first('ciudad','is-invalid'); ?>"  placeholder="Ciudad">
                <?php echo $errors->first('ciudad','<div class="invalid-feedback">Campo vacio o nombre muy largo.</div>'); ?>

            </div>
          </div>
          <div class="col-3">
            <div class="form-group">
              <label>Colonia</label>
              <input type="text" name="colonia" id="link" class="form-control <?php echo $errors->first('colonia','is-invalid'); ?>"  placeholder="Colonia">
              <?php echo $errors->first('colonia','<div class="invalid-feedback">Campo vacio o nombre muy largo.</div>'); ?>

            </div>
          </div>
          <div class="col-3">
            <div class="form-group">
              <label>Numero Interior/Exterior</label>
              <input type="number" min="0" name="numero" id="link" class="form-control <?php echo $errors->first('numero','is-invalid'); ?>"  placeholder="Numero Interior/Exterior">
              <?php echo $errors->first('numero','<div class="invalid-feedback">Campo vacio o numero muy grande.</div>'); ?>

            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-4">
            <div class="form-group">
              <label>Comprobante de domicilio</label>
              <input type="file" name="comprobante" class="form-control-file <?php echo $errors->first('comprobante','is-invalid'); ?>" accept="application/pdf">
              <?php echo $errors->first('comprobante','<div class="invalid-feedback">El comprobante debera estar en formato PDF.</div>'); ?>

            </div>
          </div>
          <?php
            $rol_id = Auth::user()->rol_id;
          ?>
          <div class="<?php if($rol_id == 7): ?> col-4 <?php else: ?> col-6 <?php endif; ?>">
            <div class="form-group">
              <label>Observaciones</label>
              <input type="text" name="observaciones" id="link" class="form-control <?php echo $errors->first('observaciones','is-invalid'); ?>"  placeholder="Observaciones" maxlength="300">
              <?php echo $errors->first('observaciones','<div class="invalid-feedback">Se supero el numero maximo de caracteres.</div>'); ?>

            </div>
          </div>
          <div class="col-2">
            <div class="form-group">
              <label>Telefono:</label>
              <input type="text" name="telefonofranquicia" class="form-control <?php echo $errors->first('telefonofranquicia','is-invalid'); ?>"  placeholder="Telefono"  value="<?php echo e(old('telefonofranquicia')); ?>">
              <?php echo $errors->first('telefonofranquicia','<div class="invalid-feedback">El telefono debe contener 10 numeros.</div>'); ?>

            </div>
          </div>
          <?php if($rol_id==7): ?>    
            <div class="col-2">
              <label> Estado de la sucursal</label>
              <div class="form-check">              
                  <input type="checkbox" name="activo" id="activo" class="form-check-input" value="1">
                  <label class="form-check-label" for="activo">Activo/Inactivo</label>
              </div>
            </div>
          <?php endif; ?>
        </div>
      <div>
      <?php if($rol_id==7): ?> 
        <div class="row">
          <dic class="col-12">
            <p style="color:#5f5f5f;"><b>Nota: Como director, es posible crear una sucursal sin agregar los documentos y para activar la sucursal es necesario seleccionar la opcion de "Estado de la sucursal".</b></p>
          </dic>
        </div>
      <?php endif; ?>
      <div class="row">
        <div class="col-4">
            <a href="<?php echo e(route('listafranquicia')); ?>" class="btn btn-outline-success btn-block"><?php echo app('translator')->get('mensajes.regresar'); ?></a>
        </div>
        <div class="col">
          <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit"><?php echo app('translator')->get('mensajes.mensajecrearfranquicia'); ?></button>
        </div>
      </div>            
    </form>
  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/franquicia/nueva.blade.php ENDPATH**/ ?>