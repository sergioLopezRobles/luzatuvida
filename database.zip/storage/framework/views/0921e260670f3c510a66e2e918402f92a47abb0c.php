
<?php $__env->startSection('titulo','Lista Franquicias'); ?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <h2 style="text-align: left; color: #0AA09E">Sucursales</h2>
  <div class="contenedortblFranquicias">
      <table id="tablaFranquicias" class="table table-bordered">
          <?php if(sizeof($franquicias)>0): ?>
              <thead>
              <tr>
                  <th  style =" text-align:center;" scope="col">SUCURSAL</th>
                  <th  style =" text-align:center;" scope="col">ESTATUS</th>
                  <th  style =" text-align:center;" scope="col">CREADOPOR</th>
                  <th  style =" text-align:center;" scope="col">ACTUALIZADOPOR</th>
                  <th  style =" text-align:center;" scope="col">ESTADO</th>
                  <th  style =" text-align:center;" scope="col">CIUDAD</th>
                  <th  style =" text-align:center;" scope="col">COLONIA</th>
                  <th  style =" text-align:center;" scope="col">NUMERO</th>
                  <th  style =" text-align:center;" scope="col">CREADOEL</th>
                  <th  style =" text-align:center;" scope="col">USUARIOS</th>
                  <th  style =" text-align:center;" scope="col">EDITAR</th>
                  <th  style =" text-align:center;" scope="col">VER</th>
              </tr>
              </thead>
          <?php endif; ?>
          <tbody>
          <?php $__currentLoopData = $franquicias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franquicia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td align='center'><?php echo e($franquicia->ID); ?></td>
                  <?php if($franquicia->ESTATUS  == 1): ?>
                      <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                  <?php else: ?>
                      <td align='center' ><i class='fas fa-check' style="color:#ffaca6;font-size:25px;"></i></td>
                  <?php endif; ?>
                  <td align='center'><?php echo e($franquicia->CREADOPOR); ?></td>
                  <td align='center'><?php echo e($franquicia->ACTUALIZADOPOR); ?></td>
                  <td align='center'><?php echo e($franquicia->ESTADO); ?></td>
                  <td align='center'><?php echo e($franquicia->CIUDAD); ?></td>
                  <td align='center'><?php echo e($franquicia->COLONIA); ?></td>
                  <td align='center'><?php echo e($franquicia->NUMERO); ?></td>
                  <td align='center'><?php echo e($franquicia->CREADOEL); ?></td>
                  <td align='center'> <a href="<?php echo e(route('usuariosFranquicia',$franquicia->ID)); ?>" ><button type="button" class="btn"><i  class="fas fa-users"></i></button></a></td>
                  <td align='center'> <a href="<?php echo e(route('editarFranquicia',$franquicia->ID)); ?>" ><button type="button" class="btn"><i  class="fas fa-pen"></i></button></a></td>
                  <td align='center'> <a href="<?php echo e(route('listacontrato',$franquicia->ID)); ?>" ><button type="button" class="btn"><i  class="fas fa-book-open"></i></button></a></td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/franquicia/tabla.blade.php ENDPATH**/ ?>