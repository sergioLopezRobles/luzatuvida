
<?php $__env->startSection('titulo','Contratos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <?php echo e(isset($errors)? var_dump($errors) : ''); ?>       -->
    <div class="row">
        <div class="col-3">
            <?php if($contrato[0]->idcontratorelacion == null): ?>
                <h2><?php echo app('translator')->get('mensajes.mensajecontrato'); ?> <?php if($contrato[0]->id_promocion > 0): ?> - Principal <?php endif; ?></h2>
            <?php else: ?>
                <h2><?php echo app('translator')->get('mensajes.mensajecontrato'); ?> - Secundario</h2>
            <?php endif; ?>
        </div>
        <?php if($contrato[0]->estatus_estadocontrato  == 2 && (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && ($contrato[0]->pago == 1 || $contrato[0]->pago == 2 || $contrato[0]->pago == 4)): ?>
            <div class="col-5"></div>
            <div class="col-2">
                <a class="btn btn-danger btn-block" data-toggle="modal" data-target="#atrasarContrato">¿ATRAZAR
                    CONTRATO?</a>
            </div>
        <?php else: ?>
            <div class="col-7"></div>
        <?php endif; ?>

        <div class="col-2">
            <?php switch($contrato[0]->estatus_estadocontrato):
                case (0): ?>
                <input type="text" style="background-color:#6c757d;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="NO TERMINADO">
                <?php break; ?>
                <?php case (1): ?>
                <input type="text" style="background-color:#5bc0de;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="TERMINADO">
                <?php break; ?>
                <?php case (2): ?>
                <input type="text" style="background-color:#0275d8;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="ENTREGADO">
                <?php break; ?>
                <?php case (3): ?>
                <input type="text" style="background-color:#ea9999;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="PRE-CANCELADO">
                <?php break; ?>
                <?php case (4): ?>
                <?php if($contrato[0]->dias <= 10): ?> <input type="text"
                                                     style="background-color:#fff2cc;color:#000000;text-align:center"
                                                     name="estatuscontrato" class="form-control"
                                                     readonly value="ABONO ATRASADO">
                <?php endif; ?>
                <?php if($contrato[0]->dias >= 11 && $contrato[0]->dias <= 20): ?> <input type="text"
                                                                                 style="background-color:#fce5cd;color:#000000;text-align:center"
                                                                                 name="estatuscontrato"
                                                                                 class="form-control" readonly
                                                                                 value="ABONO ATRASADO">
                <?php endif; ?>
                <?php if($contrato[0]->dias > 20): ?>
                    <input type="text" style="background-color:#f4cccc;color:#000000;text-align:center"
                           name="estatuscontrato" class="form-control" readonly value="ABONO ATRASADO">
                <?php endif; ?>
                <?php break; ?>
                <?php case (5): ?>
                <input type="text" style="background-color:#5cb85c;color:#FFFFFF;text-align:center"
                       name="estatuscontrato" class="form-control" readonly value="PAGADO">
                <?php break; ?>
                <?php case (6): ?>
                <input type="text" style="background-color:#ff0000;color:#FFFFFF;text-align:center"
                       name="estatuscontrato" class="form-control" readonly value="CANCELADO">
                <?php break; ?>
                <?php case (7): ?>
                <input type="text" style="background-color:#5cb85c;color:#FFFFFF;text-align:center"
                       name="estatuscontrato" class="form-control" readonly value="APROBADO">
                <?php break; ?>
                <?php case (8): ?>
                <input type="text" style="background-color:#ff0000;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="RECHAZADO">
                <?php break; ?>
                <?php case (9): ?>
                <input type="text" style="background-color:#f0cc0a;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="EN PROCESO DE APROBACION">
                <?php break; ?>
                <?php case (10): ?>
                <input type="text" style="background-color:#f0cc0a;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="MANUFACTURA">
                <?php break; ?>
                <?php case (11): ?>
                <input type="text" style="background-color:#f0cc0a;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="EN PROCESO DE ENVIO">
                <?php break; ?>
                <?php case (12): ?>
                <input type="text" style="background-color:#5bc0de;color:#FFFFFF;text-align:center"
                       name="estatuscontrato"
                       class="form-control" readonly value="ENVIADO">
                <?php break; ?>
                <?php case (14): ?>
                <input type="text" style="background-color:#ff0000;color:#FFFFFF;text-align:center"
                       name="estatuscontrato" class="form-control" readonly value="LIO/FUGA">
                <?php break; ?>
                <?php case (15): ?>
                <input type="text" style="background-color:#F88F32;color:#FFFFFF;text-align:center"
                       name="estatuscontrato" class="form-control" readonly value="SUPERVISION">
                <?php break; ?>
            <?php endswitch; ?>
        </div>
    </div>
    <?php if($contrato[0]->estatus_estadocontrato <= 1 && Auth::user()->rol_id != 4): ?>
        <?php if($contrato[0]->idcontratorelacion == null): ?>
            <div class="row">
                <?php if($contrato[0]->id_promocion > 0): ?>
                    <?php if($contrato[0]->estatus_estadocontrato == 1 && (Auth::user()->rol_id == 13 || Auth::user()->rol_id == 12) &&
                    $contratosterminadostodos == null && $contraspadre2[0]->armazones == $contraspadre2[0]->contador): ?>
                        <div class="col-6">
                        </div>
                        <div class="col-6">
                            <a class="btn btn-outline-success btn-block" data-toggle="modal"
                               data-target="#Abrirconfirmar">SALIR</a>
                        </div>
                    <?php endif; ?>
                    <?php if($contrato[0]->estatus_estadocontrato <= 1): ?>
                        <div class="col-6">
                        </div>
                        <div class="col-6">

                            <?php if($contraspadre2[0]->armazones != $contraspadre2[0]->contador || $contratosterminadostodos != null &&
                            $contraspadre2[0]->contador > 1): ?>
                                <a class="btn btn-outline-success btn-block" data-toggle="modal"
                                   data-target="#Abrirconfirmar">SIGUIENTE
                                    CONTRATO</a>
                            <?php endif; ?>
                            <?php if($contraspadre2[0]->armazones == 1 && $contraspadre2[0]->contador == 1 &&
                            $contrato[0]->estatus_estadocontrato == 0): ?>
                                <a class="btn btn-outline-success btn-block" data-toggle="modal"
                                   data-target="#Abrirconfirmar">TERMINAR
                                    CONTRATO</a>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if($contrato[0]->id_promocion === null ): ?>
                                <div class="col-6">
                                </div>
                                <div class="col-6">
                                    <?php if($contrato[0]->estatus_estadocontrato < 1): ?> <a
                                        class="btn btn-outline-success btn-block"
                                        data-toggle="modal" data-target="#Abrirconfirmar">TERMINAR
                                        CONTRATO</a>
                                    <?php else: ?>
                                        <a class="btn btn-outline-success btn-block" data-toggle="modal"
                                           data-target="#Abrirconfirmar">SALIR
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

            </div>
        <?php else: ?>
            <div class="row">
                <?php if($historialesclinicos != null && $contrato[0]->estatus_estadocontrato == 0): ?>
                    <div class="col-6">
                    </div>
                    <div class="col-6">
                        <?php if($contraspadre5[0]->id_promocion > 0 && $contraspadre5[0]->armazones == $contraspadre5[0]->contador): ?>
                            <a class="btn btn-outline-success btn-block" data-toggle="modal"
                               data-target="#Abrirconfirmarhijo">TERMINAR CONTRATO</a>
                        <?php else: ?>
                            <a class="btn btn-outline-success btn-block" data-toggle="modal"
                               data-target="#Abrirconfirmarhijo">SIGUIENTE
                                CONTRATO</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    <?php if((Auth::user()->rol_id != 12 && Auth::user()->rol_id != 13) && $contrato[0]->estatus_estadocontrato == 12): ?>
        <div class="row">
            <div class="col-6">
            </div>
            <div class="col-6">
                <?php if($contrato[0]->id_promocion < 1): ?> <a class="btn btn-outline-success btn-block" data-toggle="modal"
                                                       data-target="#Abrirentregar">PRODUCTO
                    ENTREGADO
                </a>
                <?php elseif($contraspadre2[0]->armazones == $contraspadre2[0]->contador && $contratosterminadostodos == null
                && $contraspadre2[0]->contador >= 1): ?>
                    <a class="btn btn-outline-success btn-block" data-toggle="modal" data-target="#Abrirentregar">PRODUCTO
                        ENTREGADO
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php if(Auth::user()->rol_id == 7): ?>
            <?php if(($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 4 ||
                $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12)
                && ($contrato[0]->estadogarantia != 2)): ?>
                <div class="col-2">
                    <div class="form-group">
                        <label># Contrato</label>
                        <input type="text" name="idcontra" class="form-control" readonly value="<?php echo e($contrato[0]->id); ?>">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Fecha venta</label>
                        <input type="text" name="fechaCre" class="form-control" readonly
                               value="<?php echo e($contrato[0]->created_at); ?>">
                    </div>
                </div>
                <div class="col-1">
                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="totalreal" class="form-control" readonly
                               value="$ <?php echo e($contrato[0]->totalreal); ?>">
                    </div>
                </div>
                <?php if($contrato[0]->promocion != null): ?>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total promocion</label>
                            <input type="text" name="totalpromocion" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalpromocion); ?>">
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total productos</label>
                            <?php if($contrato[0]->totalproductos != null): ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalproductos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total abonos</label>
                            <?php if($contrato[0]->totalabonos != null): ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalabonos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Saldo</label>
                            <input type="text" name="saldo" class="form-control" readonly value="$ <?php echo e($contrato[0]->total); ?>">
                        </div>
                    </div>
                    <div class="col-3">
                        <form id="frmaumentardescontar"
                              action="<?php echo e(route('aumentardescontarsaldocontrato',[$idFranquicia,$idContrato])); ?>"
                              enctype="multipart/form-data"
                              method="GET" onsubmit="btnSubmit.disabled = true;">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-8">
                                    <div class="form-group">
                                        <label>Aumentar/Descontar</label>
                                        <input type="number" name="aumentardescontar" class="form-control" min="-9999"
                                               max="9999" value="0">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <a type="button" href="" class="btn btn-outline-success" data-toggle="modal"
                                           data-target="#modalaumentardescontar">APLICAR</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total productos</label>
                            <?php if($contrato[0]->totalproductos != null): ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalproductos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total abonos</label>
                            <?php if($contrato[0]->totalabonos != null): ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalabonos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Saldo</label>
                            <input type="text" name="saldo" class="form-control" readonly value="$ <?php echo e($contrato[0]->total); ?>">
                        </div>
                    </div>
                    <div class="col-4">
                        <form id="frmaumentardescontar"
                              action="<?php echo e(route('aumentardescontarsaldocontrato',[$idFranquicia,$idContrato])); ?>"
                              enctype="multipart/form-data"
                              method="GET" onsubmit="btnSubmit.disabled = true;">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Aumentar/Descontar</label>
                                        <input type="number" name="aumentardescontar" class="form-control" min="-9999"
                                               max="9999" value="0">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <a type="button" href="" class="btn btn-outline-success" data-toggle="modal"
                                           data-target="#modalaumentardescontar">APLICAR</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="col-2">
                    <div class="form-group">
                        <label># Contrato</label>
                        <input type="text" name="idcontra" class="form-control" readonly value="<?php echo e($contrato[0]->id); ?>">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Fecha venta</label>
                        <input type="text" name="fechaCre" class="form-control" readonly
                               value="<?php echo e($contrato[0]->created_at); ?>">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="totalreal" class="form-control" readonly
                               value="$ <?php echo e($contrato[0]->totalreal); ?>">
                    </div>
                </div>
                <?php if($contrato[0]->promocion != null): ?>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Total promocion</label>
                            <input type="text" name="totalpromocion" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalpromocion); ?>">
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total productos</label>
                            <?php if($contrato[0]->totalproductos != null): ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalproductos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-1">
                        <div class="form-group">
                            <label>Total abonos</label>
                            <?php if($contrato[0]->totalabonos != null): ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalabonos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Saldo</label>
                            <input type="text" name="saldo" class="form-control" readonly value="$ <?php echo e($contrato[0]->total); ?>">
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Total productos</label>
                            <?php if($contrato[0]->totalproductos != null): ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalproductos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Total abonos</label>
                            <?php if($contrato[0]->totalabonos != null): ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalabonos); ?>">
                            <?php else: ?>
                                <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label>Saldo</label>
                            <input type="text" name="saldo" class="form-control" readonly value="$ <?php echo e($contrato[0]->total); ?>">
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="col-2">
                <div class="form-group">
                    <label># Contrato</label>
                    <input type="text" name="idcontra" class="form-control" readonly value="<?php echo e($contrato[0]->id); ?>">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Fecha venta</label>
                    <input type="text" name="fechaCre" class="form-control" readonly
                           value="<?php echo e($contrato[0]->created_at); ?>">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label>Total</label>
                    <input type="text" name="totalreal" class="form-control" readonly
                           value="$ <?php echo e($contrato[0]->totalreal); ?>">
                </div>
            </div>
            <?php if($contrato[0]->promocion != null): ?>
                <div class="col-2">
                    <div class="form-group">
                        <label>Total promocion</label>
                        <input type="text" name="totalpromocion" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalpromocion); ?>">
                    </div>
                </div>
                <div class="col-1">
                    <div class="form-group">
                        <label>Total productos</label>
                        <?php if($contrato[0]->totalproductos != null): ?>
                            <input type="text" name="totalproductos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalproductos); ?>">
                        <?php else: ?>
                            <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-1">
                    <div class="form-group">
                        <label>Total abonos</label>
                        <?php if($contrato[0]->totalabonos != null): ?>
                            <input type="text" name="totalabonos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalabonos); ?>">
                        <?php else: ?>
                            <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Saldo</label>
                        <input type="text" name="saldo" class="form-control" readonly value="$ <?php echo e($contrato[0]->total); ?>">
                    </div>
                </div>
            <?php else: ?>
                <div class="col-2">
                    <div class="form-group">
                        <label>Total productos</label>
                        <?php if($contrato[0]->totalproductos != null): ?>
                            <input type="text" name="totalproductos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalproductos); ?>">
                        <?php else: ?>
                            <input type="text" name="totalproductos" class="form-control" readonly value="$ 0">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Total abonos</label>
                        <?php if($contrato[0]->totalabonos != null): ?>
                            <input type="text" name="totalabonos" class="form-control" readonly value="$ <?php echo e($contrato[0]->totalabonos); ?>">
                        <?php else: ?>
                            <input type="text" name="totalabonos" class="form-control" readonly value="$ 0">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Saldo</label>
                        <input type="text" name="saldo" class="form-control" readonly value="$ <?php echo e($contrato[0]->total); ?>">
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <div class="row">
        <?php if(Auth::user()->rol_id == 4 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13): ?>
            <div class="col-4">
                <div class="form-group">
                    <label>Cliente</label>
                    <input type="text" name="nombreC" class="form-control" readonly value="<?php echo e($contrato[0]->nombre); ?>">
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label>Teléfono</label>
                    <input type="text" name="telefonoC" class="form-control" readonly
                           value="<?php echo e($contrato[0]->telefono); ?>">
                </div>
            </div>
            <?php if(Auth::user()->rol_id == 4): ?>
                <div class="col-2">
                    <div class="form-group">
                        <label>Nombre referencia</label>
                        <input type="text" name="nombrereferenciaC" class="form-control" readonly
                               value="<?php echo e($contrato[0]->nombrereferencia); ?>">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label>Teléfono referencia</label>
                        <input type="text" name="telefonoRC" class="form-control" readonly
                               value="<?php echo e($contrato[0]->telefonoreferencia); ?>">
                    </div>
                </div>
            <?php else: ?>
                <div class="col-4">
                    <div class="form-group">
                        <label>Teléfono referencia</label>
                        <input type="text" name="telefonoRC" class="form-control" readonly
                               value="<?php echo e($contrato[0]->telefonoreferencia); ?>">
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="col-3">
                <div class="form-group">
                    <label>Cliente</label>
                    <input type="text" name="nombreC" class="form-control" readonly value="<?php echo e($contrato[0]->nombre); ?>">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Teléfono / Teléfono referencia</label>
                    <input type="text" name="telefonoC" class="form-control" readonly
                           value="<?php echo e($contrato[0]->telefono . ' / ' . $contrato[0]->telefonoreferencia); ?>">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Creado por</label>
                    <input type="text" name="creadorporC" class="form-control" readonly
                           value="<?php echo e($contrato[0]->nombre_usuariocreacion); ?>">
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label>Optometrista asignado</label>
                    <input type="text" class="form-control" readonly value="<?php echo e($contrato[0]->name); ?>">
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-2">
            <div class="form-group">
                <label>Localidad</label>
                <input type="text" name="localidadC" class="form-control" readonly value="<?php echo e($contrato[0]->localidad); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="coloniaC" class="form-control" readonly value="<?php echo e($contrato[0]->colonia); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Calle</label>
                <input type="text" name="calleC" class="form-control" readonly value="<?php echo e($contrato[0]->calle); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Entre calles</label>
                <input type="text" name="entrecallesC" class="form-control" readonly
                       value="<?php echo e($contrato[0]->entrecalles); ?>">
            </div>
        </div>
        <div class="col-1">
            <div class="form-group">
                <label>Número</label>
                <input type="text" name="numeroC" class="form-control" readonly value="<?php echo e($contrato[0]->numero); ?>">
            </div>
        </div>
    </div>
    <?php if(((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
            && ($contrato[0]->estatus_estadocontrato == 0
                || $contrato[0]->estatus_estadocontrato == 2
                || $contrato[0]->estatus_estadocontrato == 4
                || ($contrato[0]->estatus_estadocontrato == 12 && $contrato[0]->fechacobroini == null && $contrato[0]->fechacobrofin == null))
            && ($contrato[0]->estadogarantia == null || ($contrato[0]->estadogarantia != 0 && $contrato[0]->estadogarantia != 1 && $contrato[0]->estadogarantia != 2)))): ?>
        <div class="col-12">
            <form action="<?php echo e(route('agregarformapago',[$idFranquicia,$idContrato])); ?>" enctype="multipart/form-data"
                  method="POST" onsubmit="btnSubmit.disabled = true;">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-3">
                        <label for="">FORMA DE PAGO:</label>
                        <select class="custom-select <?php echo $errors->first('formapago','is-invalid'); ?>" name="formapago"
                                id="formapago">
                            <option selected value='nada'>Seleccionar</option>
                            <?php if($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 12): ?>
                                <option value=0 <?php echo e(isset($contrato) ? ($contrato[0]->pago == '0' ? 'selected' : '') : ''); ?>>
                                    Contado
                                </option>
                            <?php endif; ?>
                            <option value=1 <?php echo e(isset($contrato) ? ($contrato[0]->pago == '1' ? 'selected' : '') : ''); ?>>
                                Semanal
                            </option>
                            <option value=2 <?php echo e(isset($contrato) ? ($contrato[0]->pago == '2' ? 'selected' : '') : ''); ?>>
                                Quincenal
                            </option>
                            <option value=4 <?php echo e(isset($contrato) ? ($contrato[0]->pago == '4' ? 'selected' : '') : ''); ?>>
                                Mensual
                            </option>
                        </select>
                        <?php if($errors->has('formapago')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('formapago')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">
                                ACTUALIZAR
                                FORMA DE PAGO
                            </button>
                        </div>
                    </div>
                </div>
                <?php if($contrato[0]->pago != '4'): ?>
                    <label style="color: #ea9999">Al cambiar a MENSUAL aceptas que actualizaste las fotos de tarjetas de pensión</label>
                <?php endif; ?>
            </form>
            <hr>
        </div>
    <?php endif; ?>
    <?php if(Auth::user()->rol_id == 4): ?>
        <div class="col-3">
            <h2> <?php echo app('translator')->get('mensajes.mensajehistorialclinico'); ?></h2>
        </div>
        <table id="tablaHistoriales2" class="table table-bordered">
            <?php if(sizeof($historialesclinicos)>0): ?>
                <thead>
                <tr>
                    <th style=" text-align:center;width:20%;">FECHA ENTREGA</th>
                    <th style=" text-align:center;width:80%;">OBSERVACIONES LABORATORIO</th>
                    <th style=" text-align:center;width:80%;">OBSERVACIONES ITERNO</th>
                </tr>
                </thead>
            <?php endif; ?>
            <tbody>
            <?php $__currentLoopData = $historialesclinicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($historial->fechaentrega); ?></td>
                    <?php if($historial->observaciones != null): ?>
                        <td align='center'><?php echo e($historial->observaciones); ?></td>
                    <?php else: ?>
                        <td align='center'>NA</td>
                    <?php endif; ?>
                    <?php if($historial->observacionesinterno != null): ?>
                        <td align='center'><?php echo e($historial->observacionesinterno); ?></td>
                    <?php else: ?>
                        <td align='center'>NA</td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    <?php if(Auth::user()->rol_id != 4): ?>
        <div class="row">
            <div class="col-3">
                <h2> <?php echo app('translator')->get('mensajes.mensajehistorialclinico'); ?></h2>
            </div>
            <table id="tablaHistoriales" class="table table-bordered">
                <?php if(sizeof($historialesclinicos)>0): ?>
                    <thead>
                    <tr>
                        <th style=" text-align:center;" scope="col">DIAGNOSTICO</th>
                        <th style=" text-align:center;" scope="col">FECHA VISITA</th>
                        <th style=" text-align:center;" scope="col">FECHA DE ENTREGA</th>
                        <th style=" text-align:center;" scope="col">OBSERVACIONES LABORATORIO</th>
                        <th style=" text-align:center;" scope="col">OBSERVACIONES INTERNO</th>
                        <?php if($contrato[0]->estatus_estadocontrato == 0 && $contrato[0]->total > 0): ?>
                            <th style=" text-align:center;" scope="col">EDITAR</th>
                        <?php endif; ?>
                    </tr>
                    </thead>
                <?php endif; ?>
                <tbody>
                <?php $__currentLoopData = $historialesclinicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align='center'><?php echo e($historial->diagnostico); ?></td>
                        <td align='center'><?php echo e($historial->created_at); ?></td>
                        <td align='center'><?php echo e($historial->fechaentrega); ?></td>
                        <?php if($historial->observaciones != null): ?>
                            <td align='center'><?php echo e($historial->observaciones); ?></td>
                        <?php else: ?>
                            <td align='center'>NA</td>
                        <?php endif; ?>
                        <?php if($historial->observacionesinterno != null): ?>
                            <td align='center'><?php echo e($historial->observacionesinterno); ?></td>
                        <?php else: ?>
                            <td align='center'>NA</td>
                        <?php endif; ?>
                        <?php if($contrato[0]->estatus_estadocontrato == 0 && $contrato[0]->total > 0): ?>
                            <td align='center'><a
                                    href="<?php echo e(route('actualizarhistorial',[$idFranquicia,$idContrato,$historial->id])); ?>">
                                    <button type="button" class="btn btn-outline-success "><i class="fas fa-pen"></i>
                                    </button>
                                </a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <hr>

        <h2> <?php echo app('translator')->get('mensajes.mensajepromociones'); ?></h2>
        <div class="row">
            <div class="col-6">
                <?php if($contrato[0]->estatus_estadocontrato == 0): ?>
                    <?php if($contrato[0]->idcontratorelacion == null && $contrato[0]->id_promocion === null): ?>
                        <?php if($contrato[0]->total > 0): ?>
                            <?php if($contrato[0]->enganche < 1): ?>
                                <form action="<?php echo e(route('agregarpromocion',[$idFranquicia,$idContrato])); ?>"
                                      enctype="multipart/form-data" method="GET" onsubmit="btnSubmit.disabled = true;">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for=""><br></label>
                                                <select
                                                    class="custom-select <?php echo $errors->first('promocion','is-invalid'); ?>"
                                                    name="promocion">
                                                    <?php if(count($promociones) > 0): ?>
                                                        <option selected value="0">Seleccionar</option>
                                                        <?php $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                value="<?php echo e($promocion->id); ?>"><?php echo e($promocion->titulo); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <option selected value="0">Sin registros</option>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('promocion')): ?>
                                                    <div class="invalid-feedback"><?php echo e($errors->first('promocion')); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <button class="btn btn-outline-success btn-block" name="btnSubmit"
                                                        type="submit">AGREGAR PROMOCIÓN
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <table id="tablaPromociones" class="table table-bordered">
            <?php if(sizeof($promocioncontrato)>0): ?>
                <thead>
                <tr>
                    <th style=" text-align:center;" scope="col">ESTADO</th>
                    <th style=" text-align:center;" scope="col">TITULO</th>
                    <th style=" text-align:center;" scope="col">INICIO</th>
                    <th style=" text-align:center;" scope="col">FIN</th>
                    <?php if($contrato[0]->estatus_estadocontrato == 0): ?>
                        <th style=" text-align:center;" scope="col">ELIMINAR</th>
                    <?php endif; ?>
                    <?php if($contrato[0]->id_promocion > 0): ?>
                        <?php if($contraspadre2[0]->armazones == $contraspadre2[0]->contador && $contratosterminadostodos == null): ?>
                            <th style=" text-align:center;" scope="col">QUITAR</th>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($contrato[0]->estatus_estadocontrato > 0): ?>
                            <th style=" text-align:center;" scope="col">QUITAR</th>
                    <?php endif; ?>
                <?php endif; ?>
                <!-- <th  style =" text-align:center;" scope="col">EDITAR</th>                                 -->
                </tr>
                </thead>
            <?php endif; ?>
            <tbody>
            <?php $__currentLoopData = $promocioncontrato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($promocion->estado == 1): ?>
                        <td align='center'><i class='fas fa-check' style="color:#9be09c;font-size:25px;"></i></td>
                    <?php else: ?>
                        <td align='center'><i class='fas fa-times' style="color:#ffaca6;font-size:25px;"></i></td>
                    <?php endif; ?>
                    <td align='center'><?php echo e($promocion->titulo); ?></td>
                    <td align='center'><?php echo e($promocion->inicio); ?></td>
                    <td align='center'><?php echo e($promocion->fin); ?></td>
                    <?php if($contrato[0]->estatus_estadocontrato == 0): ?>
                        <td align='center'><a
                                href="<?php echo e(route('eliminarPromocion',[$idFranquicia,$promocion->id_contrato, $promocion->id])); ?>"
                                name="btnSubmit"
                                class="btn btn-danger">ELIMINAR</a></td>
                    <?php endif; ?>
                    <?php if($contrato[0]->id_promocion > 0): ?>
                        <?php if($contraspadre2[0]->armazones == $contraspadre2[0]->contador && $contratosterminadostodos == null): ?>
                            <?php if($promocion->estado == 1): ?>
                                <td align='center'><a
                                        href="<?php echo e(route('desactivarPromocion',[$idFranquicia,$promocion->id_contrato, $promocion->id])); ?>"
                                        class="btn btn-warning">QUITAR</a></td>
                            <?php else: ?>
                                <td align='center'><a
                                        href="<?php echo e(route('desactivarPromocion',[$idFranquicia,$promocion->id_contrato, $promocion->id])); ?>"
                                        class="btn btn-primary">ACTIVAR</a></td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($contrato[0]->estatus_estadocontrato > 0): ?>
                            <td align='center'><a
                                    href="<?php echo e(route('desactivarPromocion',[$idFranquicia,$promocion->id_contrato, $promocion->id])); ?>"
                                    class="btn btn-primary">ACTIVAR</a></td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <hr>
    <?php endif; ?>

    <div class="row">
        <div class="col-2">
            <h2><?php echo app('translator')->get('mensajes.mensajeabonos'); ?></h2>
        </div>
        <?php if($contrato[0]->subscripcion == null): ?>
            <div class="col-3">
                <a type="button" href="" class="btn btn-outline-success btn-block" data-toggle="modal"
                   data-target="#AbrirAbono">NUEVO</a>
            </div>
        <?php else: ?>
            <h5 style="margin-top: 7px; color: red">Ya se encuentra subscrito el contrato a una cuenta</h5>
        <?php endif; ?>
        <div class="col-2">
        </div>
        <?php if($contrato[0]->pago == 1): ?>
            <div class="col-5">
                <form action="<?php echo e(route('entregarDiaPago',[$idFranquicia,$idContrato])); ?>" enctype="multipart/form-data"
                      method="GET" onsubmit="btnSubmit.disabled = true;">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-5">
                            <label for="diapago">&nbsp;</label>
                            <select class="custom-select <?php echo $errors->first('diapago','is-invalid'); ?>" name="diapago"
                                    id="diapago3">
                                <option selected value='0'>DIA DE PAGO</option>
                                <option value='Todos' <?php echo e(old('diapago') == 'Todos' ? 'selected' : ''); ?>>Todos</option>
                                <option value='Monday' <?php echo e(old('diapago') == 'Monday' ? 'selected' : ''); ?>>Lunes</option>
                                <option value='Tuesday' <?php echo e(old('diapago') == 'Tuesday' ? 'selected' : ''); ?>>Martes
                                </option>
                                <option value='Wednesday' <?php echo e(old('diapago') == 'Wednesday' ? 'selected' : ''); ?>>
                                    Miercoles
                                </option>
                                <option value='Thursday' <?php echo e(old('diapago') == 'Thursday' ? 'selected' : ''); ?>>Jueves
                                </option>
                                <option value='Friday' <?php echo e(old('diapago') == 'Friday' ? 'selected' : ''); ?>>Viernes
                                </option>
                                <option value='Saturday' <?php echo e(old('diapago') == 'Saturday' ? 'selected' : ''); ?>>Sabado
                                </option>
                            </select>
                            <?php if($errors->has('diapago')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('diapago')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit">AGREGAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        <?php endif; ?>
        <table id="tablaAbonos" class="table table-bordered">
            <?php if(sizeof($abonos)>0): ?>
                <thead>
                <tr>
                    <th style=" text-align:center;" scope="col">CODIGO</th>
                    <th style=" text-align:center;" scope="col">ABONO</th>
                    <th style=" text-align:center;" scope="col">FECHA</th>
                    <th style=" text-align:center;" scope="col">TIPO DE ABONO</th>
                    <th style=" text-align:center;" scope="col">FORMA DE PAGO</th>
                    <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                        <th style=" text-align:center;" scope="col">FOLIO</th>
                    <?php endif; ?>
                    <th style=" text-align:center;" scope="col">ELIMINAR ABONO</th>
                </tr>
                </thead>
            <?php endif; ?>
            <tbody>
            <?php $__currentLoopData = $abonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td align='center' width="7%"><?php echo e($ab->id); ?></td>
                    <td align='center'><?php echo e($ab->abono); ?></td>
                    <td align='center'><?php echo e($ab->created_at); ?></td>
                    <?php switch($ab->tipoabono):
                        case (0): ?>
                        <?php if($ab->atraso > 0): ?>
                            <td align='center'>ATRASO</td>
                        <?php else: ?>
                            <td align='center'>NORMAL</td>
                        <?php endif; ?>
                        <?php break; ?>
                        <?php case (1): ?>
                        <td align='center'>ENGANCHE</td>
                        <?php break; ?>
                        <?php case (2): ?>
                        <td align='center'>ENTREGA PRODUCTO</td>
                        <?php break; ?>
                        <?php case (3): ?>
                        <td align='center'>ABONO PERIODO</td>
                        <?php break; ?>
                        <?php case (4): ?>
                        <td align='center'>CONTADO ENGANCHE</td>
                        <?php break; ?>
                        <?php case (5): ?>
                        <td align='center'>CONTADO SIN ENGANCHE</td>
                        <?php break; ?>
                        <?php case (6): ?>
                        <td align='center'>LIQUIDADO</td>
                        <?php break; ?>
                        <?php case (7): ?>
                        <td align='center'>PRODUCTO</td>
                        <?php break; ?>
                        <?php case (8): ?>
                        <td align='center'>TARJETA</td>
                        <?php break; ?>
                    <?php endswitch; ?>
                    <?php switch($ab->metodopago):
                        case (0): ?>
                        <td align='center'>EFECTIVO</td>
                        <?php break; ?>
                        <?php case (1): ?>
                        <td align='center'>TARJETA</td>
                        <?php break; ?>
                        <?php case (2): ?>
                        <td align='center'>TRANSFERENCIA</td>
                        <?php break; ?>

                    <?php endswitch; ?>
                    <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                        <?php if($ab->folio != null): ?>
                            <td align='center'><?php echo e($ab->folio); ?></td>
                        <?php else: ?>
                            <td align='center'>S / F</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    <td align='center'>
                        <?php if($ab->metodopago == 1): ?>
                            <a class="btn btn-secondary disable">N/A</a>
                        <?php else: ?>
                            <?php if($ab->tipoabono == 7 &&
                                    ($contrato[0]->estatus_estadocontrato == 2 ||
                                    $contrato[0]->estatus_estadocontrato == 4 ||
                                    $contrato[0]->estatus_estadocontrato == 5 ||
                                    $contrato[0]->estatus_estadocontrato == 12)): ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('eliminarAbono',[$idFranquicia,$idContrato,$ab->id])); ?>"
                                   class="btn btn-danger disable">ELIMINAR</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <hr>

    <?php if(Auth::user()->rol_id != 4): ?>
        <?php if($contrato[0]->estatus_estadocontrato == 0 ||
                (Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8 &&
                ($contrato[0]->estatus_estadocontrato == 2 ||
                 $contrato[0]->estatus_estadocontrato == 4 ||
                  $contrato[0]->estatus_estadocontrato == 5 ||
                   $contrato[0]->estatus_estadocontrato == 12))): ?>
            <div class="row">
                <div class="col-2">
                    <h2><?php echo app('translator')->get('mensajes.mensajeproductos'); ?></h2>
                </div>

                <div class="col-3">
                    <a type="button" href="" class=" btn btn-outline-success btn-block" data-toggle="modal"
                       data-target="#AbrirPro">NUEVO</a>
                </div>

                <table id="tablaCP" class="table table-bordered">
                    <?php if(sizeof($contratoproducto)>0): ?>
                        <thead>
                        <tr>
                            <th style=" text-align:center;" scope="col">PRODUCTO</th>
                            <th style=" text-align:center;" scope="col">PRECIO</th>
                            <th style=" text-align:center;" scope="col">PIEZAS</th>
                            <th style=" text-align:center;" scope="col">TOTAL</th>
                            <?php if($contrato[0]->estatus_estadocontrato == 0): ?>
                                <th style=" text-align:center;" scope="col">ELIMINAR
                                    PRODUCTO
                                </th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                    <?php endif; ?>
                    <tbody>

                    <?php $__currentLoopData = $contratoproducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td align='center'><?php echo e($CP->nombre); ?></td>
                            <?php if($CP->preciop == null): ?>
                                <td align='center'>$ <?php echo e($CP->precio); ?></td>
                            <?php else: ?>
                                <td align='center'>$ <?php echo e($CP->preciop); ?></td>
                            <?php endif; ?>
                            <td align='center'><?php echo e($CP->piezas); ?></td>
                            <td align='center'>$ <?php echo e($CP->total); ?></td>
                            <?php if($contrato[0]->estatus_estadocontrato == 0): ?>
                                <td align='center'><a
                                        href="<?php echo e(route('eliminarProductoContrato',[$idFranquicia,$CP->id])); ?>"
                                        class="btn btn-danger">ELIMINAR</a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
            <hr>

            <!-- modal para productos -->
            <div class="modal fade" id="AbrirPro" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                 aria-hidden="true">
                <form action="<?php echo e(route('agregarproducto',[$idFranquicia,$idContrato])); ?>" enctype="multipart/form-data"
                      method="POST" onsubmit="btnSubmit.disabled = true;">
                    <?php echo csrf_field(); ?>
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="ExampleAbrir">Productos</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">Elegir un producto:
                                <div class="form-group">
                                    <select name="producto"
                                            class="form-control <?php echo $errors->first('producto','is-invalid'); ?>"
                                            placeholder="producto" value="<?php echo e(old('producto',0)); ?>">
                                        <option selected value='nada'>Seleccionar</option>
                                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($pro->piezas >= 10): ?>
                                                <?php if($pro->preciop == null): ?>
                                                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->nombre); ?> | $ <?php echo e($pro->precio); ?>

                                                        | <?php echo e($pro->piezas); ?>pza.
                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->nombre); ?> | Normal :
                                                        $ <?php echo e($pro->precio); ?> | Con
                                                        descuento: $ <?php echo e($pro->preciop); ?> | <?php echo e($pro->piezas); ?>pza.
                                                    </option>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('producto','<div class="invalid-feedback">Elegir un producto, campo
                                        obligatorio</div>'); ?>

                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label># piezas</label>
                                        <input type="number" name="piezas"
                                               class="form-control <?php echo $errors->first('piezas','is-invalid'); ?>" min="1"
                                               placeholder="Numero de piezas" value="<?php echo e(old('piezas', 1)); ?>">
                                        <?php echo $errors->first('piezas','<div class="invalid-feedback">Elegir una cantidad de
                                            piezas,
                                            campo obligatorio</div>'); ?>

                                    </div>
                                </div>
                                <?php if($contrato[0]->estatus_estadocontrato == 2 ||
                                     $contrato[0]->estatus_estadocontrato == 4 ||
                                      $contrato[0]->estatus_estadocontrato == 5 ||
                                       $contrato[0]->estatus_estadocontrato == 12): ?>
                                    <div class="col-12" style="color: #ea9999">
                                        Esta accion no se podra revertir, al aceptar confirmas que se te entrego la
                                        evidencia de la adquisición del producto.
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                                <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        <?php endif; ?>
    <?php endif; ?>
    <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
        <h2><?php echo app('translator')->get('mensajes.mensajehistorialcontrato'); ?></h2>
        <form id="fragregarhistorialmovimientocontrato"
              action="<?php echo e(route('agregarhistorialmovimientocontrato',[$idFranquicia,$idContrato])); ?>"
              enctype="multipart/form-data"
              method="GET" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-10">
                    <div class="form-group">
                        <input type="text" name="movimiento" class="form-control" placeholder="Movimiento"
                               maxlength="250">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <button class="btn btn-outline-success btn-block" name="btnSubmit" type="submit"
                                style="margin-top: 0px">AGREGAR
                        </button>
                    </div>
                </div>
            </div>
        </form>
        <table id="tablaHistorialC" class="table table-bordered" style="margin-bottom: 5%;">
            <?php if(sizeof($historialcontrato)>0): ?>
                <thead>
                <tr>
                    <th style=" text-align:center;" scope="col">Usuario</th>
                    <th style=" text-align:center;" scope="col">Cambios</th>
                    <th style=" text-align:center;" scope="col">Fecha</th>
                </tr>
                </thead>
            <?php endif; ?>
            <tbody>
            <?php $__currentLoopData = $historialcontrato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align='center'><?php echo e($hc->name); ?></td>
                    <td align='center'><?php echo e($hc->cambios); ?></td>
                    <td align='center'><?php echo e($hc->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <hr>
    <?php endif; ?>
    <?php if(((Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13) && ($contrato[0]->estatus_estadocontrato == 0 && $contrato[0]->idcontratorelacion == null)) ||  //Asistente u opto y estado del contrato en no terminado (Debe ser contrato padre)
        ((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8)
        && ($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 2
                || $contrato[0]->estatus_estadocontrato == 3 || $contrato[0]->estatus_estadocontrato == 4 || $contrato[0]->estatus_estadocontrato == 5
                || $contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 14 || $contrato[0]->estatus_estadocontrato == 15))): ?>

        <?php if((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && $contrato[0]->estatus_estadocontrato == 3): ?>
            <div class="row">
                <?php if($hoyNumero >= 6 || $hoyNumero <= 2): ?>
                    <div class="col-6">
                        <a type="button" class="btn btn-outline-primary btn-block"
                           href="<?php echo e(route('validarContrato',[$idFranquicia,$idContrato])); ?>">VALIDAR CONTRATO</a>
                    </div>
                    <div class="col-6">
                        <a class="btn btn-outline-danger btn-block" data-toggle="modal"
                           data-target="#cancelarContrato">CANCELAR
                            CONTRATO</a>
                    </div>
                <?php else: ?>
                    <div class="col-12">
                        <a type="button" class="btn btn-outline-primary btn-block"
                           href="<?php echo e(route('validarContrato',[$idFranquicia,$idContrato])); ?>">VALIDAR CONTRATO</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <?php if($contrato[0]->estatus_estadocontrato != 14): ?>
                <div class="row" style="margin-bottom: 5%;">
                    <?php if($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 4 || $contrato[0]->estatus_estadocontrato == 12): ?>
                        <?php if($hoyNumero >= 6 || $hoyNumero <= 2): ?>
                            <div class="col-6">
                                <a class="btn btn-outline-secondary btn-block" data-toggle="modal"
                                   data-target="#modalSupervisarContrato">SUPERVISAR
                                    CONTRATO</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-outline-danger btn-block" data-toggle="modal"
                                   data-target="#cancelarContrato">CANCELAR
                                    CONTRATO</a>
                            </div>
                        <?php else: ?>
                            <div class="col-12">
                                <a class="btn btn-outline-secondary btn-block" data-toggle="modal"
                                   data-target="#modalSupervisarContrato">SUPERVISAR
                                    CONTRATO</a>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($contrato[0]->estatus_estadocontrato == 15): ?>
                            <?php if($hoyNumero >= 6 || $hoyNumero <= 2): ?>
                                <div class="col-6">
                                    <a class="btn btn-outline-secondary btn-block" data-toggle="modal"
                                       data-target="#modalRestablecerContrato">RESTABLECER
                                        CONTRATO</a>
                                </div>
                                <div class="col-6">
                                    <a class="btn btn-outline-danger btn-block" data-toggle="modal"
                                       data-target="#cancelarContrato">CANCELAR
                                        CONTRATO</a>
                                </div>
                            <?php else: ?>
                                <div class="col-12">
                                    <a class="btn btn-outline-secondary btn-block" data-toggle="modal"
                                       data-target="#modalRestablecerContrato">RESTABLECER
                                        CONTRATO</a>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($hoyNumero >= 6 || $hoyNumero <= 2): ?>
                                <div class="col-12">
                                    <a class="btn btn-outline-danger btn-block" data-toggle="modal"
                                       data-target="#cancelarContrato">CANCELAR
                                        CONTRATO</a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php if($contrato[0]->pago == 1 || $contrato[0]->pago == 2 || $contrato[0]->pago == 4): ?>
        <!-- modal para Atrazar contratos -->
        <div class="modal fade" id="atrasarContrato" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             aria-hidden="true">
            <form action="<?php echo e(route('atrasarContrato',[$idFranquicia,$idContrato])); ?>"
                  method="POST" onsubmit="btnSubmit.disabled = true;">
                <?php echo csrf_field(); ?>
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            ¿Realmente quieres cambiar el estatus del contrato a atrasado?
                        </div>
                        <div class="modal-body">
                            Nota: Esto ya no se podra deshacer.
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                            <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>
    <!-- modal para Cancelar contratos -->
    <div class="modal fade" id="cancelarContrato" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="<?php echo e(route('cancelarContrato',[$idFranquicia,$idContrato])); ?>" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        Solicitud de confirmación
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-6">
                                ¿Deseas cancelar este contrato?
                            </div>
                            <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
                                <div class="col-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox"
                                               class="custom-control-input"
                                               name="cbLioFuga" id="customCheck1">
                                        <label class="custom-control-label" for="customCheck1">Lio/Fuga</label>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if($contrato[0]->subscripcion != null): ?>
                            <p style="color: red;margin-top: 5px;">Nota: La subscripcion tambien sera cancelada.</p>
                        <?php endif; ?>
                        <br>
                        Especifique sus razones:
                        <textarea name="comentarios"
                                  class="form-control <?php echo $errors->first('comentarios','is-invalid'); ?>" rows="10"
                                  cols="60"></textarea>
                        <?php echo $errors->first('comentarios','<div class="invalid-feedback">campo
                            obligatorio</div>'); ?>

                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- modal para Confirmar contratos -->
    <div class="modal fade" id="Abrirconfirmar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Solicitud de confirmación
                </div>
                <div class="modal-body">
                    ¿Deseas confirmar esta acción?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-success"
                       href="<?php echo e(route('nuevocontrato2',[$idFranquicia,$idContrato])); ?>">Aceptar</a>
                </div>
            </div>
        </div>
    </div>


    <!-- modal para Confirmar contratos hijos -->
    <div class="modal fade" id="Abrirconfirmarhijo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Solicitud de confirmación
                </div>
                <div class="modal-body">
                    ¿Estas seguro que quieres terminar el contrato?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-success"
                       href="<?php echo e(route('contratoHijos',[$idFranquicia,$idContrato])); ?>">Aceptar</a>
                </div>
            </div>
        </div>
    </div>


    <!-- modal para Entregar contratos -->
    <div class="modal fade" id="Abrirentregar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Solicitud de confirmación
                </div>
                <div class="modal-body">
                    Se esta realizando la entrega del producto al cliente.
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-success"
                       href="<?php echo e(route('entregarContrato',[$idFranquicia,$idContrato])); ?>">Aceptar</a>
                </div>
            </div>
        </div>
    </div>

    <!-- modal para Abonos -->
    <div class="modal fade" id="AbrirAbono" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <form action="<?php echo e(route('agregarabono',[$idFranquicia,$idContrato])); ?>" enctype="multipart/form-data"
              method="POST" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ExampleAbrir">Abonos</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label>SALDO:</label>
                                    <input type="text" name="saldo2" class="form-control" readonly
                                           value="$ <?php echo e($contrato[0]->total); ?>">
                                </div>
                            </div>
                            <?php if(Auth::user()->rol_id == 4): ?>
                                <div class="col-12">
                                    <?php else: ?>
                                        <div class="col-12">
                                            <?php endif; ?>
                                            <label>ABONAR:</label>
                                            <input type="number" step=".1" name="abono"
                                                   class="form-control <?php echo $errors->first('abono','is-invalid'); ?>"
                                                   min="0"
                                                   placeholder="Abono" <?php if($contrato[0]->totalproducto != null &&
                                $contrato[0]->estatus_estadocontrato == 0 && $contrato[0]->totalabono <
                                    $contrato[0]->
                                    totalproducto): ?>
                                                   value="<?php echo e($contrato[0]->totalproducto); ?>"
                                                   <?php else: ?> value="<?php echo e(old('abono')); ?>" <?php endif; ?>>
                                            <?php echo $errors->first('abono','<div class="invalid-feedback">El abono es
                                                obligatorio,
                                                debera ser mayor a cero</div>'); ?>

                                        </div>
                                        <div class="col-12">
                                            <label>METODO DE PAGO:</label>
                                            <select class="custom-select" name="metodopago" id="select"
                                                    onchange="metodoSeleccionado(this)">
                                                <option value="0">EFECTIVO</option>
                                                <?php if($contrato[0]->estatus_estadocontrato != 7 && $contrato[0]->estatus_estadocontrato != 10 && $contrato[0]->estatus_estadocontrato != 11 && $contrato[0]->estatus_estadocontrato != 9): ?>
                                                    <option value="1">TARJETA</option>
                                                    <option value="2">TRANSFERENCIA</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <?php if($contrato[0]->estatus_estadocontrato != 7 && $contrato[0]->estatus_estadocontrato != 10 && $contrato[0]->estatus_estadocontrato != 11 && $contrato[0]->estatus_estadocontrato != 9): ?>
                                            <div class="col-12" id="mostrarmeses" style="display:none;">
                                                <label>PAGO A MESES</label>
                                                <select class="custom-select" name="meses" id="meses">
                                                    <option value="0">PAGO UNICO</option>
                                                    <option value="1">3 MESES</option>
                                                    <option value="2">6 MESES</option>
                                                    <option value="3">9 MESES</option>
                                                </select>
                                            </div>
                                        <?php endif; ?>
                                </div>
                                <?php if(Auth::user()->rol_id == 4 && ($contrato[0]->estatus_estadocontrato >= 2 && $contrato[0]->estatus_estadocontrato < 12)): ?>
                                    <?php if($contrato[0]->pago == 1 && $contrato[0]->total > 150 || $contrato[0]->pago == 2 &&
                                    $contrato[0]->total > 300 || $contrato[0]->pago == 4 && $contrato[0]->total > 450): ?>
                                        <label>ABONOS POR ADELANTADO:</label>
                                        <div class="row">
                                            <div class="col-8">
                                                <div class="form-group">
                                                    <input type="number" name="adelanto" min="1" max="3"
                                                           class="form-control <?php echo $errors->first('adelanto'); ?>"
                                                           placeholder="Adelanto" value="<?php echo e(old('adelanto')); ?>">
                                                    <?php echo $errors->first('adelanto','<div class="invalid-feedback">La descripcion es
                                                        obligatoria.</div>'); ?>

                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <div class="form-check">
                                                    <input type="checkbox" name="adelantar" id="adelantar"
                                                           class="form-check-input"
                                                           value="1">
                                                    <label class="form-check-label" for="adelantar">Adelantar
                                                        abono</label>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <br>
                                <?php if($contrato[0]->estatus_estadocontrato == 4): ?>
                                    <?php if($contrato[0]->pago == 1 && $contrato[0]->costoatraso > 0): ?>
                                        <h5 style="color:#ff0000;">El contrato presenta un atraso de
                                            $<?php echo e($contrato[0]->costoatraso); ?><?php if($dentroRango): ?><?php if($abonoperiodo[0]->total < 150): ?>
                                                ,
                                                Abonar la cantidad de
                                                $<?php echo e($contrato[0]->semanaatraso - $abonoperiodo[0]->total); ?> para
                                                recuperar el atraso y el periodo.<?php endif; ?></h5>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($contrato[0]->pago == 1 && $contrato[0]->costoatraso == 0): ?>
                                    <h5 style="color:#ff0000;"><?php if($abonoperiodo[0]->total < 150 && $contrato[0]->
                                        estatus_estadocontrato >= 2): ?>Abonar la cantidad de
                                        $<?php echo e($contrato[0]->semanaatraso - $abonoperiodo[0]->total); ?> para completar
                                        el abono del periodo.<?php endif; ?></h5>
                                <?php endif; ?>
                                <?php if($contrato[0]->pago == 2 && $contrato[0]->costoatraso > 0): ?>
                                    <h5 style="color:#ff0000;">El contrato presenta un atraso de
                                        $<?php echo e($contrato[0]->costoatraso); ?><?php if($dentroRango): ?><?php if($abonoperiodo[0]->total <
                                        300): ?>, Abonar la cantidad de
                                        $<?php echo e($contrato[0]->quincenaatraso - $abonoperiodo[0]->total); ?> para recuperar
                                        el atraso y el periodo.<?php endif; ?></h5>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($contrato[0]->pago == 2 && $contrato[0]->costoatraso == 0): ?>
                                <h5 style="color:#ff0000;"><?php if($abonoperiodo[0]->total < 300 &&
                                                $contrato[0]->estatus_estadocontrato >= 2): ?>,abonar la cantidad de
                                    $<?php echo e($contrato[0]->quincenaatraso - $abonoperiodo[0]->total); ?> para
                                    completar
                                    el abono del periodo.<?php endif; ?></h5>
                            <?php endif; ?>
                            <?php if($contrato[0]->pago == 4 && $contrato[0]->costoatraso > 0): ?>
                                <h5 style="color:#ff0000;">El contrato presenta un atraso de
                                    $<?php echo e($contrato[0]->costoatraso); ?><?php if($dentroRango): ?><?php if($abonoperiodo[0]->total
                                            < 450): ?>, Abonar la cantidad de
                                    $<?php echo e($contrato[0]->mesatraso - $abonoperiodo[0]->total); ?> para
                                    recuperar el atraso y el periodo.<?php endif; ?></h5>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if($contrato[0]->pago == 4 && $contrato[0]->costoatraso == 0): ?>
                                <h5 style="color:#ff0000;"><?php if($abonoperiodo[0]->total < 450 &&
                                                        $contrato[0]->estatus_estadocontrato >= 2): ?>,abonar la
                                    cantidad de
                                    $<?php echo e($contrato[0]->mesatraso - $abonoperiodo[0]->total); ?> para
                                    completar
                                    el abono del periodo.<?php endif; ?></h5>
                            <?php endif; ?>
                            <?php endif; ?>
                            <div class="modal-footer">
                                <button class="btn btn-primary" type="button"
                                        data-dismiss="modal">Cancelar
                                </button>
                                <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- modal para aumentardescontar contratos -->
    <div class="modal fade" id="modalaumentardescontar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Solicitud de confirmación
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            ¿Estas seguro de aumentar/descontar el contrato?
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                    <button class="btn btn-success" name="btnSubmit" type="submit" form="frmaumentardescontar">
                        Aceptar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- modal para supervisar contratos -->
    <div class="modal fade" id="modalSupervisarContrato" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="<?php echo e(route('supervisarcontrato',[$idFranquicia,$idContrato])); ?>"
              method="GET" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        ¿Realmente quieres cambiar el estatus del contrato a supervision?
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- modal para restablecer contratos -->
    <div class="modal fade" id="modalRestablecerContrato" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <form action="<?php echo e(route('restablecercontrato',[$idFranquicia,$idContrato])); ?>"
              method="GET" onsubmit="btnSubmit.disabled = true;">
            <?php echo csrf_field(); ?>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        ¿Realmente quieres restablecer el contrato?
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-success" name="btnSubmit" type="submit">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script>
        var cantmeses = "<?php echo e($abonostarjetameses[0]->cont); ?>";
        var estadocontra = "<?php echo e($contrato[0]->estatus_estadocontrato); ?>";
        var promoactiva = "<?php echo e($contrato[0]->id_promocion); ?>";
        var pago = "<?php echo e($contrato[0]->pago); ?>";
        var idcontratorelacion = "<?php echo e($contrato[0]->idcontratorelacion); ?>";
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/historialclinico/tabla.blade.php ENDPATH**/ ?>