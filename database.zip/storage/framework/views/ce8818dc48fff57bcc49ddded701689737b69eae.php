<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
<?php if(Auth::user()->rol_id==7): ?>
  <div class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sucursales</a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
      <a class="dropdown-item" href="<?php echo e(route('nuevafranquicia')); ?>">Nueva</a>
      <a class="dropdown-item" href="<?php echo e(route('listafranquicia')); ?>">Lista</a>
    </div>
</div>
<?php endif; ?>
<?php if(((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id==6 || Auth::user()->rol_id==8): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Polizas</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
          <a class="dropdown-item" href="<?php echo e(route('listapoliza',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Lista</a>
        </div>
    </div>
<?php endif; ?>
<?php if(((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id==6 || Auth::user()->rol_id == 13 || Auth::user()->rol_id == 12 || Auth::user()->rol_id == 4): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                <a class="dropdown-item" href="<?php echo e(route('listasolicitudautorizacion',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Autorizaciones</a>
            <?php endif; ?>
          <a class="dropdown-item" href="<?php echo e(route('listacontrato',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Lista</a>
          <?php if(Auth::user()->rol_id == 7): ?>
                <a class="dropdown-item" href="<?php echo e(route('migrarcuentas',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Migrar cuentas</a>
          <?php endif; ?>
            <a class="dropdown-item" href="<?php echo e(route('traspasarcontrato',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Traspasar</a>
            <?php if(Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6): ?>
                <a class="dropdown-item" href="<?php echo e(route('reportecontratos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Reporte</a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php if(Auth::user()->rol_id==8): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('listasolicitudautorizacion',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Autorizaciones</a>
            <a class="dropdown-item" href="<?php echo e(route('traspasarcontrato',$idSucursalGlobal)); ?>">Traspasar</a>
            <a class="dropdown-item" href="<?php echo e(route('reportecontratos',$idSucursalGlobal)); ?>">Reporte</a>
        </div>
    </div>
<?php endif; ?>
<?php if(Auth::user()->rol_id==15): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('listasolicitudautorizacion',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Autorizaciones</a>
            <a class="dropdown-item" href="<?php echo e(route('listaconfirmaciones')); ?>">Lista</a>
            <a class="dropdown-item" href="<?php echo e(route('listagarantiasconfirmaciones')); ?>">Garantías</a>
            <a class="dropdown-item" href="<?php echo e(route('traspasarcontrato',$idSucursalGlobal)); ?>">Traspasar</a>
            <a class="dropdown-item" href="<?php echo e(route('reportecontratos',$idSucursalGlobal)); ?>">Reporte</a>
        </div>
    </div>
<?php endif; ?>
<?php if(Auth::user()->rol_id==16): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contratos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('listalaboratorio')); ?>">Lista</a>
        </div>
    </div>
<?php endif; ?>
<?php if(((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id==6  || Auth::user()->rol_id == 8): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Movimientos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('cobranzamovimientos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Cobranza</a>
            <div class="dropdown-item" aria-labelledby="dropdownMenu3">
                <a class="dropdown-item" href="<?php echo e(route('llamadascobranza',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Llamadas</a>
            </div>
            <a class="dropdown-item" href="<?php echo e(route('ventasmovimientos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Ventas</a>
        </div>
    </div>
<?php endif; ?>

<?php if(Auth::user()->rol_id==7 || Auth::user()->rol_id==6  || Auth::user()->rol_id == 8 || Auth::user()->rol_id==15): ?>
    <?php if(Auth::user()->rol_id==15): ?>
        <div class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Reportes</a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <a class="dropdown-item" href="<?php echo e(route('listacontratosreportes')); ?>">Entrar</a>
            </div>
        </div>
    <?php else: ?>
        <div class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Reportes</a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <a class="dropdown-item" href="<?php echo e(route('listareporteasistencia')); ?>" target="_blank">Asistencia</a>
                <a class="dropdown-item" href="<?php echo e(route('listacontratoscancelados')); ?>" target="_blank">Cancelados</a>
                <a class="dropdown-item" href="<?php echo e(route('listacontratoscuentasactivas')); ?>" target="_blank">Cuentas activas</a>
                <a class="dropdown-item" href="<?php echo e(route('cuentasfisicas')); ?>" target="_blank">Cuentas fisicas</a>
                <a class="dropdown-item" href="<?php echo e(route('listacontratosreportes')); ?>" target="_blank">Enviados</a>
                <?php if(Auth::user()->rol_id==6 || Auth::user()->rol_id==7  || Auth::user()->rol_id == 8): ?>
                    <a class="dropdown-item" href="<?php echo e(route('reportellamadas')); ?>" target="_blank">Llamadas</a>
                <?php endif; ?>
                <a class="dropdown-item" href="<?php echo e(route('reportemovimientos')); ?>" target="_blank">Movimientos</a>
                <a class="dropdown-item" href="<?php echo e(route('listacontratospagados')); ?>" target="_blank">Pagados</a>
                <a class="dropdown-item" href="<?php echo e(route('listacontratospaquetes')); ?>" target="_blank">Paquetes</a>
                <?php if(Auth::user()->rol_id==7): ?>
                    <a class="dropdown-item" href="<?php echo e(route('reportegraficas')); ?>" target="_blank">Graficas</a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if(Auth::user()->rol_id==6 || ((Auth::user()->rol_id == 7) && @isset($idFranquicia)) || Auth::user()->rol_id == 8): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Vehículos</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('listavehiculos',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Lista</a>
        </div>
    </div>
<?php endif; ?>

<?php if(Auth::user()->rol_id==8 || Auth::user()->rol_id==6 || ((Auth::user()->rol_id == 7) && @isset($idFranquicia))): ?>
    <hr style="background:white;">
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Administracion</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
          <a class="dropdown-item" href="<?php echo e(route('listasfranquicia',Auth::user()->rol_id == 7 ? $idFranquicia :  $idSucursalGlobal)); ?>">Lista</a>
        </div>
    </div>
<?php endif; ?>

<?php if(Auth::user()->rol_id == 7): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Laboratorio</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('listalaboratorio')); ?>">Principal</a>
            <a class="dropdown-item" href="<?php echo e(route('auxiliarlaboratorio')); ?>">Auxiliar</a>
        </div>
    </div>
<?php endif; ?>

<?php if(Auth::user()->rol_id == 7): ?>
  <div class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Insumos</a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
        <a class="dropdown-item" href="<?php echo e(route('insumos')); ?>">Entrar</a>
      </div>
  </div>
<?php endif; ?>
<?php if(Auth::user()->rol_id == 7): ?>
  <div class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Desarrollo</a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
        <a class="dropdown-item" href="<?php echo e(route('general')); ?>">Entrar</a>
      </div>
  </div>
<?php endif; ?>
<?php if(Auth::user()->rol_id == 6): ?>
    <div class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Usuarios</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <a class="dropdown-item" href="<?php echo e(route('usuariosFranquicia',[$idSucursalGlobal])); ?>">Entrar</a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/sidebar.blade.php ENDPATH**/ ?>