
<?php $__env->startSection('titulo','Lista Franquicias'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parciales.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>







    <h2>Polizas</h2>
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label>Estado</label>
                <input type="text" name="estado" class="form-control" readonly value="<?php echo e($franquiciaPoliza[0]->estado); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Ciudad</label>
                <input type="text" name="ciudad" class="form-control" readonly value="<?php echo e($franquiciaPoliza[0]->ciudad); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Colonia</label>
                <input type="text" name="colonia" class="form-control" readonly
                       value="<?php echo e($franquiciaPoliza[0]->colonia); ?>">
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label>Numero Interior/Exterior</label>
                <input type="text" name="numero" class="form-control" readonly value="<?php echo e($franquiciaPoliza[0]->numero); ?>">
            </div>
        </div>
    </div>

    <table id="tablaFranquicias" class="table table-bordered">
        <?php if(sizeof($polizas)>0): ?>
            <thead>
            <tr>
                <th style=" text-align:center;" scope="col">POLIZA</th>
                <th style=" text-align:center;" scope="col">FRANQUICIA</th>
                <th style=" text-align:center;" scope="col">TERMINO</th>
                <th style=" text-align:center;" scope="col">AUTORIZO</th>
                <th style=" text-align:center;" scope="col">TOTAL</th>
                <th style=" text-align:center;" scope="col">FECHA</th>
                <th style=" text-align:center;" scope="col">VER</th>
            </tr>
            </thead>
        <?php endif; ?>
        <tbody>
        <?php $__currentLoopData = $polizas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align='center'><?php echo e($poliza->ID); ?></td>
                <td align='center'><?php echo e($poliza->FRANQUICIA); ?></td>
                <td align='center'><?php echo e($poliza->REALIZO); ?></td>
                <td align='center'><?php echo e($poliza->AUTORIZO); ?></td>
                <td align='center'><?php echo e($poliza->TOTAL); ?></td>
                <td align='center'><?php echo e($poliza->CREATED_AT); ?></td>
                <td align='center'><a href="<?php echo e(route('verpoliza',[$idFranquicia,$poliza->ID])); ?>">
                        <button style="margin:0px;" type="button" class="btn btn-outline-success"><i
                                class="fas fa-book-open"></i></button>
                    </a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if(Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8): ?>
        <?php if($polizas!=null): ?>
            <div class="d-flex justify-content-center">
                <?php echo e($polizas->links('pagination::bootstrap-4')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\luzatuvida\resources\views/administracion/poliza/tabla.blade.php ENDPATH**/ ?>