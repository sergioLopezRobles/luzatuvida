<?php

return [

    'map_apikey' => env('GOOGLE_APIKEY'),
];
