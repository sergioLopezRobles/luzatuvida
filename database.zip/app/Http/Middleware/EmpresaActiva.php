<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use Illuminate\Support\Facades\DB;

class EmpresaActiva
{

    public function handle(Request $request, Closure $next)
    {
        try{

            $varIdFranquicia = $request->idFranquicia;
            $idUsuario = Auth::user()->id;
            $rolUsuario = Auth::user()->rol_id;
            $existeUsuario = DB::select("SELECT id_franquicia FROM usuariosfranquicia where id_usuario = '$idUsuario'");
            if(!$existeUsuario){
                Auth::logout();
                return redirect()->route('login');
            }else{
                $estadoSucursal =  DB::select("SELECT estado FROM configfranquicia WHERE id_franquicia = '".$existeUsuario[0]->id_franquicia."'");
                if($estadoSucursal != null){
                     if($estadoSucursal[0]->estado != 1){
                        return redirect()->route('estadofranquicia');
                    }else if(!is_null($varIdFranquicia) && ($varIdFranquicia != $existeUsuario[0]->id_franquicia)&& $rolUsuario != 7){
                         return redirect()->route('redireccionar');
                     }
                }else{
                    Auth::logout();
                    return redirect()->route('login');
                }
            }
        }catch(\Exception $e){
             ("Error: ".$e->getMessage());
        }
        return $next($request);
    }
}
