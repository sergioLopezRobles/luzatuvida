<?php

namespace App\Http\Controllers;

use App\Clases\contratosGlobal;
use App\Clases\polizaGlobales;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Input;
use App\Imports\CsvImport;

class reportes extends Controller
{
    public function listacontratosreportes()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 15)) {
            //Rol administrador, director, principal o confirmaciones

            $now = Carbon::now();
            $contratosreportes = null;
            $franquicias = null;
            $idUsuario = Auth::id();
            $idFranquicia = null;

            if(((Auth::user()->rol_id) == 15) || ((Auth::user()->rol_id) == 7)) {
                //Rol confirmaciones o director

                if(((Auth::user()->rol_id) == 15)) {
                    //Rol confirmaciones
                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f INNER JOIN sucursalesconfirmaciones sc ON f.id = sc.id_franquicia
                                                            WHERE sc.id_usuario = '$idUsuario'");
                    $contratosreportes = DB::select("SELECT r.created_at AS FECHAENVIO, UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                        WHERE STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$now','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$now','%Y-%m-%d') AND r.estatuscontrato = '12'
                                                                        AND c.id_franquicia IN (SELECT f.id FROM franquicias f INNER JOIN sucursalesconfirmaciones sc ON f.id = sc.id_franquicia WHERE sc.id_usuario = '$idUsuario')
                                                                        ORDER BY r.created_at DESC;");
                }else {
                    //Rol director
                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");
                    $contratosreportes = DB::select("SELECT r.created_at AS FECHAENVIO, UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                        WHERE STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$now','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$now','%Y-%m-%d') AND r.estatuscontrato = '12'
                                                                        ORDER BY r.created_at DESC;");
                }

            }else {
                //Rol administrador o principal
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);
                $contratosreportes = DB::select("SELECT r.created_at AS FECHAENVIO, UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                        WHERE STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$now','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$now','%Y-%m-%d') AND r.estatuscontrato = '12'
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                        ORDER BY r.created_at DESC;");

            }

            return view('administracion.reportes.tabla', [
                'contratosreportes' => $contratosreportes,
                'franquicias' => $franquicias,
                'idFranquicia' => $idFranquicia
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function filtrarlistacontratosreportes()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 15)) {
            //Rol administrador, director, principal o confirmaciones

            $now = Carbon::now();
            $contratosreportes = null;
            $franquicias = null;
            $idFranquicia = null;
            $idUsuario = Auth::id();
            $fechainibuscar = request('fechainibuscar');
            $fechafinbuscar = request('fechafinbuscar');
            $zonaSeleccionada = request('zonaSeleccionada');
            $franquiciaSeleccionada = request('franquiciaSeleccionada');

            $cadenaFechaIniYFechaFin = " ";
            $cadenaZona = " ";
            $cadenaFranquiciaSeleccionada = " ";

            //Validacion para fechaini y fechafin
            if ($fechainibuscar == null && $fechafinbuscar == null) {
                $cadenaFechaIniYFechaFin = " WHERE STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$now','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$now','%Y-%m-%d') AND r.estatuscontrato = '12'";
            }else {

                if (strlen($fechafinbuscar) > 0 && strlen($fechainibuscar) == 0) {
                    //fechafin diferente de vacio y fechaini vacio
                    return redirect()->route('listacontratosreportes')->with('alerta', 'Debes agregar una fecha inicial');
                }

                if (strlen($fechainibuscar) > 0) {
                    //fechaini diferente de vacio
                    $fechainibuscar = Carbon::parse($fechainibuscar)->format('Y-m-d');
                    if (strlen($fechafinbuscar) > 0) {
                        //fechafin diferente de vacio
                        $fechafinbuscar = Carbon::parse($fechafinbuscar)->format('Y-m-d');
                    } else {
                        //fechafin vacio
                        $fechafinbuscar = Carbon::parse(Carbon::now())->format('Y-m-d');
                    }
                    if ($fechafinbuscar < $fechainibuscar) {
                        //fechafin menor a fechaini
                        return redirect()->route('listacontratosreportes')->with('alerta', 'La fecha inicial debe ser menor o igual a la final.');
                    }

                    $cadenaFechaIniYFechaFin = " WHERE STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$fechainibuscar','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$fechafinbuscar','%Y-%m-%d') AND r.estatuscontrato = '12'";
                }

            }

            if($zonaSeleccionada != null) {
                if($franquiciaSeleccionada != null) {
                    $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = '$franquiciaSeleccionada')";
                }else {
                    $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = c.id_franquicia)";
                }
            }

            if($franquiciaSeleccionada != null) {
                $cadenaFranquiciaSeleccionada = " AND c.id_franquicia = '$franquiciaSeleccionada'";
            }

            if(((Auth::user()->rol_id) == 15) || ((Auth::user()->rol_id) == 7)) {
                //Rol confirmaciones o director

                if(((Auth::user()->rol_id) == 15)) {
                    //Rol confirmaciones
                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f INNER JOIN sucursalesconfirmaciones sc ON f.id = sc.id_franquicia
                                                            WHERE sc.id_usuario = '$idUsuario'");
                    $contratosreportes = DB::select("SELECT r.created_at AS FECHAENVIO, UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                        " . $cadenaFechaIniYFechaFin . "
                                                                        " . $cadenaZona . "
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        AND c.id_franquicia IN (SELECT f.id FROM franquicias f INNER JOIN sucursalesconfirmaciones sc ON f.id = sc.id_franquicia WHERE sc.id_usuario = '$idUsuario')
                                                                        ORDER BY r.created_at DESC;");
                }else {
                    //Rol director
                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");
                    $contratosreportes = DB::select("SELECT r.created_at AS FECHAENVIO, UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                        " . $cadenaFechaIniYFechaFin . "
                                                                        " . $cadenaZona . "
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        ORDER BY r.created_at DESC;");
                }

            }else {
                //Rol administrador  o principal
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);
                $contratosreportes = DB::select("SELECT r.created_at AS FECHAENVIO, UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                        " . $cadenaFechaIniYFechaFin . "
                                                                        " . $cadenaZona . "
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                        ORDER BY r.created_at DESC;");
            }

            return view('administracion.reportes.tabla', [
                'contratosreportes' => $contratosreportes,
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'fechainibuscar' => $fechainibuscar,
                'fechafinbuscar' => $fechafinbuscar,
                'idFranquicia' => $idFranquicia
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private static function obtenerIdFranquiciaUsuario($idUsuario) {
        $usuarioFranquicia = DB::select("SELECT id_franquicia FROM usuariosfranquicia f where id_usuario = '$idUsuario'");
        if($usuarioFranquicia != null) {
            $idFranquicia = $usuarioFranquicia[0]->id_franquicia;
        }
        return $idFranquicia;
    }

    public function listacontratoscuentasactivas()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $arrayCheckBox = array();

            $cbAprobados = 1;
            $cbManofactura = 1;
            $cbProcesoAprobacion = 1;
            $cbEnviados = 1;
            $cbEntregados = 1;
            $cbAtrasados = 1;
            $formaPagoSeleccionada = null;
            $franquiciaSeleccionada = '6E2AA';
            $zonaSeleccionada = '1';

            array_push($arrayCheckBox, $cbAprobados);
            array_push($arrayCheckBox, $cbManofactura);
            array_push($arrayCheckBox, $cbProcesoAprobacion);
            array_push($arrayCheckBox, $cbEnviados);
            array_push($arrayCheckBox, $cbEntregados);
            array_push($arrayCheckBox, $cbAtrasados);
            array_push($arrayCheckBox, $formaPagoSeleccionada);
            array_push($arrayCheckBox, $franquiciaSeleccionada);
            array_push($arrayCheckBox, $zonaSeleccionada);

            $arrayContratos = self::obtenerListaContratosCheckBoxsOFormaPago($arrayCheckBox);

//            $contratosaprobados = $arrayContratos[0];
//            $contratosmanofactura = $arrayContratos[1];
//            $contratosprocesoaprobacion = $arrayContratos[2];
//            $contratosenviados = $arrayContratos[3];
//            $contratosentregados = $arrayContratos[4];
//            $contratosatrasados = $arrayContratos[5];
//            $formaPagoSeleccionada = $arrayContratos[6];
            $idFranquicia = $arrayContratos[7];
            $franquicias = $arrayContratos[8];
//            $numTotalContratos = count($contratosaprobados) + count($contratosmanofactura) + count($contratosprocesoaprobacion) + count($contratosenviados) + count($contratosentregados) + count($contratosatrasados);

            return view('administracion.reportes.tablacuentasactivas', [
//                'contratosaprobados' => $contratosaprobados,
//                'contratosmanofactura' => $contratosmanofactura,
//                'contratosprocesoaprobacion' => $contratosprocesoaprobacion,
//                'contratosenviados' => $contratosenviados,
//                'contratosentregados' => $contratosentregados,
//                'contratosatrasados' => $contratosatrasados,
                'cbAprobados' => $cbAprobados,
                'cbManofactura' => $cbManofactura,
                'cbProcesoAprobacion' => $cbProcesoAprobacion,
                'cbEnviados' => $cbEnviados,
                'cbEntregados' => $cbEntregados,
                'cbAtrasados' => $cbAtrasados,
                'formaPagoSeleccionada' => $formaPagoSeleccionada,
//                'numTotalContratos' => $numTotalContratos,
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'idFranquicia' => $idFranquicia
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function filtrarlistacontratoscuentasactivas()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $arrayCheckBox = array();

            $cbAprobados = request('cbAprobados');
            $cbManofactura = request('cbManofactura');
            $cbProcesoAprobacion = request('cbProcesoAprobacion');
            $cbEnviados = request('cbEnviados');
            $cbEntregados = request('cbEntregados');
            $cbAtrasados = request('cbAtrasados');
            $formaPagoSeleccionada = request('formaPagoSeleccionada');
            $franquiciaSeleccionada = request('franquiciaSeleccionada');
            $zonaSeleccionada = request('zonaSeleccionada');

            array_push($arrayCheckBox, $cbAprobados);
            array_push($arrayCheckBox, $cbManofactura);
            array_push($arrayCheckBox, $cbProcesoAprobacion);
            array_push($arrayCheckBox, $cbEnviados);
            array_push($arrayCheckBox, $cbEntregados);
            array_push($arrayCheckBox, $cbAtrasados);
            array_push($arrayCheckBox, $formaPagoSeleccionada);
            array_push($arrayCheckBox, $franquiciaSeleccionada);
            array_push($arrayCheckBox, $zonaSeleccionada);

            $arrayContratos = self::obtenerListaContratosCheckBoxsOFormaPago($arrayCheckBox);

            $contratosaprobados = $arrayContratos[0];
            $contratosmanofactura = $arrayContratos[1];
            $contratosprocesoaprobacion = $arrayContratos[2];
            $contratosenviados = $arrayContratos[3];
            $contratosentregados = $arrayContratos[4];
            $contratosatrasados = $arrayContratos[5];
            $formaPagoSeleccionada = $arrayContratos[6];
            $idFranquicia = $arrayContratos[7];
            $franquicias = $arrayContratos[8];
            $numTotalContratos = count($contratosaprobados) + count($contratosmanofactura) + count($contratosprocesoaprobacion) + count($contratosenviados) + count($contratosentregados) + count($contratosatrasados);

            return view('administracion.reportes.tablacuentasactivas', [
                'contratosaprobados' => $contratosaprobados,
                'contratosmanofactura' => $contratosmanofactura,
                'contratosprocesoaprobacion' => $contratosprocesoaprobacion,
                'contratosenviados' => $contratosenviados,
                'contratosentregados' => $contratosentregados,
                'contratosatrasados' => $contratosatrasados,
                'cbAprobados' => $cbAprobados,
                'cbManofactura' => $cbManofactura,
                'cbProcesoAprobacion' => $cbProcesoAprobacion,
                'cbEnviados' => $cbEnviados,
                'cbEntregados' => $cbEntregados,
                'cbAtrasados' => $cbAtrasados,
                'formaPagoSeleccionada' => $formaPagoSeleccionada,
                'numTotalContratos' => $numTotalContratos,
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'idFranquicia' => $idFranquicia
            ]);


        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private static function obtenerListaContratosCheckBoxsOFormaPago($arrayCheckBox)
    {

        $arrayContratos = array();
        $idUsuario = Auth::id();
        $idFranquicia = null;

        $contratosaprobados = array();
        $contratosmanofactura = array();
        $contratosprocesoaprobacion = array();
        $contratosenviados = array();
        $contratosentregados = array();
        $contratosatrasados = array();

        $cbAprobados = $arrayCheckBox[0];
        $cbManofactura = $arrayCheckBox[1];
        $cbProcesoAprobacion = $arrayCheckBox[2];
        $cbEnviados = $arrayCheckBox[3];
        $cbEntregados = $arrayCheckBox[4];
        $cbAtrasados = $arrayCheckBox[5];
        $formaPagoSeleccionada = $arrayCheckBox[6];
        $franquiciaSeleccionada = null;
        if(((Auth::user()->rol_id) == 7)) {
            //Director
            $franquiciaSeleccionada = $arrayCheckBox[7];
        }
        $zonaSeleccionada = $arrayCheckBox[8];

        $cadenaFormaPago = " ";
        if($formaPagoSeleccionada != null) {
            $cadenaFormaPago = " AND c.pago = '$formaPagoSeleccionada'";
        }

        $cadenaFranquiciaSeleccionada = " ";
        if($franquiciaSeleccionada != null) {
            $cadenaFranquiciaSeleccionada = " AND c.id_franquicia = '$franquiciaSeleccionada'";
        }

        $cadenaZona = " ";
        if($zonaSeleccionada != null) {
            if($franquiciaSeleccionada != null) {
                $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = '$franquiciaSeleccionada')";
            }else {
                $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = c.id_franquicia)";
            }
        }

        $contratosTodos = null;
        $franquicias = null;
        if(((Auth::user()->rol_id) == 7)) {
            //Director
            $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");
            $contratosTodos = DB::select("SELECT UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA, c.estatus_estadocontrato as ESTATUS_ESTADOCONTRATO, c.coordenadas as COORDENADAS,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (7,9,10,11,12,2,4)
                                                                        " . $cadenaFormaPago . "
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        " . $cadenaZona . "
                                                                        ORDER BY c.created_at DESC");

            $cuentasLocalidad = DB::select("SELECT count(c.id) AS TOTALCUENTAS, UPPER(c.localidad) AS LOCALIDAD
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (7,9,10,11,12,2,4)
                                                                        " . $cadenaFormaPago . "
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        " . $cadenaZona . "
                                                                         GROUP BY c.localidad
                                                                         ORDER BY LOCALIDAD ASC;");

            $cuentasColonia = DB::select("SELECT count(c.id) AS TOTALCUENTAS, UPPER(c.colonia) AS COLONIA
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (7,9,10,11,12,2,4)
                                                                        " . $cadenaFormaPago . "
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        " . $cadenaZona . "
                                                                         GROUP BY c.colonia
                                                                         ORDER BY COLONIA ASC;");
        }else {
            //Principal o administrador
            $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);
            $contratosTodos = DB::select("SELECT UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA, c.estatus_estadocontrato as ESTATUS_ESTADOCONTRATO, c.coordenadas as COORDENADAS,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (7,9,10,11,12,2,4)
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                        " . $cadenaFormaPago . "
                                                                        " . $cadenaZona . "
                                                                        ORDER BY c.created_at DESC;");

            $cuentasLocalidad = DB::select("SELECT count(c.id) AS TOTALCUENTAS, UPPER(c.localidad) AS LOCALIDAD
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (7,9,10,11,12,2,4)
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                         " . $cadenaFormaPago . "
                                                                         " . $cadenaZona . "
                                                                         GROUP BY c.localidad
                                                                         ORDER BY LOCALIDAD ASC;");

            $cuentasColonia = DB::select("SELECT count(c.id) AS TOTALCUENTAS, UPPER(c.colonia) AS COLONIA
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (7,9,10,11,12,2,4)
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                         " . $cadenaFormaPago . "
                                                                         " . $cadenaZona . "
                                                                         GROUP BY c.colonia
                                                                         ORDER BY COLONIA ASC;");
        }

        foreach ($contratosTodos as $contrato) {

            //Contratos aprobados
            if ($cbAprobados != null) {
                if ($contrato->ESTATUS_ESTADOCONTRATO == 7) {
                    array_push($contratosaprobados, $contrato);
                }
            }

            //Contratos manofactura y en proceso de envio
            if ($cbManofactura != null) {
                if (($contrato->ESTATUS_ESTADOCONTRATO == 10) || ($contrato->ESTATUS_ESTADOCONTRATO == 11)) {
                    array_push($contratosmanofactura, $contrato);
                }
            }

            //Contratos en proceso de aprobacion
            if ($cbProcesoAprobacion != null) {
                if ($contrato->ESTATUS_ESTADOCONTRATO == 9) {
                    array_push($contratosprocesoaprobacion, $contrato);
                }
            }

            //Contratos enviados
            if ($cbEnviados != null) {
                if ($contrato->ESTATUS_ESTADOCONTRATO == 12) {
                    array_push($contratosenviados, $contrato);
                }
            }

            //Contratos entregados
            if ($cbEntregados != null) {
                if ($contrato->ESTATUS_ESTADOCONTRATO == 2) {
                    array_push($contratosentregados, $contrato);
                }
            }

            //Contratos atrasados
            if ($cbAtrasados != null) {
                if ($contrato->ESTATUS_ESTADOCONTRATO == 4) {
                    array_push($contratosatrasados, $contrato);
                }
            }
        }

        array_push($arrayContratos, $contratosaprobados);
        array_push($arrayContratos, $contratosmanofactura);
        array_push($arrayContratos, $contratosprocesoaprobacion);
        array_push($arrayContratos, $contratosenviados);
        array_push($arrayContratos, $contratosentregados);
        array_push($arrayContratos, $contratosatrasados);
        array_push($arrayContratos, $formaPagoSeleccionada);
        array_push($arrayContratos, $idFranquicia);
        array_push($arrayContratos, $franquicias);
        array_push($arrayContratos, $cuentasLocalidad);
        array_push($arrayContratos, $cuentasColonia);

        return $arrayContratos;

    }

    public function listacontratospaquetes(){

        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

//            $sucursal = "";
            if((Auth::user()->rol_id) == 7){ //Es director
                $optometristas = DB::select("SELECT u.id,u.name as nombre FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE rol_id = '12' ORDER BY name");
            }else{
                //No es el director
                $idUsuario = Auth::user()->id;
                $sucursal = DB::select("SELECT id_franquicia FROM usuariosfranquicia WHERE id_usuario = '$idUsuario'");
                $sucursal = $sucursal[0]->id_franquicia;
                $consulta = "SELECT u.id,u.name as nombre FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE u.rol_id = '12' AND uf.id_franquicia = '$sucursal' ORDER BY name";
                $optometristas = DB::select($consulta);
//                $sucursal = " AND uf.id_franquicia = '$sucursal'";
            }

            $idOptoSeleccionado = request('idOpto');
//            $idOpto = "";
//            if($idOptoSeleccionado != null){
//                $idOpto = " WHERE c.id_optometrista = '$idOptoSeleccionado'";
//            }

//            $fechaIniSeleccionada = request('fechaIni');
//            $fechaFinSeleccionada = request('fechaFin');
//
//            if($fechaIniSeleccionada != null && $fechaFinSeleccionada != null ){
//                if(strlen($idOpto)>0){ //Seleccionaron algun Opto?
//                    //Si lo seleccionaron
//                    $fecha = " AND DATE(c.created_at) BETWEEN '$fechaIniSeleccionada' AND '$fechaFinSeleccionada' ";
//                }else{
//                    //No seleccionaron un opto
//                    $fecha = " WHERE DATE(c.created_at) BETWEEN '$fechaIniSeleccionada' AND '$fechaFinSeleccionada' ";
//                }
//            }else{
//                $hoy = Carbon::now()->format('Y-m-d');
//                if(strlen($idOpto)>0){ //Seleccionaron algun Opto?
//                    //Si lo seleccionaron
//                    $fecha = " AND DATE(c.created_at) BETWEEN '$hoy' AND '$hoy' ";
//                }else{
//                    //No seleccionaron un opto
//                    $fecha = " WHERE DATE(c.created_at) BETWEEN '$hoy' AND '$hoy' ";
//                }
//            }
//
//            $consulta = "SELECT (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as NOMBRE,
//                                            c.id as CONTRATO,
//                                            c.created_at as FECHACREACION,
//                                            (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
//                                            (SELECT p.nombre FROM historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC LIMIT 1) as PAQUETE,
//                                            (SELECT hc.fotocromatico FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as foto,
//                                            (SELECT hc.ar FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as ar,
//                                            (SELECT hc.tinte FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as tinte,
//                                            (SELECT hc.blueray FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as blueray,
//                                            (SELECT hc.otroT FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as otroT,
//                                            (SELECT hc.tratamientootro FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as tratamientootro,
//                                            c.totalreal as TOTAL
//                                            FROM contratos c
//                                            INNER JOIN usuariosfranquicia uf
//                                            ON uf.id_usuario = c.id_optometrista
//                                            ".$idOpto.$fecha.$sucursal."
//                                             ORDER BY c.created_at DESC";
//
//            $contratos = DB::select($consulta);

            return view('administracion.reportes.paquetes', [
//                'contratos' => $contratos,
                'idOpto' => $idOptoSeleccionado,
                'optometristas' => $optometristas,
//                'fechaIni' => $fechaIniSeleccionada,
//                'fechaFin' => $fechaFinSeleccionada
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function validarCuentasLocalPagina(){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            if((Auth::user()->rol_id) == 7){ //Es un director?
                //Si, es un director
                $zonas = DB::select("SELECT z.id,z.zona,(SELECT f.ciudad FROM franquicias f WHERE f.id = z.id_franquicia) as ciudad FROM zonas z ORDER BY z.id");
            }else{
                //Es un administrador o principal.
                $idUsuario = Auth::user()->id;
                $sucursal = DB::select("SELECT id_franquicia FROM usuariosfranquicia WHERE id_usuario = '$idUsuario'");
                $sucursal = $sucursal[0]->id_franquicia;
                $zonas = DB::select("SELECT z.id,z.zona FROM zonas z WHERE z.id_franquicia = '$sucursal' ORDER BY z.zona");
            }

            return view('administracion.reportes.cuentasfisicas', [
                "zonas" => $zonas,
                "contratosPagina" => null,
                "contratosArchivo" => null,
                "contratosArchivoNoEncontrato" => null

            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function validarCuentasLocalPaginaArchivo(Request $request){

        $archivoExcel =$request->file('archivo');
        if($archivoExcel != null){
            if(request()->hasFile('archivo')){

                $idZona = request('zona');
                if($idZona != null){// Tenemos una zona?
                    //Si, tenemos una zona
                    if((Auth::user()->rol_id) == 7){ //El usuario, es un director?
                        //Si, es un director
                        $existeZona = DB::select("SELECT id FROM zonas WHERE id = '$idZona'");
                        $zonas = DB::select("SELECT z.id,z.zona,(SELECT f.ciudad FROM franquicias f WHERE f.id = z.id_franquicia) as ciudad FROM zonas z ORDER BY z.id");
                    }else{
                        //Es un administrador o principal.
                        $idUsuario = Auth::user()->id;
                        $existeZona = DB::select("SELECT z.id FROM zonas z INNER JOIN usuariosfranquicia uf ON uf.id_franquicia = z.id_franquicia WHERE z.id = '$idZona' AND uf.id_usuario = '$idUsuario'");
                        $sucursal = DB::select("SELECT id_franquicia FROM usuariosfranquicia WHERE id_usuario = '$idUsuario'");
                        $sucursal = $sucursal[0]->id_franquicia;
                        $zonas = DB::select("SELECT z.id,z.zona FROM zonas z WHERE z.id_franquicia = '$sucursal' ORDER BY z.zona");
                    }
                }else{
                    //No, no tenemos una zona
                    return back()->with("alerta","Por favor, selecciona una zona valida.");
                }


                if($existeZona != null){ //Existe la zona seleccionada?
                    //Si existe la zona.
                    $extension = $archivoExcel->getClientOriginalExtension();
                    if ($extension == "xlsx" || $extension == "xls") { //Es un archivo de excel?
                        try {

                            $filas = Excel::toArray(new CsvImport(), $archivoExcel);

                            $listaContratos = array();
                            $i = 0;
                            foreach ($filas[0] as $key => $contrato) {
                                $listaContratos[] =  $contrato[0];
                            }

                            $contratosExistentesPagina = DB::select("SELECT id FROM contratos WHERE id_zona = '$idZona' AND (estatus_estadocontrato = 2 OR estatus_estadocontrato = 4 OR estatus_estadocontrato = 12) ");
                            $listaContratosPagina = array();
                            foreach ($contratosExistentesPagina as $contratoExistente){
                                $listaContratosPagina[] = $contratoExistente -> id;
                            }

                            $diferenciaContratosPagina = array_diff($listaContratosPagina,$listaContratos); //Contratos que existen en la pagina/zona pero en el archivo no.
                            $diferenciaContratosArchivo = array_diff($listaContratos,$listaContratosPagina); //Contratos que existen en el archivo pero en la pagina y zona no.

                            $contratosPagina = array();
                            foreach ($diferenciaContratosPagina as $difContratoPagina){
                                \Log::info($difContratoPagina);
                                $diferenciaContratosPaginaBD = DB::select("SELECT (SELECT ec.descripcion FROM estadocontrato ec WHERE c.estatus_estadocontrato = ec.estatus) as ESTATUS,
                                                                (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) as ZONA,
                                                                (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) as SUCURSAL
                                                                                    FROM contratos c WHERE c.id = '$difContratoPagina'");
                                $contratosPagina["id"][] = $difContratoPagina;
                                $contratosPagina["estatus"][] =  $diferenciaContratosPaginaBD[0]->ESTATUS;
                                $contratosPagina["zona"][] = $diferenciaContratosPaginaBD[0]->ZONA;
                                $contratosPagina["sucursal"][] =  $diferenciaContratosPaginaBD[0]->SUCURSAL;
                            }

                            $contratosArchivo = array();

                            foreach ($diferenciaContratosArchivo as $difContratoArchivo){
                                \Log::info($difContratoArchivo);
                                if($difContratoArchivo != null){
                                    $diferenciaContratosPaginaBD = DB::select("SELECT (SELECT ec.descripcion FROM estadocontrato ec WHERE c.estatus_estadocontrato = ec.estatus) as ESTATUS,
                                                                    (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) as ZONA,
                                                                    (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) as SUCURSAL
                                                                                    FROM contratos c WHERE c.id = '$difContratoArchivo'");

                                    $contratosArchivo["id"][] = $difContratoArchivo;
                                    if($diferenciaContratosPaginaBD != null){
                                        $contratosArchivo["estatus"][] =  $diferenciaContratosPaginaBD[0]->ESTATUS;
                                        $contratosArchivo["zona"][] = $diferenciaContratosPaginaBD[0]->ZONA;
                                        $contratosArchivo["sucursal"][] = $diferenciaContratosPaginaBD[0]->SUCURSAL;
                                    }else{
                                        $contratosArchivo["estatus"][] = "SIN ESTATUS";
                                        $contratosArchivo["zona"][] = "SIN ZONA";
                                        $contratosArchivo["sucursal"][] ="SIN SUCURSAL";
                                    }
                                }
                            }

                            return view('administracion.reportes.cuentasfisicas', [
                                "zonas" => $zonas,
                                "contratosPagina" => $contratosPagina,
                                "contratosArchivo" => $contratosArchivo

                            ]);

                        } catch (\Exception $e) {
                            \Log::info("ERROR: ".$e);
                            return back()->with("error","Tuvimos un problema, por favor contacta al administrador de la pagina.");
                        }

                    }
                    return back()->with("alerta","Por favor, selecciona un archivo valido.");
                }
                //No existe la zona o no es valida.

                return back()->with("alerta","La zona no es valida.");
            }
        }
        return back()->with("alerta","Por favor, selecciona un archivo.");
    }

    public function paquetestiemporeal(Request $request){

        $idOptoSeleccionado = $request->input('idOpto');
        $fechaIniSeleccionada = $request->input('fechaIni');
        $fechaFinSeleccionada = $request->input('fechaFin');
        $ordenarPaquetes = $request->input('ordenarPaquetes');

        $idUsuario = Auth::user()->id;
        $sucursal = DB::select("SELECT id_franquicia FROM usuariosfranquicia WHERE id_usuario = '$idUsuario'");
        $sucursal = $sucursal[0]->id_franquicia;

        $hoy = Carbon::now()->format('Y-m-d');

        if(strlen($fechaIniSeleccionada) == 0){
            //Si fecha inicial es vacia -> colocar fecha del dia de hoy
            $fechaIniSeleccionada = $hoy;

        } if(strlen($fechaFinSeleccionada) == 0){
            $fechaFinSeleccionada = $hoy;
        }

        $idOpto = "";
        if(strlen($idOptoSeleccionado) > 0){
            $idOpto = " WHERE c.id_optometrista = '$idOptoSeleccionado'";
        }

        if(strlen($idOpto)>0){ //Seleccionaron algun Opto?
            //Si lo seleccionaron
            $fecha = " AND DATE(c.created_at) BETWEEN '$fechaIniSeleccionada' AND '$fechaFinSeleccionada' ";
        }else{
            //No seleccionaron un opto
            $fecha = " WHERE DATE(c.created_at) BETWEEN '$fechaIniSeleccionada' AND '$fechaFinSeleccionada' ";
        }

        if($ordenarPaquetes == 'true'){
            $consulta = "SELECT (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as NOMBRE,
                                            (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) as SUCURSAL,
                                            c.id as CONTRATO,
                                            c.created_at as FECHACREACION,
                                            (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                            (SELECT p.nombre FROM historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id ORDER BY c.created_at ASC LIMIT 1) as PAQUETE,
                                            (SELECT p.id FROM historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id ORDER BY c.created_at ASC LIMIT 1) as ID_PAQUETE,
                                            (SELECT hc.fotocromatico FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as foto,
                                            (SELECT hc.ar FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as ar,
                                            (SELECT hc.tinte FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as tinte,
                                            (SELECT hc.blueray FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as blueray,
                                            (SELECT hc.otroT FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as otroT,
                                            (SELECT hc.tratamientootro FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as tratamientootro,
                                            c.totalreal as TOTAL,
                                            c.estatus_estadocontrato as ESTADOCONTRATO
                                            FROM contratos c
                                            INNER JOIN usuariosfranquicia uf
                                            ON uf.id_usuario = c.id_optometrista
                                            ".$idOpto.$fecha."
                                             ORDER BY sucursal,ID_PAQUETE ASC";
        } else {
            $consulta = "SELECT (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as NOMBRE,
                                            (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) as SUCURSAL,
                                            c.id as CONTRATO,
                                            c.created_at as FECHACREACION,
                                            (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                            (SELECT p.nombre FROM historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC LIMIT 1) as PAQUETE,
                                            (SELECT hc.fotocromatico FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as foto,
                                            (SELECT hc.ar FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as ar,
                                            (SELECT hc.tinte FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as tinte,
                                            (SELECT hc.blueray FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as blueray,
                                            (SELECT hc.otroT FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as otroT,
                                            (SELECT hc.tratamientootro FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as tratamientootro,
                                            c.totalreal as TOTAL,
                                            c.estatus_estadocontrato as ESTADOCONTRATO
                                            FROM contratos c
                                            INNER JOIN usuariosfranquicia uf
                                            ON uf.id_usuario = c.id_optometrista
                                            ".$idOpto.$fecha."
                                             ORDER BY sucursal,c.created_at DESC";
        }


        $contratos = DB::select($consulta);
        $response = ['data' => $contratos, 'fechaIniSeleccionada'=>$fechaIniSeleccionada, 'fechaFinSeleccionada'=>$fechaFinSeleccionada];

        return response()->json($response);
    }

    public function cuentasactivastiemporeal(Request $request)
    {

        $arrayCheckBox = array();

        $cbAprobados = $request->input('cbAprobados');
        $cbManofactura = $request->input('cbManofactura');
        $cbProcesoAprobacion = $request->input('cbProcesoAprobacion');
        $cbEnviados = $request->input('cbEnviados');
        $cbEntregados = $request->input('cbEntregados');
        $cbAtrasados = $request->input('cbAtrasados');
        $formaPagoSeleccionada = $request->input('formaPagoSeleccionada');
        $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');
        $zonaSeleccionada = $request->input('zonaSeleccionada');

        array_push($arrayCheckBox, $cbAprobados);
        array_push($arrayCheckBox, $cbManofactura);
        array_push($arrayCheckBox, $cbProcesoAprobacion);
        array_push($arrayCheckBox, $cbEnviados);
        array_push($arrayCheckBox, $cbEntregados);
        array_push($arrayCheckBox, $cbAtrasados);
        array_push($arrayCheckBox, $formaPagoSeleccionada);
        array_push($arrayCheckBox, $franquiciaSeleccionada);
        array_push($arrayCheckBox, $zonaSeleccionada);

        $arrayContratos = self::obtenerListaContratosCheckBoxsOFormaPago($arrayCheckBox);

        $contratosaprobados = $arrayContratos[0];
        $contratosmanofactura = $arrayContratos[1];
        $contratosprocesoaprobacion = $arrayContratos[2];
        $contratosenviados = $arrayContratos[3];
        $contratosentregados = $arrayContratos[4];
        $contratosatrasados = $arrayContratos[5];
        $formaPagoSeleccionada = $arrayContratos[6];
        $idFranquicia = $arrayContratos[7];
        $franquicias = $arrayContratos[8];
        $cuentasLocalidad = $arrayContratos[9];
        $cuentasColonia = $arrayContratos[10];
        $numTotalContratos = count($contratosaprobados) + count($contratosmanofactura) + count($contratosprocesoaprobacion) + count($contratosenviados) + count($contratosentregados) + count($contratosatrasados);

        $view = view('administracion.reportes.listas.listacuentasactivas', [
            'contratosaprobados' => $contratosaprobados,
            'contratosmanofactura' => $contratosmanofactura,
            'contratosprocesoaprobacion' => $contratosprocesoaprobacion,
            'contratosenviados' => $contratosenviados,
            'contratosentregados' => $contratosentregados,
            'contratosatrasados' => $contratosatrasados,
            'cbAprobados' => $cbAprobados,
            'cbManofactura' => $cbManofactura,
            'cbProcesoAprobacion' => $cbProcesoAprobacion,
            'cbEnviados' => $cbEnviados,
            'cbEntregados' => $cbEntregados,
            'cbAtrasados' => $cbAtrasados,
            'formaPagoSeleccionada' => $formaPagoSeleccionada,
            'numTotalContratos' => $numTotalContratos,
            'franquicias' => $franquicias,
            'franquiciaSeleccionada' => $franquiciaSeleccionada,
            'zonaSeleccionada' => $zonaSeleccionada,
            'idFranquicia' => $idFranquicia,
            'cuentasLocalidad' => $cuentasLocalidad,
            'cuentasColonia' => $cuentasColonia
        ])->render();

        return \Response::json(array("valid"=>"true","view"=>$view));
    }

    public function listacontratoscancelados(){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $idUsuario = Auth::id();
            $idFranquicia = null;
            $franquiciaSeleccionada = '6E2AA';
            $zonaSeleccionada = 1;
            $hoy = Carbon::now()->format('Y-m-d');
            $fechaInicial = $fechaFinal = $hoy;

            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $franquiciaSeleccionada = '6E2AA';
            }

            $franquicias = null;
            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

            }else {
                //Principal o administrador
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);

            }

            return view('administracion.reportes.tablacancelados', [
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'idFranquicia' => $idFranquicia,
                'fechaInicial' => $fechaInicial,
                'fechaFinal' => $fechaFinal

            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function listacontratospagados(){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $idUsuario = Auth::id();
            $idFranquicia = null;
            $franquiciaSeleccionada = '6E2AA';
            $zonaSeleccionada = 1;
            $hoy = Carbon::now()->format('Y-m-d');
            $fechaInicial = $fechaFinal = $hoy;

            if(((Auth::user()->rol_id) == 7)) {
                //Director
                    $franquiciaSeleccionada = '6E2AA';
            }

            $franquicias = null;
            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

            }else {
                //Principal o administrador
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);

            }

            return view('administracion.reportes.tablapagados', [
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'idFranquicia' => $idFranquicia,
                'fechaInicial' => $fechaInicial,
                'fechaFinal' => $fechaFinal

            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function contratosPagadosTiempoReal(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $idUsuario = Auth::id();
            $idFranquicia = null;

            $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');;
            $zonaSeleccionada = $request->input('zonaSeleccionada');
            $fechaInicial = $request->input('fechaInicial');
            $fechaFinal = $request->input('fechaFinal');

            $hoy = Carbon::now()->format('Y-m-d');
            if(strlen($fechaInicial) == 0){
                $fechaInicial = $hoy;

            } if(strlen($fechaFinal) == 0){
                $fechaFinal = $hoy;
            }

            $cadenaFranquiciaSeleccionada = " ";
            if($franquiciaSeleccionada != null) {
                $cadenaFranquiciaSeleccionada = " AND c.id_franquicia = '$franquiciaSeleccionada'";
            }

            $cadenaZona = " ";
            if($zonaSeleccionada != null) {
                if($franquiciaSeleccionada != null) {
                    $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = '$franquiciaSeleccionada')";
                }else {
                    $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = c.id_franquicia)";
                }
            }

            $cadenaFechaPago = "AND DATE(c.ultimoabono) BETWEEN '$fechaInicial' AND '$fechaFinal'";
            $franquicias = null;
            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

                $contratosPagados = DB::select("SELECT UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA, c.estatus_estadocontrato as ESTATUS_ESTADOCONTRATO, c.coordenadas as COORDENADAS,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (5)
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        " . $cadenaZona . "
                                                                        " . $cadenaFechaPago . "
                                                                        ORDER BY ULTIMOABONO DESC;");
            }else {
                //Principal o administrador
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);
                $contratosPagados = DB::select("SELECT UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA, c.estatus_estadocontrato as ESTATUS_ESTADOCONTRATO, c.coordenadas as COORDENADAS,
                                                                        COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ULTIMOABONO
                                                                        FROM contratos c
                                                                        WHERE c.estatus_estadocontrato IN (5)
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                        " . $cadenaZona . "
                                                                        " . $cadenaFechaPago . "
                                                                        ORDER BY ULTIMOABONO DESC;");
            }

            $numTotalContratos = count($contratosPagados);
            $view = view('administracion.reportes.listas.listacontratospagados', [
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'idFranquicia' => $idFranquicia,
                'contratosPagados' => $contratosPagados,
                'numTotalContratos' => $numTotalContratos
            ])->render();

            return \Response::json(array("valid"=>"true","view"=>$view, 'fechaInicial' => $fechaInicial, 'fechaFinal' => $fechaFinal));

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratosCanceladosTiempoReal(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $idUsuario = Auth::id();
            $idFranquicia = null;

            $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');;
            $zonaSeleccionada = $request->input('zonaSeleccionada');
            $fechaInicial = $request->input('fechaInicial');
            $fechaFinal = $request->input('fechaFinal');

            $hoy = Carbon::now()->format('Y-m-d');
            if(strlen($fechaInicial) == 0){
                $fechaInicial = $hoy;

            } if(strlen($fechaFinal) == 0){
                $fechaFinal = $hoy;
            }

            $cadenaFranquiciaSeleccionada = " ";
            if($franquiciaSeleccionada != null) {
                $cadenaFranquiciaSeleccionada = " AND c.id_franquicia = '$franquiciaSeleccionada'";
            }

            $cadenaZona = " ";
            if($zonaSeleccionada != null) {
                if($franquiciaSeleccionada != null) {
                    $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = '$franquiciaSeleccionada')";
                }else {
                    $cadenaZona = " AND c.id_zona = (SELECT z.id FROM zonas z WHERE z.zona = '$zonaSeleccionada' AND z.id_franquicia = c.id_franquicia)";
                }
            }

            $cadenaFechaCancelado = "DATE(hcontrato.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'";
            $franquicias = null;
            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

                $contratosCancelados = DB::select("SELECT UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.ultimoabono as ULTIMOABONO, c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
																	    c.estatus_estadocontrato as ESTATUS_ESTADOCONTRATO, c.coordenadas as COORDENADAS, hcontrato.created_at as FECHACANCELACION
                                                                        FROM contratos c, historialcontrato hcontrato
                                                                        WHERE c.estatus_estadocontrato IN (6,8,14)
                                                                        AND (hcontrato.id_contrato = c.id AND (hcontrato.cambios like'%CANCELADO%' OR hcontrato.tipomensaje = 1) AND (" . $cadenaFechaCancelado . "))
                                                                        " . $cadenaFranquiciaSeleccionada . "
                                                                        " . $cadenaZona . "
                                                                        ORDER BY hcontrato.created_at DESC;");
            }else {
                //Principal o administrador
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);

                $contratosCancelados = DB::select("SELECT UPPER(c.id) AS CONTRATO, (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as ESTATUS,
                                                                        UPPER(c.localidad) AS LOCALIDAD, UPPER(c.entrecalles) AS ENTRECALLES, UPPER(c.colonia) AS COLONIA, UPPER(c.calle) AS CALLE, UPPER(c.numero) AS NUMERO,
                                                                        UPPER(c.nombre) AS NOMBRE,UPPER(c.telefono) AS TELEFONO, (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) AS ZONA, c.created_at AS FECHAVENTA,c.total as TOTAL,
                                                                        c.ultimoabono as ULTIMOABONO, c.pago as FORMAPAGO, (SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as FECHAENTREGA,
																	    c.estatus_estadocontrato as ESTATUS_ESTADOCONTRATO, c.coordenadas as COORDENADAS, hcontrato.created_at as FECHACANCELACION
                                                                        FROM contratos c, historialcontrato hcontrato
                                                                        WHERE c.estatus_estadocontrato IN (6,8,14)
                                                                        AND (hcontrato.id_contrato = c.id AND (hcontrato.cambios like'%CANCELADO%' OR hcontrato.tipomensaje = 1) AND (" . $cadenaFechaCancelado . "))
                                                                        AND c.id_franquicia = '$idFranquicia'
                                                                        " . $cadenaZona . "
                                                                        ORDER BY hcontrato.created_at DESC;");
            }

            $numTotalContratos = count($contratosCancelados);
            $view = view('administracion.reportes.listas.listacontratoscancelados', [
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'zonaSeleccionada' => $zonaSeleccionada,
                'idFranquicia' => $idFranquicia,
                'contratosCancelados' => $contratosCancelados,
                'numTotalContratos' => $numTotalContratos
            ])->render();

            return \Response::json(array("valid"=>"true","view"=>$view, 'fechaInicial' => $fechaInicial, 'fechaFinal' => $fechaFinal));

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }
    public function reportemovimientos(){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $idUsuario = Auth::id();
            $idFranquicia = null;
            $franquicias = null;
            $usuarios = null;

            $hoy = Carbon::now()->format('Y-m-d');
            $fechaInicial = $hoy;
            $fechaFinal = $hoy;

            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

            }else {
                //Principal o administrador
                $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);
                $usuarios = DB::select("SELECT u.id,u.name,(SELECT z.zona FROM zonas z WHERE z.id = u.id_zona) as zona
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id=uf.id_usuario
                                              WHERE u.rol_id = 4  AND uf.id_franquicia='" . $idFranquicia . "' ORDER BY u.id_zona");

            }

            return view('administracion.reportes.tablareportemovimientos', [
                'franquicias' => $franquicias,
                'idFranquicia' => $idFranquicia,
                'usuarios'=>$usuarios,
                'fechaInicial' => $fechaInicial,
                'fechaFinal' => $fechaFinal
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function usuariosreportemovimiento(Request $request){
        if (((Auth::user()->rol_id) == 7)) {
            //Rol director

            $usuarios = null;
            $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');;

            $usuarios = DB::select("SELECT u.id,u.name,(SELECT z.zona FROM zonas z WHERE z.id = u.id_zona) as zona
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id=uf.id_usuario
                                              WHERE u.rol_id = 4  AND uf.id_franquicia='" . $franquiciaSeleccionada . "' ORDER BY u.id_zona");

            $response = ['data' => $usuarios];
            return response()->json($response);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function filtroreportemovimientos(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            //Rol administrador, director, principal

            $usuarioSeleccionado = $request->input('usuarioSeleccionado');
            $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');
            $fechaInicial = $request->input('fechaInicial');
            $fechaFinal = $request->input('fechaFinal');


            $hoy = Carbon::now()->format('Y-m-d');
            if(strlen($fechaInicial) == 0){
                $fechaInicial = $hoy;

            } if(strlen($fechaFinal) == 0){
                $fechaFinal = $hoy;
            }

            if(((Auth::user()->rol_id) == 7)) {
                //Director
                $idFranquicia = $franquiciaSeleccionada;
            }else {
                //Principal o administrador
                $idFranquicia = self::obtenerIdFranquiciaUsuario($usuarioSeleccionado);
            }

            $historialMovimientos = DB::select("SELECT users.name, hc.id_contrato, c.nombre, hc.cambios, hc.created_at FROM historialcontrato hc
                                                    INNER JOIN usuariosfranquicia ON usuariosfranquicia.id_usuario = hc.id_usuarioC
                                                    INNER JOIN users ON users.id = usuariosfranquicia.id_usuario
                                                    INNER JOIN contratos c ON c.id = hc.id_contrato
                                                    WHERE usuariosfranquicia.id_franquicia = '$idFranquicia'
                                                    AND hc.id_usuarioC = '$usuarioSeleccionado'
                                                    AND DATE(hc.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'
                                                    ORDER BY hc.created_at DESC");

            $view = view('administracion.reportes.listas.listareportemovimientos', [
                'idFranquicia' => $idFranquicia,
                'historialMovimientos' => $historialMovimientos
            ])->render();

            return \Response::json(array("valid"=>"true","view"=>$view, 'fechaInicial' => $fechaInicial, 'fechaFinal' => $fechaFinal));


        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function obtenerUsuariosFranquicia(Request $request){
        $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');
        $rolSeleccionado = $request->input("rolSeleccionado");

        $usuarios = DB::select("SELECT u.id,u.name as nombre, u.rol_id  FROM users u
                                            INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario
                                            WHERE u.rol_id IN (".$rolSeleccionado.") AND uf.id_franquicia = '$franquiciaSeleccionada'
                                            ORDER BY name");

        $response = ['usuarios' => $usuarios];

        return response()->json($response);
    }

    public function reportegraficas(){
        if (Auth::check() && ((Auth::user()->rol_id) == 7)) {
            //Rol director
            $cadenaRoles = "4,12,13";

            $hoy = Carbon::now()->format('Y-m-d');
            $fechaInicial = $fechaFinal = $hoy;

            $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

            $roles = DB::select("SELECT r.id, r.rol FROM roles r where r.id IN (" .$cadenaRoles  .") ORDER BY r.rol ASC");

            return view('administracion.reportes.reportegraficas', [
                'franquicias' => $franquicias,
                'roles' => $roles,
                'cadenaRoles' => $cadenaRoles,
                'fechaInicial' => $fechaInicial,
                'fechaFinal' => $fechaFinal
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function creargraficaventas(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 7)) {
            //Rol director

            $contratosAprobados = "";
            $contratosRechazados = "";
            $contratosCancelados = "";
            $contratosLioFuga = "";
            $contratosGarantia = "";
            $abonosCobranza = "";

            $cadenaFraquicia = "";
            $cadenaUsuraio = "";
            $cadenaCobrador = "";
            $cadenaInnerJoin = "INNER JOIN users u on c.id_usuariocreacion = u.id";

            $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');
            $rolSeleccionado = $request->input('rolSeleccionado');
            $usuario = $request->input('usuarioSeleccionado');
            $fechaInicial = $request->input('fechaInicial');
            $fechaFinal = $request->input('fechaFinal');

            $hoy = Carbon::now()->format('Y-m-d');
            if(strlen($fechaInicial) == 0){
                $fechaInicial = $hoy;

            } if(strlen($fechaFinal) == 0){
                $fechaFinal = $hoy;
            }
            if(strlen($franquiciaSeleccionada) == 0 || $franquiciaSeleccionada == null){
                $cadenaFraquicia = "AND c.id_franquicia != '00000'";
                $cadenaCobrador = "AND a.id_franquicia != '00000'";
            } if(strlen($franquiciaSeleccionada) != 0){
                $cadenaFraquicia = " AND c.id_franquicia = '$franquiciaSeleccionada'";
                $cadenaCobrador = " AND a.id_franquicia = '$franquiciaSeleccionada'";
            } if($rolSeleccionado == '12'){
                //Si el rol es optometrista el parametro de filtro es usuariocreacion u optometrista asignado a contrato
                $cadenaInnerJoin = "INNER JOIN users u on (c.id_optometrista = u.id OR u.id = c.id_usuariocreacion)";
            }if(strlen($usuario) != 0){
                if($rolSeleccionado == '12'){
                    //Si el rol es optometrista
                    $cadenaUsuraio = " AND (c.id_usuariocreacion = '$usuario' OR c.id_optometrista = '$usuario')";
                } if($rolSeleccionado == '13'){
                    //Si el rol es asistente
                    $cadenaUsuraio = " AND c.id_usuariocreacion = '$usuario'";
                } if($rolSeleccionado == '4'){
                    //Si el rol es cobranza
                    $cadenaCobrador = "$cadenaCobrador" . " AND a.id_usuario = '$usuario'";
                }
            }

            //Consultas para extraccion de datos ventas y cobranza
            $consultaAprobados  = "SELECT c.id, c.id_usuariocreacion, c.id_franquicia, c.created_at, c.estatus_estadocontrato FROM contratos c
                                                    " .  $cadenaInnerJoin."
                                                    WHERE (NOT EXISTS (SELECT * FROM garantias g WHERE g.id_contrato = c.id)
                                                    OR  EXISTS (SELECT * FROM garantias g WHERE (g.id_contrato = c.id  AND (g.estadogarantia != 2 AND g.estadogarantia != 3))))
                                                    AND c.estatus_estadocontrato IN (2,4,7,10,11,12)
                                                    AND u.rol_id IN (".$rolSeleccionado.")
                                                     " . $cadenaFraquicia . "
                                                     " . $cadenaUsuraio . "
                                                     AND DATE(c.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'";

            $consultaRechazados = "SELECT DISTINCT c.id, c.id_usuariocreacion, c.id_franquicia, c.created_at FROM contratos c
                                                    " .  $cadenaInnerJoin."
                                                    where estatus_estadocontrato IN (8)
                                                    AND u.rol_id IN (".$rolSeleccionado.")
                                                     " . $cadenaFraquicia . "
                                                     " . $cadenaUsuraio . "
                                                     AND DATE(c.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'";

            $consultaCancelados = "SELECT DISTINCT c.id, c.id_usuariocreacion, c.id_franquicia, c.created_at FROM contratos c
                                                    " .  $cadenaInnerJoin."
                                                    where estatus_estadocontrato IN (6)
                                                    AND u.rol_id IN (".$rolSeleccionado.")
                                                    " . $cadenaFraquicia . "
                                                    " . $cadenaUsuraio . "
                                                     AND DATE(c.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'";

            $consultaLioFuga = "SELECT  DISTINCT c.id, c.id_usuariocreacion, c.id_franquicia, c.created_at FROM contratos c
                                                    " .  $cadenaInnerJoin."
                                                    where estatus_estadocontrato IN (14)
                                                    AND u.rol_id IN (".$rolSeleccionado.")
                                                    " . $cadenaFraquicia . "
                                                    " . $cadenaUsuraio . "
                                                     AND DATE(c.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'";

            $consultaGarantias = "SELECT c.id, c.id_usuariocreacion, c.id_franquicia, c.created_at FROM contratos c
                                                    INNER JOIN garantias g on c.id = g.id_contrato
                                                    " .  $cadenaInnerJoin."
                                                    where c.estatus_estadocontrato IN (2,4,7,10,11,12)
                                                    AND (g.estadogarantia = 2 OR g.estadogarantia = 3)
                                                    AND u.rol_id IN (".$rolSeleccionado.")
                                                    " . $cadenaFraquicia . "
                                                    " . $cadenaUsuraio . "
                                                    AND DATE(c.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'";

            $consultaAbonos = "SELECT SUM(a.abono) AS Total, DATE_FORMAT(a.created_at, '%Y-%m-%d') AS Fecha  FROM abonos a where DATE(a.created_at) BETWEEN '$fechaInicial' AND '$fechaFinal'
                            " . $cadenaCobrador . "
                            GROUP BY DATE_FORMAT(a.created_at,'%Y-%m-%d')
                            ORDER BY DATE_FORMAT(a.created_at,'%Y-%m-%d') ASC";

            //Consultas dependiendo los parametros del rol
            if($rolSeleccionado == '4,12,13'){
                //Si el rol es Asistente, Opto o Todos

                $contratosAprobados = DB::select($consultaAprobados);

                $contratosRechazados = DB::select($consultaRechazados);

                $contratosCancelados = DB::select($consultaCancelados);

                $contratosLioFuga = DB::select($consultaLioFuga);

                $contratosGarantia = DB::select($consultaGarantias);

                $abonosCobranza = DB::select($consultaAbonos);

            } if(($rolSeleccionado == '12') || ($rolSeleccionado == '13')){
                //Si el rol es Asistente u Opto

                $contratosAprobados = DB::select($consultaAprobados);

                $contratosRechazados = DB::select($consultaRechazados);

                $contratosCancelados = DB::select($consultaCancelados);

                $contratosLioFuga = DB::select($consultaLioFuga);

                $contratosGarantia = DB::select($consultaGarantias);

            } if($rolSeleccionado == '4'){
                //Si Rol es igual a Cobranza
                $abonosCobranza = DB::select($consultaAbonos);
            }


            $response = ['contratosAprobados' => $contratosAprobados, 'contratosRechazados' => $contratosRechazados, 'contratosCancelados' => $contratosCancelados ,
                        'contratosLioFuga' => $contratosLioFuga, 'contratosGarantia' => $contratosGarantia, 'abonosCobranza'=>$abonosCobranza, 'rolSeleccionado' =>$rolSeleccionado, 'fechaInicial'=>$fechaInicial, 'fechaFinal' => $fechaFinal];

            return response()->json($response);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function reportellamadas(){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7   || (Auth::user()->rol_id) == 8)) {
            //Rol ADMINISTADOR, PRINCIPAL, DIRECTOR

            //Inicializar fechas
            $hoy = Carbon::now()->format('Y-m-d');
            $fechaInicio = $fechaFinal = $hoy;

            if((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8){
                //Si rol es Administrador o Principal solo trae usuarios rol cobranza de la sucursal
                //Id usuario logueado

                $idUsuario = Auth::user()->id;
                $franquicia = DB::select("SELECT uf.id_franquicia FROM usuariosfranquicia uf WHERE uf.id_usuario = '$idUsuario'");
                $idFranquicia = $franquicia[0]->id_franquicia;

                $usuarios = DB::select("SELECT u.id,u.name,(SELECT z.zona FROM zonas z WHERE z.id = u.id_zona) as zona
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id=uf.id_usuario
                                              WHERE u.rol_id = 4  AND uf.id_franquicia='" . $idFranquicia . "' ORDER BY u.id_zona");
            } else{
                //Si es rol de riector extrae todos los usuarios rol cobranza

                $usuarios = DB::select("SELECT u.id,u.name,(SELECT z.zona FROM zonas z WHERE z.id = u.id_zona) as zona,
                                              (SELECT f.ciudad FROM franquicias f WHERE uf.id_franquicia = f.id) as ciudad
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id=uf.id_usuario
                                              WHERE u.rol_id = 4  AND uf.id_franquicia != '00000' ORDER BY ciudad, zona");
            }

            return view('administracion.reportes.tablareportellamadas', [
                'usuarios' =>$usuarios,
                'fechaInicio' => $fechaInicio,
                'fechaFinal' => $fechaFinal
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function listareportellamadas(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7   || (Auth::user()->rol_id) == 8)) {
            //Rol ADMINISTADOR, PRINCIPAL, DIRECTOR

            $contratoscorte = null;
            $cadenaCortes = "";

            $usuarioSeleccionado = $request->input("usuarioSeleccionado");
            $fechaInicio = $request->input("fechaInicio");
            $fechaFinal = $request->input("fechaFinal");

            //Validacion de fechas
            $hoy = Carbon::now()->format('Y-m-d');
            if(strlen($fechaInicio) == 0){
                //Esta vacia fecha Inicio
                $fechaInicio = $hoy;

            } if(strlen($fechaFinal) == 0){
                //Esta vacia fecha final
                $fechaFinal = $hoy;
            }

            $fechaInicio = Carbon::parse($fechaInicio)->format('Y-m-d');
            $fechaFinal = Carbon::parse($fechaFinal)->format('Y-m-d');

            if($fechaInicio < $fechaFinal){
                //Es mayor la fecha final a inicial

                //Validacion de usuario
                $existeUsuario = DB::select("SELECT u.id,u.id_zona,u.name,uf.id_franquicia FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.id = '$usuarioSeleccionado'");

                if ($existeUsuario != null) { //Esta seleccionado un usuario valido?
                    //Si esta seleccionado

                    $idUsuario = $existeUsuario[0]->id;
                    $usuarioFranquicia = $existeUsuario[0]->id_franquicia;

                    //Cortes en un periodo de tiempo para el usuario seleccionado
                    $cortesUsuario = DB::select("SELECT * FROM historialcortes hc WHERE hc.indice IN (SELECT a.id_corte FROM abonos a WHERE a.id_franquicia = '$usuarioFranquicia' AND a.id_usuario = '$idUsuario') AND hc.id_cobrador = '$idUsuario' AND hc.created_at between '$fechaInicio' and '$fechaFinal' ORDER BY hc.created_at DESC");

                    if($cortesUsuario != null){
                        //Si existe al menos un corte

                        //Recorrido para obtener indice de corte
                        foreach ($cortesUsuario as $corteUsuario) {
                            $cadenaCortes =  $cadenaCortes . $corteUsuario->indice . ', ';
                        }

                        //Eliminamos la ultima coma sobrante
                        $cadenaCortes = trim($cadenaCortes, ', ');

                        $consulta = "SELECT ccl.indice, ccl.id_contrato,
                    (SELECT hc.cambios FROM historialcontrato hc WHERE hc.id_contrato = ccl.id_contrato AND hc.id = ccl.id_historialcontrato AND hc.tipomensaje = '2') as mensaje,
                    (SELECT c.nombre FROM contratos c WHERE c.id = ccl.id_contrato AND c.id_franquicia = '$usuarioFranquicia') as nombrecliente,
                    (SELECT u.name FROM users u WHERE u.id = ccl.id_cobrador) as nombrecobrador
                    FROM contratoscortellamada ccl WHERE ccl.id_corte IN (" . $cadenaCortes . ") ORDER BY ccl.indice DESC";

                        $datoscontratoscorte =  DB::select($consulta);

                        $contratoscorte = $datoscontratoscorte; //Se le pasan los datos al arreglo contratoscortellamada
                    }
                }
            }

            $view = view('administracion.reportes.listas.listareportellamadas', [
                '$usuarioSeleccionado' => $usuarioSeleccionado,
                'contratoscorte' => $contratoscorte
            ])->render();

            return \Response::json(array("valid"=>"true","view"=>$view, 'fechaInicio' => $fechaInicio, 'fechaFinal' => $fechaFinal));


        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    //Funcion: listareporteasistencia
    //Descripcion: Traera el reporte de asistencia de la sucursal una vez seleccionada una semana en particular
    public function listareporteasistencia(){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7   || (Auth::user()->rol_id) == 8)) {
            //Rol ADMINISTADOR, PRINCIPAL, DIRECTOR

            //Obtener perido de fechas a consultar
            $now = Carbon::now();
            $nowParse = Carbon::parse($now)->format('Y-m-d');
            $polizaGlobales = new polizaGlobales();
            $numeroDia = $now->dayOfWeekIso;    //Obtenemos el dia de la semana actual
            $fechaLunes = $nowParse;    //Obtener fecha con formato

            if($numeroDia != 1 && $numeroDia != 7){
                //Si no es lunes y domingo
                $fechaLunes = $polizaGlobales::obtenerDia($numeroDia, 1);   //se obtenie la fecha del lunes anterior a la fecha actaul
            }
            if($numeroDia == 7){
                //Si es domigo obtenemos la fecha del lunes pasado
                $fechaLunes = date("Y-m-d",strtotime($nowParse."- 6 days"));
                $numeroDia = 6; //Dia semana lo tomaremos como sabado por ser ultimo dia de trabajo
            }

            $fechaSabadoSiguiente = date("Y-m-d",strtotime($fechaLunes."+ 5 days"));

            //Lista de franquicias para rol Director
            $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");

            //Polizas dentro de la semana actual
            $idUsuario = Auth::user()->id;
            $rolUsuario = Auth::user()->rol_id;
            $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);

            return view('administracion.reportes.tablareporteasistencia', [
                'idFranquicia' =>$idFranquicia,
                'rolUsuario' => $rolUsuario,
                'franquicias' => $franquicias,
                'fechaHoy' => $nowParse,
                'fechaLunes' => $fechaLunes,
                'fechaSabadoSiguiente' => $fechaSabadoSiguiente
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    //Funcion: obtenerdiasasistencia
    //Descripcion: Trae la fecha que tomara el periodo de asistencia
    public function obtenerdiasasistencia(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7   || (Auth::user()->rol_id) == 8)) {
            //Rol ADMINISTADOR, PRINCIPAL, DIRECTOR

            $diaSeleccionado = $request->input("diaSeleccionado");
            $diaSeleccionado = Carbon::parse($diaSeleccionado)->format('Y-m-d');
            $numeroDia = $request->input("numeroDia");
            $diasRestar = $numeroDia - 1;
            $fechaLunes = $diaSeleccionado;

            if($numeroDia != 1){
                //Si no es lunes
                $fechaLunes = date("Y-m-d",strtotime($diaSeleccionado."- ". $diasRestar ." days"));  //se obtenie la fecha del lunes anterior a la fecha actaul
            }
            $fechaSabadoSiguiente = date("Y-m-d",strtotime($fechaLunes."+ 5 days")); // se obtiene la fecha del siguinete sabado

            return \Response::json(array("valid"=>"true", 'fechaLunes' => $fechaLunes, 'fechaSabadoSiguiente' => $fechaSabadoSiguiente));

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function cargarListaAsistencia(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7   || (Auth::user()->rol_id) == 8)) {
            //Rol ADMINISTADOR, PRINCIPAL, DIRECTOR

            $franquiciaSeleccionada = $request->input("franquiciaSeleccionada");
            $rolUsuario = $request->input("rol_usuario");
            $fechaLunes = $request->input("fechaLunes");
            $fechaSabadoSiguiente = $request->input("fechaSabadoSiguiente");
            $cadenaPoliza = "";

            $idUsuario = Auth::user()->id;

            switch ($rolUsuario){
                case 6:
                    //Rol de administrador
                case 8:
                    //Rol de Principal
                    $idFranquicia = self::obtenerIdFranquiciaUsuario($idUsuario);
                    break;

                case 7:
                    //Rol de director
                    //Por default envia la sucursal en la posicion 0 del arreglo de franquicias
                    $idFranquicia = $franquiciaSeleccionada;
                    break;
            }

            $consulta = "SELECT p.id, p.id_franquicia,STR_TO_DATE(p.created_at,'%Y-%m-%d') AS fechaPoliza FROM poliza p
                                                WHERE p.id_franquicia = '$idFranquicia'
                                                AND STR_TO_DATE(p.created_at,'%Y-%m-%d') BETWEEN '$fechaLunes' AND '$fechaSabadoSiguiente'
                                                ORDER BY p.created_at asc";

            $polizas = DB::select($consulta);

            if($polizas != null){

                //Se tiene polizas existentes
                foreach ($polizas as $poliza){
                    $cadenaPoliza = $cadenaPoliza . $poliza->id . ',';
                }

                //Quitamos la ultima "," de la cadena
                $cadenaPoliza = trim($cadenaPoliza, ',');

                $usuarios = DB::select("SELECT DISTINCT (u.id), u.name, u.fechaeliminacion AS eliminacion, u.created_at AS fechaCreacion FROM users u
                                                INNER JOIN asistencia a ON a.id_usuario = u.id
                                                WHERE a.id_poliza IN ($cadenaPoliza)
                                                ORDER BY u.name ASC");

                $asistenciaUsuarios = self::obtenerAsistenciaUsuario($usuarios, $polizas, $fechaLunes);
            }else {
                //No existen polizas en lo que va de la semana
                $asistenciaUsuarios = null;
            }

            $view = view('administracion.reportes.listas.listareporteasistencia', [
                'asistenciaUsuarios' => $asistenciaUsuarios,
            ])->render();

            return \Response::json(array("valid"=>"true","view"=>$view));

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function obtenerAsistenciaUsuario($usuarios,$polizas, $fechaLunes){

        //Fechas de dias para comparar polizas
        $fechaLunes = $fechaLunes;
        $fechaMartes = date("Y-m-d",strtotime($fechaLunes."+ 1 days"));
        $fechaMiercoles = date("Y-m-d",strtotime($fechaLunes."+ 2 days"));
        $fechaJueves = date("Y-m-d",strtotime($fechaLunes."+ 3 days"));
        $fechaViernes = date("Y-m-d",strtotime($fechaLunes."+ 4 days"));
        $fechaSabado = date("Y-m-d",strtotime($fechaLunes."+ 5 days"));

        foreach ($usuarios as $usuario) {
            $idUsuario = $usuario ->id;
            $fechaEliminacion = $usuario ->eliminacion;

            if($fechaEliminacion != null){
                //Si usuario presenta fecha de eliminacion convertimos a tipo fecha con formato
                $fechaEliminacion = Carbon::parse($fechaEliminacion)->format('Y-m-d');
            }

            //Colocamos los nuevos atributos a cada usuario
            $usuario->asistenciaLunes = null;
            $usuario->asistenciaMartes = null;
            $usuario->asistenciaMiercoles = null;
            $usuario->asistenciaJueves = null;
            $usuario->asistenciaViernes = null;
            $usuario->asistenciaSabado = null;

            foreach ($polizas as $poliza){
                $idPoliza = $poliza -> id;

                $asistencia = DB::select("SELECT a.id_tipoasistencia FROM asistencia a WHERE a.id_poliza = '$idPoliza' AND a.id_usuario = '$idUsuario'");

                if($asistencia != null){
                    $valorAsistencia = $asistencia[0]->id_tipoasistencia;
                    switch ($valorAsistencia){
                        case 0:
                            //Falta
                            $valorAsistencia = 'F';
                            break;

                        case 1:
                            //Asistencia
                            $valorAsistencia = 'A';
                            break;

                        case 2:
                            //Retardo
                            $valorAsistencia = 'R';
                            break;
                    }
                    if($poliza->fechaPoliza == $fechaLunes){
                        $usuario->asistenciaLunes = $valorAsistencia;
                    }if($poliza->fechaPoliza == $fechaMartes){
                        $usuario->asistenciaMartes = $valorAsistencia;
                    }if($poliza->fechaPoliza == $fechaMiercoles){
                        $usuario->asistenciaMiercoles = $valorAsistencia;
                    }if($poliza->fechaPoliza == $fechaJueves){
                        $usuario->asistenciaJueves = $valorAsistencia;
                    }if($poliza->fechaPoliza == $fechaViernes){
                        $usuario->asistenciaViernes = $valorAsistencia;
                    }if($poliza->fechaPoliza == $fechaSabado){
                        $usuario->asistenciaSabado = $valorAsistencia;
                    }
                }
                //Verificamos que no haya sido dado de baja
                if(($fechaEliminacion != null) && ($poliza->fechaPoliza > $fechaEliminacion)){
                    //Si se dio de baja este usuario colocamos asistencia como F
                    if($poliza->fechaPoliza == $fechaLunes){
                        $usuario->asistenciaLunes = 'F';
                    }if($poliza->fechaPoliza == $fechaMartes){
                        $usuario->asistenciaMartes = 'F';
                    }if($poliza->fechaPoliza == $fechaMiercoles){
                        $usuario->asistenciaMiercoles = 'F';
                    }if($poliza->fechaPoliza == $fechaJueves){
                        $usuario->asistenciaJueves = 'F';
                    }if($poliza->fechaPoliza == $fechaViernes){
                        $usuario->asistenciaViernes = 'F';
                    }if($poliza->fechaPoliza == $fechaSabado){
                        $usuario->asistenciaSabado = 'F';
                    }
                }

            } // Fin ciclo polizas

        } // Fin ciclo usuarios

        return $usuarios;
    }

}
