<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Pagination\Paginator;
use App\Clases\polizaGlobales;
use App\Clases;
use Illuminate\Support\Facades\Storage;

class poliza extends Controller
{

    public function tablaPoliza($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //DIRECTOR Y ADMINISTRATIVO
        {
            $polizas = DB::table('poliza as p')
                ->select('p.id AS ID', 'p.id_franquicia AS FRANQUICIA', 'p.realizo AS REALIZO', 'p.autorizo AS AUTORIZO', 'p.total AS TOTAL', 'p.created_at AS CREATED_AT')
                ->whereRaw("p.id_franquicia  = '$idFranquicia'")
                ->orderBy('p.created_at', 'DESC')
                ->paginate(20);
            $franquiciaPoliza = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.poliza.tabla', ['polizas' => $polizas, 'idFranquicia' => $idFranquicia, 'franquiciaPoliza' => $franquiciaPoliza,
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    /*public function tablaVentas($idFranquicia, $idPoliza){
          if(Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //DIRECTOR Y ADMINISTRATIVO
          {


              return view('administracion.poliza.nueva',['polizas' => $polizas, 'idFranquicia' => $idFranquicia, 'franquiciaPoliza' => $franquiciaPoliza,
              ]);

          }else{
              if (Auth::check()) {
                return redirect()->route('redireccionar');
              }else{
                return redirect()->route('login');
              }
            }
      }*/

    public static function verpoliza($idFranquicia, $idPoliza)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //ADMINISTRADORES
        {


            $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza' AND id_franquicia = '$idFranquicia'");
            if($poliza != null) { //Existe la poliza en la sucursal actual?

                $fechaPoliza = Carbon::parse($poliza[0]->created_at)->format('Y-m-d');
                $opcion = 1;

                return view('administracion.poliza.nueva', [
                    "idFranquicia" => $idFranquicia,
                    "idPoliza" => $idPoliza,
                    "poliza" => $poliza,
                    "fecha" => $fechaPoliza,
                    "opcion"=>$opcion
                ]);

            }
            return back()->with("alerta","No se encontro la poliza.");
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function crearpolizamanual($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            try {

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $hoy = Carbon::now();
                //$hoy = Carbon::parse("2022-05-02");
                $hoyNumero = $hoy->dayOfWeekIso;
                $hoyFormato = $hoy->format('Y-m-d');
                $fechaLunes = $polizaGlobales::obtenerDia($hoyNumero, 1);  //Obtengo la fecha del dia lunes
                $ultimaPoliza = DB::select("SELECT estatus,id,total FROM poliza WHERE id_franquicia = '$idFranquicia'  ORDER BY created_at DESC LIMIT 1"); //Tomamos la ultima poliza creada sin importar si es de la misma semana o no.
                $polizaAnterior = DB::select("SELECT id,total FROM poliza WHERE created_at >= '$fechaLunes' AND id_franquicia = '$idFranquicia' ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza de la semana actual.
                $polizaAnteriorId =$polizaAnterior == null ? "" :  $polizaAnterior[0]->id ;
                $polizaAbierta = DB::select("SELECT id FROM poliza WHERE created_at  like '%" . $hoyFormato . "%' AND id_franquicia = '$idFranquicia'"); //Consultamos si ya existe una poliza el dia de hoy

                if ($polizaAbierta != null) { //Tenemos una poliza creada el dia de hoy??
                    //Si tenemos una poliza ya creada
                    return back()->with("alerta","La poliza de hoy ya fue creada.");
                }elseif($hoyNumero == 7){ //Es un dia domingo?
                    return back()->with("alerta","No puedes crear una poliza en domingo.");
                }elseif( $ultimaPoliza != null &  $ultimaPoliza[0]->estatus != 1){
                    return back()->with("alerta","No puedes crear una poliza nueva, mientras la ultima no esta terminada.");
                } else {//No tenemos una poliza creada
                    \Log::info("Poliza : Creacion");

                    //Creamos la poliza
                    $idPoliza = DB::table("poliza")->insertGetId([
                        "id_franquicia" => $idFranquicia,
                        "ingresosadmin" => 0,
                        "ingresosventas" => 0,
                        "ingresoscobranza" => 0,
                        "gastosadmin" => 0,
                        "gastoscobranza" => 0,
                        "otrosgastos" => 0,
                        "estatus" => 0,
                        "total" => 0,
                        "created_at" => $hoy
                    ]);

                    $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza'");
                    $fechaPoliza = Carbon::parse($poliza[0]->created_at)->format('Y-m-d');

                    $usuarios = DB::select("SELECT u.id FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE uf.id_franquicia = '$idFranquicia' ORDER BY u.name ASC");

                    foreach ($usuarios as $usuario) {
                        DB::table("asistencia")->insert([
                            "id_poliza" => $idPoliza,
                            "id_usuario" => $usuario->id,
                            "id_tipoasistencia" => 0,
                            "created_at" => $hoy
                        ]);
                    }

                    \Log::info("Log");

                    DB::update("UPDATE contratos SET poliza = '$idPoliza' WHERE id_franquicia = '$idFranquicia' AND estatus_estadocontrato IN (2,4,5,7,10,11,12) AND datos = '1' AND poliza IS NULL");//Actualizamos todos los contratos

                    \Log::info("Log 0");

                    DB::update("UPDATE abonos
                                        SET poliza = '$idPoliza'
                                        WHERE id_franquicia = '$idFranquicia'
                                        AND poliza IS NULL");//Actualizamos todos los abonos

                    \Log::info("Log 1");

                    $ventasOptos = $polizaGlobales::calculosVentasOptos($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Obtenemos las ventas de Optometristas
                    \Log::info("Log 2");
                    $ventasAsis = $polizaGlobales::calculosVentasAsis($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Obtenemos las ventas de Asistentes
                    \Log::info("Log 3");
                    $productividadOptos = $polizaGlobales::calculoProductividadOptos($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Obetenemos la productividad de Optos
                    \Log::info("Log 4");
                    $productividadAsis = $polizaGlobales::calculoProductividadAsis($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Optenemos la productividad de Asis
                    \Log::info("Log 5");

                    foreach ($ventasOptos as $ventaOpto) {
                        $idOpto = $ventaOpto->id;
                        $nombreOpto = $ventaOpto->name;
                        $acumuladas = $ventaOpto->acumuladas;
                        $diaActual = $ventaOpto->diaActual;
                        $acumuladasTotal = $diaActual + $acumuladas;
                        $ingresosGotas = $ventaOpto->gotas;
                        $ingresoEnganche = $ventaOpto->enganche;
                        $ingresoPoliza = $ventaOpto->polizas;
                        $ingresosVentas = ($ingresoPoliza == null ? 0 : $ingresoPoliza) + ($ingresoEnganche == null ? 0 : $ingresoEnganche) + ($ingresosGotas == null ? 0 : $ingresosGotas);
                        $ingresosVentasAcumuladas = $ingresosVentas + ($ventaOpto->ingresosventasacumulado == null ? 0 : $ventaOpto->ingresosventasacumulado);


                        $ventasOptosQuery = $polizaGlobales::obtenerQueryVentasOptos($hoyNumero, $diaActual, $idFranquicia, $idOpto);
                        $query = "INSERT INTO polizaventasdias (id,id_franquicia,id_usuario,rol,id_poliza,fechapoliza,fechapolizacierre,nombre,lunes,martes,miercoles,jueves,viernes,sabado,acumuladas,asistencia,ingresosgotas,ingresosenganche,ingresospoliza,totaldia,ingresosventas,ingresosventasacumulado)
                                    VALUES(null,'$idFranquicia','$idOpto','12','$idPoliza','$hoy',null,'$nombreOpto'," . $ventasOptosQuery . ",'$acumuladasTotal',null,'$ingresosGotas','$ingresoEnganche','$ingresoPoliza',null,'$ingresosVentas','$ingresosVentasAcumuladas')";

                        DB::insert($query);
                    }

                    \Log::info("Log 6");


                    foreach ($ventasAsis as $ventaAsis) {
                        $idOpto = $ventaAsis->id;
                        $nombreOpto = $ventaAsis->name;
                        $acumuladas = $ventaAsis->acumuladas;
                        $diaActual = $ventaAsis->diaActual;
                        $asistencia = $ventaAsis->asistencia;
                        $acumuladasTotal = $diaActual + $acumuladas;
                        $ingresosGotas = 0;
                        $ingresoEnganche = 0;
                        $ingresoPoliza = 0;
                        $ingresosVentas = 0;
                        $ingresosVentasAcumuladas = 0;

                        $ventasOptosQuery = $polizaGlobales::obtenerQueryVentasOptos($hoyNumero, $diaActual, $idFranquicia, $idOpto);
                        $query = "INSERT INTO polizaventasdias (id,id_franquicia,id_usuario,rol,id_poliza,fechapoliza,fechapolizacierre,nombre,lunes,martes,miercoles,jueves,viernes,sabado,acumuladas,asistencia,ingresosgotas,ingresosenganche,ingresospoliza,totaldia,ingresosventas,ingresosventasacumulado)
                                    VALUES(null,'$idFranquicia','$idOpto','13','$idPoliza','$hoy',null,'$nombreOpto'," . $ventasOptosQuery . ",'$acumuladasTotal',null,'$ingresosGotas','$ingresoEnganche','$ingresoPoliza',null,'$ingresosVentas','$ingresosVentasAcumuladas')";
                        DB::insert($query);
                    }

                    \Log::info("Log 7");


                    foreach ($productividadOptos as $productividadOpto) {
                        $idOpto = $productividadOpto->ID;
                        $sueldo = $productividadOpto->SUELDO;
                        $ECOJRANT = $productividadOpto->ECOJRANT == null ? 0 : $productividadOpto->ECOJRANT;
                        $ECOJR = $productividadOpto->ECOJR == null ? 0 : $productividadOpto->ECOJR;
                        $totalEcoAcu = $ECOJRANT + $ECOJR;
                        $JUNIORANT = $productividadOpto->JUNIORANT == null ? 0 : $productividadOpto->JUNIORANT;
                        $JUNIOR = $productividadOpto->JUNIOR == null ? 0 : $productividadOpto->JUNIOR;
                        $totalJrAcu = $JUNIORANT + $JUNIOR;
                        $DORADOUNOANT = $productividadOpto->DORADOUNOANT == null ? 0 : $productividadOpto->DORADOUNOANT;
                        $DORADOUNO = $productividadOpto->DORADOUNO == null ? 0 : $productividadOpto->DORADOUNO;
                        $totalDoradoAcu = $DORADOUNOANT + $DORADOUNO;
                        $DORADODOSANT = $productividadOpto->DORADODOSANT == null ? 0 : $productividadOpto->DORADODOSANT;
                        $DORADODOS = $productividadOpto->DORADODOS == null ? 0 : $productividadOpto->DORADODOS;
                        $totalDoradoDosAcu = $DORADODOSANT + ($DORADODOS == 0 ? $DORADODOS : ($DORADODOS / 2));
                        $PLATINOANT = $productividadOpto->PLATINOANT == null ? 0 : $productividadOpto->PLATINOANT;
                        $PLATINO = $productividadOpto->PLATINO == null ? 0 : $productividadOpto->PLATINO;

                        $totalPlatinoAcu = $PLATINOANT + $PLATINO;
                        $numeroVentas = $totalEcoAcu + $totalJrAcu + $totalDoradoAcu + $totalDoradoDosAcu + $totalPlatinoAcu;
                        $productividad = ($numeroVentas * 100) / 30;
                        $insumos = ($productividadOpto->INSUMOS == null ? 0 : $productividadOpto->INSUMOS) * $numeroVentas;

                        DB::table("polizaproductividad")->insert([
                            "id_franquicia" => $idFranquicia,
                            "id_poliza" => $idPoliza,
                            "id_usuario" => $idOpto,
                            "sueldo" => $sueldo,
                            "totaleco" => $totalEcoAcu,
                            "totaljr" => $totalJrAcu,
                            "totaldoradouno" => $totalDoradoAcu,
                            "totaldoradodos" => $totalDoradoDosAcu,
                            "totalplatino" => $totalPlatinoAcu,
                            "numeroventas" => $numeroVentas,
                            "productividad" => $productividad,
                            "insumos" => $insumos
                        ]);

                    }

                    \Log::info("Log 8");


                    foreach ($productividadAsis as $productividadAsi) {
                        $idAsis = $productividadAsi->ID;
                        $sueldo = $productividadAsi->SUELDO;
                        $ECOJRANT = $productividadAsi->ECOJRANT == null ? 0 : $productividadAsi->ECOJRANT;
                        $ECOJR = $productividadAsi->ECOJR == null ? 0 : $productividadAsi->ECOJR;
                        $totalEcoAcu = $ECOJRANT + $ECOJR;
                        $JUNIORANT = $productividadAsi->JUNIORANT == null ? 0 : $productividadAsi->JUNIORANT;
                        $JUNIOR = $productividadAsi->JUNIOR == null ? 0 : $productividadAsi->JUNIOR;
                        $totalJrAcu = $JUNIORANT + $JUNIOR;
                        $DORADOUNOANT = $productividadAsi->DORADOUNOANT == null ? 0 : $productividadAsi->DORADOUNOANT;
                        $DORADOUNO = $productividadAsi->DORADOUNO == null ? 0 : $productividadAsi->DORADOUNO;
                        $totalDoradoAcu = $DORADOUNOANT + $DORADOUNO;
                        $DORADODOSANT = $productividadAsi->DORADODOSANT == null ? 0 : $productividadAsi->DORADODOSANT;
                        $DORADODOS = $productividadAsi->DORADODOS == null ? 0 : $productividadAsi->DORADODOS;
                        $totalDoradoDosAcu = $DORADODOSANT + ($DORADODOS == 0 ? $DORADODOS : ($DORADODOS / 2));
                        $PLATINOANT = $productividadAsi->PLATINOANT == null ? 0 : $productividadAsi->PLATINOANT;
                        $PLATINO = $productividadAsi->PLATINO == null ? 0 : $productividadAsi->PLATINO;
                        $totalPlatinoAcu = $PLATINOANT + $PLATINO;
                        $numeroVentas = $totalEcoAcu + $totalJrAcu + $totalDoradoAcu + $totalDoradoDosAcu + $totalPlatinoAcu;
                        $productividad = ($numeroVentas * 100) / 10;
                        $insumos = $productividadAsi->INSUMOS == null ? 0 : $productividadAsi->INSUMOS;

                        DB::table("polizaproductividad")->insert([
                            "id_franquicia" => $idFranquicia,
                            "id_poliza" => $idPoliza,
                            "id_usuario" => $idAsis,
                            "sueldo" => $sueldo,
                            "totaleco" => $totalEcoAcu,
                            "totaljr" => $totalJrAcu,
                            "totaldoradouno" => $totalDoradoAcu,
                            "totaldoradodos" => $totalDoradoDosAcu,
                            "totalplatino" => $totalPlatinoAcu,
                            "numeroventas" => $numeroVentas,
                            "productividad" => $productividad,
                            "insumos" => $insumos
                        ]);
                    }

                    \Log::info("Log 9");

                    $opcion = 0;

                    return view('administracion.poliza.nueva', [
                        "idFranquicia" => $idFranquicia,
                        "idPoliza" => $idPoliza,
                        "poliza"=>$poliza,
                        "fecha"=>$fechaPoliza,
                        "opcion"=>$opcion
                    ]);
                }

            } catch (\Exception $e) {
                \Log::info("Error: " . $e);
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function crearcargarpolizatiemporeal(Request $request) {

        //Opcion
        //0- Creacion poliza
        //1- Ver poliza

        $idFranquicia = $request->input('idFranquicia');
        $opcion = $request->input('opcion');
        $idPoliza = $request->input('idPoliza');
        $view = null;

        $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
        $hoy = Carbon::now();
        //$hoy = Carbon::parse("2022-05-02");
        $hoyNumero = $hoy->dayOfWeekIso;

        if($opcion == 0) {
            //Crear poliza

            try {

                $hoyFormato = $hoy->format('Y-m-d');
                $fechaLunes = $polizaGlobales::obtenerDia($hoyNumero, 1);  //Obtengo la fecha del dia lunes
                $ultimaPoliza = DB::select("SELECT estatus,id,total FROM poliza WHERE id_franquicia = '$idFranquicia'  ORDER BY created_at DESC LIMIT 1"); //Tomamos la ultima poliza creada sin importar si es de la misma semana o no.
                $polizaAnterior = DB::select("SELECT id,total FROM poliza WHERE created_at >= '$fechaLunes' AND id_franquicia = '$idFranquicia' ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza de la semana actual.
                $polizaAnteriorId = $polizaAnterior == null ? "" : $polizaAnterior[0]->id;

                \Log::info("Log 10");


                $polizaGlobales::calculoDeCobranza($idFranquicia, $idPoliza, $polizaAnteriorId, "");


                \Log::info("Log 11");


                $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza'");
                $fechaPoliza = Carbon::parse($poliza[0]->created_at)->format('Y-m-d');
                $ventas = DB::select("SELECT pvd.nombre,pvd.lunes,pvd.martes,pvd.miercoles,pvd.jueves,pvd.viernes,pvd.sabado,pvd.acumuladas,pvd.ingresosgotas,pvd.ingresosenganche,pvd.ingresospoliza,pvd.ingresosventas,pvd.ingresosventasacumulado,a.id_tipoasistencia as asistencia
                                                FROM users u INNER JOIN polizaventasdias pvd ON u.id = pvd.id_usuario INNER JOIN asistencia a ON a.id_usuario = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '12' AND a.id_poliza = '$idPoliza' ORDER BY u.name");
                $ventasAsistente = DB::select("SELECT pvd.nombre,pvd.lunes,pvd.martes,pvd.miercoles,pvd.jueves,pvd.viernes,pvd.sabado,pvd.acumuladas,pvd.ingresosgotas,pvd.ingresosenganche,pvd.ingresospoliza,pvd.ingresosventas,pvd.ingresosventasacumulado,a.id_tipoasistencia as asistencia
                                                FROM users u INNER JOIN polizaventasdias pvd ON u.id = pvd.id_usuario INNER JOIN asistencia a ON a.id_usuario = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '13' AND a.id_poliza = '$idPoliza' ORDER BY u.name");

                $productividad = DB::select("SELECT * FROM polizaproductividad pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '12' ORDER BY u.name");

                if ($productividad != null) {
                    //Hay datos en productividad

                    foreach ($productividad as $product) {
                        //Recorrido de productividad por usuario
                        $arrayRespuesta = $polizaGlobales::obtenerNumeroContratosEntregadosAbonoAtrasadoLiquidadosConGarantiaPorPaqueteYContratosYSumaTotalRealContratosEntregadosPorUsuario($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario);
                        $arrayNumContratosPorPaquetes = $arrayRespuesta[0]; //Arreglo con el numero de contratos entregados por paquetes
                        $contratosEntregados = $arrayRespuesta[1]; //Todos los contratos entregados
                        $sumaTotalRealContratosEntregados = $arrayRespuesta[2]; //Suma de los totalReal de los contratos entregados

                        $product->totaleco = 0;
                        $product->totaljr = 0;
                        $product->totaldoradouno = 0;
                        $product->totaldoradodos = 0;
                        $product->totalplatino = 0;

                        if ($arrayNumContratosPorPaquetes != null) {
                            //Arreglo con el numero de contratos entregados por paquetes contiene informacion

                            if (array_key_exists("1", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 1
                                $product->totaleco += $arrayNumContratosPorPaquetes['1'];
                            }
                            if (array_key_exists("2", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 2
                                $product->totaleco += $arrayNumContratosPorPaquetes['2'];
                            }
                            if (array_key_exists("3", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 3
                                $product->totaleco += $arrayNumContratosPorPaquetes['3'];
                            }
                            if (array_key_exists("4", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 4
                                $product->totaljr = $arrayNumContratosPorPaquetes['4'];
                            }
                            if (array_key_exists("5", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 5
                                $product->totaldoradouno = $arrayNumContratosPorPaquetes['5'];
                            }
                            if (array_key_exists("6", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 6
                                $product->totaldoradodos = $arrayNumContratosPorPaquetes['6'];
                            }
                            if (array_key_exists("7", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 7
                                $product->totalplatino = $arrayNumContratosPorPaquetes['7'];
                            }

                        }

                        $product->numeroventas = count($contratosEntregados); //numeroventas = Todos los contratos entregados
                        $product->contratosporentregar = $polizaGlobales::obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario, 0);
                        $product->montototalreal = $polizaGlobales::obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario, 1);
                        $product->montoentregadostotalreal = $sumaTotalRealContratosEntregados;

                        $arrayRespuestaObjetivoVentas = $polizaGlobales::obtenerDineroObjetivoEnVentas($contratosEntregados, $product->numeroventas, $product->totaleco, $product->totaljr, $product->totaldoradouno + $product->totaldoradodos, $product->totalplatino);
                        $product->dineroobjetivoventastreinta = $arrayRespuestaObjetivoVentas[0];
                        $product->dineroobjetivoventascuarenta = $arrayRespuestaObjetivoVentas[1];
                    }

                }

                $productividadAsistente = DB::select("SELECT * FROM polizaproductividad pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '13' ORDER BY u.name");

                if ($productividadAsistente != null) {
                    //Hay datos en productividadAsistente

                    foreach ($productividadAsistente as $productAsist) {
                        //Recorrido de productividadAsistente por usuario
                        $productAsist->numObjetivoSemanaAnterior = $polizaGlobales::obtenerNumeroObjetivoSemanaAnteriorAsistente($idFranquicia, $poliza[0]->created_at, $productAsist->id_usuario);
                        $arrayResultados = $polizaGlobales::obtenerNoVentasAprobadasVentasAcumuladasYVentasAcumuladasAprobadasAsistente($idFranquicia, $idPoliza, $poliza[0]->created_at, $productAsist->id_usuario);
                        $productAsist->sumaContratosNumVentas = $arrayResultados[0];
                        $productAsist->sumaContratosAprobadas = $arrayResultados[1];
                        $productAsist->sumaContratosVentasAcumuladas = $arrayResultados[2];
                        $productAsist->sumaContratosVentasAcumuladasAprobadas = $arrayResultados[3];
                    }

                }

                $cobranzatabla = DB::select("SELECT * FROM polizacobranza pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' ORDER BY u.name ");
                $totaldia = DB::select("SELECT SUM(ingresosventas) as ingreso FROM polizaventasdias WHERE id_poliza = '$idPoliza'");
                $totalingresocobranza = DB::select("SELECT SUM(ingresocobranza) as ingreso FROM polizacobranza WHERE id_poliza = '$idPoliza'");
                $ingresos = DB::select("SELECT * FROM ingresosoficina WHERE id_poliza = '$idPoliza'");
                $productividadgasto = DB::select("SELECT * FROM gastos WHERE id_poliza = '$idPoliza' AND tipogasto = 1");
                $usuarioscobranza = DB::select("SELECT u.id,u.name FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE rol_id = '4' AND uf.id_franquicia = '$idFranquicia'");
                $historial = DB::select("SELECT u.name,hc.cambios,hc.created_at FROM historialpoliza hc INNER JOIN users u ON u.id = hc.id_usuarioC WHERE id_poliza = '$idPoliza'");

                $ingresosVentas = $totaldia[0]->ingreso == null ? 0 : $totaldia[0]->ingreso;
                $ingresosCobranza = $totalingresocobranza[0]->ingreso == null ? 0 : $totalingresocobranza[0]->ingreso;
                $totalUltimaPoliza = $ultimaPoliza[0]->total == null ? 0 : $ultimaPoliza[0]->total;
                $total = $ingresosVentas + $ingresosCobranza + $totalUltimaPoliza;


                DB::table("poliza")->where("id", "=", $idPoliza)->where("id_franquicia", "=", $idFranquicia)->update([
                    "ingresosadmin" => 0,
                    "ingresosventas" => $ingresosVentas,
                    "ingresoscobranza" => $ingresosCobranza,
                    "gastosadmin" => 0,
                    "gastoscobranza" => 0,
                    "otrosgastos" => 0,
                    "total" => $total
                ]);

                \Log::info("Log 12");

                $view = view('administracion.poliza.listas.contenidopoliza',
                    array("idFranquicia" => $idFranquicia,
                        "idPoliza" => $idPoliza,
                        "polizaAnterior" => $polizaAnterior,
                        "poliza" => $poliza,
                        "ventas" => $ventas,
                        "gastosadmon" => null,
                        "gastosventas" => null,
                        "gastoscobranza" => null,
                        "otrosgastos" => null,
                        "ventasAsistente" => $ventasAsistente,
                        "productividad" => $productividad,
                        "productividadAsistente" => $productividadAsistente,
                        "cobranzatabla" => $cobranzatabla,
                        "fecha" => $fechaPoliza,
                        "totaldia" => $totaldia,
                        "totalingresocobranza" => $totalingresocobranza,
                        "ingresos" => $ingresos,
                        'productividadgasto' => $productividadgasto,
                        'usuarioscobranza' => $usuarioscobranza,
                        'historial' => $historial,
                        'totalUltimaPoliza' => $totalUltimaPoliza,
                        'ingresosVentas' => $ingresosVentas,
                        'ingresosCobranza' => $ingresosCobranza,
                        'ingresosAdmin' => 0,
                        'gastosAdmin' => null,
                        'gastosVentas' => null,
                        'gastosCobranza' => 0,
                        'gastoVentas' => 0,
                        'otrosGastos' => 0,
                        'total' => $total
                    ))->render();

            } catch (\Exception $e) {
                \Log::info("Error: " . $e);
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        }else {
            //Ver poliza

            try {

                $fechaLunes = $polizaGlobales::obtenerDia($hoyNumero, 1);  //Obtengo la fecha del dia lunes

                $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza' AND id_franquicia = '$idFranquicia'");

                $fechaPoliza = Carbon::parse($poliza[0]->created_at)->format('Y-m-d');
                $polizaAnterior = DB::select("SELECT id,total FROM poliza WHERE created_at >= '$fechaLunes' AND id_franquicia = '$idFranquicia' ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza de la semana actual.
                $ultimaPoliza = DB::select("SELECT * FROM poliza WHERE  id_franquicia = '$idFranquicia' AND STR_TO_DATE(created_at,'%Y-%m-%d') < STR_TO_DATE('$fechaPoliza','%Y-%m-%d') ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza sin importar si es de la semana actual o no.

                $sumaoficina = DB::select("SELECT coalesce(Sum(monto),0)  as suma from ingresosoficina WHERE id_poliza ='$idPoliza'");
                $gastosadmon = DB::select("SELECT * FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 0");
                $sumaadmin = DB::select("SELECT coalesce(Sum(monto),0)  as suma from gastos WHERE id_poliza = '$idPoliza' and tipogasto = 0");
                $gastosventas = DB::select("SELECT * FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 1");
                $sumaventas = DB::select("SELECT coalesce(Sum(monto),0)  as suma from gastos WHERE id_poliza = '$idPoliza' and tipogasto = 1");
                $gastoscobranza = DB::select("SELECT * FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 2");
                $sumacobranza = DB::select("SELECT coalesce(Sum(monto),0)  as suma from gastos WHERE id_poliza ='$idPoliza' and tipogasto = 2");
                $otrosgastos = DB::select("SELECT * FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 3");
                $sumaotros = DB::select("SELECT coalesce(Sum(monto),0)  as suma from gastos WHERE id_poliza = '$idPoliza' and tipogasto = 3");

                $ventas = DB::select("SELECT pvd.nombre,pvd.lunes,pvd.martes,pvd.miercoles,pvd.jueves,pvd.viernes,pvd.sabado,pvd.acumuladas,pvd.ingresosgotas,pvd.ingresosenganche,pvd.ingresospoliza,pvd.ingresosventas,pvd.ingresosventasacumulado,a.id_tipoasistencia as asistencia
                                                    FROM users u INNER JOIN polizaventasdias pvd ON u.id = pvd.id_usuario INNER JOIN asistencia a ON a.id_usuario = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '12' AND a.id_poliza = '$idPoliza' ORDER BY u.name");
                $ventasAsistente = DB::select("SELECT pvd.nombre,pvd.lunes,pvd.martes,pvd.miercoles,pvd.jueves,pvd.viernes,pvd.sabado,pvd.acumuladas,pvd.ingresosgotas,pvd.ingresosenganche,pvd.ingresospoliza,pvd.ingresosventas,pvd.ingresosventasacumulado,a.id_tipoasistencia as asistencia
                                                    FROM users u INNER JOIN polizaventasdias pvd ON u.id = pvd.id_usuario INNER JOIN asistencia a ON a.id_usuario = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '13' AND a.id_poliza = '$idPoliza' ORDER BY u.name");

                $productividad = DB::select("SELECT * FROM polizaproductividad pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '12' ORDER BY u.name");

                if($productividad != null) {
                    //Hay datos en productividad

                    foreach ($productividad as $product) {
                        //Recorrido de productividad por usuario
                        $arrayRespuesta = $polizaGlobales::obtenerNumeroContratosEntregadosAbonoAtrasadoLiquidadosConGarantiaPorPaqueteYContratosYSumaTotalRealContratosEntregadosPorUsuario($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario);
                        $arrayNumContratosPorPaquetes = $arrayRespuesta[0]; //Arreglo con el numero de contratos entregados por paquetes
                        $contratosEntregados = $arrayRespuesta[1]; //Todos los contratos entregados
                        $sumaTotalRealContratosEntregados = $arrayRespuesta[2]; //Suma de los totalReal de los contratos entregados

                        $product->totaleco = 0;
                        $product->totaljr = 0;
                        $product->totaldoradouno = 0;
                        $product->totaldoradodos = 0;
                        $product->totalplatino = 0;

                        if($arrayNumContratosPorPaquetes != null) {
                            //Arreglo con el numero de contratos entregados por paquetes contiene informacion

                            if(array_key_exists("1", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 1
                                $product->totaleco += $arrayNumContratosPorPaquetes['1'];
                            }
                            if(array_key_exists("2", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 2
                                $product->totaleco += $arrayNumContratosPorPaquetes['2'];
                            }
                            if(array_key_exists("3", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 3
                                $product->totaleco += $arrayNumContratosPorPaquetes['3'];
                            }
                            if(array_key_exists("4", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 4
                                $product->totaljr = $arrayNumContratosPorPaquetes['4'];
                            }
                            if(array_key_exists("5", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 5
                                $product->totaldoradouno = $arrayNumContratosPorPaquetes['5'];
                            }
                            if(array_key_exists("6", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 6
                                $product->totaldoradodos = $arrayNumContratosPorPaquetes['6'];
                            }
                            if(array_key_exists("7", $arrayNumContratosPorPaquetes)) {
                                //Existe llave con el paquete 7
                                $product->totalplatino = $arrayNumContratosPorPaquetes['7'];
                            }

                        }

                        $product->numeroventas = count($contratosEntregados); //numeroventas = Todos los contratos entregados
                        $product->contratosporentregar = $polizaGlobales::obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario, 0);
                        $product->montototalreal = $polizaGlobales::obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario, 1);
                        $product->montoentregadostotalreal = $sumaTotalRealContratosEntregados;

                        $arrayRespuestaObjetivoVentas = $polizaGlobales::obtenerDineroObjetivoEnVentas($contratosEntregados, $product->numeroventas, $product->totaleco, $product->totaljr, $product->totaldoradouno + $product->totaldoradodos, $product->totalplatino);
                        $product->dineroobjetivoventastreinta = $arrayRespuestaObjetivoVentas[0];
                        $product->dineroobjetivoventascuarenta = $arrayRespuestaObjetivoVentas[1];
                    }

                }

                $productividadAsistente = DB::select("SELECT * FROM polizaproductividad pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '13' ORDER BY u.name");

                if ($productividadAsistente != null) {
                    //Hay datos en productividadAsistente

                    foreach ($productividadAsistente as $productAsist) {
                        //Recorrido de productividadAsistente por usuario
                        $productAsist->numObjetivoSemanaAnterior = $polizaGlobales::obtenerNumeroObjetivoSemanaAnteriorAsistente($idFranquicia, $poliza[0]->created_at, $productAsist->id_usuario);
                        $arrayResultados = $polizaGlobales::obtenerNoVentasAprobadasVentasAcumuladasYVentasAcumuladasAprobadasAsistente($idFranquicia, $idPoliza, $poliza[0]->created_at, $productAsist->id_usuario);
                        $productAsist->sumaContratosNumVentas = $arrayResultados[0];
                        $productAsist->sumaContratosAprobadas = $arrayResultados[1];
                        $productAsist->sumaContratosVentasAcumuladas = $arrayResultados[2];
                        $productAsist->sumaContratosVentasAcumuladasAprobadas = $arrayResultados[3];
                    }

                }

                $cobranzatabla = DB::select("SELECT * FROM polizacobranza pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' ORDER BY u.name ");
                $totaldia = DB::select("SELECT SUM(ingresosventas) as ingreso FROM polizaventasdias WHERE id_poliza = '$idPoliza'");
                $totalingresocobranza = DB::select("SELECT SUM(ingresocobranza) as ingreso FROM polizacobranza WHERE id_poliza = '$idPoliza'");
                $ingresos = DB::select("SELECT * FROM ingresosoficina WHERE id_poliza = '$idPoliza'");
                $productividadgasto = DB::select("SELECT * FROM gastos WHERE id_poliza = '$idPoliza' AND tipogasto = 1");
                $usuarioscobranza = DB::select("SELECT u.id,u.name FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE rol_id = '4' AND uf.id_franquicia = '$idFranquicia'");
                $historial = DB::select("SELECT u.name,hc.cambios,hc.created_at FROM historialpoliza hc INNER JOIN users u ON u.id = hc.id_usuarioC WHERE id_poliza = '$idPoliza'");

                $totalUltimaPoliza = $ultimaPoliza == null ? 0 : $ultimaPoliza[0]->total;
                $ingresosAdmin = $poliza[0]->ingresosadmin == null ? 0 : $poliza[0]->ingresosadmin;
                $ingresosVentas = $poliza[0]->ingresosventas == null ? 0 : $poliza[0]->ingresosventas;
                $ingresosCobranza = $poliza[0]->ingresoscobranza == null ? 0 : $poliza[0]->ingresoscobranza;

                $gastosAdmin = $poliza[0]->gastosadmin == null ? 0 : $poliza[0]->gastosadmin;
                $gastosCobranza = $poliza[0]->gastoscobranza == null ? 0 : $poliza[0]->gastoscobranza;
                $otrosGastos = $poliza[0]->otrosgastos == null ? 0 : $poliza[0]->otrosgastos;
                $gastoVentas = $poliza[0]->gastosventas == null ? 0 : $poliza[0]->gastosventas;


                $total = (float)$totalUltimaPoliza + (float)$ingresosVentas + (float)$ingresosCobranza + (float)$ingresosAdmin - (float)$gastoVentas - (float)$gastosAdmin - (float)$gastosCobranza - (float)$otrosGastos;


                $view = view('administracion.poliza.listas.contenidopoliza',
                array("idFranquicia" => $idFranquicia,
                    "idPoliza" => $idPoliza,
                    "polizaAnterior" => $polizaAnterior,
                    "poliza" => $poliza,
                    "sumaoficina" => $sumaoficina,
                    "gastosadmon" => $gastosadmon,
                    "sumaadmin" => $sumaadmin,
                    "gastosventas" => $gastosventas,
                    "sumaventas" => $sumaventas,
                    "gastoscobranza" => $gastoscobranza,
                    "sumacobranza" => $sumacobranza,
                    "otrosgastos" => $otrosgastos,
                    "sumaotros" => $sumaotros,
                    "ventas" => $ventas,
                    "ventasAsistente" => $ventasAsistente,
                    "productividad" => $productividad,
                    "productividadAsistente" => $productividadAsistente,
                    "cobranzatabla" => $cobranzatabla,
                    "fecha" => $fechaPoliza,
                    "totaldia" => $totaldia,
                    "totalingresocobranza" => $totalingresocobranza,
                    "ingresos" => $ingresos,
                    'productividadgasto' => $productividadgasto,
                    'usuarioscobranza' => $usuarioscobranza,
                    'historial' => $historial,
                    'totalUltimaPoliza' => $totalUltimaPoliza,
                    'ingresosVentas' => $ingresosVentas,
                    'ingresosCobranza' => $ingresosCobranza,
                    'ingresosAdmin' => $ingresosAdmin,
                    'gastosAdmin' => $gastosAdmin,
                    'gastoVentas' => $gastoVentas,
                    'gastosCobranza' => $gastosCobranza,
                    'otrosGastos' => $otrosGastos,
                    'total' => $total
                ))->render();

            } catch (\Exception $e) {
                \Log::info("Error: " . $e);
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        }

        return response()->json(array("valid" => "true","view" => $view));

    }

    public function agregarObservacion($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 8)) {
            try {
                $usuarioId = Auth::user()->id;
                $actualizar = carbon::now();
                $obs = request('observaciones');
                $poli = DB::select("SELECT * FROM poliza WHERE id = $idPoliza ");
                $observaciones = $poli[0]->observaciones;

                if ($observaciones == null && $obs == null) {
                    return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('alerta', 'Favor de llenar el campo de observaciones');
                }
                if ($observaciones == null) {
                    DB::table('poliza')->where([['id', '=', $idPoliza], ['id_franquicia', '=', $idFranquicia]])->update([
                        'observaciones' => $obs
                    ]);
                    DB::table('historialpoliza')->insert([
                        'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $actualizar,
                        'cambios' => "Se agrego la siguiente observacion: '$obs'"
                    ]);
                } else {
                    DB::table('poliza')->where([['id', '=', $idPoliza], ['id_franquicia', '=', $idFranquicia]])->update([
                        'observaciones' => null
                    ]);
                    DB::table('historialpoliza')->insert([
                        'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $actualizar,
                        'cambios' => "Se elimino la siguiente observacion: '$obs'"
                    ]);
                }
                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'la observacion se actualizo correctamente de la poliza')->with('pestaña', 'general');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function terminarPoliza($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) { //Director,Principal,Administrador
            try {
                $existeLaPoliza = DB::select("SELECT id,estatus FROM poliza WHERE id_franquicia = '$idFranquicia' AND id = '$idPoliza'");
                \Log::info("POLIZA2:".$idPoliza);
                if($existeLaPoliza != null){
                    $polizaGlobales = new polizaGlobales();
                    try {
                        switch($existeLaPoliza[0]->estatus){
                            case 0://Valor por default cuando se crea la poliza
                                $polizaGlobales::entregarPoliza($idFranquicia,$idPoliza);
                                return back()->with('bien', 'El estatus de la poliza se actualizo correctamente.')->with('pestaña', 'general');
                            case 2://En este estatus el administrador ya no la puede editar y lo hace para avisarle al director que ya esta lista la poliza.
                                $entregarORegresar = $request->entregar; // 1 Poliza entregada , 2 Regresar la poliza a 0 para que puedan seguir agregando gastos,entradas,etc.
                                if($entregarORegresar != null ){
                                    if($entregarORegresar == 2){
                                        $polizaGlobales::entregarORegresarPoliza($idPoliza,$entregarORegresar);
                                        return back()->with('bien', 'El estatus de la poliza se actualizo correctamente.')->with('pestaña', 'general');
                                    }
                                    if( $entregarORegresar == 1 && (Auth::user()->rol_id) == 7){
                                        $polizaGlobales::entregarORegresarPoliza($idPoliza,$entregarORegresar);
                                        return back()->with('bien', 'El estatus de la poliza se actualizo correctamente.')->with('pestaña', 'general');
                                    }else{
                                        return back()->with('alerta', 'Solo un superior puede realizar esta accion.')->with('pestaña', 'general');
                                    }
                                }
                            break;
                        }
                        return back()->with('alerta', 'Accion no valida.')->with('pestaña', 'general');
                    }catch(\Exception $e){
                        \Log::info("Error:".$e);
                        return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                    }
                }
                return back()->with('error', 'No se encontro la poliza solicitada.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e);
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function ingresarOficina($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            $validacion = Validator::make($request->all(), [
                'descripcion' => 'required|string|max:255',
                'recibo' => 'required|string|max:255',
                'monto' => 'required|integer',
                'fotorecibo' => 'required|image|mimes:jpg'
            ]);
            if ($validacion->fails()) {
                return back()->withErrors([
                    'descripcion' => 'Campo obligatorio',
                    'recibo' => 'Campo obligatorio',
                    'monto' => 'Campo obligatorio',
                    'fotorecibo' => 'Campo obligatorio',

                ])->with('pestaña', 'oficina');
            }
            if (request('recibo') < 0) {
                return back()->withErrors(['recibo' => 'El recibo no puede ser menor a 0']);
            }

            if (request('monto') < 0) {
                return back()->withErrors(['monto' => 'El monto no puede ser menor a 0']);
            }
            try {

                $fotorecibo = "";
                if (request()->hasFile('fotorecibo')) {
                    $fotoBruta = 'Foto-Recibo-Poliza-' . $idPoliza . '-' . time() . '.' . request()->file('fotorecibo')->getClientOriginalExtension();
                    $fotorecibo = request()->file('fotorecibo')->storeAs('uploads/imagenes/polizas/fotorecibo', $fotoBruta, 'disco');
                }
                DB::table('ingresosoficina')->insert([
                    'id_poliza' => $idPoliza, 'descripcion' => request('descripcion'),
                    'numrecibo' => request('recibo'), 'monto' => request('monto'), 'foto' => $fotorecibo, 'created_at' => Carbon::now()
                ]);

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $polizaGlobales::calcularTotales($idFranquicia,$idPoliza);

                return back()->with('bien', 'El ingreso se agrego correctamente a la poliza')->with('pestaña', 'oficina');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function registrarAsistencia($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            $rules = [
                'optometrista' => 'required',
                'asistencia' => 'required|integer',
            ];
            if (request('optometrista') == "nada") {
                return back()->withErrors(['optometrista' => 'Favor de elegir una opcion'])->with('pestaña', 'ventas');
            }

            if (request('asistencia') == "nada") {
                return back()->withErrors(['asistencia' => 'Elegir el tipo de asistencia'])->with('pestaña', 'ventas');
            }
            request()->validate($rules);
            try {
                $poliza = DB::select("SELECT * from poliza WHERE id = '$idPoliza' AND id_franquicia = '$idFranquicia'");
                $optos = request('optometrista');
                $asistencia = request('asistencia');
                $username2 = DB::select("SELECT * from users WHERE id = '$optos'");
                if ($optos != 0) {
                    $username = $username2[0]->name;
                }
                $now = carbon::now();
                $usuarioId = Auth::user()->id;
                $nowparce = $poliza[0]->created_at;
                if ($optos == '0') {
                    DB::update("UPDATE asistencia
                SET id_tipoasistencia = $asistencia
                WHERE id_poliza = '$idPoliza' AND created_at ='$nowparce'");

                    DB::table('historialpoliza')->insert([
                        'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $now,
                        'cambios' => "Se agrego asistencia para todos"
                    ]);
                    return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'Se agrego la asistencia correctamente a la poliza')->with('pestaña', 'ventas');
                }
                DB::update("UPDATE asistencia
                SET id_tipoasistencia = $asistencia
                WHERE id_poliza = '$idPoliza' AND created_at ='$nowparce'
                AND id_usuario = $optos");
                if ($asistencia == 1) {
                    $asisten = 'ASISTENCIA';
                } elseif ($asistencia == 2) {
                    $asisten = 'RETARDO';
                } else {
                    $asisten = 'FALTA';
                }
                DB::table('historialpoliza')->insert([
                    'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $now,
                    'cambios' => "Se registro '$asisten' para el usuario '$username'"
                ]);
                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'Se agrego la asistencia correctamente a la poliza')->with('pestaña', 'ventas');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function ingresarGasto($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            $validacion = Validator::make($request->all(), [
                'descripcion2' => 'required|string|max:255',
                'factura' => 'required|string|max:255',
                'monto2' => 'required|integer',
                'tipogasto' => 'required|integer',
                'fotofactura' => 'required|image|mimes:jpg'

            ]);
            if ($validacion->fails()) {
                return back()->withErrors([
                    'descripcion2' => 'Campo obligatorio',
                    'factura' => 'Campo obligatorio',
                    'monto2' => 'Campo obligatorio',
                    'tipogasto' => 'Campo obligatorio',
                    'fotofactura' => 'Campo obligatorio',
                ])->with('pestaña', 'gastos');
            }
            if (request('factura') < 0) {
                return back()->withErrors(['factura' => 'El numero de factura no puede ser menor a 0'])->with('pestaña', 'gastos');
            }
            if (request('monto2') < 0) {
                return back()->withErrors(['monto2' => 'El monto no puede ser menor a 0'])->with('pestaña', 'gastos');
            }
            try {

                $fotofactura = "";
                if (request()->hasFile('fotofactura')) {
                    $fotoBruta = 'Foto-factura-Poliza-' . $idPoliza . '-' . time() . '.' . request()->file('fotofactura')->getClientOriginalExtension();
                    $fotofactura = request()->file('fotofactura')->storeAs('uploads/imagenes/polizas/fotofactura', $fotoBruta, 'disco');
                }
                DB::table('gastos')->insert([
                    'id_poliza' => $idPoliza, 'descripcion' => request('descripcion2'),
                    'factura' => request('factura'), 'observaciones' => request('observaciones'), 'monto' => request('monto2'), 'foto' => $fotofactura, 'tipogasto' => request('tipogasto'), 'created_at' => Carbon::now()
                ]);

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $polizaGlobales::calcularTotales($idFranquicia,$idPoliza);


                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'El Gasto se agrego correctamente a la poliza')->with('pestaña', 'gastos');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function ingresarCobranza($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            $validacion = Validator::make($request->all(), [
                'cantidad' => 'required|string|max:255',
            ]);
            if ($validacion->fails()) {
                return back()->withErrors([
                    'cantidad' => 'Campo obligatorio',
                ])->with('pestaña', 'cobranza');
            }
            if (request('cantidad') < 0) {
                return back()->withErrors(['cantidad' => 'La cantidad no puede ser menor a 0'])->with('pestaña', 'cobranza');
            }
            if (request('usuario') == 'nada') {
                return back()->withErrors(['usuario' => 'Usuario obligatorio'])->with('pestaña', 'cobranza');
            }
            if (request('tipo') == 'nada') {
                return back()->withErrors(['tipo' => 'El tipo debe ser obligatorio'])->with('pestaña', 'cobranza');
            }
            try {
                $actualizar = carbon::now();
                $usuarioId = Auth::user()->id;
                $user = request('usuario');
                $tipo = request('tipo');
                $cantidad = request('cantidad');
                $tipocobranza = DB::select("SELECT * from tipocobranza WHERE id_poliza = '$idPoliza' AND id_franquicia = '$idFranquicia' AND id_usuario = '$user' AND tipo = '$tipo'");
                $tipocobranza2 = DB::select("SELECT * from gastos WHERE id_poliza = '$idPoliza' AND id_usuario = '$user'");
                $zona = DB::select("SELECT u.id, z.zona from users u inner join zonas z on u.id_zona = z.id WHERE u.id = '$user'");
                $zonauser = $zona[0]->zona;

                if ($tipocobranza == null) {
                    DB::table('tipocobranza')->insert([
                        'id_poliza' => $idPoliza, 'cantidad' => $cantidad, 'id_franquicia' => $idFranquicia,
                        'id_usuario' => $user, 'tipo' => $tipo, 'created_at' => Carbon::now()
                    ]);

                    if ($tipo == 3) {
                        DB::table('gastos')->insert([
                            'id_poliza' => $idPoliza, 'descripcion' => 'GASOLINA-ZONA ' . $zonauser, 'monto' => $cantidad, 'tipogasto' => 2, 'pertenencia' => 2, 'id_usuario' => $user, 'created_at' => Carbon::now()
                        ]);
                    }
                    return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'El registro de cobranza se agrego a la poliza')->with('pestaña', 'cobranza');
                } else {
                    $tipocobranzaid = $tipocobranza[0]->id;
                    $gastoid = $tipocobranza2[0]->id;
                    DB::table('tipocobranza')->where([['id', '=', $tipocobranzaid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'cantidad' => $cantidad, 'updated_at' => $actualizar
                    ]);
                    DB::table('gastos')->where([['id', '=', $gastoid], ['id_poliza', '=', $idPoliza]])->update([
                        'monto' => $cantidad, 'updated_at' => $actualizar
                    ]);
                    DB::table('historialpoliza')->insert([
                        'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $actualizar,
                        'cambios' => "Se Cambio la cantiddad por: '$cantidad' al registro: '$tipocobranzaid'"
                    ]);
                }

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $polizaGlobales::calcularTotales($idFranquicia,$idPoliza);

                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'El registro de cobranza se actualizo correctamente')->with('pestaña', 'cobranza');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function ingresarProductividadG($idFranquicia, $idPoliza, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'trasporte' => 'required|string|max:255',
                'salieron' => 'required|integer',
            ];
            if (request('salieron') < 1) {
                return back()->withErrors(['salieron' => 'El numero de salientes no puede ser menor a 1']);
            }
            if (request('trasporte') < 0) {
                return back()->withErrors(['trasporte' => 'la cantidad de trasporteno puede ser menor a 0']);
            }
            request()->validate($rules);
            try {

                DB::table('gastos')->insert([
                    'id_poliza' => $idPoliza, 'descripcion' => 'PASAJE VENTAS', 'monto' => request('trasporte'), 'salieron' => request('salieron'),
                    'tipogasto' => 1, 'pertenencia' => 1, 'created_at' => Carbon::now()
                ]);

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $polizaGlobales::calcularTotales($idFranquicia,$idPoliza);

                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'El Gasto se agrego correctamente a la poliza')->with('pestaña', 'productividad');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function eliminarGasto($idFranquicia, $idPoliza, $idGasto, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            try {
                $usuarioId = Auth::user()->id;
                $actualizar = carbon::now();
                $existenteGasto = DB::select("SELECT * FROM gastos WHERE id = $idGasto");
                if ($existenteGasto == null) {
                    return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('alerta', 'El Gasto que deseas eliminar ya no existe')->with('pestaña', 'gastos');
                }
                $poli = DB::select("SELECT monto, factura, observaciones, pertenencia, foto, id_usuario FROM gastos WHERE id_poliza = $idPoliza AND id = '$idGasto'");
                $monto2 = $poli[0]->monto;
                $pertenencia = $poli[0]->pertenencia;
                $factura = $poli[0]->factura;
                $observaciones = $poli[0]->observaciones;
                $usuario = $poli[0]->id_usuario;
                Storage::disk('disco')->delete($poli[0]->foto);
                DB::delete("DELETE FROM gastos WHERE id = '$idGasto' AND id_poliza = '$idPoliza'");

                if ($pertenencia == 2) {
                    DB::delete("DELETE FROM tipocobranza WHERE id_usuario = '$usuario' AND id_poliza = '$idPoliza'");
                }

                DB::table('historialpoliza')->insert([
                    'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $actualizar,
                    'cambios' => " Se elimino el gasto: '$idGasto' de la poliza: '$idPoliza' con monto: $'$monto2' numero de factura : '$factura' y con las siguientes observaciones: '$observaciones'"
                ]);

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $polizaGlobales::calcularTotales($idFranquicia,$idPoliza);


                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'El Gasto se elimino correctamente de la poliza')->with('pestaña', 'gastos');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function eliminarOficina($idFranquicia, $idPoliza, $idOficina, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {
            try {
                $usuarioId = Auth::user()->id;
                $actualizar = carbon::now();
                $existenteOficina = DB::select("SELECT * FROM ingresosoficina WHERE id = $idOficina");
                if ($existenteOficina == null) {
                    return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('alerta', 'El ingreso de oficina que deseas eliminar ya no existe')->with('pestaña', 'oficina');
                }
                $poli = DB::select("SELECT id_poliza, descripcion, numrecibo, monto, foto FROM ingresosoficina WHERE id_poliza = $idPoliza AND id = '$idOficina'");
                $monto2 = $poli[0]->monto;
                $numrecibo = $poli[0]->numrecibo;
                $descripcion = $poli[0]->descripcion;
                Storage::disk('disco')->delete($poli[0]->foto);
                DB::delete("DELETE FROM ingresosoficina WHERE id = '$idOficina' AND id_poliza = '$idPoliza'");

                DB::table('historialpoliza')->insert([
                    'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $actualizar,
                    'cambios' => " Se elimino el ingreso de oficina: '$idOficina' de la poliza: '$idPoliza' con monto: $'$monto2' numero de recibo : '$numrecibo' y con las siguiente descripcion: '$descripcion'"
                ]);

                $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales
                $polizaGlobales::calcularTotales($idFranquicia,$idPoliza);


                return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'El ingreso de oficna se elimino correctamente de la poliza')->with('pestaña', 'oficina');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function tablaAsistencia($idSucursal, $idPoliza)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //ADMINISTRADORES
        {
            $franquiciaPoliza = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idSucursal'");
            $listaAsistencia = DB::select("SELECT u.id,u.name,a.id_tipoasistencia,a.created_at,a.updated_at FROM asistencia a INNER JOIN users u ON a.id_usuario = u.id where id_poliza = '$idPoliza' order by u.name");
            $usuarios = DB::select("SELECT u.id,u.name FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.rol_id != 7 AND uf.id_franquicia = '$idSucursal' ORDER BY u.name");
            return view('administracion.poliza.tablaasistencia', ['idFranquicia' => $idSucursal, "idPoliza" => $idPoliza, "listaAsistencia" => $listaAsistencia, 'franquiciaPoliza' => $franquiciaPoliza, "usuarios" => $usuarios]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function registrarAsistenciaTabla($idFranquicia, $idPoliza)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //ADMINISTRADORES
        {
            $rules = [
                'usuario' => 'required|integer',
                'asistencia' => 'required|integer'
            ];
            request()->validate($rules);
            $usuario = request("usuario");
            $asistencia = request("asistencia");
            if ($usuario == 0) {
                DB::table("asistencia")->where('id_poliza', '=', $idPoliza)->update([
                    "id_tipoasistencia" => $asistencia,
                    "updated_at" => Carbon::now()
                ]);
                return back()->with("bien", "La asistencia se modifico correctamente.");
            } else {
                $existeUsuario = DB::select("SELECT id FROM asistencia WHERE id = '$usuario' AND id_poliza = '$idPoliza'");
                if (!is_null($existeUsuario)) {
                    if ($asistencia == 0 || $asistencia == 1 || $asistencia == 2) {
                        DB::table("asistencia")->where("id_usuario", "=", $usuario)->where('id_poliza', '=', $idPoliza)->update([
                            "id_tipoasistencia" => $asistencia,
                            "updated_at" => Carbon::now()
                        ]);
                        return back()->with("bien", "La asistencia se modifico correctamente.");
                    }
                    return back()->with("alerta", "Valor no valido para la asistencia.");
                }
                return back()->with("alerta", "No se encontro el usuario.");
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function asistenciaIndividual($idFranquicia, $idPoliza)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //ADMINISTRADORES
        {

            $usuario = request('usuario');

            if ($usuario != null) {

                $usuarioExiste = DB::select("SELECT u.id,u.foto,u.name,u.rol_id FROM users u INNER JOIN asistencia a ON a.id_usuario = u.id WHERE u.codigoasistencia = '$usuario'");
                if ($usuarioExiste != null) {

                    $ahora = Carbon::now()->format('H:i:s');
                    $controlentradasalidausuario = DB::select("SELECT horaini, horafin FROM controlentradasalidausuario WHERE id_usuario = '" . $usuarioExiste[0]->id . "'");

                    if($controlentradasalidausuario != null) {

                        $asistencia = 1;

                        $retardoInicio = $controlentradasalidausuario[0]->horaini;
                        $retardoFin = $controlentradasalidausuario[0]->horafin;
                        if ($ahora >= $retardoInicio && $ahora <= $retardoFin) {
                            $asistencia = 2;
                        } else if ($ahora > $retardoFin) {
                            $asistencia = 0;
                        }

                        DB::table("asistencia")->where("id_usuario", "=", $usuarioExiste[0]->id)->where("id_poliza", "=", $idPoliza)->update([
                            "id_tipoasistencia" => $asistencia,
                            "updated_at" => Carbon::now()
                        ]);

                        return view('administracion.poliza.asistenciaindividual', ['idFranquicia' => $idFranquicia, "idPoliza" => $idPoliza, "usuario" => $usuarioExiste, "asistencia" => $asistencia]);

                    }

                }

            }
            return view('administracion.poliza.asistenciaindividual', ['idFranquicia' => $idFranquicia, "idPoliza" => $idPoliza]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function polizaactualizarasisoptocobranza($idFranquicia, $idPoliza, $idUsuario)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 8)) //ADMINISTRADORES
        {

            try {

                $usuarioId = Auth::user()->id;
                $actualizar = carbon::now();
                $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza'");
                if ($poliza != null) {
                    //Existe poliza

                    if($poliza[0]->estatus == 0) {
                        //Estatus de la poliza es NO TERMINADA

                        $usuario = DB::select("SELECT * FROM users WHERE id = '$idUsuario'");

                        if ($usuario != null) {
                            //Existe el usuario

                            $rol_id = $usuario[0]->rol_id;
                            $name = $usuario[0]->name;

                            $hoy = Carbon::now();
                            //$hoy = Carbon::parse("2022-06-23");
                            $hoyNumero = $hoy->dayOfWeekIso;

                            $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales

                            $fechaLunes = $polizaGlobales::obtenerDia($hoyNumero, 1);  //Obtengo la fecha del dia lunes
                            $polizaAnterior = DB::select("SELECT id,total FROM poliza WHERE created_at >= '$fechaLunes' AND id_franquicia = '$idFranquicia' AND id != '$idPoliza' ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza de la semana actual.
                            $polizaAnteriorId = $polizaAnterior == null ? "" : $polizaAnterior[0]->id;

                            switch ($rol_id) {
                                case 4:
                                    //Cobranza
                                    $id_zona = $usuario[0]->id_zona;

                                    $abonos = DB::select("SELECT *
                                                        FROM abonos a
                                                        WHERE a.id_contrato IN (
                                                        SELECT c.id
                                                        FROM contratos c
                                                        WHERE a.id_franquicia = '$idFranquicia'
                                                        AND a.poliza IS NULL
                                                        AND c.id_zona = '$id_zona')");

                                    if($abonos != null) {
                                        //Existen abonos a actualizar
                                        foreach ($abonos as $abono) {
                                            $idAbono = $abono->id;
                                            $indice = $abono->indice;
                                            DB::update("UPDATE abonos
                                                                SET poliza  = '$idPoliza'
                                                                WHERE id_franquicia = '$idFranquicia'
                                                                AND id = '$idAbono'
                                                                AND indice = '$indice'");//Actualizamos todos los abonos
                                        }
                                    }

                                    $polizaGlobales::calculoDeCobranza($idFranquicia, $idPoliza, $polizaAnteriorId, $idUsuario);

                                    break;
                                case 12:
                                    //Optometrista

                                    //Eliminar datos de la tabla polizaventasdias de igual manera se van a volver a insertar
                                    DB::delete("DELETE FROM polizaventasdias
                                                    WHERE id_poliza = '$idPoliza'
                                                    AND id_franquicia = '$idFranquicia'
                                                    AND id_usuario = '$idUsuario'");

                                    //Eliminar datos de la tabla polizaproductividad de igual manera se van a volver a insertar
                                    DB::delete("DELETE FROM polizaproductividad
                                                    WHERE id_poliza = '$idPoliza'
                                                    AND id_franquicia = '$idFranquicia'
                                                    AND id_usuario = '$idUsuario'");

                                    //Actualizamos todos los contratos
                                    DB::update("UPDATE contratos SET poliza = '$idPoliza'
                                                    WHERE id_franquicia = '$idFranquicia'
                                                    AND estatus_estadocontrato IN (2,4,5,7,10,11,12)
                                                    AND datos = '1'
                                                    AND poliza IS NULL
                                                    AND id_optometrista = '$idUsuario'");

                                    $ventasOptos = $polizaGlobales::calculosVentasOptos($idFranquicia, $idPoliza, $polizaAnteriorId, $idUsuario); //Obtenemos las ventas de Optometristas
                                    $productividadOptos = $polizaGlobales::calculoProductividadOptos($idFranquicia, $idPoliza, $polizaAnteriorId, $idUsuario); //Obetenemos la productividad de Optos

                                    foreach ($ventasOptos as $ventaOpto) {
                                        $idOpto = $ventaOpto->id;
                                        $nombreOpto = $ventaOpto->name;
                                        $acumuladas = $ventaOpto->acumuladas;
                                        $diaActual = $ventaOpto->diaActual;
                                        $acumuladasTotal = $diaActual + $acumuladas;
                                        $ingresosGotas = $ventaOpto->gotas;
                                        $ingresoEnganche = $ventaOpto->enganche;
                                        $ingresoPoliza = $ventaOpto->polizas;
                                        $ingresosVentas = ($ingresoPoliza == null ? 0 : $ingresoPoliza) + ($ingresoEnganche == null ? 0 : $ingresoEnganche) + ($ingresosGotas == null ? 0 : $ingresosGotas);
                                        $ingresosVentasAcumuladas = $ingresosVentas + ($ventaOpto->ingresosventasacumulado == null ? 0 : $ventaOpto->ingresosventasacumulado);


                                        $ventasOptosQuery = $polizaGlobales::obtenerQueryVentasOptos($hoyNumero, $diaActual, $idFranquicia, $idOpto);
                                        $query = "INSERT INTO polizaventasdias (id,id_franquicia,id_usuario,rol,id_poliza,fechapoliza,fechapolizacierre,nombre,lunes,martes,miercoles,jueves,viernes,sabado,acumuladas,asistencia,ingresosgotas,ingresosenganche,ingresospoliza,totaldia,ingresosventas,ingresosventasacumulado)
                                        VALUES(null,'$idFranquicia','$idOpto','12','$idPoliza','$hoy',null,'$nombreOpto'," . $ventasOptosQuery . ",'$acumuladasTotal',null,'$ingresosGotas','$ingresoEnganche','$ingresoPoliza',null,'$ingresosVentas','$ingresosVentasAcumuladas')";

                                        DB::insert($query);
                                    }

                                    foreach ($productividadOptos as $productividadOpto) {
                                        $idOpto = $productividadOpto->ID;
                                        $sueldo = $productividadOpto->SUELDO;
                                        $ECOJRANT = $productividadOpto->ECOJRANT == null ? 0 : $productividadOpto->ECOJRANT;
                                        $ECOJR = $productividadOpto->ECOJR == null ? 0 : $productividadOpto->ECOJR;
                                        $totalEcoAcu = $ECOJRANT + $ECOJR;
                                        $JUNIORANT = $productividadOpto->JUNIORANT == null ? 0 : $productividadOpto->JUNIORANT;
                                        $JUNIOR = $productividadOpto->JUNIOR == null ? 0 : $productividadOpto->JUNIOR;
                                        $totalJrAcu = $JUNIORANT + $JUNIOR;
                                        $DORADOUNOANT = $productividadOpto->DORADOUNOANT == null ? 0 : $productividadOpto->DORADOUNOANT;
                                        $DORADOUNO = $productividadOpto->DORADOUNO == null ? 0 : $productividadOpto->DORADOUNO;
                                        $totalDoradoAcu = $DORADOUNOANT + $DORADOUNO;
                                        $DORADODOSANT = $productividadOpto->DORADODOSANT == null ? 0 : $productividadOpto->DORADODOSANT;
                                        $DORADODOS = $productividadOpto->DORADODOS == null ? 0 : $productividadOpto->DORADODOS;
                                        $totalDoradoDosAcu = $DORADODOSANT + ($DORADODOS == 0 ? $DORADODOS : ($DORADODOS / 2));
                                        $PLATINOANT = $productividadOpto->PLATINOANT == null ? 0 : $productividadOpto->PLATINOANT;
                                        $PLATINO = $productividadOpto->PLATINO == null ? 0 : $productividadOpto->PLATINO;

                                        $totalPlatinoAcu = $PLATINOANT + $PLATINO;
                                        $numeroVentas = $totalEcoAcu + $totalJrAcu + $totalDoradoAcu + $totalDoradoDosAcu + $totalPlatinoAcu;
                                        $productividad = ($numeroVentas * 100) / 30;
                                        $insumos = ($productividadOpto->INSUMOS == null ? 0 : $productividadOpto->INSUMOS) * $numeroVentas;

                                        DB::table("polizaproductividad")->insert([
                                            "id_franquicia" => $idFranquicia,
                                            "id_poliza" => $idPoliza,
                                            "id_usuario" => $idOpto,
                                            "sueldo" => $sueldo,
                                            "totaleco" => $totalEcoAcu,
                                            "totaljr" => $totalJrAcu,
                                            "totaldoradouno" => $totalDoradoAcu,
                                            "totaldoradodos" => $totalDoradoDosAcu,
                                            "totalplatino" => $totalPlatinoAcu,
                                            "numeroventas" => $numeroVentas,
                                            "productividad" => $productividad,
                                            "insumos" => $insumos
                                        ]);

                                    }

                                    break;
                                case 13:
                                    //Asistente

                                    //Eliminar datos de la tabla polizaventasdias de igual manera se van a volver a insertar
                                    DB::delete("DELETE FROM polizaventasdias
                                                    WHERE id_poliza = '$idPoliza'
                                                    AND id_franquicia = '$idFranquicia'
                                                    AND id_usuario = '$idUsuario'");

                                    //Eliminar datos de la tabla polizaproductividad de igual manera se van a volver a insertar
                                    DB::delete("DELETE FROM polizaproductividad
                                                    WHERE id_poliza = '$idPoliza'
                                                    AND id_franquicia = '$idFranquicia'
                                                    AND id_usuario = '$idUsuario'");

                                    //Actualizamos todos los contratos
                                    DB::update("UPDATE contratos SET poliza = '$idPoliza'
                                                    WHERE id_franquicia = '$idFranquicia'
                                                    AND estatus_estadocontrato IN (2,4,5,7,10,11,12)
                                                    AND datos = '1'
                                                    AND poliza IS NULL
                                                    AND id_usuariocreacion = '$idUsuario'");

                                    $ventasAsis = $polizaGlobales::calculosVentasAsis($idFranquicia, $idPoliza, $polizaAnteriorId, $idUsuario); //Obtenemos las ventas de Asistentes
                                    $productividadAsis = $polizaGlobales::calculoProductividadAsis($idFranquicia, $idPoliza, $polizaAnteriorId, $idUsuario); //Optenemos la productividad de Asis

                                    foreach ($ventasAsis as $ventaAsis) {
                                        $idOpto = $ventaAsis->id;
                                        $nombreOpto = $ventaAsis->name;
                                        $acumuladas = $ventaAsis->acumuladas;
                                        $diaActual = $ventaAsis->diaActual;
                                        $asistencia = $ventaAsis->asistencia;
                                        $acumuladasTotal = $diaActual + $acumuladas;
                                        $ingresosGotas = 0;
                                        $ingresoEnganche = 0;
                                        $ingresoPoliza = 0;
                                        $ingresosVentas = 0;
                                        $ingresosVentasAcumuladas = 0;

                                        $ventasOptosQuery = $polizaGlobales::obtenerQueryVentasOptos($hoyNumero, $diaActual, $idFranquicia, $idOpto);
                                        $query = "INSERT INTO polizaventasdias (id,id_franquicia,id_usuario,rol,id_poliza,fechapoliza,fechapolizacierre,nombre,lunes,martes,miercoles,jueves,viernes,sabado,acumuladas,asistencia,ingresosgotas,ingresosenganche,ingresospoliza,totaldia,ingresosventas,ingresosventasacumulado)
                                        VALUES(null,'$idFranquicia','$idOpto','12','$idPoliza','$hoy',null,'$nombreOpto'," . $ventasOptosQuery . ",'$acumuladasTotal',null,'$ingresosGotas','$ingresoEnganche','$ingresoPoliza',null,'$ingresosVentas','$ingresosVentasAcumuladas')";
                                        DB::insert($query);
                                    }

                                    foreach ($productividadAsis as $productividadAsi) {
                                        $idAsis = $productividadAsi->ID;
                                        $sueldo = $productividadAsi->SUELDO;
                                        $ECOJRANT = $productividadAsi->ECOJRANT == null ? 0 : $productividadAsi->ECOJRANT;
                                        $ECOJR = $productividadAsi->ECOJR == null ? 0 : $productividadAsi->ECOJR;
                                        $totalEcoAcu = $ECOJRANT + $ECOJR;
                                        $JUNIORANT = $productividadAsi->JUNIORANT == null ? 0 : $productividadAsi->JUNIORANT;
                                        $JUNIOR = $productividadAsi->JUNIOR == null ? 0 : $productividadAsi->JUNIOR;
                                        $totalJrAcu = $JUNIORANT + $JUNIOR;
                                        $DORADOUNOANT = $productividadAsi->DORADOUNOANT == null ? 0 : $productividadAsi->DORADOUNOANT;
                                        $DORADOUNO = $productividadAsi->DORADOUNO == null ? 0 : $productividadAsi->DORADOUNO;
                                        $totalDoradoAcu = $DORADOUNOANT + $DORADOUNO;
                                        $DORADODOSANT = $productividadAsi->DORADODOSANT == null ? 0 : $productividadAsi->DORADODOSANT;
                                        $DORADODOS = $productividadAsi->DORADODOS == null ? 0 : $productividadAsi->DORADODOS;
                                        $totalDoradoDosAcu = $DORADODOSANT + ($DORADODOS == 0 ? $DORADODOS : ($DORADODOS / 2));
                                        $PLATINOANT = $productividadAsi->PLATINOANT == null ? 0 : $productividadAsi->PLATINOANT;
                                        $PLATINO = $productividadAsi->PLATINO == null ? 0 : $productividadAsi->PLATINO;
                                        $totalPlatinoAcu = $PLATINOANT + $PLATINO;
                                        $numeroVentas = $totalEcoAcu + $totalJrAcu + $totalDoradoAcu + $totalDoradoDosAcu + $totalPlatinoAcu;
                                        $productividad = ($numeroVentas * 100) / 10;
                                        $insumos = $productividadAsi->INSUMOS == null ? 0 : $productividadAsi->INSUMOS;

                                        DB::table("polizaproductividad")->insert([
                                            "id_franquicia" => $idFranquicia,
                                            "id_poliza" => $idPoliza,
                                            "id_usuario" => $idAsis,
                                            "sueldo" => $sueldo,
                                            "totaleco" => $totalEcoAcu,
                                            "totaljr" => $totalJrAcu,
                                            "totaldoradouno" => $totalDoradoAcu,
                                            "totaldoradodos" => $totalDoradoDosAcu,
                                            "totalplatino" => $totalPlatinoAcu,
                                            "numeroventas" => $numeroVentas,
                                            "productividad" => $productividad,
                                            "insumos" => $insumos
                                        ]);
                                    }

                                    break;
                            }

                            //Actualizar ingresosventas e ingresoscobranza
                            $totaldia = DB::select("SELECT SUM(ingresosventas) as ingreso FROM polizaventasdias WHERE id_poliza = '$idPoliza'");
                            $totalingresocobranza = DB::select("SELECT SUM(ingresocobranza) as ingreso FROM polizacobranza WHERE id_poliza = '$idPoliza'");

                            $ingresosVentas = $totaldia[0]->ingreso == null ? 0 : $totaldia[0]->ingreso;
                            $ingresosCobranza = $totalingresocobranza[0]->ingreso == null ? 0 : $totalingresocobranza[0]->ingreso;

                            DB::table("poliza")->where("id", "=", $idPoliza)->where("id_franquicia", "=", $idFranquicia)->update([
                                "ingresosventas" => $ingresosVentas,
                                "ingresoscobranza" => $ingresosCobranza
                            ]);

                            //Guardar en historialpoliza
                            DB::table('historialpoliza')->insert([
                                'id_usuarioC' => $usuarioId, 'id_poliza' => $idPoliza, 'created_at' => $actualizar,
                                'cambios' => "Se actualizo la poliza con el usuario: " . $name
                            ]);

                            return redirect()->route('verpoliza', ['idFranquicia' => $idFranquicia, 'idPoliza' => $idPoliza])->with('bien', 'Se actualizo correctamente la poliza')->with('pestaña', 'general');

                        }

                        return back()->with('alerta', 'El usuario no existe.');

                    }

                    return back()->with('alerta', 'No se puede actualizar la poliza por que estatus es diferente a NO TERMINADA.');

                }

                return back()->with('alerta', 'La poliza no existe.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

}
