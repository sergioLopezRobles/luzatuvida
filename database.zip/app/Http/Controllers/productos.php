<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class productos extends Controller
{
    
    public function listaproductos(){
        
    }

}
