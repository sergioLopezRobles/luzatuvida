<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class promociones extends Controller
{
    public function nuevapromoarmazones($idFranquicia){
			if(Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6))
			{
				request()->validate([                            
					// 'titulo'=>'required|string|max:255',  
					// 'numero'=>'required|integer|min:1'				
				]); 	
				$franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
				return view('administracion.franquicia.administracion.promociones.nuevaarmazon',['franquiciaAdmin' => $franquiciaAdmin,'idFranquicia' => $idFranquicia,'titulo'=>request('titulo'),'numero' => request('numero')]);   
			}else{
				if (Auth::check()) {
						return redirect()->route('redireccionar');
				}else{
						return redirect()->route('login');
				}
			} 
    }

	public function promocionnueva($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) 
        {            
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.nuevapromocion',['idFranquicia' => $idFranquicia,'franquiciaAdmin' => $franquiciaAdmin]);   
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function promocioncrear($idFranquicia, Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) 
        {        		
            $rules = [
            'titulo'=>'required|string|max:255',                 
       
            'inicio'=>'required|string|max:255',
            'fin'=>'required|string|max:255'
            // 'tipopromo'=>'required|integer',  
        ];
        $ini = request('inicio');
        $fin = request('fin');
        if ($ini > $fin){
            return back()->withErrors(['inicio' => 'La fecha inicial debe ser menor que la final'])->withInput($request->all());
        }
        if (request('cantidad') > 100){
            return back()->withErrors(['cantidad' => 'No puede ser mayor a 100 la cantidad'])->withInput($request->all());
        }
        if (request('tipopromocion') == 1 && request('cantidad') != null){
            return back()->withErrors(['cantidad' => 'No se puede elegir si se selecciono por la opción por precio'])->withInput($request->all());
        }
        if (request('preciouno') == null && request('cantidad') == null){
            return back()->withErrors(['cantidad' => 'Elegir al menos una opcion de descuento'])->withInput($request->all());
        }
        if (request('preciouno') != null && request('cantidad') != null){
            return back()->withErrors(['cantidad' => 'Solo puedes elegir una opción de descuento'])->withInput($request->all());
        }
        if (request('preciouno') != null && request('tipopromocion') != 1){
            return back()->withErrors(['preciouno' => 'Solo permitido con la opcion seleccionada de por precio'])->withInput($request->all());
        }
        if (request('cantidad') < 0){
            return back()->withErrors(['cantidad' => 'No puede ser menor a 0'])->withInput($request->all());
        }
        if (request('armazones') < 1){
            return back()->withErrors(['armazones' => 'No puede ser menor a 1'])->withInput($request->all());
        }
            request()->validate($rules); 		
            try{   
                $estado = 0;
                if(!is_null(request('administrador'))){
                    if(request('administrador') == 1){
                        $estado = 1;
                    }else{
                        $estado = 0;
                    }
                } 

                $fijo = 0;
                if(!is_null(request('tipopromocion'))){
                    if(request('tipopromocion') == 1){
                        $fijo = 1;
                    }else{
                        $fijo = 0;
                    }
                } 
                
                DB::table('promocion')->insert([
                    'id_franquicia' => $idFranquicia,'titulo' => request('titulo'),'armazones' => request('armazones'),'id_tipopromocionusuario' => $estado, 
                    'contado' => $estado, 'preciouno' => request('preciouno'), 'tipopromocion' => $fijo,
                    'precioP' => request('cantidad'),'inicio'=> request('inicio'),'fin'=> request('fin'), 'status' => 1,'created_at' => Carbon::now()
                ]);
                
                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','La promoción se creo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');           
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

	public function promocionactualizar($idFranquicia,$idPromocion){
        if(Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) 
        {
            $promocion = DB::select("SELECT * FROM promocion WHERE id_franquicia = '$idFranquicia' AND id = '$idPromocion'");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.actualizarpromocion',['idFranquicia' => $idFranquicia,'promocion'=>$promocion, 'franquiciaAdmin'=>$franquiciaAdmin]);   
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

	public function promocioneditar($idFranquicia,$idPromocion, Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) 
        {        
			$rules = [                            
                'titulo'=>'required|string|max:255',                  
                'inicio'=>'required|string|max:255',
                'fin'=>'required|string|max:255',         
            ]; 
            $now = Carbon::now();
            $ini = request('inicio');
            $fin = request('fin');
            if ($ini > $fin){
                return back()->withErrors(['inicio' => 'La fecha inicial debe ser menor que la final.'])->withInput($request->all());
            }
            if (request('cantidad') > 100){
                return back()->withErrors(['cantidad' => 'Debe ser menor a 100.'])->withInput($request->all());
            }
            if (request('tipopromocion') == 1 && request('cantidad') != null){
                return back()->withErrors(['cantidad' => 'No se puede elegir si se selecciono por la opción por precio'])->withInput($request->all());
            }
            if (request('preciouno') == null && request('cantidad') == null){
                return back()->withErrors(['cantidad' => 'Elegir al menos una opcion de descuento'])->withInput($request->all());
            }
            if (request('preciouno') != null && request('cantidad') != null){
                return back()->withErrors(['cantidad' => 'Solo puedes elegir una opción de descuento'])->withInput($request->all());
            }
            if (request('preciouno') != null && request('tipopromocion') != 1){
                return back()->withErrors(['preciouno' => 'Solo permitido con la opcion seleccionada de por precio'])->withInput($request->all());
            }
            if($now > Carbon::parse($fin)){
                return back()->withErrors(['fin' => 'No puede ser menor a la fecha actual.'])->withInput($request->all());
            }

            if (request('cantidad') < 0){
                return back()->withErrors(['cantidad' => 'No puede ser menor a 0.'])->withInput($request->all());
            }
            if (request('armazones2') < 1){
                return back()->withErrors(['armazones2' => 'No puede ser menor a 1.'])->withInput($request->all());
            }
            request()->validate($rules);
            try{
                $estado = 0;
                if(!is_null(request('administrador'))){
                    if(request('administrador') == 1){
                        $estado = 1;
                    }else{
                        $estado = 0;
                    }
                } 
                $fijo = 0;
                if(!is_null(request('tipopromocion'))){
                    if(request('tipopromocion') == 1){
                        $fijo = 1;
                    }else{
                        $fijo = 0;
                    }
                }
                $forzado = 0;
                DB::table('promocion')->where([['id','=',$idPromocion],['id_franquicia','=',$idFranquicia]])->update([
                    'titulo'=>request('titulo'),'precioP'=>request('cantidad'),'preciouno'=>request('preciouno'),'armazones' => request('armazones2'),
                    'inicio'=>request('inicio'),'id_tipopromocionusuario' => $estado,'contado' => $estado,'tipopromocion' => $fijo,'fin' =>request('fin'),'status' => 1,'updated_at' => Carbon::now(),'forzado' => $forzado
                ]);

                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','La promoción se actualizo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');           
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

	public function estadoPromocionEditar($idFranquicia,$idPromocion){
        if(Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) 
        {                         			
            $promociones = DB::select("SELECT * FROM promocion WHERE id_franquicia = '$idFranquicia' and id = '$idPromocion'");           
            $estado = $promociones[0]->status;
            
              if($estado == 1){
                    $estado = 2;
                }

            try{
                $forzado = 1;
                DB::table('promocion')->where([['id','=',$idPromocion],['id_franquicia','=',$idFranquicia]])->update([
                    'status'=> $estado,'updated_at' => Carbon::now(),'forzado' => $forzado
                ]); 
                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','La promoción se actualizo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');           
            }
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }   

    

}
