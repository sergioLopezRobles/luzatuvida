<?php

namespace App\Http\Controllers;

use App\Clases\contratosGlobal;
use App\Clases\globalesServicioWeb;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\Printer;
use Mike42\Escpos\EscposImage;

class laboratorio extends Controller
{
    public function listalaboratorio()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
            //Solo los roles de Administracion, principal, director y confirmaciones pueden entrar

            $filtro = request('filtro');
            $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");
            $now = Carbon::now();

            $otrosContratos = null;
            $contratosSTerminar = null;
            $contratosPendientes = null;

            if (!is_null($filtro)) { //Tenemos un filtro?
                //Tenemos un filtro
                $contratosComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega
                                                            FROM contratos c
                                                            INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                            INNER JOIN franquicias f on f.id = c.id_franquicia
                                                            WHERE c.estatus_estadocontrato IN (7,10,11)
                                                            AND c.id like '%$filtro%'
                                                            AND c.banderacomentarioconfirmacion = 2 ORDER BY c.estatus_estadocontrato DESC,f.ciudad");

                $contratosSComentariosLabo = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega
                                                                FROM contratos c
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
                                                                c.estatus_estadocontrato IN (7,10,11) AND
                                                                c.id like '%$filtro%'
                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
                                                               ");

//                $contratosSComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega, r.created_at as fechaenvio
//                                                                FROM contratos c
//                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
//                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
//                                                                INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
//                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
//                                                                c.estatus_estadocontrato = 12 AND
//                                                                c.id like '%$filtro%'
//                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
//                                                               ");

                $contratosSTerminar = DB::select("SELECT c.id, c.estatus_estadocontrato, c.created_at, f.ciudad, ec.descripcion
                                                                FROM contratos c
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                 INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
                                                                c.id_franquicia != '00000' AND
                                                                (c.datos = 1 AND c.estatus_estadocontrato = 0 )AND
                                                                c.id like '%$filtro%'
                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC");

                $contratosPendientes = DB::select("SELECT c.id, c.estatus_estadocontrato, f.ciudad
                                                                FROM contratos c
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
                                                                c.id_franquicia != '00000' AND
                                                                (c.datos = 0 AND c.estatus_estadocontrato IS null ) AND
                                                                 c.id like '%$filtro%'
                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC");

                $otrosContratos = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega
                                                                FROM contratos c
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                WHERE c.id_franquicia != '00000' AND
                                                                c.estatus_estadocontrato IN (1,2,3,4,5,6,8,9,12,14) AND
                                                                c.id like '%$filtro%'
                                                                ORDER BY c.estatus_estadocontrato ASC
                                                               ");

            } else {
                //Sin filtro
                $contratosComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega FROM contratos c
                                                            INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato INNER JOIN franquicias f on f.id = c.id_franquicia WHERE c.estatus_estadocontrato IN (7,10,11)
                                                            AND c.banderacomentarioconfirmacion = 2 ORDER BY c.estatus_estadocontrato DESC, f.ciudad");

                $contratosSComentariosLabo = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega
                                                                FROM contratos c
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
                                                                c.estatus_estadocontrato IN (7,10,11)
                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
                                                               ");

//                $contratosSComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega, r.created_at as fechaenvio
//                                                                FROM contratos c
//                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
//                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
//                                                                INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
//                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
//                                                                c.estatus_estadocontrato = 12
//                                                                AND STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$now','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$now','%Y-%m-%d')
//                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
//                                                               ");

            }

            return view("administracion.laboratorio.tabla", [
                "contratosComentarios" => $contratosComentarios,
//                "contratosSComentarios" => $contratosSComentarios,
                'contratosSComentariosLabo' => $contratosSComentariosLabo,
                'contratosSTerminar'=>$contratosSTerminar,
                'contratosPendientes' => $contratosPendientes,
                "otrosContratos" => $otrosContratos,
                'franquicias' => $franquicias,
                'filtro' => $filtro
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function estadolaboratorio($idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
            $contrato = DB::select("SELECT c.id,c.estatus_estadocontrato,z.zona,c.banderacomentarioconfirmacion,f.ciudad,
                                            (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as opto,
                                          c.nombre,c.calle,c.numero,c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,
                                          c.casatipo,c.casacolor,c.nombrereferencia,c.telefonoreferencia,c.correo,c.fotoine,c.fotoineatras,c.fotocasa,c.comprobantedomicilio,
                                          c.tarjeta,c.tarjetapensionatras,c.pago,ec.descripcion,c.created_at as fecha
                                          FROM contratos c
                                          INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                          INNER JOIN zonas z ON z.id = c.id_zona
                                          INNER JOIN franquicias f ON f.id = c.id_franquicia
                                          WHERE c.id = '$idContrato'");
//            if ($contrato != null) {
//                if ($contrato[0]->estatus_estadocontrato != 7 && $contrato[0]->estatus_estadocontrato != 10 && $contrato[0]->estatus_estadocontrato != 11
//                    && $contrato[0]->estatus_estadocontrato != 12) {
//                    return back()->with("alerta", "De momento no tienes acceso a este contrato.");
//                }
//            } else {
//                return back()->with("alerta", "No se encontro el contrato.");
//            }

            $datosContratos = DB::select("SELECT c.datos FROM contratos c WHERE c.id = '$idContrato'");
            if($datosContratos[0]->datos == 0){
                return back()->with("alerta", "No se encontro el contrato.");
            }

            $tieneGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = 2");

            if ($tieneGarantia != null) {//Tiene garantia?
                //Si tiene garantia

                $historialClinico = DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon,
                                                    (SELECT color FROM producto p WHERE p.id = hc.id_producto) as colorarmazon, hc.id_producto, hc.fechaentrega, hc.bifocalotro,
                                                    hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,g.id as garantia,
                                                    (SELECT p.piezas FROM producto  p WHERE p.id = hc.id_producto) as piezasr,
                                                    (SELECT g.id FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id) as garantia,
                                                    (SELECT u.name FROM users u WHERE u.id = (SELECT g.id_optometrista FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id)) as optogarantia
                                                    FROM historialclinico hc
                                                    INNER JOIN garantias g ON g.id_contrato = hc.id_contrato
                                                    WHERE hc.id_contrato = '$idContrato' AND g.id_historialgarantia = hc.id AND g.estadogarantia = 2");
            } else {

                //No tiene garantia
                $historialClinico = DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon,
                                                    (SELECT color FROM producto p WHERE p.id = hc.id_producto) as colorarmazon, hc.id_producto, hc.fechaentrega, hc.bifocalotro,
                                                    hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,
                                                    (SELECT p.piezas FROM producto  p WHERE p.id = hc.id_producto) as piezasr,
                                                    (SELECT g.id FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id AND (g.estadogarantia = 2 AND g.estadocontratogarantia = 2)) as garantia,
                                                    (SELECT u.name FROM users u WHERE u.id = (SELECT c.id_optometrista FROM contratos c WHERE c.id= hc.id_contrato)) as optocontrato
                                                    FROM historialclinico hc WHERE id_contrato = '$idContrato'");

            }


            $comentarios = DB::select("SELECT u.name,m.comentario,m.fecha FROM mensajesconfirmaciones m INNER JOIN users u ON u.id = m.id_usuario WHERE m.id_contrato = '$idContrato' ORDER BY m.fecha DESC");
            if ($contrato[0]->banderacomentarioconfirmacion == 2) {
                DB::table("contratos")->where("id", "=", $idContrato)->update([
                    "banderacomentarioconfirmacion" => 0
                ]);
            }
            $usuario = Auth::id();
            $historialContrato = DB::select("SELECT u.name,hc.cambios,hc.created_at FROM historialcontrato hc INNER JOIN users u ON u.id = hc.id_usuarioC WHERE id_usuarioC = '$usuario' AND id_contrato = '$idContrato' ORDER BY created_at DESC");


            //Obtencion de datos para mandar a imprimir en impresora termica
            $historialesClinicosImpresoraTermica = $historialClinico;

            //Obtencion de datos sobre estado garantia para imprimir tiket
            $consultaGarantia = DB::select("SELECT estadogarantia FROM garantias WHERE id_contrato = '$idContrato'");
            if($consultaGarantia != null){
                $estadoGarantia = $consultaGarantia[0] -> estadogarantia;
            } else {
                $estadoGarantia = " ";
            }

            if ($historialesClinicosImpresoraTermica != null) {

                $contadorHistorial = 1;
                $idHistorial1 = null;
                $fechaEntregaHistorial1 = null;
                $nombreProducto1 = null;
                $colorProducto1 = null;
                $observacionesHistorial1 = null;
                $esfericoder1 = null;
                $cilindroder1 = null;
                $ejeder1 = null;
                $addder1 = null;
                $altder1 = null;
                $esfericoizq1 = null;
                $cilindroizq1 = null;
                $ejeizq1 = null;
                $addizq1 = null;
                $altizq1 = null;
                $material1 = null;
                $bifocal1 = null;
                $tratamientos1 = "";
                $idHistorial2 = null;
                $fechaEntregaHistorial2 = null;
                $nombreProducto2 = null;
                $colorProducto2 = null;
                $observacionesHistorial2 = null;
                $esfericoder2 = null;
                $cilindroder2 = null;
                $ejeder2 = null;
                $addder2 = null;
                $altder2 = null;
                $esfericoizq2 = null;
                $cilindroizq2 = null;
                $ejeizq2 = null;
                $addizq2 = null;
                $altizq2 = null;
                $material2 = null;
                $bifocal2 = null;
                $tratamientos2 = "";
                $comentariosContrato = "";

                //Obtener comentarios contrato
                foreach ($comentarios as $comentario) {
                    $comentariosContrato = $comentariosContrato . $comentario->comentario . "&";
                }

                foreach ($historialesClinicosImpresoraTermica as $historialClinicoImpresora) {

                    $idProducto = $historialClinicoImpresora->id_producto;
                    $producto = DB::select("SELECT nombre, color FROM producto WHERE id_tipoproducto = '1' AND id = '$idProducto'");
                    if ($producto != null) {

                        if ($contadorHistorial == 1) {
                            $idHistorial1 = $historialClinicoImpresora->id;
                            $fechaEntregaHistorial1 = $historialClinicoImpresora->fechaentrega;
                            $nombreProducto1 = self::remplazarCaracteres($producto[0]->nombre);
                            $colorProducto1 = self::remplazarCaracteres($producto[0]->color);
                            $observacionesHistorial1 = self::remplazarCaracteres($historialClinicoImpresora->observaciones);
                            //Ojo derecho
                            $esfericoder1 = self::remplazarCaracteres($historialClinicoImpresora->esfericoder);
                            $cilindroder1 = self::remplazarCaracteres($historialClinicoImpresora->cilindroder);
                            $ejeder1 = self::remplazarCaracteres($historialClinicoImpresora->ejeder);
                            $addder1 = self::remplazarCaracteres($historialClinicoImpresora->addder);
                            $altder1 = self::remplazarCaracteres($historialClinicoImpresora->altder);
                            //Ojo izquierdo
                            $esfericoizq1 = self::remplazarCaracteres($historialClinicoImpresora->esfericoizq);
                            $cilindroizq1 = self::remplazarCaracteres($historialClinicoImpresora->cilindroizq);
                            $ejeizq1 = self::remplazarCaracteres($historialClinicoImpresora->ejeizq);
                            $addizq1 = self::remplazarCaracteres($historialClinicoImpresora->addizq);
                            $altizq1 = self::remplazarCaracteres($historialClinicoImpresora->altizq);

                            if ($esfericoder1 == null) {
                                $esfericoder1 = "NA";
                            }
                            if ($cilindroder1 == null) {
                                $cilindroder1 = "NA";
                            }
                            if ($ejeder1 == null) {
                                $ejeder1 = "NA";
                            }
                            if ($addder1 == null) {
                                $addder1 = "NA";
                            }
                            if ($altder1 == null) {
                                $altder1 = "NA";
                            }
                            if ($esfericoizq1 == null) {
                                $esfericoizq1 = "NA";
                            }
                            if ($cilindroizq1 == null) {
                                $cilindroizq1 = "NA";
                            }
                            if ($ejeizq1 == null) {
                                $ejeizq1 = "NA";
                            }
                            if ($addizq1 == null) {
                                $addizq1 = "NA";
                            }
                            if ($altizq1 == null) {
                                $altizq1 = "NA";
                            }

                            //Material
                            $material1 = self::remplazarCaracteres($historialClinicoImpresora->material);
                            $materialotro1 = self::remplazarCaracteres($historialClinicoImpresora->materialotro);
                            //Bifocal
                            $bifocal1 = self::remplazarCaracteres($historialClinicoImpresora->bifocal);
                            $bifocalotro1 = self::remplazarCaracteres($historialClinicoImpresora->bifocalotro);
                            //Tratamientos
                            $fotocromatico1 = self::remplazarCaracteres($historialClinicoImpresora->fotocromatico);
                            $ar1 = self::remplazarCaracteres($historialClinicoImpresora->ar);
                            $tinte1 = self::remplazarCaracteres($historialClinicoImpresora->tinte);
                            $blueray1 = self::remplazarCaracteres($historialClinicoImpresora->blueray);
                            $otroT1 = self::remplazarCaracteres($historialClinicoImpresora->otroT);
                            $tratamientootro1 = self::remplazarCaracteres($historialClinicoImpresora->tratamientootro);

                            if ($material1 == 0) {
                                $material1 = "Hi index";
                            } elseif ($material1 == 1) {
                                $material1 = "CR";
                            } elseif ($material1 == 3) {
                                $material1 = $materialotro1;
                            }

                            if ($bifocal1 == 0) {
                                $bifocal1 = "FT";
                            } elseif ($bifocal1 == 1) {
                                $bifocal1 = "Blend";
                            } elseif ($bifocal1 == 2) {
                                $bifocal1 = "Progresivo";
                            } elseif ($bifocal1 == 3) {
                                $bifocal1 = "NA";
                            } elseif ($bifocal1 == 4) {
                                $bifocal1 = $bifocalotro1;
                            }

                            //Validacion tratamientos
                            if ($fotocromatico1 == 1) {
                                $tratamientos1 = "Fotocromatico|";
                            }
                            if ($ar1 == 1) {
                                $tratamientos1 = $tratamientos1 . "AR|";
                            }
                            if ($tinte1 == 1) {
                                $tratamientos1 = $tratamientos1 . "Tinte|";
                            }
                            if ($blueray1 == 1) {
                                $tratamientos1 = $tratamientos1 . "BlueRay|";
                            }
                            if ($otroT1 == 1) {
                                $tratamientos1 = $tratamientos1 . $tratamientootro1 . "|";
                            }
                            $tratamientos1 = substr_replace($tratamientos1, '', -1); //Quitar el ultimo |


                        } else {

                            $idHistorial2 = $historialClinicoImpresora->id;
                            $fechaEntregaHistorial2 = $historialClinicoImpresora->fechaentrega;
                            $nombreProducto2 = self::remplazarCaracteres($producto[0]->nombre);
                            $colorProducto2 = self::remplazarCaracteres($producto[0]->color);
                            $observacionesHistorial2 = self::remplazarCaracteres($historialClinicoImpresora->observaciones);
                            //Ojo derecho
                            $esfericoder2 = self::remplazarCaracteres($historialClinicoImpresora->esfericoder);
                            $cilindroder2 = self::remplazarCaracteres($historialClinicoImpresora->cilindroder);
                            $ejeder2 = self::remplazarCaracteres($historialClinicoImpresora->ejeder);
                            $addder2 = self::remplazarCaracteres($historialClinicoImpresora->addder);
                            $altder2 = self::remplazarCaracteres($historialClinicoImpresora->altder);
                            //Ojo izquierdo
                            $esfericoizq2 = self::remplazarCaracteres($historialClinicoImpresora->esfericoizq);
                            $cilindroizq2 = self::remplazarCaracteres($historialClinicoImpresora->cilindroizq);
                            $ejeizq2 = self::remplazarCaracteres($historialClinicoImpresora->ejeizq);
                            $addizq2 = self::remplazarCaracteres($historialClinicoImpresora->addizq);
                            $altizq2 = self::remplazarCaracteres($historialClinicoImpresora->altizq);

                            if ($esfericoder2 == null) {
                                $esfericoder2 = "NA";
                            }
                            if ($cilindroder2 == null) {
                                $cilindroder2 = "NA";
                            }
                            if ($ejeder2 == null) {
                                $ejeder2 = "NA";
                            }
                            if ($addder2 == null) {
                                $addder2 = "NA";
                            }
                            if ($altder2 == null) {
                                $altder2 = "NA";
                            }
                            if ($esfericoizq2 == null) {
                                $esfericoizq2 = "NA";
                            }
                            if ($cilindroizq2 == null) {
                                $cilindroizq2 = "NA";
                            }
                            if ($ejeizq2 == null) {
                                $ejeizq2 = "NA";
                            }
                            if ($addizq2 == null) {
                                $addizq2 = "NA";
                            }
                            if ($altizq2 == null) {
                                $altizq2 = "NA";
                            }

                            //Material
                            $material2 = self::remplazarCaracteres($historialClinicoImpresora->material);
                            $materialotro2 = self::remplazarCaracteres($historialClinicoImpresora->materialotro);
                            //Bifocal
                            $bifocal2 = self::remplazarCaracteres($historialClinicoImpresora->bifocal);
                            $bifocalotro2 = self::remplazarCaracteres($historialClinicoImpresora->bifocalotro);
                            //Tratamientos
                            $fotocromatico2 = self::remplazarCaracteres($historialClinicoImpresora->fotocromatico);
                            $ar2 = self::remplazarCaracteres($historialClinicoImpresora->ar);
                            $tinte2 = self::remplazarCaracteres($historialClinicoImpresora->tinte);
                            $blueray2 = self::remplazarCaracteres($historialClinicoImpresora->blueray);
                            $otroT2 = self::remplazarCaracteres($historialClinicoImpresora->otroT);
                            $tratamientootro2 = self::remplazarCaracteres($historialClinicoImpresora->tratamientootro);

                            if ($material2 == 0) {
                                $material2 = "Hi index";
                            } elseif ($material2 == 1) {
                                $material2 = "CR";
                            } elseif ($material2 == 3) {
                                $material2 = $materialotro2;
                            }

                            if ($bifocal2 == 0) {
                                $bifocal2 = "FT";
                            } elseif ($bifocal2 == 1) {
                                $bifocal2 = "Blend";
                            } elseif ($bifocal2 == 2) {
                                $bifocal2 = "Progresivo";
                            } elseif ($bifocal2 == 3) {
                                $bifocal2 = "NA";
                            } elseif ($bifocal2 == 4) {
                                $bifocal2 = $bifocalotro2;
                            }

                            $tratamientos2 = "";
                            //Validacion tratamientos
                            if ($fotocromatico2 == 1) {
                                $tratamientos2 = "Fotocromatico|";
                            }
                            if ($ar2 == 1) {
                                $tratamientos2 = $tratamientos2 . "AR|";
                            }
                            if ($tinte2 == 1) {
                                $tratamientos2 = $tratamientos2 . "Tinte|";
                            }
                            if ($blueray2 == 1) {
                                $tratamientos2 = $tratamientos2 . "BlueRay|";
                            }
                            if ($otroT2 == 1) {
                                $tratamientos2 = $tratamientos2 . $tratamientootro2 . "|";
                            }
                            $tratamientos2 = substr_replace($tratamientos2, '', -1); //Quitar el ultimo |
                        }

                        $contadorHistorial++;

                    } else {
                        return back()->with("alerta", "No existe el producto");
                    }

                }

            } else {
                return back()->with("alerta", "No existe el contrato");
            }

            return view("administracion.laboratorio.estadolaboratorio", [
                "contrato" => $contrato,
                "comentarios" => $comentarios,
                'idContrato' => $idContrato,
                'historialClinico' => $historialClinico,
                'idHistorial1' => $idHistorial1,
                'fechaEntregaHistorial1' => $fechaEntregaHistorial1,
                'nombreProducto1' => $nombreProducto1,
                'colorProducto1' => $colorProducto1,
                'observacionesHistorial1' => $observacionesHistorial1,
                'esfericoder1' => $esfericoder1,
                'cilindroder1' => $cilindroder1,
                'ejeder1' => $ejeder1,
                'addder1' => $addder1,
                'altder1' => $altder1,
                'esfericoizq1' => $esfericoizq1,
                'cilindroizq1' => $cilindroizq1,
                'ejeizq1' => $ejeizq1,
                'addizq1' => $addizq1,
                'altizq1' => $altizq1,
                'material1' => $material1,
                'bifocal1' => $bifocal1,
                'tratamientos1' => $tratamientos1,
                'idHistorial2' => $idHistorial2,
                'fechaEntregaHistorial2' => $fechaEntregaHistorial2,
                'nombreProducto2' => $nombreProducto2,
                'colorProducto2' => $colorProducto2,
                'observacionesHistorial2' => $observacionesHistorial2,
                'esfericoder2' => $esfericoder2,
                'cilindroder2' => $cilindroder2,
                'ejeder2' => $ejeder2,
                'addder2' => $addder2,
                'altder2' => $altder2,
                'esfericoizq2' => $esfericoizq2,
                'cilindroizq2' => $cilindroizq2,
                'ejeizq2' => $ejeizq2,
                'addizq2' => $addizq2,
                'altizq2' => $altizq2,
                'material2' => $material2,
                'bifocal2' => $bifocal2,
                'tratamientos2' => $tratamientos2,
                'historialcontrato' => $historialContrato,
                'estadoGarantia' => $estadoGarantia,
                'comentariosContrato' => $comentariosContrato,
                'garantia' => $tieneGarantia
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function comentariolaboratorio($idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
            $rules = [
                'comentario' => 'required|string',
            ];
            request()->validate($rules);

            $contrato = DB::select("SELECT c.estatus_estadocontrato
                                          FROM contratos c
                                          WHERE c.id = '$idContrato'");
            if ($contrato != null) {
                if ($contrato[0]->estatus_estadocontrato != 7 && $contrato[0]->estatus_estadocontrato != 10 && $contrato[0]->estatus_estadocontrato != 11) {
                    return back()->with("alerta", "Ya no tienes permisos de agregar comentariros.");
                }
            }

            try {
                $ahora = Carbon::now();
                DB::table('mensajesconfirmaciones')->insert([
                    "id_contrato" => $idContrato, "id_usuario" => Auth::user()->id, "comentario" => request("comentario"), "fecha" => $ahora
                ]);

                DB::table("contratos")->where("id", "=", $idContrato)->update([
                    "banderacomentarioconfirmacion" => 3
                ]);

                return back()->with("bien", "El mensaje se guardo correctamente");
            } catch (\Exception $e) {
                return back()->with("alerta", "Error: " . $e);
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function estadolaboratorioactualizar($idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
            $rules = [
                'estatus' => 'required|integer',
            ];
            request()->validate($rules);

            $estatus = request("estatus");
            if ($estatus != 8) {
                if ($estatus < 10 || $estatus > 12) {
                    return back()->with("alerta", "Estatus no valido.");
                }
            }

            $datosContratos = DB::select("SELECT c.datos FROM contratos c WHERE c.id = '$idContrato'");

            $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idContrato'");

            if ($contrato != null) {
                //Si $estatus es menor al estatus_estadocontrato no se puede actualizar
                if($contrato[0]->estatus_estadocontrato > $estatus){
                    return back()->with("alerta", "No puedes cambiar el estatus del contrato a un estatus anterior.");
                } if($datosContratos[0]->datos == 0){
                    return back()->with("alerta", "No se encontro el contrato.");
                } if ($contrato[0]->estatus_estadocontrato == 12) {
                    return back()->with("alerta", "No puedes cambiar el estatus del contrato en este momento.");
                } else {
                    if ($contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11) {

                        $contratosGlobal = new contratosGlobal;

                        DB::table("contratos")->where("id", "=", $idContrato)->update([
                            "estatus_estadocontrato" => $estatus,
                            "costoatraso" => 0
                        ]);

                        if ($estatus == 12) {
                            DB::table("garantias")->where("id_contrato", "=", $idContrato)->update([
                                "estadogarantia" => 3
                            ]);

                            //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                            $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, Auth::id());
                        }
                        $estatusContrato = self::obtenerEstatusContrato($estatus);
                        DB::table('historialcontrato')->insert([
                            'id' => self::getHistorialContratoId(), 'id_usuarioC' => Auth::id(), 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Laboratorio cambio el estatus a '$estatusContrato'"
                        ]);

                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => $estatus,
                            'created_at' => Carbon::now()
                        ]);

                        $tieneGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = 2");
                        if($tieneGarantia != null) {
                            //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                            $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, Auth::id());
                        }

                        return redirect()->route('listalaboratorio')->with("bien", "El contrato cambio  a " . $estatusContrato);

                    } else {
                        return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");
                    }
                }
            } else {
                //El contrato no existe
                return back()->with("bien", "El contrato no es valido.");
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private static function obtenerEstatusContrato($estatus)
    {

        switch ($estatus) {
            case 10:
                return "Manofactura";
            case 11:
                return "En proceso de envio..";
            case 12:
                return "Enviado";
            case 8:
                return "Rechazado";
        }
        return "Estatus:" . $estatus;
    }

    /* Metodo/Funcion: getHistorialContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getHistorialContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from historialcontrato where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }    // Comparar si ya existe el id en la base de datos

    /* Metodo/Funcion: generadorRandom2
    Descripcion: Esta función crea un ID alfanumerico de 5 digitos para registros
    */
    private function generadorRandom2($length = 5)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    public function auxiliarlaboratorio()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 2)) {
            //Solo los roles de Administracion, principal, director y confirmaciones pueden entrar
            $historiales = null;
            $filtro = request('filtro');
            if (!is_null($filtro)) { //Tenemos un filtro?
                //Tenemos un filtro
                $historiales = DB::select("SELECT * FROM historialclinico hc INNER JOIN contratos c ON hc.id_contrato = c.id WHERE id_contrato = '$filtro' AND c.estatus_estadocontrato in (7,9,10,11,12)"); //Pendiente validar el estado del contrato
            }
            return view("administracion.laboratorio.auxiliar", ["historiales" => $historiales, "idContrato" => $filtro]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarestadoenviado()
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
            //Solo los roles de director y laboratorio pueden entrar
            $contratosSComentariosLabo = DB::select("SELECT c.id
                                                                FROM contratos c
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                WHERE c.estatus_estadocontrato = 11
                                                                AND c.banderacomentarioconfirmacion != 2
                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC");

            foreach ($contratosSComentariosLabo as $contratoSComentariosLabo) {
                $contratoEntrante = request('check' . $contratoSComentariosLabo->id);
                if ($contratoEntrante != null) {
                    DB::table("contratos")->where("id", "=", $contratoSComentariosLabo->id)->update([
                        "estatus_estadocontrato" => 12
                    ]);

                    DB::table("garantias")->where("id_contrato", "=", $contratoSComentariosLabo->id)->update([
                        "estadogarantia" => 3
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => self::getHistorialContratoId(), 'id_usuarioC' => Auth::id(), 'id_contrato' => $contratoSComentariosLabo->id, 'created_at' => Carbon::now(), 'cambios' => "Laboratorio cambio el estatus a 'Enviado'"
                    ]);

                    //Insertar en tabla registroestadocontrato
                    DB::table('registroestadocontrato')->insert([
                        'id_contrato' => $contratoSComentariosLabo->id,
                        'estatuscontrato' => 12,
                        'created_at' => Carbon::now()
                    ]);

                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                    $contratosGlobal = new contratosGlobal;
                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($contratoSComentariosLabo->id, Auth::id());
                }

            }

            return redirect()->route('listalaboratorio')->with("bien", "El estatus de los contratos se actualizo correctamente.");
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private static function remplazarCaracteres($cadena)
    {
        $cadenaremplazo = str_replace('⁰', '', $cadena);
        $cadenaremplazo = str_replace('°', '', $cadenaremplazo);

        static $map = [
            // single letters
            'à' => 'a',
            'á' => 'a',
            'â' => 'a',
            'ã' => 'a',
            'ä' => 'a',
            'ą' => 'a',
            'å' => 'a',
            'ā' => 'a',
            'ă' => 'a',
            'ǎ' => 'a',
            'ǻ' => 'a',
            'À' => 'A',
            'Á' => 'A',
            'Â' => 'A',
            'Ã' => 'A',
            'Ä' => 'A',
            'Ą' => 'A',
            'Å' => 'A',
            'Ā' => 'A',
            'Ă' => 'A',
            'Ǎ' => 'A',
            'Ǻ' => 'A',


            'ç' => 'c',
            'ć' => 'c',
            'ĉ' => 'c',
            'ċ' => 'c',
            'č' => 'c',
            'Ç' => 'C',
            'Ć' => 'C',
            'Ĉ' => 'C',
            'Ċ' => 'C',
            'Č' => 'C',

            'ď' => 'd',
            'đ' => 'd',
            'Ð' => 'D',
            'Ď' => 'D',
            'Đ' => 'D',


            'è' => 'e',
            'é' => 'e',
            'ê' => 'e',
            'ë' => 'e',
            'ę' => 'e',
            'ē' => 'e',
            'ĕ' => 'e',
            'ė' => 'e',
            'ě' => 'e',
            'È' => 'E',
            'É' => 'E',
            'Ê' => 'E',
            'Ë' => 'E',
            'Ę' => 'E',
            'Ē' => 'E',
            'Ĕ' => 'E',
            'Ė' => 'E',
            'Ě' => 'E',

            'ƒ' => 'f',


            'ĝ' => 'g',
            'ğ' => 'g',
            'ġ' => 'g',
            'ģ' => 'g',
            'Ĝ' => 'G',
            'Ğ' => 'G',
            'Ġ' => 'G',
            'Ģ' => 'G',


            'ĥ' => 'h',
            'ħ' => 'h',
            'Ĥ' => 'H',
            'Ħ' => 'H',

            'ì' => 'i',
            'í' => 'i',
            'î' => 'i',
            'ï' => 'i',
            'ĩ' => 'i',
            'ī' => 'i',
            'ĭ' => 'i',
            'į' => 'i',
            'ſ' => 'i',
            'ǐ' => 'i',
            'Ì' => 'I',
            'Í' => 'I',
            'Î' => 'I',
            'Ï' => 'I',
            'Ĩ' => 'I',
            'Ī' => 'I',
            'Ĭ' => 'I',
            'Į' => 'I',
            'İ' => 'I',
            'Ǐ' => 'I',

            'ĵ' => 'j',
            'Ĵ' => 'J',

            'ķ' => 'k',
            'Ķ' => 'K',


            'ł' => 'l',
            'ĺ' => 'l',
            'ļ' => 'l',
            'ľ' => 'l',
            'ŀ' => 'l',
            'Ł' => 'L',
            'Ĺ' => 'L',
            'Ļ' => 'L',
            'Ľ' => 'L',
            'Ŀ' => 'L',


            'ñ' => 'n',
            'ń' => 'n',
            'ņ' => 'n',
            'ň' => 'n',
            'ŉ' => 'n',
            'Ñ' => 'N',
            'Ń' => 'N',
            'Ņ' => 'N',
            'Ň' => 'N',

            'ò' => 'o',
            'ó' => 'o',
            'ô' => 'o',
            'õ' => 'o',
            'ö' => 'o',
            'ð' => 'o',
            'ø' => 'o',
            'ō' => 'o',
            'ŏ' => 'o',
            'ő' => 'o',
            'ơ' => 'o',
            'ǒ' => 'o',
            'ǿ' => 'o',
            'Ò' => 'O',
            'Ó' => 'O',
            'Ô' => 'O',
            'Õ' => 'O',
            'Ö' => 'O',
            'Ø' => 'O',
            'Ō' => 'O',
            'Ŏ' => 'O',
            'Ő' => 'O',
            'Ơ' => 'O',
            'Ǒ' => 'O',
            'Ǿ' => 'O',


            'ŕ' => 'r',
            'ŗ' => 'r',
            'ř' => 'r',
            'Ŕ' => 'R',
            'Ŗ' => 'R',
            'Ř' => 'R',


            'ś' => 's',
            'š' => 's',
            'ŝ' => 's',
            'ş' => 's',
            'Ś' => 'S',
            'Š' => 'S',
            'Ŝ' => 'S',
            'Ş' => 'S',

            'ţ' => 't',
            'ť' => 't',
            'ŧ' => 't',
            'Ţ' => 'T',
            'Ť' => 'T',
            'Ŧ' => 'T',


            'ù' => 'u',
            'ú' => 'u',
            'û' => 'u',
            'ü' => 'u',
            'ũ' => 'u',
            'ū' => 'u',
            'ŭ' => 'u',
            'ů' => 'u',
            'ű' => 'u',
            'ų' => 'u',
            'ư' => 'u',
            'ǔ' => 'u',
            'ǖ' => 'u',
            'ǘ' => 'u',
            'ǚ' => 'u',
            'ǜ' => 'u',
            'Ù' => 'U',
            'Ú' => 'U',
            'Û' => 'U',
            'Ü' => 'U',
            'Ũ' => 'U',
            'Ū' => 'U',
            'Ŭ' => 'U',
            'Ů' => 'U',
            'Ű' => 'U',
            'Ų' => 'U',
            'Ư' => 'U',
            'Ǔ' => 'U',
            'Ǖ' => 'U',
            'Ǘ' => 'U',
            'Ǚ' => 'U',
            'Ǜ' => 'U',


            'ŵ' => 'w',
            'Ŵ' => 'W',

            'ý' => 'y',
            'ÿ' => 'y',
            'ŷ' => 'y',
            'Ý' => 'Y',
            'Ÿ' => 'Y',
            'Ŷ' => 'Y',

            'ż' => 'z',
            'ź' => 'z',
            'ž' => 'z',
            'Ż' => 'Z',
            'Ź' => 'Z',
            'Ž' => 'Z',


            // accentuated ligatures
            'Ǽ' => 'A',
            'ǽ' => 'a',
        ];
        return strtr($cadenaremplazo, $map);
    }

    public function rechazarContratoLaboratorio($idContrato)
    {
        $comentarios = request('comentarios');

        if (strlen($comentarios) == 0) {
            //Comentarios vacio
            return back()->with('alerta', 'Campo especificaciónes obligatorio');
        }

        $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idContrato'");

        if ($contrato != null) {

            $existeGarantia = DB::select("SELECT * FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = '2' ORDER BY created_at ASC limit 1");

            if($existeGarantia == null){
                //Si no tiene garantia
                if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {

                    if ($contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11) {

                        $actualizar = Carbon::now();
                        $usuarioId = Auth::user()->id;

                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');

                        try {

                            DB::table('contratos')->where('id', '=', $idContrato)->update([
                                'estatus_estadocontrato' => 8, 'estatusanteriorcontrato' => $contrato[0]->estatus_estadocontrato
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 8,
                                'created_at' => Carbon::now()
                            ]);

                            DB::table('historialcontrato')->insert([
                                'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Contrato rechazado por laboratorio con la siguiente descripcion: '$comentarios'"
                            ]);

                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                            return redirect()->route('listalaboratorio')->with('bien', 'El contrato se rechazo correctamente.');

                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e->getMessage());
                            return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
                        }

                    } else {
                        return back()->with('alerta', 'Necesitas permisos adicionales para hacer esto.');
                    }

                } else {
                    if (Auth::check()) {
                        return redirect()->route('redireccionar');
                    } else {
                        return redirect()->route('login');
                    }
                }

            }else{
                //El contrato contiene garantia
                return back()->with('alerta', 'No se puedes rechazar el contrato debido a que tiene garantia.');
            }
        }
        return back()->with('alerta', 'No se encontro el contrato.');
    }

//    public function filtrarcontratosenviados()
//    {
//        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
//            //Rol director o laboratorio
//
//            $now = Carbon::now();
//            $fechainibuscar = request('fechainibuscar');
//            $fechafinbuscar = request('fechafinbuscar');
//            $franquiciaSeleccionada = request('franquiciaSeleccionada');
//
//            $cadenaFechaIniYFechaFin = " ";
//            $cadenaFranquiciaSeleccionada = " ";
//
//            //Validacion para fechaini y fechafin
//            if ($fechainibuscar == null && $fechafinbuscar == null) {
//                $cadenaFechaIniYFechaFin = " AND STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$now','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$now','%Y-%m-%d')";
//            }else {
//
//                if (strlen($fechafinbuscar) > 0 && strlen($fechainibuscar) == 0) {
//                    //fechafin diferente de vacio y fechaini vacio
//                    return redirect()->route('listalaboratorio')->with('alerta', 'Debes agregar una fecha inicial');
//                }
//
//                if (strlen($fechainibuscar) > 0) {
//                    //fechaini diferente de vacio
//                    $fechainibuscar = Carbon::parse($fechainibuscar)->format('Y-m-d');
//                    if (strlen($fechafinbuscar) > 0) {
//                        //fechafin diferente de vacio
//                        $fechafinbuscar = Carbon::parse($fechafinbuscar)->format('Y-m-d');
//                    } else {
//                        //fechafin vacio
//                        $fechafinbuscar = Carbon::parse(Carbon::now())->format('Y-m-d');
//                    }
//                    if ($fechafinbuscar < $fechainibuscar) {
//                        //fechafin menor a fechaini
//                        return redirect()->route('listalaboratorio')->with('alerta', 'La fecha inicial debe ser menor o igual a la final.');
//                    }
//
//                    $cadenaFechaIniYFechaFin = " AND STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$fechainibuscar','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$fechafinbuscar','%Y-%m-%d')";
//                }
//
//            }
//
//            if($franquiciaSeleccionada != null) {
//                $cadenaFranquiciaSeleccionada = " AND c.id_franquicia = '$franquiciaSeleccionada'";
//            }
//
//            $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where id != '00000'");
//
//            $contratosComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega FROM contratos c
//                                                            INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato INNER JOIN franquicias f on f.id = c.id_franquicia WHERE c.estatus_estadocontrato IN (7,10,11,12)
//                                                            AND c.banderacomentarioconfirmacion = 2 ORDER BY c.estatus_estadocontrato DESC, f.ciudad");
//
//            $contratosSComentariosLabo = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega
//                                                                FROM contratos c
//                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
//                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
//                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
//                                                                c.estatus_estadocontrato IN (7,10,11)
//                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
//                                                               ");
//
//            $contratosSComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega, r.created_at as fechaenvio
//                                                                FROM contratos c
//                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
//                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
//                                                                INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
//                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
//                                                                c.estatus_estadocontrato = 12
//                                                                " . $cadenaFechaIniYFechaFin . "
//                                                                " . $cadenaFranquiciaSeleccionada . "
//                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
//                                                               ");
//
//
//            return view("administracion.laboratorio.tabla", [
//                "contratosComentarios" => $contratosComentarios,
//                "contratosSComentarios" => $contratosSComentarios,
//                'contratosSComentariosLabo' => $contratosSComentariosLabo,
//                'franquicias' => $franquicias,
//                'fechainibuscar' => $fechainibuscar,
//                'fechafinbuscar' => $fechafinbuscar,
//                'franquiciaSeleccionada' => $franquiciaSeleccionada
//            ]);
//
//        } else {
//            if (Auth::check()) {
//                return redirect()->route('redireccionar');
//            } else {
//                return redirect()->route('login');
//            }
//        }
//    }

    public function contratosenviadostiemporeal(Request $request){
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 16)) {
            //Rol director o laboratorio

            $filtro = $request->input('filtro');
            $fechainibuscar = $request->input('fechainibuscar');
            $fechafinbuscar = $request->input('fechafinbuscar');
            $franquiciaSeleccionada = $request->input('franquiciaSeleccionada');

            $cadenaFranquiciaSeleccionada = " ";
            $cadenaFiltro = " ";

            $hoy = Carbon::now()->format('Y-m-d');

            if(strlen($fechainibuscar) == 0){
                $fechainibuscar = $hoy;

            } if(strlen($fechafinbuscar) == 0){
                $fechafinbuscar = $hoy;
            }

            if (strlen($fechainibuscar) > 0) {
                //fechaini diferente de vacio
                $fechainibuscar = Carbon::parse($fechainibuscar)->format('Y-m-d');
            } if (strlen($fechafinbuscar) > 0) {
                //fechafin diferente de vacio
                $fechafinbuscar = Carbon::parse($fechafinbuscar)->format('Y-m-d');
            }

            $cadenaFechaIniYFechaFin = " AND STR_TO_DATE(r.created_at,'%Y-%m-%d') >= STR_TO_DATE('$fechainibuscar','%Y-%m-%d') AND STR_TO_DATE(r.created_at,'%Y-%m-%d') <= STR_TO_DATE('$fechafinbuscar','%Y-%m-%d')";


            if($franquiciaSeleccionada != null) {
                $cadenaFranquiciaSeleccionada = " AND c.id_franquicia = '$franquiciaSeleccionada'";
            }

            if($filtro != null){
                $cadenaFiltro = "AND c.id like '%$filtro%'";
            }
            $contratosEnviadosSComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,f.ciudad,c.created_at,(SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY hc.created_at DESC limit 1) as fechaentrega, r.created_at as fechaenvio
                                                                FROM contratos c
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                INNER JOIN registroestadocontrato r ON r.id_contrato = c.id
                                                                WHERE c.banderacomentarioconfirmacion != 2 AND
                                                                c.estatus_estadocontrato = 12
                                                                " . $cadenaFechaIniYFechaFin . "
                                                                " . $cadenaFranquiciaSeleccionada . "
                                                                " . $cadenaFiltro . "
                                                                ORDER BY c.estatus_estadocontrato DESC,f.ciudad ASC
                                                               ");

            $view = view("administracion.laboratorio.contratosenviados.tablacontratosenviados", [
                "contratosEnviadosSComentarios" => $contratosEnviadosSComentarios
            ])->render();

            return \Response::json(array("vaid"=>"true", "view"=>$view,"fechainibuscar" => $fechainibuscar, "fechafinbuscar" => $fechafinbuscar));

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function obtenerEstadoPromocion($idContrato)
    {
        $respuesta = false;

        $contrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato'");
        if ($contrato[0]->idcontratorelacion != null) {
            //Es un contrato hijo
            $idContrato = $contrato[0]->idcontratorelacion;
        }

        $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_contrato = '$idContrato'");

        if ($promocioncontrato != null) {
            if ($promocioncontrato[0]->estado == 1) {
                //Promocion esta activa
                $respuesta = true;
            }
        }
        return $respuesta;
    }

    public function cancelarGarantiaHistorialLaboratorio($idContrato, $idHistorial)
    {
        if (Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15))) {

            try {

                $datosHistorial = DB::select("SELECT id_contrato FROM historialclinico WHERE id = '$idHistorial'  AND id_contrato = '$idContrato'");

                if ($datosHistorial != null) {
                    $idContrato = $datosHistorial[0]->id_contrato;

                    $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idContrato'");

                    if ($contrato != null) {
                        //Existe el contrato

                        if ($contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11 ||
                        $contrato[0]->estatus_estadocontrato == 12) {
                            //MANOFACTURA, PROCESO DE ENVIO, ENVIADO

                            $garantiasCancelar = DB::select("SELECT id, id_historial, estadocontratogarantia, totalhistorialcontratogarantia, totalpromocioncontratogarantia,
                                                                        totalrealcontratogarantia FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = 2");

                            if ($garantiasCancelar != null) {//Tiene garantias para cancelar?
                                //Tiene garantias para cancelar

                                $globalesServicioWeb = new globalesServicioWeb;
                                $usuarioId = Auth::user()->id;

                                foreach ($garantiasCancelar as $garantiaCancelar) {

                                    $idGarantia = $garantiaCancelar->id;
                                    $idhistorial = $garantiaCancelar->id_historial;
                                    $estadocontratogarantia = $garantiaCancelar->estadocontratogarantia;
                                    $totalhistorialcontratogarantia = $garantiaCancelar->totalhistorialcontratogarantia;
                                    $totalpromocioncontratogarantia = $garantiaCancelar->totalpromocioncontratogarantia;
                                    $totalrealcontratogarantia = $garantiaCancelar->totalrealcontratogarantia;

                                    //Ya se habian creado las garantias
                                    $contrato = DB::select("SELECT totalhistorial, totalpromocion, totalabono, totalproducto FROM contratos WHERE id = '$idContrato'");

                                    if ($contrato != null) {
                                        //Se encontro el contrato
                                        $totalhistorial = $contrato[0]->totalhistorial;
                                        $totalpromocion = $contrato[0]->totalpromocion;
                                        $totalabono = $contrato[0]->totalabono;
                                        $totalproducto = $contrato[0]->totalproducto;

                                        if ($this->obtenerEstadoPromocion($idContrato)) {
                                            //Tiene promocion
                                            if ($totalpromocion > $totalpromocioncontratogarantia) {
                                                //Devolver el estado del contrato, el total, y el totalpromocion a como estaban
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia,
                                                    'total' => $totalpromocioncontratogarantia + $totalproducto - $totalabono,
                                                    'totalpromocion' => $totalpromocioncontratogarantia,
                                                    'totalhistorial' => $totalhistorialcontratogarantia,
                                                    'totalreal' => $totalrealcontratogarantia
                                                ]);
                                            } else {
                                                //Devolver el estado del contrato
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia
                                                ]);
                                            }

                                        } else {
                                            //No tiene promocion
                                            if ($totalhistorial > $totalhistorialcontratogarantia) {
                                                //Devolver el estado del contrato, el total, y el totalhistorial a como estaban
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia,
                                                    'total' => $totalhistorialcontratogarantia + $totalproducto - $totalabono,
                                                    'totalhistorial' => $totalhistorialcontratogarantia,
                                                    'totalpromocion' => $totalpromocioncontratogarantia,
                                                    'totalreal' => $totalrealcontratogarantia
                                                ]);
                                            } else {
                                                //Devolver el estado del contrato
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia
                                                ]);
                                            }

                                        }

                                        //Insertar en tabla registroestadocontrato
                                        DB::table('registroestadocontrato')->insert([
                                            'id_contrato' => $idContrato,
                                            'estatuscontrato' => $estadocontratogarantia,
                                            'created_at' => Carbon::now()
                                        ]);

                                    } else {
                                        return redirect()->route('listaconfirmaciones')->with('alerta', 'No se encontro el contrato.');
                                    }

                                    //Actualizar estadogarantia a 4
                                    DB::table('garantias')->where([['id', '=', $idGarantia], ['id_contrato', '=', $idContrato], ['id_historial', '=', $idhistorial]])->update([
                                        'estadogarantia' => 4,
                                        'updated_at' => Carbon::now()
                                    ]);
                                    //Guardar movimiento
                                    DB::table('historialcontrato')->insert([
                                        'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se cancelo la garantia al historial '$idhistorial'"
                                    ]);

                                    //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                                    DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                                    $contratosGlobal = new contratosGlobal;
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, Auth::id());

                                }

                                return redirect()->route('listalaboratorio')->with('bien', 'Se cancelo correctamente la garantia.');
                            }

                            //No tiene garantias para cancelar
                            return redirect()->route('listalaboratorio')->with('alerta', 'No se puede cancelar la garantia por que no tiene asignada.');

                        }

                        return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");

                    }

                    return back()->with("alerta","No se encontro el contrato.");

                } else {
                    //No presenta historial clinico el contrato
                    return back()->with("alerta","No se encontro el historial clinico del contrato");
                }

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

}
