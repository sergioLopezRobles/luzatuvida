<?php

namespace App\Http\Controllers;

use App\Clases\calculofechaspago;
use App\Clases\contratosGlobal;
use App\Clases\globalesServicioWeb;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Session;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\confirmacion;
use Twilio\Rest\Client;
use Illuminate\Pagination\Paginator;
use Image;

class confirmaciones extends Controller
{

    public function listaconfirmaciones(){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))        {

            //Solo los roles de Administracion, principal, director y confirmaciones pueden entrar
            $filtro = request('filtro');
            $contratosScomentarios = null;
            $contratosConComentarios = null;
            $contratosSTerminar = null;
            $contratosPendientes = null;
            $contratosFueraConfimaciones = null;

            if($filtro != null){ //Tenemos un filtro?
                //Tenemos un filtro

                try{

                    if(Auth::user()->rol_id == 7){
                        //Es un usuario director
                        $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN (1,9)
                                                                   AND (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                   AND c.banderacomentarioconfirmacion != 3
                                                                   AND c.id_franquicia != '00000'
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                        $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN (1,9)
                                                                   AND (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                   AND c.banderacomentarioconfirmacion = 3
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                        $contratosSTerminar = DB::select("SELECT c.id,c.estatus_estadocontrato,c.created_at, us.name as usuariocreacion, u.name as optometrista, ec.descripcion, f.ciudad as sucursal FROM contratos c
	                                                            INNER JOIN users u ON c.id_optometrista = u.id
                                                                INNER JOIN users as us ON  us.id =  c.id_usuariocreacion
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                WHERE   c.id_franquicia != '00000' AND
                                                                (c.datos = 1 AND c.estatus_estadocontrato = 0 )AND
                                                                 (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                  ORDER BY c.estatus_estadocontrato DESC");

                        $contratosPendientes = DB::select("SELECT c.id,c.estatus_estadocontrato,c.created_at, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                INNER JOIN users as us ON  us.id =  c.id_usuariocreacion
                                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                 WHERE   c.id_franquicia != '00000' AND
                                                                 (c.datos = 0 AND c.estatus_estadocontrato IS null ) AND
                                                                 (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                  ORDER BY c.estatus_estadocontrato DESC");

                        $contratosFueraConfimaciones = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN (2,3,4,5,6,8,12,13,14)
                                                                   AND (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                   AND c.id_franquicia != '00000'
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato,c.created_at ASC");


                    }else if(Auth::user()->rol_id == 15){
                        $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN (1,9)
                                                AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                AND c.banderacomentarioconfirmacion != 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                        $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN (1,9)
                                                AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                AND c.banderacomentarioconfirmacion = 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                        $contratosSTerminar = DB::select("SELECT c.id,c.estatus_estadocontrato,c.created_at, us.name as usuariocreacion, u.name as optometrista, ec.descripcion, f.ciudad as sucursal FROM contratos c
	                                                            INNER JOIN users u ON c.id_optometrista = u.id
                                                                INNER JOIN users as us ON  us.id =  c.id_usuariocreacion
                                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                WHERE   c.id_franquicia != '00000' AND
                                                                (c.datos = 1 AND c.estatus_estadocontrato = 0 )AND
                                                                 (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                  ORDER BY c.estatus_estadocontrato DESC");

                        $contratosPendientes = DB::select("SELECT c.id,c.estatus_estadocontrato,c.created_at, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                INNER JOIN users as us ON  us.id =  c.id_usuariocreacion
                                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                 WHERE sc.id_usuario = '".Auth::user()->id."' AND
                                                                 (c.datos = 0 AND c.estatus_estadocontrato IS null ) AND
                                                                 (c.id like '%$filtro%' OR us.name like '%$filtro%')
                                                                  ORDER BY c.estatus_estadocontrato DESC");

                        $contratosFueraConfimaciones = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                 INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                 INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                                 INNER JOIN users u ON c.id_optometrista = u.id
                                                                 INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                 INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                 WHERE sc.id_usuario = '".Auth::user()->id."'
                                                                 AND c.estatus_estadocontrato IN (2,3,4,5,6,8,12,13,14)
                                                                 AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                                 GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                 ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                    }else{
                        //Cualquier otro usuario
                        return redirect()->route('redireccionar');
                    }

                }catch(\Exception $e){
                    \Log::info("Error".$e);
                }

            }else{
                //Sin filtro

                try{

                    if(Auth::user()->rol_id == 7){
                        //Es un usuario director

                         $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN (1,9)
                                                                   AND c.banderacomentarioconfirmacion != 3
                                                                   AND c.id_franquicia != '00000'
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                        $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name,c.nombre, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN (1,9)
                                                                   AND c.banderacomentarioconfirmacion = 3
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name,c.nombre, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                    }else if(Auth::user()->rol_id == 15){
                        //Es un usuario de confirmaciones

                        $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN (1,9)
                                                AND c.banderacomentarioconfirmacion != 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                        $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN (1,9)
                                                AND c.banderacomentarioconfirmacion = 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato,c.created_at ASC");

                    }else{
                        //Cualquier otro usuario
                        return redirect()->route('redireccionar');
                    }

                }catch(\Exception $e){
                    \Log::info("Error".$e);
                }

            }

            return view("administracion.confirmaciones.tabla",
                ["contratosScomentarios"=>$contratosScomentarios,
                    "contratosConComentarios"=>$contratosConComentarios,
                    "contratosSTerminar"=>$contratosSTerminar,
                    "contratosPendientes"=>$contratosPendientes,
                    "filtro"=>$filtro,
                    'contratosFueraConfimaciones' => $contratosFueraConfimaciones]);

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function estadoconfirmacion($idContrato){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {

            $existeContrato = DB::select("SELECT * FROM contratos WHERE id ='$idContrato'");
            if($existeContrato != null){
                //Si existe contrato
                $garantia = DB::select("SELECT id, indice FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = '2' ORDER BY created_at ASC limit 1");

                if($garantia != null) {
                    //Tiene garantia en estado 2
                    $idGarantia = $garantia[0]->id;
                    $indice = $garantia[0]->indice;
                    //Eliminar garantia con estado en 2 si es que las hay excepto la elegida anteriormente
                    DB::delete("DELETE FROM garantias WHERE id = '$idGarantia' AND estadogarantia = '2' AND indice != '$indice'");
                }

                //Actualizar contrato en tabla contratostemporalessincronizacion
                $contratosGlobal = new contratosGlobal;
                $contratosGlobal::actualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato);

                $contrato = DB::select("SELECT c.id,c.estatus_estadocontrato,ec.descripcion,z.zona,c.banderacomentarioconfirmacion,c.id_optometrista,
                                          (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as opto,
                                          (SELECT hc.edad FROM historialclinico hc WHERE hc.id_contrato = c.id ORDER BY c.created_at DESC LIMIT 1) as edad,
                                          c.nombre,c.calle,c.numero,c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,
                                          c.casatipo,c.casacolor,c.nombrereferencia,c.telefonoreferencia,c.correo,c.fotoine,c.fotoineatras,c.fotocasa, c.fotootros, c.comprobantedomicilio,
                                          c.tarjeta,c.tarjetapensionatras,c.pago,ec.descripcion,c.pagare,c.total,c.totalpromocion,
                                          (SELECT (SELECT promoc.id FROM promocion promoc WHERE promoc.armazones = '1' AND promoc.id = pc.id_promocion) FROM promocioncontrato pc WHERE pc.id_contrato = c.id AND pc.estado = '1') AS promocion,
                                          (SELECT SUM(a.abono) FROM abonos a WHERE a.id_contrato = c.id)as totalabonos,c.id_zona, c.subscripcion,
                                          (SELECT p.titulo FROM promocion p WHERE p.id = c.id_promocion) as titulopromocion,
                                          (SELECT fechaentrega FROM historialclinico WHERE id_contrato = c.id ORDER BY c.created_at LIMIT 1) as fechaentrega, c.coordenadas,
                                          c.nombre_usuariocreacion as nombreasistente, c.id_usuariocreacion, c.totalreal,
                                          (SELECT SUM(prod.total) FROM contratoproducto prod WHERE prod.id_contrato = c.id)as totalproductos
                                          FROM contratos c
                                          INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                          INNER JOIN zonas z ON z.id = c.id_zona
                                          WHERE c.id = '$idContrato'");

                $franquicia = DB::select("SELECT id_franquicia FROM contratos WHERE id = '$idContrato'");
                $idFranquicia =  $franquicia[0]->id_franquicia;
                $historiales =  DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon,
                                                    hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,hc.observacionesinterno,hc.created_at,hc.bifocalotro,
                                                    (SELECT color FROM producto p WHERE p.id = hc.id_producto) as colorarmazon,
                                                    (SELECT p.nombre FROM paquetes p WHERE p.id = hc.id_paquete AND p.id_franquicia = '$idFranquicia' LIMIT 1) as paquete,
                                                    (SELECT g.id FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id) as garantia,
                                                    (SELECT u.name FROM users u WHERE u.id = (SELECT g.id_optometrista FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id)) as optogarantia,
                                                    (SELECT g.id FROM garantias g WHERE g.id_historial = hc.id AND g.estadogarantia = 2) as cancelargarantia,
                                                    (SELECT hsc.esfericoder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscesfericoder,
                                                    (SELECT hsc.cilindroder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) AS hsccilindroder,
                                                    (SELECT hsc.ejeder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscejeder,
                                                    (SELECT hsc.addder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscaddder,
                                                    (SELECT hsc.esfericoizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscesfericoizq,
                                                    (SELECT hsc.cilindroizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hsccilindroizq,
                                                    (SELECT hsc.ejeizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscejeizq,
                                                    (SELECT hsc.addizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscaddizq
                                                    FROM historialclinico hc
                                                    WHERE id_contrato = '$idContrato' ORDER BY created_at ASC");

                $zonas = DB::select("SELECT id,zona FROM zonas where id_franquicia ='$idFranquicia' ORDER BY id");

                $infoFranquicia = DB::select("SELECT estado,ciudad,colonia,numero FROM franquicias WHERE id = '".$franquicia[0]->id_franquicia."'");
                $comentarios = DB::select("SELECT u.name,m.comentario,m.fecha FROM mensajesconfirmaciones m INNER JOIN users u ON u.id = m.id_usuario WHERE m.id_contrato = '$idContrato' ORDER BY m.fecha DESC");

                $usuario = Auth::id();
                $historialContrato = DB::select("SELECT u.name,hc.cambios,hc.created_at FROM historialcontrato hc INNER JOIN users u ON u.id = hc.id_usuarioC WHERE (hc.id_usuarioC = '$usuario' OR u.rol_id = '16') AND hc.id_contrato = '$idContrato' ORDER BY created_at DESC");

                $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");

                if($contrato[0]->banderacomentarioconfirmacion == 3){
                    DB::table("contratos")->where("id","=",$idContrato)->update([
                        "banderacomentarioconfirmacion" => 0
                    ]);
                }

                $productos = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id_tipoproducto = '2'");
                $contratoproducto = DB::select("SELECT p.nombre, p.precio, c.piezas, c.total, p.preciop
                                                        FROM contratoproducto c
                                                        inner join producto p on c.id_producto = p.id
                                                        WHERE id_contrato = '$idContrato'");

                $optometristas = DB::select("SELECT u.ID,u.NAME
                                    FROM users u
                                    INNER JOIN usuariosfranquicia uf
                                    ON uf.id_usuario = u.id
                                    WHERE uf.id_franquicia = '$idFranquicia'
                                    AND u.rol_id = 12 ORDER BY u.name");

                $asistentes = DB::select("SELECT u.ID,u.NAME
                                    FROM users u
                                    INNER JOIN usuariosfranquicia uf
                                    ON uf.id_usuario = u.id
                                    WHERE uf.id_franquicia = '$idFranquicia'
                                    AND u.rol_id = 13 ORDER BY u.name");

                $datosDiagnosticoHistorial = DB::select("SELECT hc.edad, hc.diagnostico, hc.ocupacion, hc.diabetes, hc.hipertension,
                                                    hc.embarazada, hc.durmioseisochohoras, hc.actividaddia, hc.problemasojos, hc.dolor,
                                                    hc.ardor, hc.golpeojos, hc.otroM, hc.molestiaotro, hc.ultimoexamen
                                                    FROM historialclinico hc
                                                    WHERE id_contrato = '$idContrato' ORDER BY created_at ASC LIMIT 1");

                return view("administracion.confirmaciones.estadoconfirmacion",["contrato"=>$contrato,"infoFranquicia" => $infoFranquicia,"comentarios"=>$comentarios,
                    'idContrato'=>$idContrato,'historiales'=> $historiales,'zonas'=>$zonas, 'historialcontrato' => $historialContrato, 'tieneHistorialGarantia' => $tieneHistorialGarantia,
                    'productos' => $productos, 'contratoproducto' => $contratoproducto, 'asistentes' => $asistentes, 'optometristas' => $optometristas,
                    'datosDiagnosticoHistorial' => $datosDiagnosticoHistorial, 'garantia' => $garantia, 'idFranquicia' => $idFranquicia
                ]);
            } else {
                //No existe contrato
                return redirect()->route('listaconfirmaciones')->with("alerta","No se encontro el contrato.");
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function observacioninternalaboratoriohistorial($idContrato,$idHistorial,$opcion){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {

            //opcion
            //0-> Observacion laboratorio
            //1-> Observacion interna

            $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idContrato'");

            if($contrato != null) {
                //Existe el contrato

                if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 9) {
                    //TERMINADO, APROBADO O EN PROCESO DE APROBACION

                    $historial = DB::select("SELECT id, observaciones, observacionesinterno FROM historialclinico WHERE id_contrato = '$idContrato' AND id = '$idHistorial'");

                    if ($historial != null) {//Existe el historial??
                        //Existe el historial

                        $observaciones = $historial[0]->observaciones;
                        $observacionesinterno = $historial[0]->observacionesinterno;

                        if($opcion == 0) {
                            //Observacion laboratorio
                            $campoobservacionlaboratorio = request('observacionlaboratorio');
                            $observaciones = $campoobservacionlaboratorio;
                            if ($campoobservacionlaboratorio == null) {
                                $observaciones = "";
                            }
                            $mensajeAlerta = "laboratorio";
                        }else {
                            //Observacion interna
                            $campoobservacioninterna = request('observacioninterna');
                            $observacionesinterno = $campoobservacioninterna;
                            if ($campoobservacioninterna == null) {
                                $observacionesinterno = "";
                            }
                            $mensajeAlerta = "interna";
                        }

                        DB::table("historialclinico")
                            ->where("id_contrato", "=", $idContrato)
                            ->where("id", "=", $idHistorial)
                            ->update([
                                "observaciones" => $observaciones,
                                "observacionesinterno" => $observacionesinterno
                            ]);

                        return back()->with("bien", "La observacion " . $mensajeAlerta . " se actualizo correctamente.");

                    }

                    //No existe el historial
                    return back()->with("alerta", "No se encontro el historial.");

                }

                return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");

            }

            return back()->with("alerta","No se encontro el contrato.");

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }

    }

    public function actualizarfechaentregaconfirmaciones($idContrato) {

        $fechaentrega = request('fechaentrega');

        if (strlen($fechaentrega) > 0) {
            //fechaentrega diferente de vacio

            $fechaentrega = Carbon::parse($fechaentrega)->format('Y-m-d');

            try {

                $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idContrato'");

                if ($contrato != null) {
                    //Existe el contrato

                    if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 9) {
                        //TERMINADO, APROBADO O EN PROCESO DE APROBACION

                        $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");

                        $tipo = 0;
                        if ($tieneHistorialGarantia != null) {
                            //Tiene historiales con garantia
                            $tipo = 1;
                        }

                        $historiales = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = '$tipo'");

                        if ($historiales != null) {
                            foreach ($historiales as $historial) {
                                DB::table("historialclinico")->where("id", "=", $historial->id)->update([
                                    "fechaentrega" => $fechaentrega
                                ]);
                            }
                        }

                        return back()->with("bien", "Se actualizo correctamente la fecha de entrega.");

                    }

                    return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");

                }

                return back()->with("alerta","No se encontro el contrato.");

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        }else {
            //fechaentrega vacio
            return back()->with("alerta","Campo fecha entrega vacio.");
        }

    }

    public function comentarioconfirmacion($idContrato){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {
            $rules = [
                'comentario' => 'required|string',
            ];
            request()->validate($rules);
            $contrato = DB::select("SELECT c.estatus_estadocontrato
                                          FROM contratos c
                                          WHERE c.id = '$idContrato'");
            if($contrato != null){
                if($contrato[0]->estatus_estadocontrato != 1 && $contrato[0]->estatus_estadocontrato != 7 && $contrato[0]->estatus_estadocontrato != 9
                    && $contrato[0]->estatus_estadocontrato != 10 && $contrato[0]->estatus_estadocontrato !=11){
                    return back()->with("alerta","Ya no tienes permisos de agregar comentarios.");
                }
            }

            try {
                $ahora = Carbon::now();
                DB::table('mensajesconfirmaciones')->insert([
                    "id_contrato"=>$idContrato,"id_usuario"=>Auth::user()->id,"comentario"=>request("comentario"),"fecha"=>$ahora
                ]);

                DB::table("contratos")->where("id","=",$idContrato)->update([
                    "banderacomentarioconfirmacion" => 2
                ]);

                return back()->with("bien","El mensaje se guardo correctamente");
            }catch(\Exception $e){
                return back()->with("alerta","Error: ".$e);
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }

    }

    public function estadoconfirmacionactualizar($idContrato){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {

            $rules = [
                'estatus' => 'required|integer',
            ];
            request()->validate($rules);

            $estatus = request("estatus");
            $hoy = Carbon::now();

            $contratosGlobal = new contratosGlobal;

            if($estatus == 1) {
                //Contrato con historial con garantia (Editable)

                $ultimoHistorialClinicoGarantia = DB::select("SELECT id, id_paquete, created_at FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1 ORDER BY created_at DESC limit 1");

                if($ultimoHistorialClinicoGarantia != null) {

                    $idUltimoHistorialClinicoGarantia = $ultimoHistorialClinicoGarantia[0]->id;
                    $idPaqueteUltimoHistorialClinicoGarantia = $ultimoHistorialClinicoGarantia[0]->id_paquete;

                    if($idPaqueteUltimoHistorialClinicoGarantia == 6) {
                        //Dorado 2
                        $createdAtUltimoHistorialClinicoGarantia = $ultimoHistorialClinicoGarantia[0]->created_at;
                        $historialesClinicosGarantias = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1 AND STR_TO_DATE(created_at,'%Y-%m-%d') = STR_TO_DATE('$createdAtUltimoHistorialClinicoGarantia','%Y-%m-%d')");

                        if($historialesClinicosGarantias != null) {
                            foreach ($historialesClinicosGarantias as $historialgarantia) {
                                if($historialgarantia->id != $idUltimoHistorialClinicoGarantia) {
                                    DB::table("garantias")->where("id_historialgarantia", "=", $historialgarantia->id)->update([
                                        "updated_at" => $hoy
                                    ]);
                                }
                            }
                        }
                    }

                    DB::table("garantias")->where("id_historialgarantia", "=", $idUltimoHistorialClinicoGarantia)->update([
                        "updated_at" => $hoy
                    ]);
                    DB::table("contratos")->where("id", "=", $idContrato)->update([
                        "estatus_estadocontrato" => $estatus,
                        "updated_at" => $hoy
                    ]);

                    //Insertar en tabla registroestadocontrato
                    DB::table('registroestadocontrato')->insert([
                        'id_contrato' => $idContrato,
                        'estatuscontrato' => $estatus,
                        'created_at' => Carbon::now()
                    ]);

                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                    $ultimaGarantiaCreada = DB::select("SELECT id_optometrista FROM garantias WHERE id_contrato = '$idContrato' AND id_historialgarantia = '$idUltimoHistorialClinicoGarantia'
                                                                ORDER BY created_at LIMIT 1");
                    if($ultimaGarantiaCreada != null) {
                        $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $ultimaGarantiaCreada[0]->id_optometrista);
                    }

                    return redirect()->route('listaconfirmaciones')->with("bien", "El estatus se actualizo correctamente y ahora se puede editar nuevamente.");

                }

            }else {
                //Contrato sin historial con garantia (NO TERMINADO, EN PROCESO DE APROBACION, APROBADO)

                if ($estatus != 0) {
                    if ($estatus < 7 || $estatus > 9) {
                        return back()->with("alerta", "Estatus no valido.");
                    }
                }
                $contrato = DB::select("SELECT estatus_estadocontrato, idcontratorelacion, enganche, promocionterminada, id_zona FROM contratos WHERE id = '$idContrato'");

                if ($this->obtenerEstadoPromocion($idContrato) && $contrato[0]->promocionterminada == 0) {
                    //Tiene promocion y promocion no ha sido terminada
                    return redirect()->route('estadoconfirmacion', [$idContrato])->with('alerta', 'No se puede cambiar el estado por que tiene una promoción sin terminar');
                }

                if ($contrato[0]->idcontratorelacion == null) {
                    $idcontratoreal = $idContrato;
                } else {
                    $idcontratoreal = $contrato[0]->idcontratorelacion;
                }
                $datoscontrato = DB::select("SELECT f.id AS idfranqui, f.colonia, f.numero, f.ciudad, f.estado, f.telefonofranquicia,c.nombre, c.id AS idcontrato, c.created_at, ch.fechaentrega, ch.id_paquete, p.nombre as nombrepaquete, p.precio, c.enganche,c.totalhistorial, c.total,COALESCE(c.totalabono,0) as totalabono,c.totalproducto, c.totalpromocion, c.telefono, c.correo FROM contratos c
                                                    INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                    INNER JOIN historialclinico ch ON c.id = ch.id_contrato
                                                    INNER JOIN paquetes p ON p.id = ch.id_paquete
                                                    WHERE c.id = '$idContrato'");
                                                        $promociones = DB::select("SELECT c.id, p.titulo  FROM contratos c
                                                    INNER JOIN promocion p ON p.id = c.id_promocion
                                                    WHERE c.id = '$idcontratoreal'");
                                                        $productos = DB::select("SELECT c.id, p.nombre, p.precio, tp.tipo FROM contratoproducto c
                                                    INNER JOIN producto p ON p.id = c.id_producto
                                                    INNER JOIN tipoproducto tp ON tp.id = p.id_tipoproducto
                                                    WHERE c.id_contrato = '$idContrato'");

                if ($datoscontrato[0]->totalpromocion > 0) {
                    $promo2 = $datoscontrato[0]->totalpromocion;
                    $promo = $datoscontrato[0]->totalhistorial - $promo2;
                } else {
                    $promo = "";
                }
                if ($promociones == null) {
                    $promoname = "";
                } else {
                    $promoname = $promociones[0]->titulo;
                }

                if ($contrato != null) {
                    if ($contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11 || $contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 8) {
                        return back()->with("alerta", "No puedes cambiar el estatus del contrato en este momento.");
                    } else {
                        if ($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9 || $contrato[0]->estatus_estadocontrato == 7) {

                            DB::table("contratos")->where("id", "=", $idContrato)->update([
                                "updated_at" => $hoy,
                                "estatus_estadocontrato" => $estatus
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => $estatus,
                                'created_at' => Carbon::now()
                            ]);

                            $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1 ORDER BY created_at LIMIT 1");

                            //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                            if ($tieneHistorialGarantia != null) {
                                //Tiene garantia
                                $ultimaGarantiaCreada = DB::select("SELECT id_optometrista FROM garantias WHERE id_contrato = '$idContrato'
                                                                            AND id_historialgarantia = '" . $tieneHistorialGarantia[0]->id . "'
                                                                            ORDER BY created_at LIMIT 1");
                                if($ultimaGarantiaCreada != null) {
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $ultimaGarantiaCreada[0]->id_optometrista);
                                }
                            }else {
                                //No tiene garantia
                                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, Auth::id());
                            }

                            $globalesServicioWeb = new globalesServicioWeb;
                            $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');
                            $usuarioId = Auth::user()->id;

                            if ($estatus == 7) {
                                //Cambio de estado a APROBADO
                                //POR EL MOMENTO YA NO SE MANDARAN CORREOS
                                /*if ($datoscontrato[0]->correo != null) {
                                    $datos = [
                                        "nombrecliente" => $datoscontrato[0]->nombre,
                                        "idcontrato" => $datoscontrato[0]->idcontrato,
                                        "creacion" => $datoscontrato[0]->created_at,
                                        "entrega" => $datoscontrato[0]->fechaentrega,
                                        "colonia" => $datoscontrato[0]->colonia,
                                        "numero" => $datoscontrato[0]->numero,
                                        "ciudad" => $datoscontrato[0]->ciudad,
                                        "estado" => $datoscontrato[0]->estado,
                                        "nombrepaquete" => $datoscontrato[0]->nombrepaquete,
                                        "preciopaquete" => $datoscontrato[0]->precio,
                                        "total" => $datoscontrato[0]->total,
                                        "promocionnombre" => $promoname,
                                        "productos" => $productos,
                                        "totalabono" => $datoscontrato[0]->totalabono,
                                        "historial" => $datoscontrato[0]->totalhistorial,
                                        "promo" => $promo,
                                        "promoenganche" => $datoscontrato[0]->enganche,
                                        "telefonofranquicia" => $datoscontrato[0]->telefonofranquicia,
                                    ];
                                    Mail::to($datoscontrato[0]->correo)->queue(new confirmacion($datos));
                                }*/

                                DB::table('historialcontrato')->insert([
                                    'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $hoy, 'cambios' => "Se cambio el estatus a aprobado"
                                ]);

                                //Reducir calidad a imagenes del contrato
                                $this->reducirCalidadImagenesContrato($idContrato);

                                //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                                DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                                //Agregar contrato a cobradores si tiene garantia el contrato
                                if ($tieneHistorialGarantia != null) {
                                    //Tiene garantia
                                    $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $contrato[0]->id_zona . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona

                                    if ($cobradoresAsignadosAZona != null) {
                                        //Existen cobradores
                                        foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                            //Recorrido cobradores
                                            $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                                        }
                                    }
                                }

                                return redirect()->route('listaconfirmaciones')->with("bien", "El contrato fue aprobado.");
                            } elseif ($estatus == 0) {
                                //Cambio de estado a NO TERMINADO
                                DB::table('historialcontrato')->insert([
                                    'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $hoy, 'cambios' => "Se cambio el estatus a no terminado"
                                ]);

                                return redirect()->route('listaconfirmaciones')->with("bien", "El estatus del contrato se actualizo correctamente a no terminado.");
                            }

                            //Cambio de estado a EN PROCESO DE APROBACION
                            DB::table('historialcontrato')->insert([
                                'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $hoy, 'cambios' => "Se cambio el estatus a en proceso de aprobacion"
                            ]);
                            return back()->with("bien", "El estatus se actualizo correctamente.");

                        } else {
                            return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");
                        }

                    }

                } else {
                    //El contrato no existe
                    return back()->with("bien", "El contrato no es valido.");
                }

            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function reducirCalidadImagenesContrato($idContrato)
    {

        $contrato = DB::select("SELECT fotoine, fotoineatras, fotocasa, comprobantedomicilio, pagare, tarjeta, tarjetapensionatras, fotootros FROM contratos WHERE id = '$idContrato'");

        if($contrato != null) {
            //Existe el contrato
            $rutaimagenes = array();

            array_push($rutaimagenes, $contrato[0]->fotoine);
            array_push($rutaimagenes, $contrato[0]->fotoineatras);
            array_push($rutaimagenes, $contrato[0]->fotocasa);
            array_push($rutaimagenes, $contrato[0]->comprobantedomicilio);
            array_push($rutaimagenes, $contrato[0]->pagare);
            array_push($rutaimagenes, $contrato[0]->tarjeta);
            array_push($rutaimagenes, $contrato[0]->tarjetapensionatras);
            array_push($rutaimagenes, $contrato[0]->fotootros);

            foreach ($rutaimagenes as $rutaimagen) {

                try {

                    if ($rutaimagen != null) {
                        $alto = Image::make(config('filesystems.disks.disco.root') . '/' . $rutaimagen)->height();
                        $ancho = Image::make(config('filesystems.disks.disco.root') . '/' . $rutaimagen)->width();
                        if ($alto > $ancho) {
                            $imagen = Image::make(config('filesystems.disks.disco.root') . '/' . $rutaimagen)->resize(600, 800);
                        } else {
                            $imagen = Image::make(config('filesystems.disks.disco.root') . '/' . $rutaimagen)->resize(800, 600);
                        }
                        $imagen->save();
                    }

                }catch(\Exception $e){
                    continue;
                }

            }
        }
    }

    public function confirmacionesagregardocumentos($idContrato){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {

            $contrato = DB::select("SELECT id,fotoine,fotoineatras,fotocasa,comprobantedomicilio,pagare,tarjeta,tarjetapensionatras,fotootros,estatus_estadocontrato FROM contratos where id = '$idContrato' ");

            if($contrato != null) {
                //Existe el contrato

                if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 9 || $contrato[0]->estatus_estadocontrato == 10) {
                    //TERMINADO, APROBADO, EN PROCESO DE APROBACION O MANOFACTURA

                    request()->validate([
                        'fotoine' => 'nullable|image|mimes:jpg',
                        'fotocasa' => 'nullable|image|mimes:jpg',
                        '$fotoineatras' => 'nullable|image|mimes:jpg',
                        'pagare' => 'nullable|image|mimes:jpg',
                        'comprobantedomicilio' => 'nullable|image|mimes:jpg',
                        'tarjetapensionatras' => 'nullable|image|mimes:jpg',
                        'tarjetapension' => 'nullable|image|mimes:jpg',
                        'fotootros' => 'nullable|image|mimes:jpg'

                    ]);

                    $globalesServicioWeb = new globalesServicioWeb;
                    $usuarioId = Auth::user()->id;
                    $actualizar = Carbon::now();

                    if (request()->hasFile('fotoine')) {
                        //Se ingreso una identificacion
                        Storage::disk('disco')->delete($contrato[0]->fotoine);
                        $fotoBruta = 'Foto-ine-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                        $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto ine frente"
                        ]);

                    } else {
                        //Se toamara la identificacion anterior
                        $fotoine = $contrato[0]->fotoine;
                    }

                    if (request()->hasFile('fotoineatras')) {
                        //Se ingreso una identificacion
                        Storage::disk('disco')->delete($contrato[0]->fotoineatras);
                        $fotoBruta = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                        $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto ine atras"
                        ]);

                    } else {
                        //Se toamara la identificacion anterior
                        $fotoineatras = $contrato[0]->fotoineatras;
                    }

                    if (request()->hasFile('fotocasa')) {
                        Storage::disk('disco')->delete($contrato[0]->fotocasa);
                        $fotoBruta1 = 'Foto-casa-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                        $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta1, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto casa"
                        ]);

                    } else {
                        $fotocasa = $contrato[0]->fotocasa;
                    }

                    if (request()->hasFile('comprobantedomicilio')) {
                        Storage::disk('disco')->delete($contrato[0]->comprobantedomicilio);
                        $fotoBruta2 = 'Foto-comprobantedomicilio-' . $contrato[0]->id . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                        $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedocmicilio', $fotoBruta2, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto comprobante de domicilio"
                        ]);

                    } else {
                        $comprobantedomicilio = $contrato[0]->comprobantedomicilio;
                    }

                    if (request()->hasFile('pagare')) {
                        Storage::disk('disco')->delete($contrato[0]->pagare);
                        $fotoBruta5 = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta5, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto pagare"
                        ]);

                    } else {
                        $fotopagare = $contrato[0]->pagare;
                    }

                    if (request()->hasFile('tarjetapension')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjeta);
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjetapension')->getClientOriginalExtension();
                        $tarjeta = request()->file('tarjetapension')->storeAs('uploads/imagenes/contratos/tarjeta', $fotoBruta3, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto tarjeta pension frente"
                        ]);

                    } else {
                        $tarjeta = $contrato[0]->tarjeta;
                    }

                    if (request()->hasFile('tarjetapensionatras')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjetapensionatras);
                        $fotoBruta3 = 'Foto-tarjetapensionatras' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta3, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto tarjeta pension atras"
                        ]);

                    } else {
                        $tarjetapensionatras = $contrato[0]->tarjetapensionatras;
                    }

                    if (request()->hasFile('fotootros')) {
                        Storage::disk('disco')->delete($contrato[0]->pagare);
                        $fotoBruta6 = 'Foto-Otros' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotootros')->getClientOriginalExtension();
                        $fotootros = request()->file('fotootros')->storeAs('uploads/imagenes/contratos/fotootros', $fotoBruta6, 'disco');

                        //Guardar movimiento en historialcontrato
                        DB::table('historialcontrato')->insert([
                            'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la foto Otros"
                        ]);

                    } else {
                        $fotootros = $contrato[0]->fotootros;
                    }

                    DB::table("contratos")->where("id", "=", $idContrato)->update([
                        "fotoine" => $fotoine,
                        "fotoineatras" => $fotoineatras,
                        "fotocasa" => $fotocasa,
                        "comprobantedomicilio" => $comprobantedomicilio,
                        "pagare" => $fotopagare,
                        "tarjeta" => $tarjeta,
                        "tarjetapensionatras" => $tarjetapensionatras,
                        "fotootros" => $fotootros
                    ]);

                    return redirect()->route('estadoconfirmacion', [$idContrato])->with("bien", "Las imagenes se actualizaron correctamente.");

                }

                return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");

            }

            return back()->with("alerta","No se encontro el contrato.");

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function actualizarContratoConfirmaciones($idContrato,Request $request){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {
            $existeContrato = DB::select("SELECT id, id_usuariocreacion, nombre_usuariocreacion, estatus_estadocontrato, id_optometrista, id_zona FROM contratos WHERE id ='$idContrato'");
            if($existeContrato != null){
                //Existe el contrato

                if($existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 7 || $existeContrato[0]->estatus_estadocontrato == 9 || $existeContrato[0]->estatus_estadocontrato == 10) {
                    //TERMINADO, APROBADO, EN PROCESO DE APROBACION O MANOFACTURA

                    $rules = [
                        'nombre' => 'required|string|max:255',
                        'edad' => 'required|string|max:255',
                        'calle' => 'required|string|max:255',
                        'numero' => 'required|string|min:1|max:255',
                        'departamento' => 'required|string|max:255',
                        'alladode' => 'required|string|max:255',
                        'frentea' => 'required|string|max:255',
                        'entrecalles' => 'required|string|max:255',
                        'colonia' => 'required|string|max:255',
                        'localidad' => 'required|string|max:255',
                        'telefono' => 'required|string|size:10|regex:/[0-9]/',
                        'casatipo' => 'required|string|max:255',
                        'casacolor' => 'required|string|max:255',
                        'nr' => 'required|string|max:255',
                        'tr' => 'required|string|size:10|regex:/[0-9]/',
                    ];

                    request()->validate($rules);

                    DB::table("historialclinico")->where("id_contrato", "=", $idContrato)->update([
                        'edad' => request('edad')
                    ]);

                    $idAsistenteActualizar = $existeContrato[0]->id_usuariocreacion;
                    $nombreAsistenteActualizar = $existeContrato[0]->nombre_usuariocreacion;
                    $idOptometristaActualizar = $existeContrato[0]->id_optometrista;
                    $idZonaActualizar = $existeContrato[0]->id_zona;

                    //ACTUALIZAR ASISTENTE Y OPTO
                    if ($existeContrato[0]->estatus_estadocontrato == 0 || $existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 9) {
                        //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION
                        $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");
                        if ($tieneHistorialGarantia == null) {
                            //No tiene garantias
                            $consultaAsistenteActualizar = DB::select("SELECT name FROM users WHERE id = '" . request('asistente') . "'");
                            if ($consultaAsistenteActualizar != null) {
                                $idAsistenteActualizar = request('asistente');
                                $nombreAsistenteActualizar = $consultaAsistenteActualizar[0]->name;
                                $idOptometristaActualizar = request('optometrista');
                            }
                        }
                    }

                    //ACTUALIZAR ZONA
                    if ($existeContrato[0]->estatus_estadocontrato == 0 || $existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 9
                            || $existeContrato[0]->estatus_estadocontrato == 7) {
                        //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION Y APROBADO
                        $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");
                        if ($tieneHistorialGarantia == null) {
                            //No tiene garantias
                            $idZonaActualizar = request('zona');
                        }
                    }

                    DB::table("contratos")->where("id", "=", $idContrato)->update([
                        'id_zona' => $idZonaActualizar,
                        'nombre' => request('nombre'),
                        'calle' => request('calle'),
                        'numero' => request('numero'),
                        'depto' => request('departamento'),
                        'alladode' => request('alladode'),
                        'frentea' => request('frentea'),
                        'entrecalles' => request('entrecalles'),
                        'colonia' => request('colonia'),
                        'localidad' => request('localidad'),
                        'telefono' => request('telefono'),
                        'casatipo' => request('casatipo'),
                        'casacolor' => request('casacolor'),
                        'telefonoreferencia' => request('tr'),
                        'nombrereferencia' => request('nr'),
                        'coordenadas' => request('coordenadas'),
                        'id_usuariocreacion' => $idAsistenteActualizar,
                        'nombre_usuariocreacion' => $nombreAsistenteActualizar,
                        'id_optometrista' => $idOptometristaActualizar
                    ]);

                    //Guardar movimiento en historialcontrato
                    $globalesServicioWeb = new globalesServicioWeb;
                    $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');
                    $usuarioId = Auth::user()->id;
                    $actualizar = Carbon::now();

                    DB::table('historialcontrato')->insert([
                        'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo el contrato"
                    ]);

                    $contratosGlobal = new contratosGlobal;

                    $idZonaActualizarAprobados = $existeContrato[0]->id_zona;
                    if($existeContrato[0]->id_zona != $idZonaActualizar) {
                        //Es por que se cambio la zona del contrato
                        $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $existeContrato[0]->id_zona . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona anterior

                        if ($cobradoresAsignadosAZona != null) {
                            //Existen cobradores
                            foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                //Recorrido cobradores
                                DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato' AND id_usuario = '" . $cobradorAsignadoAZona->id . "'");
                            }
                        }

                        $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $idZonaActualizar . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona nueva

                        if ($cobradoresAsignadosAZona != null) {
                            //Existen cobradores
                            foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                //Recorrido cobradores
                                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                            }
                        }

                        $idZonaActualizarAprobados = $idZonaActualizar;
                    }

                    //Validacion de si es garantia o no
                    $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1 ORDER BY created_at LIMIT 1");

                    switch ($existeContrato[0]->estatus_estadocontrato) {
                        case 0:
                        case 1:
                        case 9: //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION
                            //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                            if ($tieneHistorialGarantia != null) {
                                //Tiene garantia
                                $ultimaGarantiaCreada = DB::select("SELECT id_optometrista FROM garantias WHERE id_contrato = '$idContrato'
                                                                                AND id_historialgarantia = '" . $tieneHistorialGarantia[0]->id . "'
                                                                                ORDER BY created_at LIMIT 1");
                                if($ultimaGarantiaCreada != null) {
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $ultimaGarantiaCreada[0]->id_optometrista);
                                }
                            }else {
                                //No tiene garantia
                                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $idAsistenteActualizar);
                            }
                            break;
                        case 7: //APROBADO
                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato (Opcional lo puse en caso de que no se haga en confirmaciones)
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                            //Agregar contrato a cobradores si tiene garantia el contrato
                            if ($tieneHistorialGarantia != null) {
                                //Tiene garantia
                                $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $idZonaActualizarAprobados . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona

                                if ($cobradoresAsignadosAZona != null) {
                                    //Existen cobradores
                                    foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                        //Recorrido cobradores
                                        $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                                    }
                                }
                            }
                            break;
                    }

                    return back()->with("bien", "El contrato se actualizo correctamente.");

                }

                return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");

            }

            return back()->with("alerta","No se encontro el contrato.");

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }

    }

    public function actualizarTotalContratoConfirmacioness($idContrato){
        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))
        {
            $existeContrato = DB::select("SELECT c.id,c.estatus_estadocontrato,c.promocionterminada,c.id_franquicia,c.pago,c.enganche,
                                                (SELECT (SELECT promoc.id FROM promocion promoc WHERE promoc.armazones = '1' AND promoc.id = pc.id_promocion) FROM promocioncontrato pc WHERE pc.id_contrato = c.id AND pc.estado = '1') AS promocion,
                                                c.subscripcion FROM contratos  c WHERE  c.id = '$idContrato'");
            if($existeContrato != null){
                //Existe el contrato
                if($existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 9){
                    //TERMINADO/PROCESO DE APROBACION

                    if($existeContrato[0]->subscripcion == null){
                        //No esta subscripto a meses con tarjeta

                        $totalActualizado = request('totalActualizado');
                        $totalAbono = DB::select("SELECT SUM(abono) as sumaabonos FROM abonos where id_contrato = '$idContrato' AND tipoabono != 7");
                        if($totalAbono != null && ($totalAbono[0]->sumaabonos <= $totalActualizado)){

                            if($existeContrato[0]->promocion != null) {
                                //Tiene promocion y esta activa
                                if($existeContrato[0]->promocionterminada == 1) {
                                    //Promocion terminada
                                    $id_promocion = $existeContrato[0]->promocion;
                                    $promocion = DB::select("SELECT tipopromocion, precioP, preciouno FROM promocion where id = '$id_promocion'");

                                    if($promocion != null) {
                                        //Si existe la promocion

                                        if($promocion[0]->tipopromocion == 1) {
                                            //Promocion fija
                                            $preciouno = $promocion[0]->preciouno;
                                            DB::table("contratos")->where("id","=",$idContrato)->update([
                                                "totalhistorial" => $totalActualizado,
                                                "totalreal" => $totalActualizado,
                                                "totalpromocion" => $totalActualizado - $preciouno
                                            ]);
                                        }else {
                                            //Promocion por porcentaje
                                            $precioP = $promocion[0]->precioP;
                                            $totalpromocion = $totalActualizado - (($totalActualizado / 100) * $precioP);
                                            DB::table("contratos")->where("id","=",$idContrato)->update([
                                                "totalhistorial" => $totalActualizado,
                                                "totalreal" => $totalActualizado,
                                                "totalpromocion" => $totalpromocion
                                            ]);
                                        }

                                    }else {
                                        //No existe la promocion
                                        return back()->with("alerta","La promocion ya no existe actualmente.");
                                    }

                                }else {
                                    //Promocion no ha sido terminada
                                    return back()->with("alerta","No se puede actualizar el total del contrato por que la promocion aun no ha sido terminada.");
                                }

                            }else {
                                //No tiene promocion

                                if($existeContrato[0]->pago == 0 && $totalAbono[0]->sumaabonos > 0) {
                                    //Forma de pago de contado y tiene abonos

                                    $descuento = 0;
                                    if($this->obtenerBanderaContadoEngancheOSinEnganche($idContrato, $existeContrato[0]->id_franquicia, 4)) {
                                        //Tiene contadoenganche

                                        if($this->obtenerBanderaContadoEngancheOSinEnganche($idContrato, $existeContrato[0]->id_franquicia, 5)) {
                                            //Tiene contadosinenganche
                                            $descuento = 300;
                                        }else {
                                            //No tiene contadosinenganche
                                            $descuento = 100;
                                        }
                                    }else {
                                        //No tiene contadoenganche

                                        if($this->obtenerBanderaContadoEngancheOSinEnganche($idContrato, $existeContrato[0]->id_franquicia, 5)) {
                                            //Tiene contadosinenganche
                                            if ($existeContrato[0]->enganche == 1) {
                                                //Tiene activado el enganche
                                                $descuento = 200;
                                            }else {
                                                //No tiene activado el enganche
                                                $descuento = 300;
                                            }
                                        }else {
                                            //No tiene contadosinenganche
                                            $descuento = 0;
                                        }
                                    }

                                    $totalrealActualizar = $totalActualizado;
                                    $totalActualizado = $totalActualizado - $descuento;

                                }else {
                                    //Forma de pago contado y no tiene abono o semanal, quicenal o mensual

                                    $totalrealActualizar = $totalActualizado;
                                    if ($existeContrato[0]->enganche == 1) {
                                        //Tiene activado el enganche
                                        $totalActualizado = $totalActualizado - 100;
                                    }

                                }

                                if($totalActualizado < $totalAbono[0]->sumaabonos) {
                                    return back()->with("alerta","No se puede actualizar el total del contrato por que es menor al total de abonos.");
                                }

                                DB::table("contratos")->where("id","=",$idContrato)->update([
                                    "totalhistorial" => $totalActualizado,
                                    "totalreal" => $totalrealActualizar
                                ]);

                            }

                            //Calculo total
                            $this->calculoTotal($idContrato, $existeContrato[0]->id_franquicia);

                            return back()->with("bien","El total se actualizo correctamente.");

                        }else{
                            return back()->with("alerta","No se puede actualizar el total del contrato por que es mayor el total de abonos.");
                        }

                    }else{
                        return back()->with("alerta","El contrato tiene una subscripcion.");
                    }

                }else{
                    return back()->with("alerta","El contrato no tiene el estatus de TERMINADO/PROCESO DE APROBACION.");
                }
            }else{
                return back()->with("alerta","No se encontro el contrato.");
            }


        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function obtenerBanderaContadoEngancheOSinEnganche($idContrato, $idFranquicia, $tipo) {

        $respuesta = false;

        $consultaabono = DB::select("SELECT id FROM abonos WHERE id_contrato = '$idContrato' AND id_franquicia = '$idFranquicia' AND tipoabono = '$tipo'");

        if ($consultaabono != null) {
            $respuesta = true;
        }

        return $respuesta;
    }

    public function listagarantiasconfirmaciones(){

        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))        {

            //Solo los roles de principal, director y confirmaciones pueden entrar
            $filtro = request('filtro');
            $contratosGaratias = null;
            if($filtro != null){ //Tenemos un filtro?
                //Tenemos un filtro
                try{
                    if((Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 7){
                        //Es un usuario principal o administrador

                        $contratosGaratias = DB::table('contratos as c')
                            ->join('estadocontrato as ec', 'ec.estatus', '=', 'c.estatus_estadocontrato')
                            ->join('sucursalesconfirmaciones as sc', 'c.id_franquicia', '=', 'sc.id_franquicia')
                            ->select('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->whereRaw("c.datos = 1")
                            ->whereRaw("c.id like '%$filtro%'")
                            ->groupBy('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->orderBy('c.created_at', 'DESC')
                            ->paginate(200);
                    }else{

                        $contratosGaratias = DB::table('contratos as c')
                            ->join('estadocontrato as ec', 'ec.estatus', '=', 'c.estatus_estadocontrato')
                            ->join('sucursalesconfirmaciones as sc', 'c.id_franquicia', '=', 'sc.id_franquicia')
                            ->select('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->whereRaw("sc.id_usuario = '".Auth::user()->id."'")
                            ->whereRaw("c.datos = 1")
                            ->whereRaw("c.id like '%$filtro%'")
                            ->groupBy('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->orderBy('c.created_at', 'DESC')
                            ->paginate(200);
                    }
                }catch(\Exception $e){
                    \Log::info("Error".$e);
                }
            }else{
                //Sin filtro
                try{
                    if((Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 7){
                        //Es un usuario principal o administrador

                        $contratosGaratias = DB::table('contratos as c')
                            ->join('estadocontrato as ec', 'ec.estatus', '=', 'c.estatus_estadocontrato')
                            ->join('sucursalesconfirmaciones as sc', 'c.id_franquicia', '=', 'sc.id_franquicia')
                            ->select('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->whereRaw("c.datos = 1")
                            ->groupBy('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->orderBy('c.created_at', 'DESC')
                            ->paginate(50);
                    }else{
                        //Es un usuario de confirmaciones
                        $contratosGaratias = DB::table('contratos as c')
                            ->join('estadocontrato as ec', 'ec.estatus', '=', 'c.estatus_estadocontrato')
                            ->join('sucursalesconfirmaciones as sc', 'c.id_franquicia', '=', 'sc.id_franquicia')
                            ->select('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->whereRaw("sc.id_usuario = '".Auth::user()->id."'")
                            ->whereRaw("c.datos = 1")
                            ->groupBy('c.id','ec.descripcion','c.nombre','c.created_at')
                            ->orderBy('c.created_at', 'DESC')
                            ->paginate(50);

                    }
                }catch(\Exception $e){
                    \Log::info("Error".$e);
                }
            }

            return view("administracion.confirmaciones.tablagarantias",['contratosGaratias' => $contratosGaratias]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function vercontratogarantiaconfirmaciones($idContrato){

        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))        {

            $contrato = null;
            $historiales = null;

            try{

                $contrato = DB::select("SELECT c.id,c.estatus_estadocontrato,ec.descripcion,z.zona,c.banderacomentarioconfirmacion,
                                            (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as opto,
                                            (SELECT z.zona FROM zonas z WHERE z.id = c.id_zona) as zonacontrato,
                                          c.nombre,c.calle,c.numero,c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,
                                          c.casatipo,c.casacolor,c.nombrereferencia,c.telefonoreferencia,c.correo,c.fotoine,c.fotoineatras,c.fotocasa,c.comprobantedomicilio,
                                          c.tarjeta,c.tarjetapensionatras,c.pago,ec.descripcion,c.pagare,c.total,c.totalpromocion,(SELECT estado FROM promocioncontrato pc WHERE pc.id_contrato = c.id) AS promocion,
                                          (SELECT SUM(a.abono) FROM abonos a WHERE a.id_contrato = c.id)as totalabonos,c.id_zona, c.subscripcion,
                                          (SELECT p.titulo FROM promocion p WHERE p.id = c.id_promocion) as titulopromocion
                                          FROM contratos c
                                          INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                          INNER JOIN zonas z ON z.id = c.id_zona
                                          WHERE c.datos = 1
                                          AND c.id = '$idContrato'");
                if($contrato == null){
                    return back()->with("alerta","No se encontro el contrato.");
                }
                $franquicia = DB::select("SELECT id_franquicia FROM contratos WHERE id = '$idContrato'");
                $idFranquicia =  $franquicia[0]->id_franquicia;
                $historiales =  DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon,
                                                    hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,hc.observacionesinterno,
                                                    (SELECT p.nombre FROM paquetes p WHERE p.id = hc.id_paquete AND p.id_franquicia = '$idFranquicia' LIMIT 1) as paquete
                                                    FROM historialclinico hc WHERE id_contrato = '$idContrato'");

                $infoFranquicia = DB::select("SELECT estado,ciudad,colonia,numero FROM franquicias WHERE id = '".$franquicia[0]->id_franquicia."'");

            }catch(\Exception $e){
                \Log::info("Error".$e);
            }

            return view("administracion.confirmaciones.contratogarantia",["contrato" => $contrato, "infoFranquicia" => $infoFranquicia,
                'idContrato'=>$idContrato,'historiales'=> $historiales]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function rechazarContratoConfirmaciones($idContrato)
    {
        $comentarios = request('comentarios');

        if (strlen($comentarios) == 0) {
            //Comentarios vacio
            return back()->with('alerta', 'Campo especificaciónes obligatorio');
        }

        $contrato = DB::select("SELECT estatus_estadocontrato, promocionterminada FROM contratos WHERE id = '$idContrato'");

        if ($contrato != null) {

            $existeGarantia = DB::select("SELECT * FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = '2' ORDER BY created_at ASC limit 1");

            if($existeGarantia == null){
                //No tiene garantia el contrato
                if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15))) {

                    if($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) {
                        //Estado del contrato es TERMIANDO o EN PROCESO DE APROBACION

                        if ($this->obtenerEstadoPromocion($idContrato) && $contrato[0]->promocionterminada == 0) {
                            //Tiene promocion y promocion no ha sido terminada
                            return redirect()->route('estadoconfirmacion', [$idContrato])->with('alerta', 'No se puede rechazar el contrato por que tiene una promocion sin terminar');
                        }

                        $actualizar = Carbon::now();
                        $usuarioId = Auth::user()->id;

                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');

                        try {

                            DB::table('contratos')->where('id', '=', $idContrato)->update([
                                'estatus_estadocontrato' => 8, 'estatusanteriorcontrato' => $contrato[0]->estatus_estadocontrato
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 8,
                                'created_at' => Carbon::now()
                            ]);

                            DB::table('historialcontrato')->insert([
                                'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Contrato rechazado por confirmaciones con la siguiente descripcion: '$comentarios'"
                            ]);

                            //Reducir calidad a imagenes del contrato
                            $this->reducirCalidadImagenesContrato($idContrato);

                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                            return redirect()->route('listaconfirmaciones')->with('bien', 'El contrato se rechazo correctamente.');

                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e->getMessage());
                            return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
                        }

                    }else{
                        return back()->with('alerta','Necesitas permisos adicionales para hacer esto.');
                    }

                } else {
                    if (Auth::check()) {
                        return redirect()->route('redireccionar');
                    } else {
                        return redirect()->route('login');
                    }
                }
            }else{
                //Si tiene garantia -> no se puede rechazar el contrato
                return back()->with('alerta', 'No se puedes rechazar el contrato debido a que tiene garantia.');
            }
        }
        return back()->with('alerta', 'No se encontro el contrato.');
    }

    private function obtenerEstadoPromocion($idContrato)
    {
        $respuesta = false;

        $contrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato'");
        if ($contrato[0]->idcontratorelacion != null) {
            //Es un contrato hijo
            $idContrato = $contrato[0]->idcontratorelacion;
        }

        $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_contrato = '$idContrato'");

        if ($promocioncontrato != null) {
            if ($promocioncontrato[0]->estado == 1) {
                //Promocion esta activa
                $respuesta = true;
            }
        }
        return $respuesta;
    }

    public function cancelarGarantiaHistorialConfirmaciones($idContrato, $idHistorial)
    {
        if (Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15))) {

            try {

                $datosHistorial = DB::select("SELECT id_contrato FROM historialclinico WHERE id = '$idHistorial' AND id_contrato = '$idContrato'");

                if ($datosHistorial != null) {
                    $idContrato = $datosHistorial[0]->id_contrato;

                    $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idContrato'");

                    if ($contrato != null) {
                        //Existe el contrato

                        if ($contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 7 || $contrato[0]->estatus_estadocontrato == 9) {
                            //TERMINADO, APROBADO O EN PROCESO DE APROBACION

                            $garantiasCancelar = DB::select("SELECT id, id_historial, estadocontratogarantia, totalhistorialcontratogarantia, totalpromocioncontratogarantia,
                                                                    totalrealcontratogarantia FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = 2");

                            if ($garantiasCancelar != null) {//Tiene garantias para cancelar?
                                //Tiene garantias para cancelar

                                $globalesServicioWeb = new globalesServicioWeb;
                                $usuarioId = Auth::user()->id;

                                foreach ($garantiasCancelar as $garantiaCancelar) {

                                    $idGarantia = $garantiaCancelar->id;
                                    $idhistorial = $garantiaCancelar->id_historial;
                                    $estadocontratogarantia = $garantiaCancelar->estadocontratogarantia;
                                    $totalhistorialcontratogarantia = $garantiaCancelar->totalhistorialcontratogarantia;
                                    $totalpromocioncontratogarantia = $garantiaCancelar->totalpromocioncontratogarantia;
                                    $totalrealcontratogarantia = $garantiaCancelar->totalrealcontratogarantia;

                                    //Ya se habian creado las garantias
                                    $contrato = DB::select("SELECT totalhistorial, totalpromocion, totalabono, totalproducto FROM contratos WHERE id = '$idContrato'");

                                    if ($contrato != null) {
                                        //Se encontro el contrato
                                        $totalhistorial = $contrato[0]->totalhistorial;
                                        $totalpromocion = $contrato[0]->totalpromocion;
                                        $totalabono = $contrato[0]->totalabono;
                                        $totalproducto = $contrato[0]->totalproducto;

                                        if ($this->obtenerEstadoPromocion($idContrato)) {
                                            //Tiene promocion
                                            if ($totalpromocion > $totalpromocioncontratogarantia) {
                                                //Devolver el estado del contrato, el total, y el totalpromocion a como estaban
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia,
                                                    'total' => $totalpromocioncontratogarantia + $totalproducto - $totalabono,
                                                    'totalpromocion' => $totalpromocioncontratogarantia,
                                                    'totalhistorial' => $totalhistorialcontratogarantia,
                                                    'totalreal' => $totalrealcontratogarantia
                                                ]);
                                            } else {
                                                //Devolver el estado del contrato
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia
                                                ]);
                                            }

                                        } else {
                                            //No tiene promocion
                                            if ($totalhistorial > $totalhistorialcontratogarantia) {
                                                //Devolver el estado del contrato, el total, y el totalhistorial a como estaban
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia,
                                                    'total' => $totalhistorialcontratogarantia + $totalproducto - $totalabono,
                                                    'totalhistorial' => $totalhistorialcontratogarantia,
                                                    'totalpromocion' => $totalpromocioncontratogarantia,
                                                    'totalreal' => $totalrealcontratogarantia
                                                ]);
                                            } else {
                                                //Devolver el estado del contrato
                                                DB::table('contratos')->where('id', '=', $idContrato)->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia
                                                ]);
                                            }

                                        }

                                        //Insertar en tabla registroestadocontrato
                                        DB::table('registroestadocontrato')->insert([
                                            'id_contrato' => $idContrato,
                                            'estatuscontrato' => $estadocontratogarantia,
                                            'created_at' => Carbon::now()
                                        ]);

                                    } else {
                                        return redirect()->route('listaconfirmaciones')->with('alerta', 'No se encontro el contrato.');
                                    }

                                    //Actualizar estadogarantia a 4
                                    DB::table('garantias')->where([['id', '=', $idGarantia], ['id_contrato', '=', $idContrato], ['id_historial', '=', $idhistorial]])->update([
                                        'estadogarantia' => 4,
                                        'updated_at' => Carbon::now()
                                    ]);
                                    //Guardar movimiento
                                    DB::table('historialcontrato')->insert([
                                        'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se cancelo la garantia al historial '$idhistorial'"
                                    ]);

                                    //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                                    DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion (Pondre mi id_usuario (Sergio) para que salgan bien las cosas)
                                    $contratosGlobal = new contratosGlobal;
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, '61');

                                }

                                return redirect()->route('listaconfirmaciones')->with('bien', 'Se cancelo correctamente la garantia.');
                            }

                            //No tiene garantias para cancelar
                            return redirect()->route('listaconfirmaciones')->with('alerta', 'No se puede cancelar la garantia por que no tiene asignada.');

                        }

                        return back()->with("alerta", "Necesitas permisos adicionales para hacer esto.");

                    }

                    return back()->with("alerta","No se encontro el contrato.");

                } else {
                    //No presenta hitorial clinico
                    return back()->with("alerta","No se encontro el historial clinico del contrato");
                }

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function listaconfirmacioneslaboratrio(Request $request){

        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))        {

            //Solo los roles de Administracion, principal, director y confirmaciones pueden entrar

            $filtro = $request->input('filtro');
            $cbAprobados = $request->input('cbAprobados');
            $cbManofactura = $request->input('cbManofactura');
            $cbEnviados = $request->input('cbEnviados');
            $cbComentarios = $request->input('cbComentarios');

            $contratosScomentarios = null;
            $contratosConComentarios = null;

            $estado_contrato = "";

            if($cbAprobados == "true" && $cbManofactura == "true" && $cbEnviados == "true"){
                $estado_contrato = "7,10,11";
            }if(($cbAprobados == "true") && ($cbManofactura == "true") && ($cbEnviados == "false")){
                $estado_contrato = "7,10";
            }if(($cbAprobados == "true") && ($cbManofactura == "false") && ($cbEnviados == "false")){
                $estado_contrato = "7";
            }if(($cbAprobados == "false") && ($cbManofactura == "true") && ($cbEnviados == "false")) {
                $estado_contrato = "10";
            }if(($cbAprobados == "false") && ($cbManofactura == "true") && ($cbEnviados == "true")){
                $estado_contrato = "10,11";
            } if(($cbAprobados == "false") && ($cbManofactura == "false") && ($cbEnviados == "true")){
                $estado_contrato = "11";
            }if(($cbAprobados == "true") && ($cbManofactura == "false") && ($cbEnviados == "true")){
                $estado_contrato = "7,11";
            }if(($cbAprobados == "false") && ($cbManofactura == "false") && ($cbEnviados == "true")){
                $estado_contrato = "11";
            }

            if($filtro != null){ //Tenemos un filtro?
                //Tenemos un filtro
                try{
                    if((Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 7){
                        //Es un usuario principal o administrador
                        if($cbComentarios == "true"){
                            //Esta seleccionado con Comentarios
                            $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN ($estado_contrato)
                                                                   AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                                   AND c.banderacomentarioconfirmacion = 3
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato DESC");
                        } else{
                            $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN ($estado_contrato)
                                                                   AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                                   AND c.banderacomentarioconfirmacion != 3
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato DESC");
                        }
                    }else{
                        if($cbComentarios == "true"){
                            $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN ($estado_contrato)
                                                AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                AND c.banderacomentarioconfirmacion = 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato DESC");
                        } else{
                            $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal   FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN ($estado_contrato)
                                                AND (c.id like '%$filtro%' or us.name like '%$filtro%')
                                                AND c.banderacomentarioconfirmacion != 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato DESC");
                        }
                    }
                }catch(\Exception $e){
                    \Log::info("Error".$e);
                }
            }else{
                //Sin filtro
                try{
                    if((Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 7){
                        //Es un usuario principal o administrador

                        if($cbComentarios == "true"){
                            $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN ($estado_contrato)
                                                                   AND c.banderacomentarioconfirmacion = 3
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato DESC");
                        } else {
                            $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                                   INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                                   INNER JOIN usuariosfranquicia uf ON c.id_franquicia = uf.id_franquicia
                                                                   INNER JOIN users u ON c.id_optometrista = u.id
                                                                   INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                                   INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                   WHERE c.estatus_estadocontrato IN ($estado_contrato)
                                                                   AND c.banderacomentarioconfirmacion != 3
                                                                   GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                                   ORDER BY c.estatus_estadocontrato DESC");

                        }
                    }else{
                        //Es un usuario de confirmaciones

                        if($cbComentarios == "true"){
                            $contratosConComentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN ($estado_contrato)
                                                AND c.banderacomentarioconfirmacion = 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato DESC");
                        } else {
                            $contratosScomentarios = DB::select("SELECT c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion, c.id_optometrista, c.created_at, u.name, us.name as usuariocreacion, f.ciudad as sucursal FROM contratos c
                                                INNER JOIN estadocontrato ec ON ec.estatus = c.estatus_estadocontrato
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON c.id_optometrista = u.id
                                                INNER JOIN users us ON c.id_usuariocreacion = us.id
                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                WHERE sc.id_usuario = '".Auth::user()->id."'
                                                AND c.estatus_estadocontrato IN ($estado_contrato)
                                                AND c.banderacomentarioconfirmacion != 3
                                                GROUP BY c.id,ec.descripcion,c.estatus_estadocontrato,c.banderacomentarioconfirmacion,c.created_at,c.id_optometrista,u.name, us.name, f.ciudad
                                                ORDER BY c.estatus_estadocontrato DESC");
                        }
                    }
                }catch(\Exception $e){
                    \Log::info("Error".$e);
                }
            }

            $view = view('administracion.confirmaciones.confirmacioneslaboratorio.tablalaboratorio', [
                'contratosScomentarios'=>$contratosScomentarios,
                'contratosConComentarios'=>$contratosConComentarios]) -> render();

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
        return \Response::json(array("valid"=>"true","view"=>$view));
    }

    public function agregarproductoconfirmaciones($idContrato) {

        $producto = request('producto');

        if (strlen($producto) > 0) {
            //producto diferente de vacio

            try {

                $contrato = DB::select("SELECT estatus_estadocontrato, id_franquicia, id_usuariocreacion FROM contratos WHERE id = '$idContrato'");

                if($contrato != null) {
                    $estadoContrato = $contrato[0]->estatus_estadocontrato;

                    if($estadoContrato == 1 || $estadoContrato == 9) {
                        //TERMINADO O EN PROCESO DE APROBACION
                        $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");

                        if($tieneHistorialGarantia != null) {
                            //Tiene historiales con garantia
                            return back()->with("alerta","No se puede agregar producto por que es una garantia.");
                        }

                        $globalesServicioWeb = new globalesServicioWeb;

                        $idFranquicia = $contrato[0]->id_franquicia;
                        $id_usuariocreacion = $contrato[0]->id_usuariocreacion;

                        $datosproducto = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id = '$producto'");

                        if($datosproducto != null) {
                            //Existe el producto

                            $precio = $datosproducto[0]->precio;
                            $nombre = $datosproducto[0]->nombre;
                            $preciop = $datosproducto[0]->preciop;
                            $piezasactualizar = $datosproducto[0]->piezas - 1;
                            if ($preciop == null) {
                                $precioproducto = $precio * 1;
                            } else {
                                $precioproducto = $preciop * 1;
                            }

                            //Agregar producto al contrato
                            DB::table('contratoproducto')->insert([
                                'id' => $globalesServicioWeb::generarIdAlfanumerico('contratoproducto', '5'),
                                'id_franquicia' => $idFranquicia,
                                'id_contrato' => $idContrato,
                                'id_usuario' => $id_usuariocreacion,
                                'id_producto' => $producto,
                                'piezas' => 1,
                                'total' => $precioproducto,
                                'created_at' => Carbon::now()
                            ]);

                            //Descontar pieza al producto
                            DB::table('producto')->where([['id', '=', $producto], ['id_franquicia', '=', $idFranquicia]])->update([
                                'piezas' => $piezasactualizar
                            ]);

                            //Guardar en historial de movimientos el producto
                            DB::table('historialcontrato')->insert([
                                'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'),
                                'id_usuarioC' => Auth::user()->id,
                                'id_contrato' => $idContrato,
                                'created_at' => Carbon::now(),
                                'cambios' => " Se agrego el producto: '$producto'-'$nombre' cantidad de piezas: '1' con total de: $'$precioproducto'"
                            ]);

                            //Agregar abono al contrato
                            DB::table('abonos')->insert([
                                'id' => $globalesServicioWeb::generarIdAlfanumerico('abonos', '5'),
                                'folio' => null,
                                'id_franquicia' => $idFranquicia,
                                'id_contrato' => $idContrato,
                                'id_usuario' => $id_usuariocreacion,
                                'tipoabono' => 7,
                                'abono' => $precioproducto,
                                'metodopago' => 0,
                                'adelantos' => 0,
                                'corte' => 2,
                                'created_at' => Carbon::now()
                            ]);

                            //Guardar en historial de movimientos el abono
                            DB::table('historialcontrato')->insert([
                                'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'),
                                'id_usuarioC' => Auth::user()->id,
                                'id_contrato' => $idContrato,
                                'created_at' => Carbon::now(),
                                'cambios' => " Se agrego el abono : '$precioproducto'"
                            ]);

                            //Calculo del total
                            $this->calculoTotal($idContrato, $idFranquicia);

                            return back()->with("bien", "Se agrego correctamente el producto.");

                        }

                        return back()->with("alerta","El producto no existe.");

                    }

                    return back()->with("alerta","Solo se puede agregar producto con estatus TERMINADO/EN PROCESO DE APROBACION.");

                }

                return back()->with("alerta","El contrato no existe.");

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        }

        return back()->with("alerta","Seleccionar el producto a agregar.");

    }

    public function calculoTotal($idContrato, $idFranquicia)
    {

        $this->actualizarTotalProductoContrato($idContrato, $idFranquicia);
        $this->actualizarTotalAbonoContrato($idContrato, $idFranquicia);

        if ($this->obtenerEstadoPromocion($idContrato)) {
            //Tiene promocion y esta activa
            $promocionterminada = DB::select("SELECT promocionterminada FROM contratos where id = '$idContrato'");
            if ($promocionterminada != null) {
                if ($promocionterminada[0]->promocionterminada == 1) {
                    //Promocion ha sido terminada
                    DB::update("UPDATE contratos
                        SET total = coalesce(totalpromocion,0)  + coalesce(totalproducto,0) - coalesce(totalabono,0)
                        WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                } else {
                    //Promocion no ha sido terminada
                    DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                }
            }
        } else {
            //No tiene promocion o existe la promocion pero esta desactivada
            DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
        }
    }

    private function actualizarTotalProductoContrato($idContrato, $idFranquicia)
    {
        DB::update("UPDATE contratos c
                    SET c.totalproducto = coalesce((SELECT SUM(cp.total) FROM contratoproducto cp WHERE cp.id_contrato = c.id), 0)
                    WHERE c.id = '$idContrato' AND c.id_franquicia ='$idFranquicia'");
    }

    private function actualizarTotalAbonoContrato($idContrato, $idFranquicia)
    {
        DB::update("UPDATE contratos c
                    SET c.totalabono = coalesce((SELECT SUM(a.abono) FROM abonos a WHERE a.id_contrato = c.id), 0)
                    WHERE c.id = '$idContrato' AND c.id_franquicia ='$idFranquicia'");
    }

    public function listaconfirmacionesgarantiasprincipal(){

        if(Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15)))        {

            //Solo los roles de Administracion, principal, director y confirmaciones pueden entrar

            try{

                if((Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 7){
                    //Es un usuario principal o director

                    $contratosGarantias = DB::select("SELECT g.id_contrato AS id_contrato,
                                                                c.created_at AS fechacreacioncontrato,
                                                                c.estatus_estadocontrato AS estatus_estadocontrato,
                                                                c.nombre_usuariocreacion AS nombre_usuariocreacion,
                                                                (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) AS nombreoptometrista,
                                                                (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as descripcion,
                                                                (SELECT ga.created_at FROM garantias ga WHERE ga.id_contrato = g.id_contrato AND ga.estadogarantia IN (0,1) ORDER BY created_at DESC LIMIT 1) as fechacreaciongarantia,
                                                                (SELECT ga.estadogarantia FROM garantias ga WHERE ga.id_contrato = g.id_contrato AND ga.estadogarantia IN (0,1) ORDER BY created_at DESC LIMIT 1) as estadogarantia,
                                                                f.ciudad as sucursal
                                                                FROM garantias g INNER JOIN contratos c
                                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                WHERE g.id_contrato = c.id
                                                                AND c.id_franquicia != '00000'
                                                                AND g.estadogarantia IN (0,1)
                                                                AND c.estatus_estadocontrato IN (2,4,5,12)
                                                                GROUP BY g.id_contrato, c.created_at, c.estatus_estadocontrato, c.nombre_usuariocreacion, c.id_optometrista, f.ciudad");

                }else{
                    //Es un usuario de confirmaciones

                    $contratosGarantias = DB::select("SELECT g.id_contrato AS id_contrato,
                                                                c.created_at AS fechacreacioncontrato,
                                                                c.estatus_estadocontrato AS estatus_estadocontrato,
                                                                c.nombre_usuariocreacion AS nombre_usuariocreacion,
                                                                (SELECT u.name FROM users u WHERE u.id = c.id_optometrista) AS nombreoptometrista,
                                                                (SELECT ec.descripcion FROM estadocontrato ec WHERE ec.estatus = c.estatus_estadocontrato) as descripcion,
                                                                (SELECT ga.created_at FROM garantias ga WHERE ga.id_contrato = g.id_contrato AND ga.estadogarantia IN (0,1) ORDER BY created_at DESC LIMIT 1) as fechacreaciongarantia,
                                                                (SELECT ga.estadogarantia FROM garantias ga WHERE ga.id_contrato = g.id_contrato AND ga.estadogarantia IN (0,1) ORDER BY created_at DESC LIMIT 1) as estadogarantia,
                                                                f.ciudad as sucursal
                                                                FROM garantias g INNER JOIN contratos c
                                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                                INNER JOIN franquicias f ON c.id_franquicia = f.id
                                                                WHERE g.id_contrato = c.id
                                                                AND sc.id_usuario = '" . Auth::user()->id . "'
                                                                AND g.estadogarantia IN (0,1)
                                                                AND c.estatus_estadocontrato IN (2,4,5,12)
                                                                GROUP BY g.id_contrato, c.created_at, c.estatus_estadocontrato, c.nombre_usuariocreacion, c.id_optometrista, f.ciudad");

                }

            }catch(\Exception $e){
                \Log::info("Error".$e);
            }

            $view = view('administracion.confirmaciones.confirmacioneslaboratorio.tablagarantiasvistaprincipal', [
                'contratosGarantias'=>$contratosGarantias])->render();

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
        return \Response::json(array("valid"=>"true","view"=>$view));
    }

    //Funcion: actualizardiagnosticoconfirmaciones
    //Descripcion: Permite actualizar el diagnostico para un contrato y actualiza los historiales
    public function actualizardiagnosticoconfirmaciones($idContrato){
        if (Auth::check() && (((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 15))) {
            $edad = request('edad');
            $diagnostico = request('diagnostico');
            $ocupacion = request('ocupacion');
            $diabetes = request('diabetes');
            $hipertension = request('hipertension');
            $embarazada = request('embarazada');
            $durmioseisochohoras = request('durmioseisochohoras');
            $actividaddia = request('actividaddia');
            $problemasojos = request('problemasojos');
            $dolor = request('dolor');
            $golpeojos = request('golpeojos');
            $ardor = request('ardor');
            $otroM = request('otroM');
            $molestiaotro = request('molestiaotro');
            $ultimoexamen = request('ultimoexamen');

            //Valores checkBox
            $dolor = ($dolor != null)? $dolor = 1: $dolor = 0;
            $ardor = ($ardor != null)? $ardor = 1: $ardor = 0;
            $golpeojos = ($golpeojos != null)? $golpeojos = 1: $golpeojos = 0;
            $otroM = ($otroM != null)? $otroM = 1: $otroM = 0;

            //Si se selecciono Otra Molestia
            if($otroM == 1){
                //Si se selecciona es obligatorio llenar la opcion de otro
                $rules = [
                    'molestiaotro' => 'required|string'
                ];
                request()->validate($rules);
            }else{
                //Si no esta seleccionado -> vaciar el campo de otra molestia para evitar datos erroneos
                $molestiaotro = null;
            }

            $existeContrato = DB::select("SELECT * FROM contratos WHERE id ='$idContrato'");

            if($existeContrato != null){
                //Existe el contrato

                if($existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 7 || $existeContrato[0]->estatus_estadocontrato == 9 || $existeContrato[0]->estatus_estadocontrato == 10) {
                    //TERMINADO, APROBADO, EN PROCESO DE APROBACION O MANOFACTURA

                    $existeDiagnostico = DB::select("SELECT * FROM historialclinico hc WHERE hc.id_contrato = '$idContrato'");

                    if($existeDiagnostico != null){
                        //Si tiene diagnostico

                        try {

                            //Actualizar diagnosticos del contrato
                            DB::table("historialclinico")
                                ->where("id_contrato", "=", $idContrato)
                                ->update([
                                    'edad' => $edad,
                                    'diagnostico' => $diagnostico,
                                    'ocupacion' => $ocupacion,
                                    'diabetes' => $diabetes,
                                    'hipertension' => $hipertension,
                                    'dolor' => $dolor,
                                    'ardor' => $ardor,
                                    'golpeojos' => $golpeojos,
                                    'otroM' => $otroM,
                                    'molestiaotro' => $molestiaotro,
                                    'ultimoexamen' => $ultimoexamen,
                                    'embarazada' => $embarazada,
                                    'durmioseisochohoras' => $durmioseisochohoras,
                                    'actividaddia' => $actividaddia,
                                    'problemasojos' => $problemasojos,
                                    'updated_at' => Carbon::now()
                                ]);

                            //Registrar el movimiento al contrato
                            $globalesServicioWeb = new globalesServicioWeb;
                            $usuarioId = Auth::user()->id;

                            DB::table('historialcontrato')->insert([
                                'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' =>  Carbon::now(),
                                'cambios' => "Se actualizo diagnostico"
                            ]);

                            return back()->with("bien"," Diagnostico actualizado correctamente.");

                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e->getMessage());
                            return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
                        }

                    }
                    //No presenta ningun diagnostico el contrato
                    return back()->with("alerta"," Diagnostico no encontrado para el contrato.");
                }
                //Pertenece a otro estatus
                return back()->with("alerta"," No se puede actualizar el diagnostico debido al estatus del contrato.");
            }
            //No existe contrato
            return back()->with("alerta","No existe el contrato.");

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarformapagoconfirmaciones($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 15)) {
            $rules = [
                'formapago' => 'required|string',
            ];
            if (request('formapago') != 0 && request('formapago') != 1 && request('formapago') != 2 && request('formapago') != 4) {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago correcta']);
            }
            if (request('formapago') == 'nada') {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago']);
            }

            request()->validate($rules);

            $contrato = DB::select("SELECT c.estatus_estadocontrato, c.fechacobroini, c.fechacobrofin, c.pago, c.diapago, c.total,
                                            (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia
                                            FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

            if($contrato != null) {
                //Existe contrato

                if(($contrato[0]->estatus_estadocontrato == 1
                        || $contrato[0]->estatus_estadocontrato == 7
                        || $contrato[0]->estatus_estadocontrato == 9
                        || ($contrato[0]->fechacobroini == null && $contrato[0]->fechacobrofin == null))
                    && ($contrato[0]->estadogarantia == null || ($contrato[0]->estadogarantia != 0 && $contrato[0]->estadogarantia != 1 && $contrato[0]->estadogarantia != 2))) {
                    //El contrado es una venta nueva, en estatus TERMINADO, EN PROCESO DE APROBACION, APROBADOS, no tienen garantias asignadas

                    $formaPagoActualizar = request('formapago');

                    if($contrato[0]->pago != $formaPagoActualizar) {
                        //La forma de pago es diferente a la actual
                        if($formaPagoActualizar != 0){
                            //La forma de pago es diferente a de contado
                            if($contrato[0]->total != 0){
                                //Total es diferente de 0

                                $fechaCobroIniActualizar = null;
                                $fechaCobroFinActualizar = null;
                                $fechaDiaSeleccionadoActualizar = null;

                                //Actualizar forma de pago en contratos
                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'pago' => $formaPagoActualizar,
                                    'fechacobroini' => $fechaCobroIniActualizar,
                                    'fechacobrofin' => $fechaCobroFinActualizar,
                                    'diaseleccionado' => $fechaDiaSeleccionadoActualizar
                                ]);

                                //Guardar en tabla historialcontrato

                                $globalesServicioWeb = new globalesServicioWeb;
                                $usuarioId = Auth::user()->id;
                                $formaPagoTexto = null;

                                if ($formaPagoActualizar == 1) {
                                    $formaPagoTexto = 'Semanal';
                                } elseif ($formaPagoActualizar == 2) {
                                    $formaPagoTexto = 'Quincenal';
                                }elseif ($formaPagoActualizar == 4) {
                                    $formaPagoTexto = 'Mensual';
                                }

                                DB::table('historialcontrato')->insert([
                                    'id' => $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5'), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Se actualizo la forma de pago '$formaPagoTexto'"
                                ]);

                                return back()->with('bien', 'La forma de pago se actualizó correctamente.');
                            }
                            //El total del contrato es 0
                            return back()->with('alerta', 'No se puede cambiar la forma de pago al contrato.');

                        }
                        //Se intenta cambiar a forma de contado
                        return back()->with('alerta', 'No se puede cambiar de forma de pago de contado.');

                    }
                    //Forma de pago sigue siendo la misma
                    return back()->with('alerta', 'Se esta cambiando a la misma forma de pago.');

                }else
                    //No cumplio con las validaciones
                    return back()->with('alerta', 'No se puede cambiar la forma de pago al contrato.');

            }
            //No existe el contrato
            return back()->with('alerta', 'El contrato no existe.');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }
}
