<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Calculation\Database\DVar;

class vehiculos extends Controller {

    public function listavehiculos($idFranquicia){
        if (Auth::check() && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL

            return view('administracion.vehiculos.tablavehiculos', [
                'idFranquicia' => $idFranquicia
            ]);
        }else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public  function cargarlistavehiculos(Request $request){

        $idFranquicia = $request->input('idFranquicia');

        if((Auth::user()->rol_id) == 7) {
            //Director
            if($idFranquicia == '00000') {
                //Franquicia de prueba
                $listavehiculos = DB::select("SELECT v.indice, v.numserie, v.marca, v.modelo, v.id_franquicia,
                                            (SELECT s.ultimoservicio from servicio s WHERE v.numserie = s.id_moto ORDER BY s.created_at DESC LIMIT 1 ) AS ultimoservicio,
                                            (SELECT s.siguienteservicio from servicio s WHERE v.numserie = s.id_moto ORDER BY s.created_at DESC LIMIT 1 ) AS siguienteservicio,
                                            (SELECT f.ciudad FROM franquicias f WHERE f.id = v.id_franquicia) as ciudadfranquicia
                                            FROM vehiculos v
                                            ORDER BY v.indice DESC;");
            }else {
                //Otra franquicia diferente a la de prueba
                $listavehiculos = DB::select("SELECT v.indice, v.numserie, v.marca, v.modelo, v.id_franquicia,
                                            (SELECT s.ultimoservicio from servicio s WHERE v.numserie = s.id_moto ORDER BY s.created_at DESC LIMIT 1 ) AS ultimoservicio,
                                            (SELECT s.siguienteservicio from servicio s WHERE v.numserie = s.id_moto ORDER BY s.created_at DESC LIMIT 1 ) AS siguienteservicio,
                                            (SELECT f.ciudad FROM franquicias f WHERE f.id = v.id_franquicia) as ciudadfranquicia
                                            FROM vehiculos v
                                            WHERE v.id_franquicia != '00000'
                                            ORDER BY v.indice DESC;");
            }
        }else {
            //Administrador o principal
            $listavehiculos = DB::select("SELECT v.indice, v.numserie, v.marca, v.modelo, v.id_franquicia,
                                            (SELECT s.ultimoservicio from servicio s WHERE v.numserie = s.id_moto ORDER BY s.created_at DESC LIMIT 1 ) AS ultimoservicio,
                                            (SELECT s.siguienteservicio from servicio s WHERE v.numserie = s.id_moto ORDER BY s.created_at DESC LIMIT 1 ) AS siguienteservicio,
                                            (SELECT f.ciudad FROM franquicias f WHERE f.id = v.id_franquicia) as ciudadfranquicia
                                            FROM vehiculos v
                                            WHERE v.id_franquicia = '$idFranquicia'
                                            ORDER BY v.indice DESC;");
        }

        $i = count($listavehiculos) + 1;


        $view = view('administracion.vehiculos.listas.listavehiculosregistrados', [
            'listavehiculos' => $listavehiculos,
            'i' => $i
        ])->render();

        return \Response::json(array("valid"=>"true","view"=>$view));

    }

    public  function nuevovehiculo($id_franquicia, Request $request){
        if (Auth::check() && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)){
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL

            //Valores de formulario
            $numSerie = $request->input('numSerie');
            $kilometraje = $request->input('kilometraje');
            $sigKilometraje = $request->input('sigKilometraje');
            $ultimoServicio = $request->input('ultimoServicio');
            $sigServicio = $request->input('sigServicio');
            $marcaVehiculo = $request->input('marcaVehiculo');
            $numCilindros = $request->input('numCilindros');
            $lineaVehiculo = $request->input('lineaVehiculo');
            $modelo = $request->input('modeloVehiculo');
            $claseVehiculo = $request->input('claseVehiculo');
            $tipoVehiculo = $request->input('tipoVehiculo');
            $capacidad = $request->input('capacidad');
            $numMotor = $request->input('numMotor');
            $descripcion = $request->input('descripcion');


            //Validaciones de campos
            request()->validate([
                'numSerie' => 'required|string|min:17|max:17',
                'kilometraje' => 'required|numeric',
                'sigKilometraje' => 'required|numeric',
                'ultimoServicio' => 'required',
                'sigServicio' => 'required',
                'marcaVehiculo' => 'required|string|min:2|max:255',
                'numCilindros' => 'required|numeric',
                'lineaVehiculo' => 'required|string|min:1|max:255',
                'modeloVehiculo' => 'required|string|min:1|max:255',
                'claseVehiculo' => 'required|string|min:1|max:255',
                'tipoVehiculo' => 'required|string|min:1|max:255',
                'capacidad' => 'required|string|min:2|max:255',
                'numMotor' => 'required|string|min:11|max:17',
                'factura' => 'required|file|mimes:pdf',
                'descripcion' => 'required|string|min:1|max:250'
            ]);

            try {

                $vehiculoExistente = DB::select("SELECT * FROM vehiculos v WHERE v.numserie = '$numSerie'");

                if($vehiculoExistente == null ){
                    //No existe un vehiculo con ese nuemero de serie

                    //Velidar fecha
                    $ultimoServicio = Carbon::parse($ultimoServicio)->format('Y-m-d');
                    $sigServicio =  Carbon::parse($sigServicio)->format('Y-m-d');

                    if($sigServicio > $ultimoServicio){

                        $facturaServicioVehiculo = "";
                        if (request()->hasFile('factura')) {
                            $facturaServicioVehiculoBruta = 'factura-servicio-vehiculo-' . $numSerie . '-' . time() . '.' . request()->file('factura')->getClientOriginalExtension();
                            $facturaServicioVehiculo = request()->file('factura')->storeAs('uploads/imagenes/vehiculos/factura', $facturaServicioVehiculoBruta, 'disco');

                        }

                        //Insertar nuevo registro tabla vehiculos

                        DB::table('vehiculos')->insert([
                            'id_franquicia' => $id_franquicia, 'numserie' => $numSerie, 'marca' => $marcaVehiculo, 'cilindros' => $numCilindros,
                            'linea' => $lineaVehiculo, 'modelo' => $modelo, 'clase' => $claseVehiculo, 'tipo' => $tipoVehiculo,
                            'capacidad' => $capacidad, 'nummotor' => $numMotor, 'created_at' => Carbon::now()
                        ]);

                        //Insertar nuevo registro tabla servicio
                        DB::table('servicio')->insert([
                            'id_moto' => $numSerie, 'kilometraje' => $kilometraje, 'siguientekilometraje' => $sigKilometraje, 'ultimoservicio' => $ultimoServicio,
                            'siguienteservicio' => $sigServicio, 'descripcion' => $descripcion, 'factura' => $facturaServicioVehiculo, 'created_at' => Carbon::now()
                        ]);

                        return redirect()->route('listavehiculos',[$id_franquicia])->with('bien', 'El vehiculo se registro correctamente');

                    } else {
                        return back()->with('alerta', 'La fecha de ultimo servicio debe ser menor a siguiente servicio');
                    }

                } else {
                    //Ya existe numero de serie registrado
                    return back()->with('alerta', 'El vehiculo ya esta registrado');
                }

            } catch (\Exception $e){
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function vervehiculo($idFranquicia, $numSerie){
        if (Auth::check() && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)){


            try {
                $existeVehiculo = DB::select("SELECT * FROM vehiculos WHERE numserie = '$numSerie' AND id_franquicia = '$idFranquicia'");

                if ($existeVehiculo != null) {
                    //Existe vehiculo

                    $vehiculo = DB::select("SELECT * FROM vehiculos WHERE numserie = '$numSerie' AND id_franquicia = '$idFranquicia'");
                    $servicios = DB::select("SELECT s.id_moto, s.kilometraje, s.siguientekilometraje, s.ultimoservicio, s.siguienteservicio, s.factura, s.descripcion
                                                    FROM servicio s WHERE s.id_moto = '$numSerie'
                                                    ORDER BY s.created_at DESC");

                    $ultimoServicio = DB::select("SELECT s.ultimoservicio FROM servicio s WHERE s.id_moto = '$numSerie' ORDER BY s.ultimoservicio DESC LIMIT 1");

                    $i = count($servicios) + 1;
                    return view('administracion.vehiculos.vervehiculo', [
                        'vehiculo' => $vehiculo,
                        'servicios' => $servicios,
                        'idFranquicia'=>$idFranquicia,
                        'ultimoServicio' => $ultimoServicio,
                        'i' => $i
                    ]);

                }
                return back()->with('alerta', 'No se encontro el vehiculo');

            } catch (\Exception $e){
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public  function actualizarvehiculo($idFranquicia, $id_moto, Request $request){
        if (Auth::check() && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)){


            //Valores de formulario
            $numSerie = $request->input('numSerie');
            $marcaVehiculo = $request->input('marcaVehiculo');
            $numCilindros = $request->input('numCilindros');
            $lineaVehiculo = $request->input('lineaVehiculo');
            $modelo = $request->input('modeloVehiculo');
            $claseVehiculo = $request->input('claseVehiculo');
            $tipoVehiculo = $request->input('tipoVehiculo');
            $capacidad = $request->input('capacidad');
            $numMotor = $request->input('numMotor');

            //Validaciones de campos
            request()->validate([
                'numSerie' => 'required|string|min:17|max:17',
                'marcaVehiculo' => 'required|string|min:5|max:255',
                'numCilindros' => 'required|numeric',
                'lineaVehiculo' => 'required|string|min:1|max:255',
                'modeloVehiculo' => 'required|string|min:1|max:255',
                'claseVehiculo' => 'required|string|min:1|max:255',
                'tipoVehiculo' => 'required|string|min:5|max:255',
                'capacidad' => 'required|string|min:2|max:255',
                'numMotor' => 'required|string|min:11|max:17'
            ]);

            try {
                //Actualizamos el vehiculo

                DB::table('vehiculos')->where("numserie","=", $id_moto)->where("id_Franquicia","=",$idFranquicia)->update([
                    'numserie' => $numSerie, 'marca' => $marcaVehiculo, 'cilindros' => $numCilindros,
                    'linea' => $lineaVehiculo, 'modelo' => $modelo, 'clase' => $claseVehiculo, 'tipo' => $tipoVehiculo,
                    'capacidad' => $capacidad, 'nummotor' => $numMotor, 'updated_at' => Carbon::now()
                ]);

                if($id_moto != $numSerie){
                    //Si se actualiza el numero de serie del vehiculo - Actualizarlo en tabla servicio

                    DB::table('servicio')->where('id_moto', $id_moto)->update([
                        'id_moto' => $numSerie, 'updated_at' => Carbon::now()
                    ]);
                }

                return redirect()->route('vervehiculo', ['idFranquicia' => $idFranquicia, 'idMoto' => $numSerie])->with('bien', "El vehiculo se actualizó correctamente");

            } catch (\Exception $e){
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function registrarnuevoservicio($idFranquicia, $id_moto, Request $request){
        if (Auth::check() && (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)){


            //Valores de formulario
            $kilometraje = $request->input('kilometraje');
            $sigKilometraje = $request->input('sigKilometraje');
            $ultimoServicio = $request->input('ultimoServicio');
            $sigServicio = $request->input('sigServicio');
            $descripcion = $request->input('descripcion');


            //Validaciones de campos
            request()->validate([
                'kilometraje' => 'required|numeric',
                'sigKilometraje' => 'required|numeric',
                'ultimoServicio' => 'required',
                'sigServicio' => 'required',
                'factura' => 'required|file|mimes:pdf',
                'descripcion' => 'required|string|min:1|max:250'
            ]);

            try {

                $vehiculoExistente = DB::select("SELECT * FROM vehiculos v WHERE v.numserie = '$id_moto' AND id_franquicia = '$idFranquicia'");

                if($vehiculoExistente != null ){
                    //Existe un vehiculo con ese nuemero de serie

                    //Velidar fecha
                    $ultimoServicio = Carbon::parse($ultimoServicio)->format('Y-m-d');
                    $sigServicio =  Carbon::parse($sigServicio)->format('Y-m-d');

                    if($sigServicio > $ultimoServicio){

                        $facturaServicioVehiculo = "";
                        if (request()->hasFile('factura')) {
                            $facturaServicioVehiculoBruta = 'factura-servicio-vehiculo-' . $id_moto . '-' . time() . '.' . request()->file('factura')->getClientOriginalExtension();
                            $facturaServicioVehiculo = request()->file('factura')->storeAs('uploads/imagenes/vehiculos/factura', $facturaServicioVehiculoBruta, 'disco');

                        }

                        //Insertar nuevo registro tabla servicio
                        DB::table('servicio')->insert([
                            'id_moto' => $id_moto, 'kilometraje' => $kilometraje, 'siguientekilometraje' => $sigKilometraje, 'ultimoservicio' => $ultimoServicio,
                            'siguienteservicio' => $sigServicio, 'descripcion' => $descripcion, 'factura' => $facturaServicioVehiculo, 'created_at' => Carbon::now()
                        ]);

                        return redirect()->route('vervehiculo', ['idFranquicia' => $idFranquicia, 'idMoto' => $id_moto])->with('bien', 'El servicio se registro correctamente');

                    } else {
                        return back()->with('alerta', 'La fecha de ultimo servicio debe ser menor a siguiente servicio');
                    }

                } else {
                    //No existe numero de serie registrado
                    return back()->with('alerta', 'Vehiculo no registrado');
                }

            } catch (\Exception $e){
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function descargarfacturaservicio($idMoto)
    {
        if ((Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8)) //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL
        {
            $existeVehiculo = DB::select("SELECT factura FROM servicio WHERE id_Moto = '$idMoto'");
            if ($existeVehiculo != null) { //Existe el vehiculo?
                //Si existe el vehiculo
                $archivo = $existeVehiculo[0]->factura;
                return Storage::disk('disco')->download($archivo);
            } else {
                //No existe el vehiculo
                return back()->with('alerta', 'No se encontro el vehiculo.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

}
