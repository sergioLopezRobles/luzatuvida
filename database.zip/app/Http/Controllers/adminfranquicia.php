<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Image;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use File;


class adminfranquicia extends Controller
{
    public function listas($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {

            $productosSucursal = DB::select("SELECT p.id, p.estado, p.nombre, tipoproducto.tipo, p.foto, p.piezas, p.color, p.precio,p.id_tipoproducto, p.activo, p.preciop
                FROM producto as p
                INNER JOIN tipoproducto
                ON tipoproducto.id = p.id_tipoproducto
                WHERE p.id_tipoproducto != 1
                AND p.id_franquicia = '$idFranquicia'
                order by p.created_at desc
                ");

            $productosGeneral=DB::table('producto as p')
                ->select('p.id','p.estado','p.nombre','tipoproducto.tipo','p.foto','p.piezas', 'p.color', 'p.precio','p.id_tipoproducto','p.activo','p.preciop')
                ->join('tipoproducto', 'tipoproducto.id', '=', 'p.id_tipoproducto')
                ->whereRaw("p.id_tipoproducto = '1'")
                ->orderBy('p.created_at', 'DESC')
                ->paginate(15);

            $tratamientos = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $promociones = DB::select("SELECT * FROM promocion WHERE id_franquicia = '$idFranquicia'");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            $mensajes = DB::select("SELECT * FROM mensajes WHERE id_franquicia = '$idFranquicia'");

            return view('administracion.franquicia.administracion.listas',['productosGeneral' => $productosGeneral, 'productosSucursal' => $productosSucursal, 'franquiciaAdmin' => $franquiciaAdmin,'idFranquicia' => $idFranquicia,'tratamientos'=>$tratamientos,'paquetes'=>$paquetes,'promociones'=>$promociones,'mensajes'=> $mensajes]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function filtrarproducto($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $filtro = request('filtro');
            $productos=DB::table('producto as p')
            ->select('p.id','p.estado','p.nombre','tipoproducto.tipo','p.foto','p.piezas', 'p.color', 'p.precio','p.id_tipoproducto','p.activo','p.preciop')
            ->join('tipoproducto', 'tipoproducto.id', '=', 'p.id_tipoproducto')
            ->whereRaw("p.id_franquicia = '$idFranquicia'")
            ->whereRaw("(p.estado LIKE '%$filtro%'
             OR p.nombre LIKE '%$filtro%' OR tipoproducto.tipo LIKE '%$filtro%' OR p.piezas LIKE '$filtro' OR p.color LIKE '%$filtro%' OR p.preciop LIKE '%$filtro%')")
            ->orderBy('p.created_at', 'DESC')
            ->paginate(20);
            $tratamientos = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $promociones = DB::select("SELECT * FROM promocion WHERE id_franquicia = '$idFranquicia'");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            $mensajes = DB::select("SELECT * FROM mensajes WHERE id_franquicia = '$idFranquicia'");


            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.listas',['productos' => $productos, 'franquiciaAdmin' => $franquiciaAdmin,'idFranquicia' => $idFranquicia,'tratamientos'=>$tratamientos,'paquetes'=>$paquetes,'promociones'=>$promociones,'mensajes'=> $mensajes]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    private  function getProductosId() {
        $unico = "";
        $esUnico = false;
        while(!$esUnico){
            $temporalId = $this->generadorRandom();
            $existente = DB::select("select id from producto where id = '$temporalId'");
            if (sizeof ($existente) == 0){
                $unico = $temporalId;
                $esUnico = true;
            }
        }
           return $unico;
    }

    private function generadorRandom($length = 5){
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    public function productonuevo($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            $tipoproducto  = DB::select("SELECT * FROM tipoproducto");
            return view('administracion.franquicia.administracion.nuevoproducto',['franquiciaAdmin' => $franquiciaAdmin,'idFranquicia' => $idFranquicia, 'tipoproducto' => $tipoproducto]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function productocrear($idFranquicia, Request $request){

        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))

        {
            if(request('tipoproducto')== 1){
               $validacion = Validator::make($request->all(),[
                    'producto'=>'required|string|max:255',
                    'piezas'=>'required|integer',
                    'foto'=> 'nullable|image|mimes:jpg',
                    'color'=> 'required|string|max:255'

               ]);

               if($validacion->fails()){
                   return back()->withErrors($validacion);
               }
               $precio = null;
               $in = null;
               $fi = null;
               $preciop = null;
            }  else {

                $validacion = Validator::make($request->all(),[
                    'producto'=>'required|string|max:255',
                    'piezas'=>'required|integer',
                    'foto'=> 'nullable|image|mimes:jpg',
                    'color'=> 'required|string|max:255',
                    'precio'=>'required|integer'

               ]);
               if($validacion->fails()){
                   return back()->withErrors($validacion);
               }
               $precio = request('precio');
               $in = request('iniciop');
               $fi = request('finp');
               $preciop = request('preciop');
            }

            if(request('finp') != null || request('iniciop') != null || request('preciop') != null || request('activo') != null  ) {
                $validacion = Validator::make($request->all(),[
                    'iniciop'=>'required|date',
                    'finp'=>'required|date',
                    'preciop'=>'required|integer'

               ]);
               if($validacion->fails()){
                   return back()->withErrors([
                       'iniciop'=> "Campos requeridos",
                       'finp'=> "Campos requeridos",
                       'preciop'=> "Campos requeridos"
                   ]);
               }

               $fecha1 = Carbon::parse(request('iniciop'));
               $fecha2 = Carbon::parse(request('finp'));

               if($fecha1->gt($fecha2)){
                  return back()->withErrors([
                 'iniciop'=> "No puede ser mayor a la fecha final",
                 'finp'=> "No puede ser menor a la fecha inicial",

                  ])->withInput($request->all());
                }
             }

             if(request('preciop') > request('precio')){
                return back()->withErrors([
               'preciop'=> "No puede ser mayor el precio de la promoción que el principal",

                ])->withInput($request->all());
              }
            try{
                $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                $randomId = $this->getProductosId();

                $estado = 0;
                if(!is_null(request('estado'))){
                    if(request('estado') == 1){
                        $estado = 1;
                    }else{
                        $estado = 0;
                    }
                }

                $activo = 0;
                if(!is_null(request('activo'))){
                    if(request('activo') == 1){
                        $activo = 1;
                    }else{
                        $activo = 0;
                    }
                }

                $productos = DB::select("SHOW TABLE STATUS LIKE 'producto'");
                $siguienteId = $productos[0]->Auto_increment;

                $foto="";
                if(request()->hasFile('foto')){
                    $fotoBruta='Foto-Producto-'.$siguienteId.'-'.time(). '.' . request()->file('foto')->getClientOriginalExtension();
                    $foto=request()->file('foto')->storeAs('uploads/imagenes/productos/fotos', $fotoBruta,'disco');
                    $alto = Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->height();
                    $ancho = Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->width();
                    if($alto > $ancho){
                        $imagenfoto=Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->resize(600,800);
                    }else{
                        $imagenfoto=Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->resize(800,600);
                    }
                    $imagenfoto->save();
                }

                DB::table('producto')->insert([
                    'id'=> $randomId, 'id_franquicia' => $idFranquicia,'nombre' => request('producto'),'id_tipoproducto' => request('tipoproducto'),'piezas' => request('piezas'),'precio'=> $precio,'foto'=>$foto,
                    'color'=>request('color'),'estado' => $estado,'created_at' => Carbon::now(), 'iniciop' => $in,'finp' => $fi, 'preciop' => $preciop,
                    'activo' => $activo
                ]);
                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','El producto se creo correctamente.');

            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function productoactualizar($idFranquicia,$idProducto){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $producto = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id = '$idProducto'");
            $tipoproducto  = DB::select("SELECT * FROM tipoproducto");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.actualizarproducto',['idFranquicia' => $idFranquicia,'producto'=>$producto,'franquiciaAdmin'=>$franquiciaAdmin, 'tipoproducto' => $tipoproducto]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function productoeditar($idFranquicia,$idProducto, Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            if(request('tipoproducto')== 1){
                $validacion = Validator::make($request->all(),[
                     'nombre'=>'required|string|max:255',
                     'piezas'=>'required|integer',
                     'foto'=> 'nullable|image|mimes:jpg',
                     'color'=> 'required|string|max:255'
                ]);

                if($validacion->fails()){
                    return back()->withErrors($validacion);
                }
                $precio = null;
                $in = null;
                $fi = null;
                $preciop = null;

             }  else {
                 $validacion = Validator::make($request->all(),[
                     'nombre'=>'required|string|max:255',
                     'piezas'=>'required|integer',
                     'foto'=> 'nullable|image|mimes:jpg',
                     'color'=> 'required|string|max:255',
                     'precio'=>'required|integer'

                ]);
                if($validacion->fails()){
                    return back()->withErrors($validacion);
                }
                $precio = request('precio');
                $in = request('iniciop');
                $fi = request('finp');
                $preciop = request('preciop');
             }
            if(request('finp') != null || request('iniciop') != null || request('preciop') != null || request('activo') != null   ) {
                 $validacion = Validator::make($request->all(),[
                     'iniciop'=>'required|date',
                     'finp'=>'required|date',
                     'preciop'=>'required|integer'

                ]);
                if($validacion->fails()){
                    return back()->withErrors([
                        'iniciop'=> "Campos requeridos",
                        'finp'=> "Campos requeridos",
                        'preciop'=> "Campos requeridos"
                    ])->withInput($request->all());
                }

                $fecha1 = Carbon::parse(request('iniciop'));
                $fecha2 = Carbon::parse(request('finp'));
                if($fecha1->gt($fecha2)){
                   return back()->withErrors([
                    'iniciop'=> "No puede ser mayor a la fecha final"
                   ])->withInput($request->all());
                 }
              }

              if(request('preciop') > request('precio')){
                 return back()->withErrors([
                    'preciop'=> "El precio no puede ser mayor al precio normal del producto."
                 ])->withInput($request->all());
               }
            try{

                $estado = 0;
                if(!is_null(request('estado'))){
                    if(strlen(request('estado')) == 0){
                        $estado = 0;
                    }else{
                        $estado = 1;
                    }
                }
                $activo = 0;
                if(!is_null(request('activo'))){
                    if(strlen(request('activo')) == 0){
                        $activo = 0;
                    }else{
                        $activo = 1;
                    }
                }

                $producto = DB::select("SELECT * FROM producto WHERE id = '$idProducto' AND id_franquicia = '$idFranquicia'");
                $foto="";
                $fotoBool = false;
                if(strlen($producto[0]->foto) > 0){
                    if(request()->hasFile('foto')){
                        Storage::disk('disco')->delete($producto[0]->foto);
                        $fotoBruta='Foto-Producto-'.$producto[0]->id.'-'.time(). '.' . request()->file('foto')->getClientOriginalExtension();
                        $foto=request()->file('foto')->storeAs('uploads/imagenes/productos/fotos', $fotoBruta,'disco');

                    }else{
                        $foto = $producto[0]->foto;
                    }
                }else{
                    if(request()->hasFile('foto')){
                        $fotoBruta='Foto-Producto-'.$producto[0]->id.'-'.time(). '.' . request()->file('foto')->getClientOriginalExtension();
                        $foto=request()->file('foto')->storeAs('uploads/imagenes/productos/fotos', $fotoBruta,'disco');
                        $alto = Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->height();
                        $ancho = Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->width();
                        if($alto > $ancho){
                            $imagenfoto=Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->resize(600,800);
                        }else{
                            $imagenfoto=Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/productos/fotos/'.$fotoBruta)->resize(800,600);
                        }
                    $imagenfoto->save();
                    }else{
                        $foto = null;
                    }
                }
                $forzado = 0;
                DB::table('producto')->where([['id','=',$idProducto],['id_franquicia','=',$idFranquicia]])->update([
                    'nombre'=>request('nombre'), 'id_tipoproducto'=>request('tipoproducto'),'piezas'=>request('piezas'),'precio'=>$precio,
                    'color'=>request('color'),'estado' => $estado,'foto' => $foto,  'iniciop' => $in,'finp' => $fi, 'preciop' => $preciop,
                    'activo' => $activo,'forzado' => $forzado
                ]);
                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','El producto se actualizo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }


    public function productodesactivarpromo($idFranquicia,$idProducto){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $activo = 0;
            $forzado = 1;
            DB::table('producto')->where('id','=',$idProducto)->update([
                'activo'=>$activo,'forzado' => $forzado
            ]);
            return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','La promocion del producto se desactivo correctamente.');
          }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function tratamientonuevo($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.nuevotratamiento',['franquiciaAdmin' => $franquiciaAdmin,'idFranquicia' => $idFranquicia]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function  tratamientocrear($idFranquicia,Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $rules = [
                'tratamiento'=>'required|string|max:255',
                'precio'=>'required|integer'
            ];
            if (request('precio') < 0){
                return back()->withErrors(['precio' => 'El precio no puede ser menor a 0'])->withInput($request->all());
            }
            request()->validate($rules);
            try{
                DB::table('tratamientos')->insert([
                    'id_franquicia' => $idFranquicia,'nombre' => request('tratamiento'),'precio'=> request('precio'),'created_at' => Carbon::now()
                ]);

                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','El tratamiento se creo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function tratamientoactualizar($idFranquicia,$idTratamiento){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {

            $tratamiento = DB::select("SELECT * FROM tratamientos WHERE id = '$idTratamiento' AND id_franquicia = '$idFranquicia'");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.actualizartratamiento',['idFranquicia' => $idFranquicia,'tratamiento'=>$tratamiento,'franquiciaAdmin' => $franquiciaAdmin]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function tratamientoeditar($idFranquicia,$idTratamiento,Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $rules =  [
                'tratamiento'=>'required|string|max:255',
                'precio'=>'required|integer'
            ];
            if (request('precio') < 0){
                return back()->withErrors(['precio' => 'El precio no puede ser menor a 0'])->withInput($request->all());
            }
            try{
                DB::table('tratamientos')->where([['id','=',$idTratamiento],['id_franquicia','=',$idFranquicia]])->update([
                    'precio'=>request('precio'),
                ]);
                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','El tratamiento se actualizo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function paquetenuevo($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.nuevopaquete',['franquiciaAdmin' => $franquiciaAdmin,'idFranquicia' => $idFranquicia]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function  paquetecrear($idFranquicia,Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
                $rules = [
                'paquete'=>'required|string|max:255',
                'precio'=>'required|integer'
            ];
            if (request('precio') < 0){
                return back()->withErrors(['precio' => 'El precio no puede ser menor a 0'])->withInput($request->all());
            }
            request()->validate($rules);
            try{
                DB::table('paquetes')->insert([
                    'id_franquicia' => $idFranquicia,'nombre' => request('paquete'),'precio'=> request('precio'),'created_at' => Carbon::now()
                ]);

                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','el paquete se creo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function paqueteactualizar($idFranquicia,$idPaquete){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {

            $paquete = DB::select("SELECT * FROM paquetes WHERE id = '$idPaquete' AND id_franquicia = '$idFranquicia'");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.franquicia.administracion.actualizarpaquete',['idFranquicia' => $idFranquicia,'paquete'=>$paquete,'franquiciaAdmin' => $franquiciaAdmin]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function paqueteeditar($idFranquicia,$idPaquete,Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $rules = [
                'paquete'=>'required|string|max:255',
                'precio'=>'required|integer'
            ];
            if (request('precio') < 0){
                return back()->withErrors(['precio' => 'El precio no puede ser menor a 0'])->withInput($request->all());
            }

            try{
                DB::table('paquetes')->where([['id','=',$idPaquete],['id_franquicia','=',$idFranquicia]])->update([
                    'nombre'=>request('paquete'),'precio'=>request('precio'),'updated_at' => Carbon::now()
                ]);
                return redirect()->route('listasfranquicia',$idFranquicia)->with('bien','El paquete se actualizo correctamente.');
            }catch(\Exception $e){
                \Log::info("Error: ".$e->getMessage());
                return back()->with('error','Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function mensajeNuevo($idFranquicia){
        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {

            return view('administracion.franquicia.administracion.mensajes.nuevo',["idFranquicia"=>$idFranquicia]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function crearmensaje($idFranquicia, Request $request){

        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            $rules = [
                'descripcion'=>'required|string',
                'numero'=>'required|integer'
            ];
            request()->validate($rules);
            $fecha = null;
            if(strlen($request->fecha) > 0){
                try{ $fecha =   Carbon::parse($request->fecha);}catch(\Exception $e){ return back()->with("alerta","Ingresa una fecha correcta.")->withInput($request->all());}
            }
            DB::table("mensajes")->insert([
                "id_franquicia" => $idFranquicia,
                "descripcion" => $request->descripcion,
                "fechalimite" =>$fecha,
                "intentos" => $request->numero,
                "created_at" => Carbon::now()
            ]);

            return redirect()->route('listasfranquicia',$idFranquicia)->with("bien","El mensaje fue creado correctamente.");

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }
    public function eliminarmensaje($idFranquicia,$idMensaje){

        if(Auth::check() && ((Auth::user()->rol_id) == 6 || ((Auth::user()->rol_id) == 7)  || ((Auth::user()->rol_id) == 8)))
        {
            try{
                DB::delete("DELETE FROM mensajes WHERE id = '$idMensaje'");
            }catch(\Exception $e){
                \Log::info("Error:".$e);
            }
            return redirect()->route('listasfranquicia',$idFranquicia)->with("bien","El mensaje se elimino correctamente.");

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

}









