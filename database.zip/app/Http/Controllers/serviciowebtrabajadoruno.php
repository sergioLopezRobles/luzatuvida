<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Clases\globalesServicioWeb;

class serviciowebtrabajadoruno extends Controller
{
    public function iniciarsesion()
    {

        //\Log::info("iniciarsesion");

        $correo = strtoupper(request("correo"));
        $contrasena = request("contrasena");
        $dispositivo = request("dispositivo");
        $idunico = request("idunico");
        $version = request("version");
        $modelo = request("modelo");
        $versiongradle = request("versiongradle");
        $lenguajetelefono = request("lenguajetelefono");

        try {

            $validarAplicacion = DB::select("SELECT id FROM dispositivos WHERE id = '$dispositivo' AND estatus = 1");

            $datos = [];
            if ($validarAplicacion != null) {//Existe aplicacion?
                //Aplicacion existe

                $usuario = DB::select("SELECT u.id, u.rol_id, u.name, u.email, u.password, u.id_zona, u.logueado FROM users u WHERE UPPER(u.email) = '$correo'");
                if ($usuario != null) { //Usuario exite?
                    //Usuario existe

                    $id_usuario = $usuario[0]->id;
                    $usuariofranquicia = DB::select("SELECT (SELECT f.ciudad FROM franquicias f WHERE f.id = uf.id_franquicia) as sucursal, (SELECT f.telefonoatencionclientes FROM franquicias f WHERE f.id = uf.id_franquicia) as telefonoatencionclientessucursal FROM usuariosfranquicia uf WHERE uf.id_usuario = '$id_usuario'");

                    if ($usuariofranquicia != null) {
                        //Usuario franquicia existe

                        if ($usuario[0]->rol_id == 12 || $usuario[0]->rol_id == 13 || $usuario[0]->rol_id == 4) {
                            //Usuario admitido

                            if ($usuario[0]->logueado == 1) {
                                //Usuario logueado en la pagina
                                $datos[0]["codigo"] = "LOLATV8";
                                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";
                            } else {

                                if (Hash::check($contrasena, $usuario[0]->password)) { //Validacion credenciales
                                    //Credenciales correctas

                                    $fechaActual = Carbon::now();
                                    $dispositivoActivo = DB::select("SELECT estatus FROM dispositivosusuarios WHERE identificadorunico = '$idunico' AND id_usuario = '$id_usuario'");

                                    if ($dispositivoActivo != null) { //Existe el dispositivo?
                                        //Existe dispositivo

                                        if ($dispositivoActivo[0]->estatus == 1) {
                                            //Dispositivo activado

                                            $token = Str::random(60); //Token
                                            DB::delete("DELETE FROM tokenlolatv where usuario_id =" . $usuario[0]->id);
                                            DB::table("tokenlolatv")->insert(["token" => $token, "usuario_id" => $usuario[0]->id]);
                                            $datos[0]["codigo"] = "LOLATV3";
                                            $datos[0]["id"] = $id_usuario;
                                            $datos[0]["usuario"] = $usuario[0]->name;
                                            $datos[0]["correo"] = $usuario[0]->email;
                                            $datos[0]["rol"] = $usuario[0]->rol_id;
                                            $datos[0]["fechaactual"] = Carbon::parse($fechaActual)->format('Y-m-d');
                                            $datos[0]["id_zona"] = $usuario[0]->id_zona;
                                            $datos[0]["token"] = $token;
                                            $datos[0]["sucursal"] = $usuariofranquicia[0]->sucursal;
                                            $datos[0]["telefonoatencionclientessucursal"] = $usuariofranquicia[0]->telefonoatencionclientessucursal;
                                            DB::table("users")->where("id", "=", $usuario[0]->id)->update([
                                                "logueado" => 2
                                            ]);
                                            //\Log::info("{'datos': '" . base64_encode(json_encode($datos)) . "'}");
                                            return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                                        }

                                        //Dispositivo activado
                                        $datos[0]["codigo"] = "LOLATV2";
                                        return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                                    }

                                    //No existe dispositivo
                                    DB::table("dispositivosusuarios")->insert([
                                        "id_usuario" => $usuario[0]->id,
                                        "versionandroid" => $version,
                                        "modelo" => $modelo,
                                        "identificadorunico" => $idunico,
                                        "versiongradle" => $versiongradle,
                                        "lenguajetelefono" => $lenguajetelefono,
                                        "created_at" => $fechaActual]);
                                    $datos[0]["codigo"] = "LOLATV2";
                                    return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";;

                                }

                                //Credenciales incorrectas
                                $datos[0]["codigo"] = "LOLATV1";
                                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                            }

                        }

                        //Usuario no admitido
                        $datos[0]["codigo"] = "LOLATV10";
                        return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                    }

                    //Usuario franquicia no existe
                    $datos[0]["codigo"] = "LOLATV11";
                    return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                }

                //Usuario no existe
                $datos[0]["codigo"] = "LOLATV1";
                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

            } else {

                //Aplicacion no existe
                $appactual = DB::select("SELECT apk FROM dispositivos WHERE estatus = '1'");
                $datos[0]["codigo"] = "LOLATV4";
                $datos[0]["appactual"] = asset($appactual[0]->apk);
                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

            }

        }catch(\Exception $e){
            \Log::info("Error: serviciowebtrabajadoruno: (iniciarsesion) - correo: " . $correo . "\n" . $e);
        }

    }

    public function sincronizarcero()
    { //Esta funcion se mandara a llamar cuando se tiene el token y cuando se hacen cambios constantes en las tablas

        //\Log::info("Sincronizar0");

        $globalesServicioWeb = new globalesServicioWeb;

        $fechaActual = Carbon::now();

        $token = request("token");
        $dispositivo = request("dispositivo");
        $idunico = request("idunico");
        $version = request("version");
        $modelo = request("modelo");

        $validarToken = DB::select("SELECT * FROM tokenlolatv WHERE token = '$token'"); //Validamos si el token es valido

        $tokenValido = false;
        $id_usuario = "";
        if ($validarToken != null) {
            $tokenValido = true;
            $id_usuario = $validarToken[0]->usuario_id;
        }

        try {

            $validarAplicacion = DB::select("SELECT id FROM dispositivos WHERE id = '$dispositivo' AND estatus = 1");
            $dispositivoActivo = DB::select("SELECT estatus FROM dispositivosusuarios WHERE identificadorunico = '$idunico' AND id_usuario = '$id_usuario'");

            if ($validarAplicacion != null) { //Existe aplicacion?
                //Aplicacion existe

                if ($dispositivoActivo != null) { //Existe el dispositivo usuario?
                    //Existe dispositivo usuario

                    if ($dispositivoActivo[0]->estatus == 1) {
                        //Dispositivo activado

                        if ($tokenValido) {
                            //Token valido
                            $jsonDatos = request("datos");
                            $usuario = DB::select("SELECT uf.id_franquicia, u.id FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE u.id = '" . $validarToken[0]->usuario_id . "'");
                            $respuesta = $globalesServicioWeb::insertarOModificarRegistrosTablas($jsonDatos, $usuario[0]->id_franquicia, $usuario[0]->id); //Mandamos el jsonDatos y obtenemos el id de la franquicia del usuario logueado
                            return $respuesta;
                        }

                        //Token no valido
                        $datos[0]["codigo"] = "LOLATV7";
                        return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                    }

                    //No esta activado
                    $datos[0]["codigo"] = "LOLATV2";
                    return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                }

                //No existe dispositivo usuario
                $datos[0]["codigo"] = "LOLATV7";
                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

            } else {
                //Aplicacion no existe

                if ($dispositivoActivo != null) { //Existe el dispositivo usuario?
                    //Existe el dispositivo usuario

                    if ($dispositivoActivo[0]->estatus == 1) { //Activado

                        if ($tokenValido) {
                            //Token es valido
                            $jsonDatos = request("datos");

                            $usuario = DB::select("SELECT uf.id_franquicia, u.id FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE u.id = '" . $validarToken[0]->usuario_id . "'");
                            $globalesServicioWeb::insertarOModificarRegistrosTablas($jsonDatos, $usuario[0]->id_franquicia, $usuario[0]->id); //Mandamos el jsonDatos y obtenemos el id de la franquicia del usuario logueado
                            $datos[0]["codigo"] = "LOLATV6";
                            return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";
                        }

                        //Token no es valido
                        $datos[0]["codigo"] = "LOLATV7";
                        return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";
                    }

                    //No esta activado
                    $datos[0]["codigo"] = "LOLATV2";
                    return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

                }

                //No existe el dispositivo usuario
                $datos[0]["codigo"] = "LOLATV7";
                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

            }

        }catch(\Exception $e){
            \Log::info("Error: serviciowebtrabajadoruno: (sincronizarcero) - id_usuario: " . $id_usuario . "\n" . $e);
        }

    }

    public function sincronizaruno()
    { //Esta funcion se mandara a llamar cuando se tiene el token y ademas la version de aplicacion que tiene el usuario ya noes valido.

        $globalesServicioWeb = new globalesServicioWeb;

        $token = request("token");
        $correo = request("correo");
        $contrasena = request("contrasena");
        $jsonDatos = request("datos");

        $validarToken = DB::select("SELECT * FROM tokenlolatv WHERE token = '$token'"); //Validamos si el token es valido
        $tokenValido = false;
        if ($validarToken != null) {
            $tokenValido = true;
        }

        if ($tokenValido) {
            $usuario = DB::select("SELECT u.id, u.password, uf.id_franquicia FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE u.email = '$correo'");
            if ($usuario != null) {
                if (Hash::check($contrasena, $usuario[0]->password)) {
                    if ($validarToken[0]->usuario_id == $usuario[0]->id) { // Validamos que el token corresponda al mismo usuario

                        $respuesta = $globalesServicioWeb::insertarOModificarRegistrosTablas($jsonDatos, $usuario[0]->id_franquicia); //Mandamos el jsonDatos y obtenemos el id de la franquicia del usuario logueado
                        return $respuesta;

                    }
                }
            }

        }

    }

    public function sincronizardos()
    { //Funcion para mandar la informacion desde la pagina web hacia la aplicacion movil.
        //\Log::info("Sincronizar2");

        $token = request("token");
        $tokenValido = DB::select("SELECT usuario_id FROM tokenlolatv WHERE token = '$token'");
        if ($tokenValido != null) {// Existe el token
            //El token es valido
            //\Log::info("ENTRO");

            try {

                $usuario = DB::select("SELECT uf.id_franquicia, u.name, u.rol_id, u.id_zona, u.id FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.id = '" . $tokenValido[0]->usuario_id . "'");
                $idFranquicia = $usuario[0]->id_franquicia; //Obtenemos el id de la franquicia del usuario logueado

                $globalesServicioWeb = new globalesServicioWeb;

                $mensajes = null;
                $contratos = null;
                $historialesClinicos = null;
                $abonos = array();
                $productosDeContrato = null;
                $promocionContrato = array();
                $productos = null;
                $usuarios = null;
                $zonas = null;
                $promociones = null;
                $paquetes = null;
                $tratamientos = null;
                $numContratosVacios = null;
                $contratosnuevos = null;
                $garantias = null;
                $ruta = null;
                $totalcontratosconabonos = null;
                $jsonabonosgeneral = null;
                $contratosliosfugas = null;
                $historialessinconversion = null;
                $ventas = array();
                $configuracionmovil = array();

                $now = Carbon::now();
                $nowParse = Carbon::parse($now)->format('Y-m-d');
                if ($usuario[0]->rol_id == 12 || $usuario[0]->rol_id == 13) {
                    //Si es un optometrista o un asistente

                    $numContratosVacios = DB::select("SELECT COUNT(id) as totalids
                        FROM contratos WHERE id_franquicia = '$idFranquicia' AND id_usuariocreacion = '" . $tokenValido[0]->usuario_id . "' AND datos = '0'");

                    $numContratosACrear = 20 - $numContratosVacios[0]->totalids;
                    if ($numContratosACrear > 0) {
                        //Se necesita crear mas contratos perzonalizados

                        $anoActual = Carbon::now()->format('y'); //Obtener los ultimos 2 digitos del año 21, 22, 23, 24, etc

                        //Obtener indice de la franquicia
                        $franquicia = DB::select("SELECT indice FROM franquicias WHERE id = '$idFranquicia'");
                        $identificadorFranquicia = "";
                        if ($franquicia != null) {
                            //Existe franquicia
                            $identificadorFranquicia = $globalesServicioWeb::obtenerIdentificadorFranquicia($franquicia[0]->indice);
                        }
                        $identificadorFranquicia = $anoActual . $identificadorFranquicia; //Seria el identificadorFranquicia completo = 22001, 22002, 22003, etc

                        //Obtener el ultimo id generado en la tabla de contrato
                        $contratoSelect = DB::select("SELECT id FROM contratos WHERE id_franquicia = '$idFranquicia' AND id LIKE '%$identificadorFranquicia%' ORDER BY id DESC LIMIT 1");
                        if ($contratoSelect != null) {
                            //Existe registro (Significa que ya hay contratos personalizados creados)
                            $idContrato = substr($contratoSelect[0]->id, -5);
                            $ultimoIdContratoPerzonalizado = $idContrato;
                        }else {
                            //Sera el primer contrato perzonalizado a crear de la sucursal
                            $ultimoIdContratoPerzonalizado = 0;
                        }

                        //Recorrido de contratos a crear
                        for ($i = 0; $i < $numContratosACrear; $i++) {
                            $arrayRespuesta = $globalesServicioWeb::generarIdContratoPersonalizado($identificadorFranquicia, $ultimoIdContratoPerzonalizado);
                            DB::table("contratos")->insert(["id" => $arrayRespuesta[0], "id_franquicia" => $idFranquicia, "id_usuariocreacion" => $tokenValido[0]->usuario_id,
                                "nombre_usuariocreacion" => $usuario[0]->name, "poliza" => null]);
                            $ultimoIdContratoPerzonalizado = $arrayRespuesta[1] + 1;
                        }

                    }

                    $mensajes = DB::select("SELECT IFNULL(id, '') as id, IFNULL(descripcion, '') as descripcion, IFNULL(fechalimite, '') as fechalimite, IFNULL(intentos, '') as intentos FROM mensajes WHERE id_franquicia = '$idFranquicia'");

                    $contratosnuevos = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(datos, '') as datos,
                            IFNULL(id_usuariocreacion, '') as id_usuariocreacion,
                            IFNULL(nombre_usuariocreacion, '') as nombre_usuariocreacion,
                            IFNULL(id_zona, '') as id_zona,
                            IFNULL(estatus, '') as estatus, IFNULL(nombre, '') as nombre,
                            IFNULL(calle, '') as calle,
                            IFNULL(numero, '') as numero,
                            IFNULL(depto, '') as depto,
                            IFNULL(alladode, '') as alladode,
                            IFNULL(frentea, '') as frentea,
                            IFNULL(entrecalles, '') as entrecalles,
                            IFNULL(colonia, '') as colonia,
                            IFNULL(localidad, '') as localidad,
                            IFNULL(telefono, '') as telefono,
                            IFNULL(telefonoreferencia, '') as telefonoreferencia,
                            IFNULL(correo, '') as correo,
                            IFNULL(nombrereferencia, '') as nombrereferencia,
                            IFNULL(casatipo, '') as casatipo,
                            IFNULL(casacolor, '') as casacolor,
                            IFNULL(fotoine, '') as fotoine,
                            IFNULL(fotocasa, '') as fotocasa,
                            IFNULL(comprobantedomicilio, '') as comprobantedomicilio,
                            IFNULL(pagare, '') as pagare,
                            IFNULL(fotootros, '') as fotootros,
                            IFNULL(pagosadelantar, '') as pagosadelantar,
                            IFNULL(created_at, '') as created_at,
                            IFNULL(updated_at, '') as updated_at,
                            IFNULL(id_optometrista, '') as id_optometrista,
                            IFNULL(tarjeta, '') as tarjeta,
                            IFNULL(pago, '') as pago,
                            IFNULL(id_promocion, '') as id_promocion,
                            IFNULL(fotoineatras, '') as fotoineatras,
                            IFNULL(tarjetapensionatras, '') as tarjetapensionatras,
                            IFNULL(total, '') as total,
                            IFNULL(idcontratorelacion, '') as idcontratorelacion,
                            IFNULL(contador, '') as contador,
                            IFNULL(totalhistorial, '') as totalhistorial,
                            IFNULL(totalpromocion, '') as totalpromocion,
                            IFNULL(totalproducto, '') as totalproducto,
                            IFNULL(totalabono, '') as totalabono,
                            IFNULL(fechaatraso, '') as fechaatraso,
                            IFNULL(costoatraso, '') as costoatraso,
                            IFNULL(ultimoabono, '') as ultimoabono,
                            IFNULL(estatus_estadocontrato, '') as estatus_estadocontrato,
                            IFNULL(diapago, '') as diapago,
                            IFNULL(fechacobroini, '') as fechacobroini,
                            IFNULL(fechacobrofin, '') as fechacobrofin,
                            IFNULL(enganche, '') as enganche,
                            IFNULL(entregaproducto, '') as entregaproducto,
                            IFNULL(diaseleccionado, '') as diaseleccionado,
                            IFNULL(fechaentrega, '') as fechaentrega,
                            IFNULL(promocionterminada, '') as promocionterminada,
                            IFNULL(subscripcion, '') as subscripcion,
                            IFNULL(fechasubscripcion, '') as fechasubscripcion,
                            IFNULL(nota, '') as nota,
                            IFNULL(totalreal, '') as totalreal,
                            IFNULL(diatemporal, '') as diatemporal,
                            IFNULL(coordenadas, '') as coordenadas
                            FROM contratos
                            WHERE id_franquicia = '$idFranquicia'
                            AND id_usuariocreacion = '" . $tokenValido[0]->usuario_id . "'
                            AND datos = '0'");

                    $contratos = DB::select("SELECT * FROM contratostemporalessincronizacion WHERE id_usuario = '" . $usuario[0]->id . "'");

                    //\Log::info("Total contratosnuevos: " . count($contratosnuevos));
                    //\Log::info("Total contratos: " . count($contratos));
                    $consulta = "SELECT IFNULL(hc.id, '') as id,
                            IFNULL(hc.id_contrato, '') as id_contrato,
                            IFNULL(hc.edad, '') as edad,
                            IFNULL(hc.fechaentrega, '') as fechaentrega,
                            IFNULL(hc.diagnostico, '') as diagnostico,
                            IFNULL(hc.ocupacion, '') as ocupacion,
                            IFNULL(hc.diabetes, '') as diabetes,
                            IFNULL(hc.hipertension, '') as hipertension,
                            IFNULL(hc.dolor, '') as dolor,
                            IFNULL(hc.ardor, '') as ardor,
                            IFNULL(hc.golpeojos, '') as golpeojos,
                            IFNULL(hc.otroM, '') as otroM,
                            IFNULL(hc.molestiaotro, '') as molestiaotro,
                            IFNULL(hc.ultimoexamen, '') as ultimoexamen,
                            IFNULL(hc.esfericoder, '') as esfericoder,
                            IFNULL(hc.cilindroder, '') as cilindroder,
                            IFNULL(hc.ejeder, '') as ejeder,
                            IFNULL(hc.addder, '') as addder,
                            IFNULL(hc.altder, '') as altder,
                            IFNULL(hc.esfericoizq, '') as esfericoizq,
                            IFNULL(hc.cilindroizq, '') as cilindroizq,
                            IFNULL(hc.ejeizq, '') as ejeizq,
                            IFNULL(hc.addizq, '') as addizq,
                            IFNULL(hc.altizq, '') as altizq,
                            IFNULL(hc.id_producto, '') as id_producto,
                            IFNULL(hc.id_paquete, '') as id_paquete,
                            IFNULL(hc.material, '') as material,
                            IFNULL(hc.materialotro, '') as materialotro,
                            IFNULL(hc.costomaterial, '') as costomaterial,
                            IFNULL(hc.bifocal, '') as bifocal,
                            IFNULL(hc.fotocromatico, '0') as fotocromatico,
                            IFNULL(hc.ar, '0') as ar,
                            IFNULL(hc.tinte, '0') as tinte,
                            IFNULL(hc.blueray, '0') as blueray,
                            IFNULL(hc.otroT, '') as otroT,
                            IFNULL(hc.tratamientootro, '') as tratamientootro,
                            IFNULL(hc.costotratamiento, '') as costotratamiento,
                            IFNULL(hc.observaciones, '') as observaciones,
                            IFNULL(hc.observacionesinterno, '') as observacionesinterno,
                            IFNULL(hc.tipo, '') as tipo,
                            IFNULL(hc.bifocalotro, '') as bifocalotro,
                            IFNULL(hc.costobifocal, '') as costobifocal,
                            IFNULL(hc.embarazada, '') as embarazada,
                            IFNULL(hc.durmioseisochohoras, '') as durmioseisochohoras,
                            IFNULL(hc.actividaddia, '') as actividaddia,
                            IFNULL(hc.problemasojos, '') as problemasojos,
                            IFNULL(hc.created_at, '') as created_at,
                            IFNULL(hc.updated_at, '') as updated_at
                            FROM historialclinico hc
                            INNER JOIN contratos c ON hc.id_contrato = c.id
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND (c.id_usuariocreacion = '" . $tokenValido[0]->usuario_id . "' AND c.estatus_estadocontrato IN (0,1,9) AND hc.tipo = 0 )
                            OR (c.id IN (SELECT g.id_contrato
                                        FROM garantias g
                                        INNER JOIN contratos con ON con.id = g.id_contrato
                                        WHERE g.id_optometrista = '" . $tokenValido[0]->usuario_id . "'
                                        AND (g.estadogarantia = 1 OR (g.estadogarantia = 2 AND STR_TO_DATE(g.updated_at,'%Y-%m-%d') = STR_TO_DATE('$nowParse','%Y-%m-%d')))
                                            AND con.estatus_estadocontrato IN (1,2,5,12,4,9) AND con.id_franquicia = '$idFranquicia') AND hc.tipo IN (0,1))";

                    $historialesClinicos = DB::select($consulta);

                    $abonos = $globalesServicioWeb::obtenerAbonosContratos($contratos, $idFranquicia);
                    $productosDeContrato = DB::select(
                        "SELECT IFNULL(cp.id, '') as id,
                            IFNULL(cp.id_contrato, '') as id_contrato,
                            IFNULL(cp.id_producto, '') as id_producto,
                            IFNULL(cp.id_franquicia, '') as id_franquicia,
                            IFNULL(cp.id_usuario, '') as id_usuario,
                            IFNULL(cp.created_at, '') as created_at,
                            IFNULL(cp.updated_at, '') as updated_at,
                            IFNULL(cp.piezas, '') as piezas,
                            IFNULL(cp.total, '') as total
                            FROM contratoproducto cp
                            INNER JOIN contratos c ON c.id = cp.id_contrato
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND c.id_usuariocreacion = '" . $tokenValido[0]->usuario_id . "'
                            AND c.estatus_estadocontrato IN (0,1,9)");

                    $promocionContrato = $globalesServicioWeb::obtenerPromocionesContratos($contratos);

                    /*\Log::info("Total promo: " . count($promocionContrato));
                    \Log::info("PromocionC: " . print_r($promocionContrato, true));*/
                    $productos = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(id_tipoproducto, '') as id_tipoproducto,
                            IFNULL(nombre, '') as nombre,
                            IFNULL(piezas, '') as piezas,
                            IFNULL(color, '') as color,
                            IFNULL(precio, '') as precio,
                            IFNULL(activo, '') as activo,
                            IFNULL(preciop, '') as preciop
                            FROM producto
                            WHERE estado = 1
                            AND ((id_tipoproducto != 1
                                AND id_franquicia = '$idFranquicia')
                                OR (id_tipoproducto = 1))");

                    $usuarios = DB::select(
                        "SELECT IFNULL(u.id, '') as id,
                            IFNULL(u.rol_id, '') as rol_id,
                            IFNULL(name, '') as name
                            FROM users u
                            INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario
                            WHERE u.rol_id = 12
                            AND uf.id_franquicia = '$idFranquicia'");

                    $zonas = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(zona, '') as zona
                            FROM zonas
                            WHERE id_franquicia = '$idFranquicia'");

                    $promociones = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(titulo, '') as titulo,
                            IFNULL(precioP, '') as precioP,
                            IFNULL(inicio, '') as inicio,
                            IFNULL(fin, '') as fin,
                            IFNULL(status, '') as status,
                            IFNULL(asignado, '') as asignado,
                            IFNULL(id_tipopromocionusuario, '') as id_tipopromocionusuario,
                            IFNULL(contado, '') as contado,
                            IFNULL(armazones, '') as armazones,
                            IFNULL(tipopromocion, '') as tipopromocion,
                            IFNULL(preciouno, '') as preciouno
                            FROM promocion
                            WHERE id_franquicia = '$idFranquicia'
                            AND status = '1'
                            AND id_tipopromocionusuario = '0'");

                    $paquetes = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(nombre, '') as nombre,
                            IFNULL(precio, '') as precio
                            FROM paquetes
                            WHERE id_franquicia = '$idFranquicia'");

                    $tratamientos = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(nombre, '') as nombre,
                            IFNULL(precio, '') as precio
                            FROM tratamientos
                            WHERE id_franquicia = '$idFranquicia'");

                    $garantias = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(id_contrato, '') as id_contrato,
                            IFNULL(id_historial, '') as id_historial,
                            IFNULL(id_historialgarantia, '') as id_historialgarantia,
                            IFNULL(id_optometrista, '') as id_optometrista,
                            IFNULL(estadogarantia, '') as estadogarantia,
                            IFNULL(created_at, '') as created_at,
                            IFNULL(updated_at, '') as updated_at
                            FROM garantias
                            WHERE id_optometrista = '" . $tokenValido[0]->usuario_id . "'
                            AND (estadogarantia = 1 OR (estadogarantia = 2 AND STR_TO_DATE(updated_at,'%Y-%m-%d') = STR_TO_DATE('$now','%Y-%m-%d')))");

                    $contratosliosfugas = DB::select(
                        "SELECT IFNULL(c.id, '') AS id,
                            IFNULL(c.nombre, '') AS nombre,
                            IFNULL(c.colonia, '') AS colonia,
                            IFNULL(c.calle, '') AS calle,
                            IFNULL(c.numero, '') AS numero,
                            IFNULL(c.telefono, '') AS telefono,
                            IFNULL((SELECT hco.cambios
                                    FROM historialcontrato hco
                                    WHERE hco.id_contrato = c.id
                                    AND tipomensaje = '1'
                                    ORDER BY hco.created_at DESC LIMIT 1), '') AS cambios
                            FROM contratos c
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND c.estatus_estadocontrato = '14'");


                    $consulta = "SELECT IFNULL(hs.id_contrato, '') as id_contrato,
                            IFNULL(hs.id_historial, '') as id_historial,
                            IFNULL(hs.esfericoder, '') as esfericoder,
                            IFNULL(hs.cilindroder, '') as cilindroder,
                            IFNULL(hs.ejeder, '') as ejeder,
                            IFNULL(hs.addder, '') as addder,
                            IFNULL(hs.esfericoizq, '') as esfericoizq,
                            IFNULL(hs.cilindroizq, '') as cilindroizq,
                            IFNULL(hs.ejeizq, '') as ejeizq,
                            IFNULL(hs.addizq, '') as addizq,
                            IFNULL(hs.created_at, '') as created_at
                            FROM historialsinconversion hs INNER JOIN contratos c
                            ON hs.id_contrato = c.id
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND c.id_usuariocreacion = '" . $tokenValido[0]->usuario_id . "'
                            AND c.estatus_estadocontrato IN (0,1,9)
                            OR c.id IN (SELECT g.id_contrato
                                        FROM garantias g
                                        WHERE g.id_optometrista = '" . $tokenValido[0]->usuario_id . "'
                                        AND (g.estadogarantia = 1 OR (g.estadogarantia = 2 AND STR_TO_DATE(g.updated_at,'%Y-%m-%d') = STR_TO_DATE('$nowParse','%Y-%m-%d')))
                                        AND c.estatus_estadocontrato IN (1,2,5,12,4))";

                    $historialessinconversion = DB::select($consulta);

                    //Obtenemos el Optometrista y Asistente con mas ventas en la semana
                    $ventas = $globalesServicioWeb::obtenerVentas($now,$nowParse);

                } elseif ($usuario[0]->rol_id == 4) {
                    //Si el usuario es alguien de cobranza
                    //\Log::info("ENTRO A COBRANZA");

                    $mensajes = DB::select(
                        "SELECT IFNULL(id, '') as id,
                            IFNULL(descripcion, '') as descripcion,
                            IFNULL(fechalimite, '') as fechalimite,
                            IFNULL(intentos, '') as intentos
                            FROM mensajes
                            WHERE id_franquicia = '$idFranquicia'");

                    $contratos = DB::select("SELECT * FROM contratostemporalessincronizacion WHERE id_usuario = '" . $usuario[0]->id . "'");

                    $arrayContratos = array();
                    //$now = Carbon::parse("2022-02-12");
                    $hoyNumero = $now->dayOfWeekIso; // Comienza en lunes -> 1 y obtenemos el dia actual de la semana
                    $fechaSabadoAntes = $globalesServicioWeb::obtenerDia($now, $hoyNumero, 0); //Obtenemos la fecha del dia sabado anterior
                    $fechaViernesSiguiente = $globalesServicioWeb::obtenerDia($now, $hoyNumero, 1); //Obtenemos la fecha del dia viernes siguiente
                    foreach ($contratos as $contrato) {

                        $diaTemporal = $contrato->diatemporal;

                        if ($contrato->estatus_estadocontrato == 12 || $contrato->estatus_estadocontrato == 5) {
                            //ENVIADOS Y LIQUIDADOS
                            if ($diaTemporal != null) { //Tiene dia temporal?
                                //Tiene dia temporal
                                if (Carbon::parse($now)->format('Y-m-d') >= Carbon::parse($diaTemporal)->format('Y-m-d')) {
                                    //Actualizar diatemporal a null
                                    DB::table("contratos")->where("id", "=", $contrato->id)->where("id_franquicia", "=", $idFranquicia)->update([
                                        "diatemporal" => null
                                    ]);
                                    $contrato->diatemporal = ""; //Mandar vacio el atributo diatemporal al movil
                                    array_push($arrayContratos, $contrato); //Agregar contrato a array
                                }
                            } else {
                                //No tiene dia temporal
                                array_push($arrayContratos, $contrato); //Agregar contrato a array
                            }
                        } else {
                            //ENTREGADOS Y ABONOS ATRASADOS

                            switch ($contrato->pago) {
                                case 1:
                                    //SEMANAL
                                    if (!$globalesServicioWeb::tieneAbonoEnFechas($contrato->ultimoabonoreal, $fechaSabadoAntes, $fechaViernesSiguiente)) {
                                        //No tiene abono el contrato
                                        if ($diaTemporal != null) { //Tiene dia temporal?
                                            //Tiene dia temporal
                                            if (Carbon::parse($now)->format('Y-m-d') >= Carbon::parse($diaTemporal)->format('Y-m-d')) {
                                                //Actualizar diatemporal a null
                                                DB::table("contratos")->where("id", "=", $contrato->id)->where("id_franquicia", "=", $idFranquicia)->update([
                                                    "diatemporal" => null
                                                ]);
                                                $contrato->diatemporal = ""; //Mandar vacio el atributo diatemporal al movil
                                                array_push($arrayContratos, $contrato); //Agregar contrato a array
                                            }
                                        } else {
                                            //No tiene dia temporal
                                            array_push($arrayContratos, $contrato); //Agregar contrato a array
                                        }
                                    } else {
                                        //Tiene abono el contrato
                                        //Actualizar diatemporal a null
                                        DB::table("contratos")->where("id", "=", $contrato->id)->where("id_franquicia", "=", $idFranquicia)->update([
                                            "diatemporal" => null
                                        ]);
                                    }
                                    break;
                                default:
                                    //QUICENAL O MENSUAL
                                    if ($contrato->fechacobroini == null && $contrato->fechacobrofin == null) {
                                        //fechacobroini y fechacobrofin son null
                                        if ($diaTemporal != null) { //Tiene dia temporal?
                                            //Tiene dia temporal
                                            if (Carbon::parse($now)->format('Y-m-d') >= Carbon::parse($diaTemporal)->format('Y-m-d')) {
                                                //Actualizar diatemporal a null
                                                DB::table("contratos")->where("id", "=", $contrato->id)->where("id_franquicia", "=", $idFranquicia)->update([
                                                    "diatemporal" => null
                                                ]);
                                                $contrato->diatemporal = ""; //Mandar vacio el atributo diatemporal al movil
                                                array_push($arrayContratos, $contrato); //Agregar contrato a array
                                            }
                                        } else {
                                            //No tiene dia temporal
                                            array_push($arrayContratos, $contrato); //Agregar contrato a array
                                        }
                                    } else {
                                        //fechacobroini y fechacobrofin son diferente de null
                                        if ((Carbon::parse($contrato->fechacobroini)->format('Y-m-d') >= Carbon::parse($fechaSabadoAntes)->format('Y-m-d')
                                                && Carbon::parse($contrato->fechacobroini)->format('Y-m-d') <= Carbon::parse($fechaViernesSiguiente)->format('Y-m-d'))
                                            || (Carbon::parse($contrato->fechacobrofin)->format('Y-m-d') >= Carbon::parse($fechaSabadoAntes)->format('Y-m-d')
                                                && Carbon::parse($contrato->fechacobrofin)->format('Y-m-d') <= Carbon::parse($fechaViernesSiguiente)->format('Y-m-d'))
                                            || (Carbon::parse($now)->format('Y-m-d') >= Carbon::parse($contrato->fechacobroini)->format('Y-m-d')
                                                && Carbon::parse($now)->format('Y-m-d') <= Carbon::parse($contrato->fechacobrofin)->format('Y-m-d'))) {

                                            if (!$globalesServicioWeb::tieneAbonoEnFechas($contrato->ultimoabonoreal, $contrato->fechacobroini, $contrato->fechacobrofin)
                                                && !$globalesServicioWeb::tieneAbonoEnFechas($contrato->ultimoabonoreal, $fechaSabadoAntes, $fechaViernesSiguiente)) {
                                                //No tiene abono el contrato

                                                if ($diaTemporal != null) { //Tiene dia temporal?
                                                    //Tiene dia temporal
                                                    if (Carbon::parse($now)->format('Y-m-d') >= Carbon::parse($diaTemporal)->format('Y-m-d')) {
                                                        //Actualizar diatemporal a null
                                                        DB::table("contratos")->where("id", "=", $contrato->id)->where("id_franquicia", "=", $idFranquicia)->update([
                                                            "diatemporal" => null
                                                        ]);
                                                        $contrato->diatemporal = ""; //Mandar vacio el atributo diatemporal al movil
                                                        array_push($arrayContratos, $contrato); //Agregar contrato a array
                                                    }
                                                } else {
                                                    //No tiene dia temporal
                                                    array_push($arrayContratos, $contrato); //Agregar contrato a array
                                                }

                                            } else {
                                                //Tiene abono el contrato
                                                //Actualizar diatemporal a null
                                                DB::table("contratos")->where("id", "=", $contrato->id)->where("id_franquicia", "=", $idFranquicia)->update([
                                                    "diatemporal" => null
                                                ]);
                                            }

                                        }
                                    }
                                    break;
                            }

                        }
                    }

                    $contratos = $arrayContratos;

                    $historialesClinicos = DB::select(
                        "SELECT IFNULL(hc.id, '') as id,
                            IFNULL(hc.id_contrato, '') as id_contrato,
                            IFNULL(hc.edad, '') as edad,
                            IFNULL(hc.fechaentrega, '') as fechaentrega,
                            IFNULL(hc.diagnostico, '') as diagnostico,
                            IFNULL(hc.ocupacion, '') as ocupacion,
                            IFNULL(hc.diabetes, '') as diabetes,
                            IFNULL(hc.hipertension, '') as hipertension,
                            IFNULL(hc.dolor, '') as dolor,
                            IFNULL(hc.ardor, '') as ardor,
                            IFNULL(hc.golpeojos, '') as golpeojos,
                            IFNULL(hc.otroM, '') as otroM,
                            IFNULL(hc.molestiaotro, '') as molestiaotro,
                            IFNULL(hc.ultimoexamen, '') as ultimoexamen,
                            IFNULL(hc.esfericoder, '') as esfericoder,
                            IFNULL(hc.cilindroder, '') as cilindroder,
                            IFNULL(hc.ejeder, '') as ejeder,
                            IFNULL(hc.addder, '') as addder,
                            IFNULL(hc.altder, '') as altder,
                            IFNULL(hc.esfericoizq, '') as esfericoizq,
                            IFNULL(hc.cilindroizq, '') as cilindroizq,
                            IFNULL(hc.ejeizq, '') as ejeizq,
                            IFNULL(hc.addizq, '') as addizq,
                            IFNULL(hc.altizq, '') as altizq,
                            IFNULL(hc.id_producto, '') as id_producto,
                            IFNULL(hc.id_paquete, '') as id_paquete,
                            IFNULL(hc.material, '') as material,
                            IFNULL(hc.materialotro, '') as materialotro,
                            IFNULL(hc.costomaterial, '') as costomaterial,
                            IFNULL(hc.bifocal, '') as bifocal,
                            IFNULL(hc.fotocromatico, '0') as fotocromatico,
                            IFNULL(hc.ar, '0') as ar,
                            IFNULL(hc.tinte, '0') as tinte,
                            IFNULL(hc.blueray, '0') as blueray,
                            IFNULL(hc.otroT, '') as otroT,
                            IFNULL(hc.tratamientootro, '') as tratamientootro,
                            IFNULL(hc.costotratamiento, '') as costotratamiento,
                            IFNULL(hc.observaciones, '') as observaciones,
                            IFNULL(hc.observacionesinterno, '') as observacionesinterno,
                            IFNULL(hc.tipo, '') as tipo,
                            IFNULL(hc.bifocalotro, '') as bifocalotro,
                            IFNULL(hc.costobifocal, '') as costobifocal,
                            IFNULL(hc.embarazada, '') as embarazada,
                            IFNULL(hc.durmioseisochohoras, '') as durmioseisochohoras,
                            IFNULL(hc.actividaddia, '') as actividaddia,
                            IFNULL(hc.problemasojos, '') as problemasojos,
                            IFNULL(hc.created_at, '') as created_at,
                            IFNULL(hc.updated_at, '') as updated_at
                            FROM historialclinico hc
                            INNER JOIN contratos c ON hc.id_contrato = c.id
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND c.id_zona = '" . $usuario[0]->id_zona . "'
                            AND (c.estatus_estadocontrato IN (2,4,12)
                                OR c.id IN (SELECT g.id_contrato
                                            FROM garantias g
                                            INNER JOIN contratos con ON con.id = g.id_contrato
                                            WHERE con.estatus_estadocontrato IN (1,7,9,10,11)
                                            AND con.id_franquicia = '$idFranquicia'
                                            AND con.id_zona = '" . $usuario[0]->id_zona . "'
                                            AND g.estadogarantia IN (1,2) AND g.id_contrato = c.id))");

                    $abonos = $globalesServicioWeb::obtenerAbonosContratos($contratos, $idFranquicia);

                    $promocionContrato = $globalesServicioWeb::obtenerPromocionesContratos($contratos);

                    $usuarios = DB::select("SELECT IFNULL(u.id, '') as id, IFNULL(u.rol_id, '') as rol_id, IFNULL(name, '') as name FROM users u INNER JOIN usuariosfranquicia uf ON u.id = uf.id_usuario WHERE u.rol_id = 12 AND uf.id_franquicia = '$idFranquicia'");

                    $garantias = $globalesServicioWeb::obtenerGarantiasContratos($contratos);

                    $ruta = $globalesServicioWeb::obtenerRuta($contratos, $usuario[0]->id);

                    $totalcontratosconabonos = DB::select("SELECT COUNT(c.id) as totalcontratosconabonos FROM contratos c WHERE c.id IN (SELECT a.id_contrato FROM abonos a WHERE a.corte = '0' AND c.id_franquicia = '$idFranquicia' AND a.id_usuario = '" . $usuario[0]->id . "' GROUP BY a.id_contrato)");

                    $jsonabonosgeneral = $globalesServicioWeb::obtenerJsonAbonosGeneral($usuario[0]->id);

                    //\Log::info("Total contratos: " . count($contratos));
                    //\Log::info("Total historialesClinicos: " . count($historialesClinicos));
                    //\Log::info("Total abonos: " . count($abonos));
                    //\Log::info("Total promocionContrato: " . count($promocionContrato));
                    //\Log::info("Total usuarios: " . count($usuarios));
                }

                $llaves = DB::select("SELECT IFNULL(ll.llave, '') as llave, IFNULL(ll.tipo, '') as tipo FROM llaves ll WHERE ll.id_franquicia = '$idFranquicia'");

                //Obtenemos la configuracion activa para la app movil
                $consulta = "SELECT IFNULL(indice, '') as indice,
                        IFNULL(fotologo, '') as fotologo,
                        IFNULL(coloriconos, '') as coloriconos,
                        IFNULL(colorencabezados, '') as colorencabezados,
                        IFNULL(colornavbar, '') as colornavbar,
                        IFNULL(estadoconfiguracion, '') as estadoconfiguracion
                        FROM configuracionmovil
                        WHERE estadoconfiguracion = 1";

                $configuracionmovil = DB::select($consulta);

                //Desencriptar llaves para que vallan al movil desencriptadas
                foreach ($llaves as $llave) {
                    try {
                        if(strlen($llave->llave) > 0) {
                            //Tiene algo la llave
                            $llave->llave = Crypt::decryptString($llave->llave);
                        }
                    } catch (DecryptException $e) {
                        \Log::info("Error: serviciowebtrabajadoruno llaves tipo: " . $llave->tipo . "\n" . $e->getMessage());
                    }
                }

                $datos[0]["codigo"] = "LOLATV3";
                $datos[0]["mensajes"] = $mensajes;
                $datos[0]["contratosnuevos"] = $contratosnuevos;
                $datos[0]["contratos"] = $contratos;
                $datos[0]["historialesclinicos"] = $historialesClinicos;
                $datos[0]["abonos"] = $abonos;
                $datos[0]["contratosproductos"] = $productosDeContrato;
                $datos[0]["promocioncontratos"] = $promocionContrato;
                $datos[0]["productos"] = $productos;
                $datos[0]["usuarios"] = $usuarios;
                $datos[0]["zonas"] = $zonas;
                $datos[0]["promociones"] = $promociones;
                $datos[0]["paquetes"] = $paquetes;
                $datos[0]["tratamientos"] = $tratamientos;
                $datos[0]["garantias"] = $garantias;
                $datos[0]["ruta"] = $ruta;
                $datos[0]["totalcontratosconabonos"] = $totalcontratosconabonos;
                $datos[0]["jsonabonosgeneral"] = $jsonabonosgeneral;
                $datos[0]["contratosliosfugas"] = $contratosliosfugas;
                $datos[0]["historialessinconversion"] = $historialessinconversion;
                $datos[0]["llaves"] = $llaves;
                $datos[0]["ventas"] = $ventas;
                $datos[0]["configuracionmovil"] = $configuracionmovil;

                //\Log::info("{'datos': '" . base64_encode(json_encode($datos)) . "'}");
                return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

            }catch(\Exception $e){
                \Log::info("Error: serviciowebtrabajadoruno: (sincronizardos) - id_usuario: " . $tokenValido[0]->usuario_id . "\n" . $e);
            }

        } else {
            //El token no es valido, se debera cerrar sesion.
            $datos[0]["codigo"] = "LOLATV5";
            return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";
        }
    }

    public function cerrarsesion()
    {

        //\Log::info("cerrarsesion");

        $token = request("token");

        $validarToken = DB::select("SELECT * FROM tokenlolatv WHERE token = '$token'"); //Validamos si el token es valido

        $tokenValido = false;
        if ($validarToken != null) {
            $tokenValido = true;
        }

        if ($tokenValido) {
            //Token valido
            $usuario = DB::select("SELECT id FROM users WHERE id = '" . $validarToken[0]->usuario_id . "'");
            DB::delete("DELETE FROM tokenlolatv where usuario_id =" . $usuario[0]->id);
            DB::table("users")->where("id", "=", $usuario[0]->id)->update([
                "logueado" => 0
            ]);

            $datos[0]["codigo"] = "LOLATV9";
            return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";
        }

        //Token no valido
        $datos[0]["codigo"] = "LOLATV7";
        return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

    }

}
