<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use Illuminate\Support\Facades\DB;

class direccionamiento extends Controller
{
    public function redireccionar(){
        if(Auth::check()){
            switch(Auth::user()->rol_id){
                case 6:                         //ADMINISTRATIVO
                    $idUsuario = Auth::user()->id;
                    $existeUsuario = DB::select("SELECT id_franquicia FROM usuariosfranquicia where id_usuario = '$idUsuario'");
                    if($existeUsuario == null || $existeUsuario[0]->id_franquicia == ""){
                        Auth::logout();
                        return redirect()->route('login')->with("alerta", 'Usuario sin sucursal asignada');
                    }else {
                        $idFranquicia = DB::select("SELECT id_franquicia FROM usuariosfranquicia WHERE id_usuario = '$idUsuario'");
                        $ahora = Carbon::now();
                        $idFra = $idFranquicia[0]->id_franquicia;
                        $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND  uf.id_franquicia= '$idFra' AND  STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
                        $totalGarantias = DB::select("SELECT COUNT(g.id_contrato) AS total FROM garantias g  WHERE  g.estadogarantia IN (0) AND STR_TO_DATE(g.created_at,'%Y-%m-%d') = '".$ahora->format('Y-m-d')."'");
                        $mensajeGarantias = "";

                        if($totalGarantias[0]->total == 1){
                            $mensajeGarantias = "<br><br>Hay ".$totalGarantias[0]->total." reporte de garatia nuevo.";
                        }if($totalGarantias[0]->total > 1){
                            $mensajeGarantias = "<br><br>Hay ".$totalGarantias[0]->total." reportes de garatias nuevos.";
                        }

                        if($totalRenovacion[0]->total > 0 || $totalGarantias[0]->total > 0){
                            if($totalRenovacion[0]->total > 0 && $totalGarantias[0]->total == 0){
                                return redirect()->route('listapoliza',$idFranquicia[0]->id_franquicia)->with("mensaje","Existen ".$totalRenovacion[0]->total." contratos para renovar.");
                            }if($totalRenovacion[0]->total > 0 && $totalGarantias[0]->total > 0){
                                return redirect()->route('listapoliza',$idFranquicia[0]->id_franquicia)->with("mensaje","Existen ".$totalRenovacion[0]->total." contratos para renovar.".$mensajeGarantias);
                            }if($totalRenovacion[0]->total == 0 && $totalGarantias[0]->total > 0){
                                return redirect()->route('listapoliza',$idFranquicia[0]->id_franquicia)->with("mensaje",$mensajeGarantias);
                            }
                        }
                        return redirect()->route('listapoliza',$idFranquicia[0]->id_franquicia);
                    }
                case 7:                         //DIRECTOR
                    return redirect()->route('listafranquicia');
                case 8:                         //PRINCIPAL
                    $idUsuario = Auth::user()->id;
                    $idFranquicia = DB::select("SELECT id_franquicia FROM usuariosfranquicia WHERE id_usuario = '$idUsuario'");
                    return redirect()->route('listapoliza',$idFranquicia[0]->id_franquicia);
                case 15:                        //CONFIRMACIONES
                    return redirect()->route('listaconfirmaciones');
                case 16: //LABORATORIO PRINCIPAL
                    return redirect()->route('listalaboratorio');
                default:
                    Auth::logout();
                    return redirect()->route('login');
            }
        }else{
            return redirect()->route('login');
        }
    }

    public function estadofranquicia(){
        try{
            $idUsuario = Auth::user()->id;
            $existeUsuario = DB::select("SELECT id_franquicia FROM usuariosfranquicia where id_usuario = '$idUsuario'");
            if(!$existeUsuario){
                Auth::logout();
                return redirect()->route('login');
            }else{
                $estadoSucursal =  DB::select("SELECT estado FROM configfranquicia WHERE id_franquicia = '".$existeUsuario[0]->id_franquicia."'");
                if($estadoSucursal != null){
                     if($estadoSucursal[0]->estado == 1){
                        return redirect()->route('redireccionar');
                    }else{
                        return view('administracion.franquicia.estadofranquicia');
                    }
                }else{
                    Auth::logout();
                    return redirect()->route('login');
                }
            }
        }catch(\Exception $e){
             \Log::info("Error: ".$e->getMessage());
        }

    }

}
