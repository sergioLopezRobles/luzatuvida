<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Image;
use Uuid;

class general extends Controller
{
    public function listas(){
        if(Auth::check() && ((Auth::user()->rol_id) == 7))
        {
            $dispositivos = DB::select("SELECT * FROM dispositivos ORDER BY created_at DESC");
            return view('administracion.general.listas',['dispositivos'=>$dispositivos]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function dispositivonuevo(){
        if(Auth::check() && ((Auth::user()->rol_id) == 7))
        {
            $continuar = false;
            do{
                $idDispositivo = strtoupper(Uuid::generate()->string);
                $existe = DB::select("SELECT id FROM dispositivos WHERE id = '$idDispositivo'");
                if($existe == null){
                    $continuar = true;
                }
            }while(!$continuar);
            return view('administracion.general.dispositivos.nuevo',["idDispositivo" => $idDispositivo]);
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function dispositivocrear(Request $request){
        if(Auth::check() && ((Auth::user()->rol_id) == 7))
        {
            $rules = [
                'titulo' => 'required|string|max:255',
                'descripcion' => 'required|string|max:255',
                'version' => 'required|string|max:7',
                'apk' => 'required',
                'idDispositivo' => 'required|string'
            ];
            request()->validate($rules);

            $titulo =  request('titulo');
            $descripcion =  request('descripcion');
            $version =  request('version');

            if(strcmp(request()->file('apk')->getClientOriginalExtension(),"apk")  != 0 ){
                return back()->withErrors(['apk'=>''])->withInput($request->all());
            }

            $activar = 0;
            $ahora = Carbon::now();
            if(request('activo') == 1){
                $activar = 1;
                $fechaActivacion = "";
            }else{
                $fechaActivacion = request('fechaactivacion');
                if(Carbon::parse($fechaActivacion) <= $ahora){
                    return back()->with(['error'=>'La fecha de activacion no puede ser menor o gual a la fecha actual.'])->withInput($request->all());
                }
            }

            $fotoBruta='Aplicacion-'.time(). '.' . request()->file('apk')->getClientOriginalExtension();
            $apk=request()->file('apk')->storeAs('uploads/aplicaciones', $fotoBruta,'disco');

            if($activar == 1){
                $desactivar = 0;
                DB::table('dispositivos')->where('estatus','=','1')->update([
                    'estatus'=>$desactivar
                ]);
            }

            DB::table('dispositivos')->insert([
                'id'=> $request ->idDispositivo,'titulo' => $titulo,'descripcion' => $descripcion, 'version' => $version, 'apk' => $apk,'fechaactivacion' =>  $fechaActivacion,'estatus'=> $activar,'created_at' => $ahora
            ]);

            return redirect()->route('general')->with('bien','El dispositivo se creo correctamente.');

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function dispositivoestatus($idDispositivo,$estatus){
        if(Auth::check() && ((Auth::user()->rol_id) == 7))
        {

            $estado = 0;
            if($estatus == 0 ){
                $estado = 1;
            }

            DB::table('dispositivos')->where('estatus','=','1')->update([
                'estatus' => 0
            ]);

            DB::table('dispositivos')->where('id','=',$idDispositivo)->update([
                'estatus' => $estado
            ]);

            return redirect()->route('general')->with('bien','El dispositivo de actualizo correctamente.');
        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function configuracion(){
        if(Auth::check() && ((Auth::user()->rol_id) == 7))
        {

            $configuracionActual = DB::select("SELECT * FROM configuracionmovil cm WHERE cm.estadoconfiguracion = 1");

            return view('administracion.general.configuracion',['configuracionActual' => $configuracionActual]);

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function actualizarConfiguracion(){
        if(Auth::check() && ((Auth::user()->rol_id) == 7))
        {

            $logo =  request('imagenLogo');
            $icono =  request('icono');
            $encabezados =  request('encabezados');
            $navbar =  request('navbar');
            $configuracionPredeterminada = request('cbDefault');

            $existeConfiguracion = DB::select("SELECT * FROM configuracionmovil cm WHERE cm.estadoconfiguracion = 1");

            if($existeConfiguracion != null){
                //Si ya existe una configuracion activa
                $idConfiguracion = $existeConfiguracion[0]->indice;

                //Desactivamos la configuracion actual
                DB::table('configuracionmovil')->where('indice','=',$idConfiguracion)->update([
                    'estadoconfiguracion' => 0
                ]);
            }

            //configuracion predeterminada
            if($configuracionPredeterminada == 1){
                //Si esta seleccionado el checkbox
                $existeConfiguracionDefault = DB::select("SELECT * FROM configuracionmovil cm WHERE cm.fotologo = '' AND cm.coloriconos = ''
                                                                AND cm.colorencabezados = '' AND cm.colornavbar = ''");

                if($existeConfiguracionDefault != null){
                    //Si ya se habia registrado antes la configuracion por default
                    //Actualizamos ese registro a un estatus 1 (activar configuracion)
                    $indiceConfiguracionDefault = $existeConfiguracionDefault[0]->indice;

                    DB::table('configuracionmovil')->where('indice','=',$indiceConfiguracionDefault)->update([
                        'estadoconfiguracion' => 1, 'updated_at' => Carbon::now()
                    ]);
                } else {
                    //Si no existe la registramos por primera vez
                    DB::table('configuracionmovil')->insert([
                        'fotologo' => null,'coloriconos' => null, 'colorencabezados' => null, 'colornavbar' => null,
                        'estadoconfiguracion' =>  1,'created_at' => Carbon::now()
                    ]);
                }

            } else {

                //Validacion de tamaño de imagen -> Recmendado a 500x163 px
                $fotoLogo = null;
                if (request()->hasFile('imagenLogo')) {
                    $fotoLogoBruta = 'Logotipo-Configuracion-' . time() . '.' . request()->file('imagenLogo')->getClientOriginalExtension();
                    $fotoLogo = request()->file('imagenLogo')->storeAs('uploads/imagenes/configuracion/logo', $fotoLogoBruta, 'disco');
                    $alto = Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/configuracion/logo/'.$fotoLogoBruta)->height();
                    $ancho = Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/configuracion/logo/'.$fotoLogoBruta)->width();
                    if($alto > $ancho){
                        $imagenfoto=Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/configuracion/logo/'.$fotoLogoBruta)->resize(500,163);
                    }else{
                        $imagenfoto=Image::make(config('filesystems.disks.disco.root').'/uploads/imagenes/configuracion/logo/'.$fotoLogoBruta)->resize(500,163);
                    }
                    $imagenfoto->save();

                }

                //Registramos la configuracion nueva y activamos por default
                DB::table('configuracionmovil')->insert([
                    'fotologo' => $fotoLogo,'coloriconos' => $icono, 'colorencabezados' => $encabezados, 'colornavbar' => $navbar,
                    'estadoconfiguracion' =>  1,'created_at' => Carbon::now()
                ]);
            }

            return back()->with('bien','La configuracion se actualizó correctamente.');

        }else{
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

}
