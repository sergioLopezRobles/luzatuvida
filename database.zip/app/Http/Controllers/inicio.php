<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class inicio extends Controller
{
    public function cargarTodo(){
      return view('administracion.administracion');
    }
}
