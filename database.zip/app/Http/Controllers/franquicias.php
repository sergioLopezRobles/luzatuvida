<?php

namespace App\Http\Controllers;

use App\archivos;
use App\Clases\contratosGlobal;
use App\Clases\globalesServicioWeb;
use DateTime;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use mysql_xdevapi\Exception;
use Session;
use Carbon\Carbon;
use App\Models\User;
use Image;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use function PHPUnit\Framework\isEmpty;
use ZipArchive;
use Extractor;


class franquicias extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }//constructor

    public function nuevafranquicia()
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7) //ID DEL DIRECTOR
        {
            return view('administracion.franquicia.nueva');
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    //Funcion para dar de alta una nueva franquicia
    public function crearFranquicia()
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7) //ID DEL DIRECTOR
        {

            request()->validate([
                'foto' => 'nullable|image|mimes:jpg',
                'curp' => 'nullable|file|mimes:pdf',
                'rfc' => 'nullable|file|mimes:pdf',
                'hacienda' => 'nullable|file|mimes:pdf',
                'actanacimiento' => 'nullable|file|mimes:pdf',
                'identificacion' => 'nullable|file|mimes:pdf',
                'estado' => 'required|max:30',
                'ciudad' => 'required|max:255',
                'colonia' => 'required|max:255',
                'numero' => 'required|max:10',
                'telefonofranquicia' => 'required|string|size:10|regex:/[0-9]/',
                'comprobante' => 'nullable|file|mimes:pdf',
                'observaciones' => 'max:300',
                'telefonoatencionclientes' => 'required|string|min:10|max:13|regex:/^[0-9\-]+$/'
            ]);

            $total = 0;
            $franquicias = DB::select("SHOW TABLE STATUS LIKE 'franquicias'");
            $siguienteId = $franquicias[0]->Auto_increment;
            try {

                $foto = "";
                $fotoBool = false;
                if (request()->hasFile('foto')) {
                    $fotoBruta = 'Foto-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('foto')->getClientOriginalExtension();
                    $foto = request()->file('foto')->storeAs('uploads/imagenes/franquicia/fotos', $fotoBruta, 'disco');
                    $fotoBool = true;
                    $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/franquicia/fotos/' . $fotoBruta)->height();
                    $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/franquicia/fotos/' . $fotoBruta)->width();
                    if ($alto > $ancho) {
                        $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/franquicia/fotos/' . $fotoBruta)->resize(600, 800);
                    } else {
                        $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/franquicia/fotos/' . $fotoBruta)->resize(800, 600);
                    }
                    $imagenfoto->save();
                }
                $curp = "";
                $curpBool = false;
                if (request()->hasFile('curp')) {
                    $curpBruto = 'Curp-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('curp')->getClientOriginalExtension();
                    $curp = request()->file('curp')->storeAs('uploads/imagenes/franquicia/curp', $curpBruto, 'disco');
                    $curpBool = true;

                }
                $rfc = "";
                $rfcBool = false;
                if (request()->hasFile('rfc')) {
                    $rfcBruto = 'Rfc-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('rfc')->getClientOriginalExtension();
                    $rfc = request()->file('rfc')->storeAs('uploads/imagenes/franquicia/rfc', $rfcBruto, 'disco');
                    $rfcBool = true;

                }
                $hacienda = "";
                $haciendaBool = false;
                if (request()->hasFile('hacienda')) {
                    $haciendaBruta = 'Hacienda-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('hacienda')->getClientOriginalExtension();
                    $hacienda = request()->file('hacienda')->storeAs('uploads/imagenes/franquicia/hacienda', $haciendaBruta, 'disco');
                    $haciendaBool = true;

                }
                $actanacimiento = "";
                $actanacimientoBool = false;
                if (request()->hasFile('actanacimiento')) {
                    $actanacimientoBruta = 'Actanacimiento-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('actanacimiento')->getClientOriginalExtension();
                    $actanacimiento = request()->file('actanacimiento')->storeAs('uploads/imagenes/franquicia/actanacimiento', $actanacimientoBruta, 'disco');
                    $actanacimientoBool = true;

                }
                $identificacion = "";
                $identificacionBool = false;
                if (request()->hasFile('identificacion')) {
                    $identificacionBruta = 'Identificacion-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('identificacion')->getClientOriginalExtension();
                    $identificacion = request()->file('identificacion')->storeAs('uploads/imagenes/franquicia/identificacion', $identificacionBruta, 'disco');
                    $identificacionBool = true;

                }

                $estado = "";
                $estadoBool = false;
                if (strlen(request('estado')) > 0) {
                    $estado = request('estado');
                    $estadoBool = true;
                }

                $ciudad = "";
                $ciudadBool = false;
                if (strlen(request('ciudad')) > 0) {
                    $ciudad = request('ciudad');
                    $ciudadBool = true;
                }
                $colonia = "";
                $coloniaBool = false;
                if (strlen(request('colonia')) > 0) {
                    $colonia = request('colonia');
                    $coloniaBool = true;
                }
                $numero = "";
                $numeroBool = false;
                if (strlen(request('numero')) > 0) {
                    $numero = request('numero');
                    $numeroBool = true;
                }
                $comprobante = "";
                $comprobanteBool = false;
                if (request()->hasFile('comprobante')) {
                    $comprobanteBruto = 'Comprobante-Franquicia-' . $siguienteId . '-' . time() . '.' . request()->file('comprobante')->getClientOriginalExtension();
                    $comprobante = request()->file('comprobante')->storeAs('uploads/imagenes/franquicia/comprobante', $comprobanteBruto, 'disco');
                    $comprobanteBool = true;
                }

                $observaciones = "";
                $observacionesBool = false;
                if (strlen(request('observaciones')) > 0) {
                    $observaciones = request('observaciones');
                    $observacionesBool = true;
                }

                $generado = false;
                do {
                    $idFranquicia = strtoupper(Str::random(5));
                    $existe = DB::select("SELECT id FROM franquicias WHERE id =' $idFranquicia'");
                    if ($existe == null) {
                        try {
                            $generado = true;
                        } catch (\Exception $e) {
                            \Log::error('Error: ' . $e->getMessage());
                            return back()->with('error', 'Tuvimos un error, por favor contacta al Administrador de la pagina.\nError: ' . $e->getMessage())->with('fcreada');
                        }
                    }
                } while (!$generado);


                $actualizadopor = "";
                DB::table('franquicias')->insert([
                    'id' => $idFranquicia, 'creadopor' => strtoupper(Auth::user()->name), 'actualizadopor' => $actualizadopor, 'foto' => $foto, 'curp' => $curp, 'rfc' => $rfc, 'hacienda' => $hacienda, 'actanacimiento' => $actanacimiento, 'identificacion' => $identificacion, 'estado' => strtoupper($estado),
                    'ciudad' => strtoupper($ciudad), 'colonia' => strtoupper($colonia), 'numero' => strtoupper($numero), 'comprobante' => $comprobante, 'observaciones' => strtoupper($observaciones), 'telefonofranquicia' => request('telefonofranquicia'), 'created_at' => Carbon::now(),
                    'telefonoatencionclientes' => request('telefonoatencionclientes')
                ]);

                if (request('activo') == 1) {
                    $status = 1;
                } else {
                    if ($fotoBool && $curpBool && $rfcBool && $haciendaBool && $actanacimientoBool && $identificacionBool && $estadoBool && $ciudadBool && $coloniaBool && $numeroBool && $comprobanteBool && $observacionesBool) {
                        $status = 1;
                    } else {
                        $status = 2;
                    }
                }


                //TRATAMIENTOS
                DB::table("tratamientos")->insert([
                    "id" => 3,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "Fotocromático",
                    "precio" => "600",
                    "created_at" => Carbon::now()
                ]);

                DB::table("tratamientos")->insert([
                    "id" => 4,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "A/R",
                    "precio" => "0",
                    "created_at" => Carbon::now()
                ]);

                DB::table("tratamientos")->insert([
                    "id" => 5,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "tinte",
                    "precio" => "200",
                    "created_at" => Carbon::now()
                ]);

                DB::table("tratamientos")->insert([
                    "id" => 6,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "BlueRay",
                    "precio" => "600",
                    "created_at" => Carbon::now()
                ]);

                //PAQUETES
                DB::table("paquetes")->insert([
                    "id" => 1,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "LECTURA",
                    "precio" => "900",
                    "created_at" => Carbon::now()
                ]);

                DB::table("paquetes")->insert([
                    "id" => 2,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "PROTECCION",
                    "precio" => "1490",
                    "created_at" => Carbon::now()
                ]);

                DB::table("paquetes")->insert([
                    "id" => 3,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "ECO JR",
                    "precio" => "1490",
                    "created_at" => Carbon::now()
                ]);

                DB::table("paquetes")->insert([
                    "id" => 4,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "JR",
                    "precio" => "1790",
                    "created_at" => Carbon::now()
                ]);

                DB::table("paquetes")->insert([
                    "id" => 5,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "DORADO 1",
                    "precio" => "1890",
                    "created_at" => Carbon::now()
                ]);

                DB::table("paquetes")->insert([
                    "id" => 6,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "DORADO 2",
                    "precio" => "2290",
                    "created_at" => Carbon::now()
                ]);

                DB::table("paquetes")->insert([
                    "id" => 7,
                    "id_franquicia" => $idFranquicia,
                    "nombre" => "PLATINO",
                    "precio" => "2590",
                    "created_at" => Carbon::now()
                ]);

                //PROMOCIONES

                DB::table("promocion")->insert([
                    "id_franquicia" => $idFranquicia,
                    "titulo" => "3 x 2 CONVENIO",
                    "precioP" => "100",
                    "inicio" => new DateTime('first day of January'),
                    "fin" => new DateTime('last day of December'),
                    "status" => "1",
                    "created_at" => Carbon::now(),
                    "id_tipopromocionusuario" => 0,
                    "armazones" => 3
                ]);

                DB::table("promocion")->insert([
                    "id_franquicia" => $idFranquicia,
                    "titulo" => "2 POR 1 Y MEDIO CONVENIO",
                    "precioP" => "50",
                    "inicio" => new DateTime('first day of January'),
                    "fin" => new DateTime('last day of December'),
                    "status" => "1",
                    "created_at" => Carbon::now(),
                    "id_tipopromocionusuario" => 0,
                    "armazones" => 2
                ]);

                DB::table("promocion")->insert([
                    "id_franquicia" => $idFranquicia,
                    "titulo" => "ARMAZON PROPIO ( PAQ. ECO JR | JR | DORADO 1 | PLATINO )",
                    "precioP" => NULL,
                    "inicio" => new DateTime('first day of January'),
                    "fin" => new DateTime('last day of December'),
                    "status" => "1",
                    "created_at" => Carbon::now(),
                    "id_tipopromocionusuario" => 0,
                    "armazones" => 1,
                    "preciouno" => 300
                ]);

                DB::table("promocion")->insert([
                    "id_franquicia" => $idFranquicia,
                    "titulo" => "CLIENTE FRECUENTE",
                    "precioP" => NULL,
                    "inicio" => new DateTime('first day of January'),
                    "fin" => new DateTime('last day of December'),
                    "status" => "1",
                    "created_at" => Carbon::now(),
                    "id_tipopromocionusuario" => 0,
                    "armazones" => 1,
                    "preciouno" => 300
                ]);

                //ZONAS

                DB::table("zonas")->insert([
                    "id_franquicia" => $idFranquicia,
                    "zona" => "1",
                    "created_at" => Carbon::now()
                ]);

                DB::table("zonas")->insert([
                    "id_franquicia" => $idFranquicia,
                    "zona" => "2",
                    "created_at" => Carbon::now()
                ]);

                DB::table("zonas")->insert([
                    "id_franquicia" => $idFranquicia,
                    "zona" => "3",
                    "created_at" => Carbon::now()
                ]);

                DB::table("zonas")->insert([
                    "id_franquicia" => $idFranquicia,
                    "zona" => "4",
                    "created_at" => Carbon::now()
                ]);

                DB::table("zonas")->insert([
                    "id_franquicia" => $idFranquicia,
                    "zona" => "5",
                    "created_at" => Carbon::now()
                ]);

                DB::table("zonas")->insert([
                    "id_franquicia" => $idFranquicia,
                    "zona" => "6",
                    "created_at" => Carbon::now()
                ]);


                DB::table('configfranquicia')->insert([
                    'id_franquicia' => $idFranquicia, 'estado' => $status
                ]);

                //Agregar franquicia a tabla llaves
                DB::table('llaves')->insert([
                    'id_franquicia' => $idFranquicia,
                    'llave' => null,
                    'tipo' => 0,
                    'created_at' => Carbon::now()
                ]);

                DB::table('llaves')->insert([
                    'id_franquicia' => $idFranquicia,
                    'llave' => null,
                    'tipo' => 1,
                    'created_at' => Carbon::now()
                ]);

                if ($status = 1) {
                    return redirect()->route('listafranquicia')->with('bien', 'La sucursal se creo correctamente.')->with('fcreada', 'Bien!');
                }
                return redirect()->route('listafranquicia')->with('alerta', 'La sucursal se creo, pero aun no se encuentra activa.')->with('fcreada', 'Bien!');
            } catch (\Exception $e) {
                \Log::error('Error: ' . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al Administrador de la pagina.\nError: ' . $e->getMessage())->with('fcreada');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }//crearFranquicia

    public function tablaFranquicia()
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7) //ROL DEL DIRECTOR
        {

            $franquicias = DB::select("SELECT fra.id as ID,fra.creadopor as CREADOPOR,fra.actualizadopor as ACTUALIZADOPOR,fra.estado as ESTADO,fra.ciudad as CIUDAD,fra.colonia as COLONIA,fra.numero as NUMERO,fra.created_at AS CREADOEL,cofra.estado AS ESTATUS
                                FROM franquicias fra
                                INNER JOIN  configfranquicia cofra
                                ON fra.id = cofra.id_franquicia
                                ORDER BY fra.created_at ASC");
            return view('administracion.franquicia.tabla', ['franquicias' => $franquicias]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function editarFranquicia($id)
    {

        if (Auth::check() && (Auth::user()->rol_id) == 7) //ROL DEL DIRECTOR
        {
            $franquicia = DB::select("SELECT * FROM franquicias WHERE id = '$id'");
            $estado = DB::select("SELECT estado FROM configfranquicia WHERE id_franquicia = '$id'");

            if ($franquicia == null) {
                return redirect()->route('listafranquicia');
            }

            try {

                //Obtenemos clave publicable
                $clavepublicablestripe = DB::select("SELECT llave FROM llaves WHERE id_franquicia = '$id' AND tipo = 0");
                if($clavepublicablestripe != null) {
                    if(strlen($clavepublicablestripe[0]->llave) > 0) {
                        //Tiene algo la llave
                        $franquicia[0]->clavepublicablestripe = Crypt::decryptString($clavepublicablestripe[0]->llave);
                    }else {
                        //Esta null la llave
                        $franquicia[0]->clavepublicablestripe = $clavepublicablestripe[0]->llave;
                    }
                }

                //Obtenemos clave secreta
                $clavesecretastripe = DB::select("SELECT llave FROM llaves WHERE id_franquicia = '$id' AND tipo = 1");
                if($clavesecretastripe != null) {
                    if(strlen($clavesecretastripe[0]->llave) > 0) {
                        //Tiene algo la llave
                        $franquicia[0]->clavesecretastripe = Crypt::decryptString($clavesecretastripe[0]->llave);
                    }else {
                        //Esta null la llave
                        $franquicia[0]->clavesecretastripe = $clavesecretastripe[0]->llave;
                    }
                }

            } catch (DecryptException $e) {
                return back()->with('error', 'Tuvimos un error, por favor contacta al Administrador de la pagina. Error: ' . $e->getMessage());
            }

            return view('administracion.franquicia.editar', ['franquicia' => $franquicia, 'estado' => $estado]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarFranquicia($id, Request $request)
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7) //ROL DEL DIRECTOR
        {

            request()->validate([
                'foto' => 'nullable|image|mimes:jpg',
                'curp' => 'nullable|file|mimes:pdf',
                'rfc' => 'nullable|file|mimes:pdf',
                'hacienda' => 'nullable|file|mimes:pdf',
                'actanacimiento' => 'nullable|file|mimes:pdf',
                'identificacion' => 'nullable|file|mimes:pdf',
                'estado' => 'max:30',
                'ciudad' => 'max:255',
                'colonia' => 'max:255',
                'numero' => 'max:10',
                'comprobante' => 'nullable|file|mimes:pdf',
                'observaciones' => 'max:300',
                'telefonoatencionclientes' => 'required|string|min:10|max:13|regex:/^[0-9\-]+$/'
            ]);

            $clavepublicablestripe = $request->input('claveP');
            $clavesecretastripe = $request->input('claveS');

            if ($clavepublicablestripe != null || $clavesecretastripe != null) {
                if($clavepublicablestripe == null || $clavesecretastripe == null) {
                    //Alguna de las 2 no tiene nada
                    return back()->with('alerta', 'Se necesitan de agregar tanto la clave publicable como la clave secreta');
                }else {
                    //Las 2 tienen algo
                    $clavepublicablestripe = Crypt::encryptString($clavepublicablestripe);
                    $clavesecretastripe = Crypt::encryptString($clavesecretastripe);
                }
            }

            try {

                $franquicia = DB::select("SELECT * FROM franquicias WHERE id='$id'");

                $foto = "";
                $fotoBool = false;
                if (strlen($franquicia[0]->foto) > 0) {
                    if (request()->hasFile('foto')) {
                        Storage::disk('disco')->delete($franquicia[0]->foto);
                        $fotoBruta = 'Foto-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('foto')->getClientOriginalExtension();
                        $foto = request()->file('foto')->storeAs('uploads/imagenes/franquicia/fotos', $fotoBruta, 'disco');
                        $fotoBool = true;
                        $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->height();
                        $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->width();
                        if ($alto > $ancho) {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->resize(600, 800);
                        } else {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->resize(800, 600);
                        }
                        $imagenfoto->save();
                    } else {
                        $foto = $franquicia[0]->foto;
                        $fotoBool = true;
                    }
                } else {
                    if (request()->hasFile('foto')) {
                        $fotoBruta = 'Foto-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('foto')->getClientOriginalExtension();
                        $foto = request()->file('foto')->storeAs('uploads/imagenes/franquicia/fotos', $fotoBruta, 'disco');
                        $fotoBool = true;
                        $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->height();
                        $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->width();
                        if ($alto > $ancho) {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->resize(600, 800);
                        } else {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotos/' . $fotoBruta)->resize(800, 600);
                        }
                        $imagenfoto->save();
                    } else {
                        $fotoBool = false;
                    }

                }

                $curp = "";
                $curpBool = false;
                if (strlen($franquicia[0]->curp) > 0) {
                    if (request()->hasFile('curp')) {
                        Storage::disk('disco')->delete($franquicia[0]->curp);
                        $curpBruto = 'Curp-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('curp')->getClientOriginalExtension();
                        $curp = request()->file('curp')->storeAs('uploads/imagenes/franquicia/curp', $curpBruto, 'disco');
                        $curpBool = true;
                        $alto1 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->height();
                        $ancho1 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->width();
                        if ($alto1 > $ancho1) {
                            $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->resize(600, 800);
                        } else {
                            $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->resize(800, 600);
                        }
                        $imagencurp->save();
                    } else {
                        $curp = $franquicia[0]->curp;
                        $curpBool = true;
                    }
                } else {
                    if (request()->hasFile('curp')) {
                        $curpBruto = 'Curp-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('curp')->getClientOriginalExtension();
                        $curp = request()->file('curp')->storeAs('uploads/imagenes/franquicia/curp', $curpBruto, 'disco');
                        $curpBool = true;
                        $alto1 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->height();
                        $ancho1 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->width();
                        if ($alto1 > $ancho1) {
                            $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->resize(600, 800);
                        } else {
                            $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/curp/' . $curpBruto)->resize(800, 600);
                        }
                        $imagencurp->save();
                    } else {
                        $curpBool = false;
                    }
                }

                $rfc = "";
                $rfcBool = false;
                if (strlen($franquicia[0]->rfc) > 0) {
                    if (request()->hasFile('rfc')) {
                        Storage::disk('disco')->delete($franquicia[0]->rfc);
                        $rfcBruto = 'Rfc-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('rfc')->getClientOriginalExtension();
                        $rfc = request()->file('rfc')->storeAs('uploads/imagenes/franquicia/rfc', $rfcBruto, 'disco');
                        $rfcBool = true;
                        $alto2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->height();
                        $ancho2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->width();
                        if ($alto2 > $ancho2) {
                            $imagenrfc = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->resize(600, 800);
                        } else {
                            $imagenrfc = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->resize(800, 600);
                        }
                        $imagenrfc->save();
                    } else {
                        $rfc = $franquicia[0]->rfc;
                        $rfcBool = true;
                    }
                } else {
                    if (request()->hasFile('rfc')) {
                        $rfcBruto = 'Rfc-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('rfc')->getClientOriginalExtension();
                        $rfc = request()->file('rfc')->storeAs('uploads/imagenes/franquicia/rfc', $rfcBruto, 'disco');
                        $rfcBool = true;
                        $alto2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->height();
                        $ancho2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->width();
                        if ($alto2 > $ancho2) {
                            $imagenrfc = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->resize(600, 800);
                        } else {
                            $imagenrfc = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/rfc/' . $rfcBruto)->resize(800, 600);
                        }
                        $imagenrfc->save();
                    } else {
                        $rfcBool = false;
                    }
                }

                $hacienda = "";
                $haciendaBool = false;
                if (strlen($franquicia[0]->hacienda) > 0) {
                    if (request()->hasFile('hacienda')) {
                        Storage::disk('disco')->delete($franquicia[0]->hacienda);
                        $haciendaBruta = 'Hacienda-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('hacienda')->getClientOriginalExtension();
                        $hacienda = request()->file('hacienda')->storeAs('uploads/imagenes/franquicia/hacienda', $haciendaBruta, 'disco');
                        $haciendaBool = true;
                        $alto3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->height();
                        $ancho3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->width();
                        if ($alto3 > $ancho3) {
                            $imagenhacienda = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->resize(600, 800);
                        } else {
                            $imagenhacienda = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->resize(800, 600);
                        }
                        $imagenhacienda->save();
                    } else {
                        $hacienda = $franquicia[0]->hacienda;
                        $haciendaBool = true;
                    }
                } else {
                    if (request()->hasFile('hacienda')) {
                        $haciendaBruta = 'Hacienda-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('hacienda')->getClientOriginalExtension();
                        $hacienda = request()->file('hacienda')->storeAs('uploads/imagenes/franquicia/hacienda', $haciendaBruta, 'disco');
                        $haciendaBool = true;
                        $alto3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->height();
                        $ancho3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->width();
                        if ($alto3 > $ancho3) {
                            $imagenhacienda = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->resize(600, 800);
                        } else {
                            $imagenhacienda = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/hacienda/' . $haciendaBruta)->resize(800, 600);
                        }
                        $imagenhacienda->save();
                    } else {
                        $haciendaBool = false;
                    }
                }

                $actanacimiento = "";
                $actanacimientoBool = false;
                if (strlen($franquicia[0]->actanacimiento) > 0) {
                    if (request()->hasFile('actanacimiento')) {
                        Storage::disk('disco')->delete($franquicia[0]->actanacimiento);
                        $actanacimientoBruta = 'Actanacimiento-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('actanacimiento')->getClientOriginalExtension();
                        $actanacimiento = request()->file('actanacimiento')->storeAs('uploads/imagenes/franquicia/actanacimiento', $actanacimientoBruta, 'disco');
                        $actanacimientoBool = true;
                        $alto4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->height();
                        $ancho4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->width();
                        if ($alto4 > $ancho4) {
                            $imagenactanacimientop = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->resize(600, 800);
                        } else {
                            $imagenactanacimiento = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->resize(800, 600);
                        }
                        $imagenactanacimiento->save();
                    } else {
                        $actanacimiento = $franquicia[0]->actanacimiento;
                        $actanacimientoBool = true;
                    }
                } else {
                    if (request()->hasFile('actanacimiento')) {
                        $actanacimientoBruta = 'Actanacimiento-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('actanacimiento')->getClientOriginalExtension();
                        $actanacimiento = request()->file('actanacimiento')->storeAs('uploads/imagenes/franquicia/actanacimiento', $actanacimientoBruta, 'disco');
                        $actanacimientoBool = true;
                        $alto4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->height();
                        $ancho4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->width();
                        if ($alto4 > $ancho4) {
                            $imagenactanacimientop = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->resize(600, 800);
                        } else {
                            $imagenactanacimiento = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/actanacimiento/' . $actanacimientoBruta)->resize(800, 600);
                        }
                        $imagenactanacimiento->save();
                    } else {
                        $actanacimientoBool = false;
                    }
                }

                $identificacion = "";
                $identificacionBool = false;
                if (strlen($franquicia[0]->identificacion) > 0) {
                    if (request()->hasFile('identificacion')) {
                        Storage::disk('disco')->delete($franquicia[0]->identificacion);
                        $identificacionBruta = 'Identificacion-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('identificacion')->getClientOriginalExtension();
                        $identificacion = request()->file('identificacion')->storeAs('uploads/imagenes/franquicia/identificacion', $identificacionBruta, 'disco');
                        $identificacionBool = true;
                        $alto5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->height();
                        $ancho5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->width();
                        if ($alto5 > $ancho5) {
                            $imagenidentificacion = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->resize(600, 800);
                        } else {
                            $imagenidentificacion = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->resize(800, 600);
                        }
                        $imagenidentificacion->save();
                    } else {
                        $identificacion = $franquicia[0]->identificacion;
                        $identificacionBool = true;
                    }
                } else {
                    if (request()->hasFile('identificacion')) {
                        $identificacionBruta = 'Identificacion-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('identificacion')->getClientOriginalExtension();
                        $identificacion = request()->file('identificacion')->storeAs('uploads/imagenes/franquicia/identificacion', $identificacionBruta, 'disco');
                        $identificacionBool = true;
                        $alto5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->height();
                        $ancho5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->width();
                        if ($alto5 > $ancho5) {
                            $imagenidentificacion = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->resize(600, 800);
                        } else {
                            $imagenidentificacion = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/identificacion/' . $identificacionBruta)->resize(800, 600);
                        }
                        $imagenidentificacion->save();
                    } else {
                        $haciendaBool = false;
                    }
                }

                $estado = $franquicia[0]->estado;
                $estadoBool = false;
                if (strlen($estado) > 0) {
                    if (strlen(request('estado')) > 0) {
                        $estado = request('estado');
                    }
                    $estadoBool = true;
                } else {
                    if (strlen(request('estado')) > 0) {
                        $estado = request('estado');
                        $estadoBool = true;
                    }
                }


                $ciudad = $franquicia[0]->ciudad;
                $ciudadBool = false;
                if (strlen($ciudad) > 0) {
                    if (strlen(request('ciudad')) > 0) {
                        $ciudad = request('ciudad');
                    }
                    $ciudadBool = true;
                } else {
                    if (strlen(request('ciudad')) > 0) {
                        $ciudad = request('ciudad');
                        $ciudadBool = true;
                    }
                }

                $colonia = $franquicia[0]->colonia;
                $coloniaBool = false;
                if (strlen($colonia) > 0) {
                    if (strlen(request('colonia')) > 0) {
                        $colonia = request('colonia');
                    }
                    $coloniaBool = true;
                } else {
                    if (strlen(request('colonia')) > 0) {
                        $colonia = request('colonia');
                        $coloniaBool = true;
                    }
                }

                $numero = $franquicia[0]->numero;
                $numeroBool = false;
                if (strlen($numero) > 0) {
                    if (strlen(request('numero')) > 0) {
                        $numero = request('numero');
                    }
                    $numeroBool = true;
                } else {
                    if (strlen(request('numero')) > 0) {
                        $numero = request('numero');
                        $numeroBool = true;
                    }
                }

                $comprobante = "";
                $comprobanteBool = false;
                if (strlen($franquicia[0]->comprobante) > 0) {
                    if (request()->hasFile('comprobante')) {
                        Storage::disk('disco')->delete($franquicia[0]->comprobante);
                        $comprobanteBruto = 'Comprobante-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('comprobante')->getClientOriginalExtension();
                        $comprobante = request()->file('comprobante')->storeAs('uploads/imagenes/franquicia/comprobante', $comprobanteBruto, 'disco');
                        $comprobanteBool = true;
                        $alto6 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->height();
                        $ancho6 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->width();
                        if ($alto6 > $ancho6) {
                            $imagencomprobante = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->resize(600, 800);
                        } else {
                            $imagencomprobante = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->resize(800, 600);
                        }
                        $imagencomprobante->save();
                    } else {
                        $comprobante = $franquicia[0]->comprobante;
                        $comprobanteBool = true;
                    }
                } else {
                    if (request()->hasFile('comprobante')) {
                        $comprobanteBruto = 'Comprobante-Franquicia-' . $franquicia[0]->id . '-' . time() . '.' . request()->file('comprobante')->getClientOriginalExtension();
                        $comprobante = request()->file('comprobante')->storeAs('uploads/imagenes/franquicia/comprobante', $comprobanteBruto, 'disco');
                        $comprobanteBool = true;
                        $alto6 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->height();
                        $ancho6 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->width();
                        if ($alto6 > $ancho6) {
                            $imagencomprobante = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->resize(600, 800);
                        } else {
                            $imagencomprobante = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobante/' . $comprobanteBruto)->resize(800, 600);
                        }
                        $imagencomprobante->save();
                    } else {
                        $comprobanteBool = false;
                    }
                }

                $observaciones = $franquicia[0]->observaciones;
                $observacionesBool = false;
                if (strlen($observaciones) > 0) {
                    if (strlen(request('observaciones')) > 0) {
                        $observaciones = request('observaciones');
                    }
                    $observacionesBool = true;
                } else {
                    if (strlen(request('observaciones')) > 0) {
                        $observaciones = request('observaciones');
                        $observacionesBool = true;
                    }
                }

                $estadofranquicia = 1;
                if (strlen(request('activo')) == 0) {
                    $estadofranquicia = 0;
                }


                DB::table('franquicias')->where('id', $franquicia[0]->id)->update([
                    'actualizadopor' => strtoupper(Auth::user()->name), 'foto' => $foto, 'curp' => $curp, 'rfc' => $rfc, 'hacienda' => $hacienda, 'actanacimiento' => $actanacimiento, 'identificacion' => $identificacion, 'estado' => strtoupper($estado),
                    'ciudad' => strtoupper($ciudad), 'colonia' => strtoupper($colonia), 'numero' => strtoupper($numero), 'comprobante' => $comprobante, 'observaciones' => strtoupper($observaciones), 'telefonofranquicia' => request('telefonofranquicia'), 'updated_at' => Carbon::now(),
                    'telefonoatencionclientes' => request('telefonoatencionclientes')
                ]);

                if ($fotoBool && $curpBool && $rfcBool && $haciendaBool && $actanacimientoBool && $identificacionBool && $estadoBool && $ciudadBool && $coloniaBool && $numeroBool && $comprobanteBool && $observacionesBool) {
                    $status = 1;
                } else {
                    $status = 2;
                }

                if ((Auth::user()->rol_id) == 7) {
                    DB::table('configfranquicia')->where('id_franquicia', $franquicia[0]->id)->update(['estado' => $estadofranquicia]);
                } else {
                    DB::table('configfranquicia')->where('id_franquicia', $franquicia[0]->id)->update([
                        'estado' => $status
                    ]);
                }

                //Actualizar clavepublicable y clavesecreta en la tabla llaves
                DB::table('llaves')->where([['id_franquicia', '=', $franquicia[0]->id], ['tipo', '=', 0]])->update([
                    'llave' => $clavepublicablestripe
                ]);
                DB::table('llaves')->where([['id_franquicia', '=', $franquicia[0]->id], ['tipo', '=', 1]])->update([
                    'llave' => $clavesecretastripe
                ]);

                if ($status == 1 || $estadofranquicia = 1) {
                    return redirect()->route('listafranquicia')->with('bien', 'La sucursal se actualizo correctamente.')->with('fcreada', 'Bien!');
                }
                return redirect()->route('listafranquicia')->with('alerta', ' La sucursal se actualizo, pero no se encuentra activa.')->with('fcreada', 'Alerta!');

            } catch (\Exception $e) {
                \Log::error('Error: ' . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al Administrador de la pagina. Error: ' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function usuariosfranquicia($idFranquicia, Request $request)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {

            $ahora = Carbon::now();

            if(Auth::user()->rol_id == 7) {
                //Director
                if($idFranquicia == '00000') {
                    //Franquicia de prueba
                    $usuariosfranquicia = DB::select("SELECT u.id as ID, u.foto AS FOTO, u.name AS NOMBRE,u.email AS CORREO, r.rol AS ROL ,u.renovacion, u.codigoasistencia AS NOCONTROL, uf.id_franquicia as ID_FRANQUICIA, (SELECT ciudad FROM franquicias WHERE id = uf.id_franquicia) as CIUDADFRANQUICIA
                            FROM users u
                            INNER JOIN roles r
                            ON r.id = u.rol_id
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            ORDER BY u.name");
                    $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
                }else {
                    //Otra franquicia diferente a la de prueba
                    $usuariosfranquicia = DB::select("SELECT u.id as ID, u.foto AS FOTO, u.name AS NOMBRE,u.email AS CORREO, r.rol AS ROL ,u.renovacion, u.codigoasistencia AS NOCONTROL, uf.id_franquicia as ID_FRANQUICIA, (SELECT ciudad FROM franquicias WHERE id = uf.id_franquicia) as CIUDADFRANQUICIA
                            FROM users u
                            INNER JOIN roles r
                            ON r.id = u.rol_id
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            WHERE uf.id_franquicia != '00000'
                            ORDER BY CIUDADFRANQUICIA, u.name");
                    $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND  uf.id_franquicia != '00000' AND  STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
                }
            }else {
                //Adiministrador o principal
                $usuariosfranquicia = DB::select("SELECT u.id as ID, u.foto AS FOTO, u.name AS NOMBRE,u.email AS CORREO, r.rol AS ROL ,u.renovacion, u.codigoasistencia AS NOCONTROL, uf.id_franquicia as ID_FRANQUICIA, (SELECT ciudad FROM franquicias WHERE id = uf.id_franquicia) as CIUDADFRANQUICIA
                            FROM users u
                            INNER JOIN roles r
                            ON r.id = u.rol_id
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            WHERE uf.id_franquicia = '$idFranquicia'
                            ORDER BY u.name");
                $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND  uf.id_franquicia= '$idFranquicia' AND  STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
            }

            $franquicia = DB::select("SELECT * FROM franquicias WHERE id='$idFranquicia'");
            $sucursales = DB::select("SELECT id,estado,ciudad,colonia,numero FROM franquicias WHERE id != '00000' ORDER BY ciudad ASC");
            $roles = DB::select("SELECT * FROM roles WHERE id <> 7");
            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia' ORDER BY zona");

            return view('administracion.franquicia.usuarios', ['usuariosfranquicia' => $usuariosfranquicia,
                'franquicia' => $franquicia,
                'roles' => $roles,
                'id' => $idFranquicia,
                'zonas' => $zonas,
                'sucursales' => $sucursales,
                'idFranquicia' => $idFranquicia,
                'totalRenovacion' => $totalRenovacion
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function nuevousuariofranquicia($id, Request $request)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {
            if (!$request->has('usuarioP')) {
                $rol = request()->rol;
                $idsSucursales = array();
                $contador = 0;
                if ($rol == 4 || $rol == 12 || $rol == 13 || $rol == 14) {
                    if ($rol == 4) {
//                        request()->validate([
//                            'nombre' => 'required|string|min:5|max:255',
//                            'correo' => 'email',
//                            'contrasena' => ['required', 'string', 'min:8', 'regex:/[a-z]/', 'regex:/[A-Z]/', 'regex:/[0-9]/'],
//                            'ccontrasena' => 'required|same:contrasena',
//                            'rol' => 'required',
//                            'foto' => 'required|image|mimes:jpg',
//                            'actanacimiento' => 'required|file|mimes:pdf',
//                            'identificacion' => 'required|file|mimes:pdf',
//                            'curp' => 'required|image|mimes:jpg',
//                            'comprobante' => 'required|file|mimes:pdf',
//                            'seguro' => 'required|file|mimes:pdf',
//                            'solicitud' => 'required|file|mimes:pdf',
//                            'tarjetapago' => 'required|image|mimes:jpg',
//                            'otratarjetapago' => 'required|image|mimes:jpg',
//                            'contratolaboral' => 'required|image|mimes:jpg',
//                            'contactoemergencia' => 'required|file|mimes:pdf',
//                            'idzona' => 'required',
//                            'sueldo' => 'required|numeric|gt:0',
//                            'pagare' => 'required|file|mimes:pdf',
//                            'tarjeta' => 'required|string|min:16|max:20',
//                            'otratarjeta' => 'required|string|min:16|max:20'
//                        ]);
                    } else {
                        request()->validate([
                            'nombre' => 'required|string|min:5|max:255',
                            'correo' => 'email',
                            'contrasena' => ['required', 'string', 'min:8', 'regex:/[a-z]/', 'regex:/[A-Z]/', 'regex:/[0-9]/'],
                            'ccontrasena' => 'required|same:contrasena',
                            'rol' => 'required',
                            'foto' => 'required|image|mimes:jpg',
                            'actanacimiento' => 'required|file|mimes:pdf',
                            'identificacion' => 'required|file|mimes:pdf',
                            'curp' => 'required|image|mimes:jpg',
                            'comprobante' => 'required|file|mimes:pdf',
                            'seguro' => 'required|file|mimes:pdf',
                            'solicitud' => 'required|file|mimes:pdf',
                            'contratolaboral' => 'required|file|mimes:jpg',
                            'tarjetapago' => 'required|image|mimes:jpg',
                            'otratarjetapago' => 'required|image|mimes:jpg',
                            'contactoemergencia' => 'required|file|mimes:pdf',
                            'sueldo' => 'required|numeric|gt:0',
                            'pagare' => 'nullable|file|mimes:pdf',
                            'tarjeta' => 'required|string|min:16|max:20',
                            'otratarjeta' => 'required|string|min:16|max:20'
                        ]);
                    }
                } else {
                    request()->validate([
                        'nombre' => 'required|string|min:5|max:255',
                        'correo' => 'email',
                        'contrasena' => ['required', 'string', 'min:8', 'regex:/[a-z]/', 'regex:/[A-Z]/', 'regex:/[0-9]/'],
                        'ccontrasena' => 'required|same:contrasena',
                        'rol' => 'required',
                        'foto' => 'required|image|mimes:jpg',
                        'actanacimiento' => 'required|file|mimes:pdf',
                        'identificacion' => 'required|file|mimes:pdf',
                        'curp' => 'required|image|mimes:jpg',
                        'comprobante' => 'required|file|mimes:pdf',
                        'seguro' => 'required|file|mimes:pdf',
                        'solicitud' => 'required|file|mimes:pdf',
                        'tarjetapago' => 'required|image|mimes:jpg',
                        'otratarjetapago' => 'required|image|mimes:jpg',
                        'contratolaboral' => 'required|image|mimes:jpg',
                        'contactoemergencia' => 'required|file|mimes:pdf',
                        'pagare' => 'nullable|file|mimes:pdf',
                        'tarjeta' => 'required|string|min:16|max:20',
                        'otratarjeta' => 'required|string|min:16|max:20'
                    ]);

                    if ($rol == 15) {
                        $franquicias = DB::select("SELECT id FROM franquicias");
                        foreach ($franquicias as $franquicia) {
                            $franquiciaEntrada = request("$franquicia->id");
                            if (!is_null($franquiciaEntrada) && $franquiciaEntrada > 0) {
                                array_push($idsSucursales, $franquicia->id);
                                $contador++;
                            }
                        }
                        if ($contador == 0) {
                            return back()->with('alerta', 'Debes seleccionar al menos una sucursal')->withInput($request->all());
                        }
                    }
                }

                $correo = request()->correo;
                $existeCorreo = DB::select("SELECT * FROM users WHERE email = '$correo'");
                if ($existeCorreo == null) {
                    try {

                        $total = 0;
                        $usuarios = DB::select("SHOW TABLE STATUS LIKE 'users'");
                        $siguienteId = $usuarios[0]->Auto_increment;


                        $archivosComprimir = [];
                        $foto = "";
                        if (request()->hasFile('foto')) {
                            $fotoBruta = 'Foto-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('foto')->getClientOriginalExtension();
                            $foto = request()->file('foto')->storeAs('uploads/imagenes/usuarios/foto', $fotoBruta, 'disco');
                            $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->height();
                            $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->width();
                            if ($alto > $ancho) {
                                $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->resize(600, 800);
                            } else {
                                $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->resize(800, 600);
                            }
                            $imagenfoto->save();
                        }

                        $actanacimiento = "";
                        if (request()->hasFile('actanacimiento')) {
                            $actanacimientoBruta = 'Actanacimiento-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('actanacimiento')->getClientOriginalExtension();
                            $actanacimiento = request()->file('foto')->storeAs('uploads/imagenes/usuarios', $actanacimientoBruta, 'disco');
                            array_push($archivosComprimir, $actanacimientoBruta);
                        }

                        $identificacion = "";
                        if (request()->hasFile('identificacion')) {
                            $identificacionBruta = 'Identificacion-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('identificacion')->getClientOriginalExtension();
                            $identificacion = request()->file('identificacion')->storeAs('uploads/imagenes/usuarios', $identificacionBruta, 'disco');
                            array_push($archivosComprimir, $identificacionBruta);

                        }

                        $curp = "";
                        if (request()->hasFile('curp')) {
                            $curpBruta = 'Curp-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('curp')->getClientOriginalExtension();
                            $curp = request()->file('curp')->storeAs('uploads/imagenes/usuarios', $curpBruta, 'disco');
                            $alto3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->height();
                            $ancho3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->width();
                            if ($alto3 > $ancho3) {
                                $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->resize(600, 800);
                            } else {
                                $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->resize(800, 600);
                            }
                            $imagencurp->save();
                            array_push($archivosComprimir, $curpBruta);
                        }

                        $comprobante = "";
                        if (request()->hasFile('comprobante')) {
                            $comprobanteBruta = 'Comprobante-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('comprobante')->getClientOriginalExtension();
                            $comprobante = request()->file('comprobante')->storeAs('uploads/imagenes/usuarios', $comprobanteBruta, 'disco');
                            array_push($archivosComprimir, $comprobanteBruta);

                        }

                        $seguro = "";
                        if (request()->hasFile('seguro')) {
                            $seguroBruta = 'Seguro-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('seguro')->getClientOriginalExtension();
                            $seguro = request()->file('seguro')->storeAs('uploads/imagenes/usuarios', $seguroBruta, 'disco');
                            array_push($archivosComprimir, $seguroBruta);

                        }

                        $solicitud = "";
                        if (request()->hasFile('solicitud')) {
                            $solicitudBruta = 'Solicitud-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('solicitud')->getClientOriginalExtension();
                            $solicitud = request()->file('solicitud')->storeAs('uploads/imagenes/usuarios', $solicitudBruta, 'disco');
                            array_push($archivosComprimir, $solicitudBruta);
                        }

                        $tarjetapago = "";
                        if (request()->hasFile('tarjetapago')) {
                            $tarjetapagoBruta = 'Tarjetapago-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('tarjetapago')->getClientOriginalExtension();
                            $tarjetapago = request()->file('tarjetapago')->storeAs('uploads/imagenes/usuarios', $tarjetapagoBruta, 'disco');
                            $alto7 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->height();
                            $ancho7 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->width();
                            if ($alto7 > $ancho7) {
                                $imagentarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->resize(600, 800);
                            } else {
                                $imagentarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->resize(800, 600);
                            }
                            $imagentarjetapago->save();
                            array_push($archivosComprimir, $tarjetapagoBruta);
                        }

                        $contratolaboral = "";
                        if (request()->hasFile('contratolaboral')) {
                            $contratolaboralBruta = 'contratolaboral-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('contratolaboral')->getClientOriginalExtension();
                            $contratolaboral = request()->file('contratolaboral')->storeAs('uploads/imagenes/usuarios', $contratolaboralBruta, 'disco');
                            $alto8 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->height();
                            $ancho8 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->width();
                            if ($alto8 > $ancho8) {
                                $imagencontratolaboral = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->resize(600, 800);
                            } else {
                                $imagencontratolaboral = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->resize(800, 600);
                            }
                            $imagencontratolaboral->save();
                            array_push($archivosComprimir, $contratolaboralBruta);
                        }


                        $contactoemergencia = "";
                        if (request()->hasFile('contactoemergencia')) {
                            $contactoemergenciaBruta = 'Contactoemergencia-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('contactoemergencia')->getClientOriginalExtension();
                            $contactoemergencia = request()->file('contactoemergencia')->storeAs('uploads/imagenes/usuarios', $contactoemergenciaBruta, 'disco');
                            array_push($archivosComprimir, $contactoemergenciaBruta);

                        }

                        $pagare = "";
                        if (request()->hasFile('pagare')) {
                            $pagareBruta = 'Pagare-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                            $pagare = request()->file('pagare')->storeAs('uploads/imagenes/usuarios', $pagareBruta, 'disco');
                            array_push($archivosComprimir, $pagareBruta);
                        }

                        $otratarjetapago = "";
                        if (request()->hasFile('otratarjetapago')) {
                            $otratarjetapagoBruta = 'Otratarjetapago-Usuario-' . $siguienteId . '-' . time() . '.' . request()->file('otratarjetapago')->getClientOriginalExtension();
                            $otratarjetapago = request()->file('otratarjetapago')->storeAs('uploads/imagenes/usuarios', $otratarjetapagoBruta, 'disco');
                            $alto9 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->height();
                            $ancho9 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->width();
                            if ($alto9 > $ancho9) {
                                $imagenotratarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->resize(600, 800);
                            } else {
                                $imagenotratarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->resize(800, 600);
                            }
                            $imagenotratarjetapago->save();
                            array_push($archivosComprimir, $otratarjetapagoBruta);
                        }

                        self::comprimirArchivosUsuarios($siguienteId, $archivosComprimir, 0);


                        $idZona = null;
                        if ($rol == 4) {
                            $idZona = request('idzona');
                        }

                        $fecharenovacion = request('fecharenovacion');
                        $hoy = Carbon::now();
                        if (!is_null($fecharenovacion)) {
                            try {
                                $fecharenovacion = Carbon::parse($fecharenovacion);
                                if ($fecharenovacion <= $hoy) {
                                    return back()->withErrors(['fecharenovacion' => 'Fecha no valida'])->withInput($request->all());
                                }

                            } catch (\Exception $e) {
                                return back()->withErrors(['fecharenovacion' => 'Fecha no valida'])->withInput($request->all());
                            }
                        }

                        $numControl = "";
                        try {
                            $ultimoNumeroControl = DB::select("SELECT codigoasistencia FROM users WHERE codigoasistencia IS NOT NULL ORDER BY id DESC LIMIT 1");
                            \Log::info("ULTIMO NUMERO DE CONTROL:" . $ultimoNumeroControl[0]->codigoasistencia);
                            if ($ultimoNumeroControl[0]->codigoasistencia != null) {
                                $numControl .= $ultimoNumeroControl[0]->codigoasistencia + 1;
                            }
                            \Log::info("NUEVO NUMERO DE CONTROL:" . $numControl);
                        } catch (\Exception $e) {
                            \Log::info("Error:" . $e);
                        }
                        $idUsuario = User::create([
                            'name' => request()->nombre,
                            'email' => request()->correo,
                            'password' => Hash::make(request()->contrasena),
                            'rol_id' => request()->rol,
                            'foto' => $foto,
                            'actanacimiento' => $actanacimiento,
                            'identificacion' => $identificacion,
                            'curp' => $curp,
                            'codigoasistencia' => $numControl,
                            'comprobantedomicilio' => $comprobante,
                            'segurosocial' => $seguro,
                            'solicitud' => $solicitud,
                            'tarjetapago' => $tarjetapago,
                            'otratarjetapago' => $otratarjetapago,
                            'contratolaboral' => $contratolaboral,
                            'contactoemergencia' => $contactoemergencia,
                            'pagare' => $pagare,
                            'id_zona' => $idZona,
                            'sueldo' => request()->sueldo,
                            'renovacion' => $fecharenovacion,
                            'tarjeta' => request()->tarjeta,
                            'otratarjeta' => request()->otratarjeta,
                            'created_at' => $hoy
                        ]);

                        DB::table('usuariosfranquicia')->insert([
                            'id_usuario' => $idUsuario->id, 'id_franquicia' => $id, 'created_at' => Carbon::now()
                        ]);

                        DB::table('franquicias')->where('id', $id)->update([
                            'actualizadopor' => strtoupper(Auth::user()->name), 'updated_at' => Carbon::now()
                        ]);

                        if ($contador > 0 && $rol == 15) {
                            foreach ($idsSucursales as $idSucursal) {
                                DB::table("sucursalesconfirmaciones")->insert([
                                    "id_usuario" => $idUsuario->id, "id_franquicia" => $idSucursal
                                ]);
                            }
                        }

                        //Registrar el usuario en tabla controlentradasalidausuario
                        DB::table("controlentradasalidausuario")->insert([
                            "id_usuario" => $idUsuario->id,
                            "horaini" => "08:10:00", //Horario inicial por default
                            "horafin" => "08:20:00", //Horario final por default
                            "created_at" => Carbon::now()
                        ]);

                        //Guardar contratos en tabla contratostemporalessincronizacion
                        if($rol == 4) {
                            $contratosGlobal = new contratosGlobal;
                            $contratosGlobal::insertarDatosTablaContratosTemporalesSincronizacion($id, $idUsuario->id, $idZona, $rol);
                        }

                        return back()->with('bien', 'El usuario se creo correctamente');

                    } catch (\Exception $e) {
                        \Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());

                    }
                } else {
                    return back()->with('alerta', 'El correo ya se encuentra en uso.')->withInput($request->all());
                }

            } else {

                $idUsuarioP = $request->input('usuarioP');
                $existeUsuario = DB::select("SELECT * FROM users WHERE id = ' $idUsuarioP' ");
                if ($existeUsuario != null) {
                    $existeUsuarioEnFranquicia = DB::select("SELECT * FROM usuariosfranquicia WHERE id_usuario = ' $idUsuarioP' AND id_franquicia = '$id'");
                    if ($existeUsuarioEnFranquicia == null) {
                        try {

                            DB::table('usuariosfranquicia')->insert([
                                'id_usuario' => $idUsuarioP, 'id_franquicia' => $id, 'created_at' => Carbon::now()
                            ]);

                            DB::table('franquicias')->where('id', $id)->update([
                                'actualizadopor' => strtoupper(Auth::user()->name), 'updated_at' => Carbon::now()
                            ]);

                            $idUsuario = $existeUsuario[0]->id;

                            //Crear contratos vacios y actualizar id_franquicia
                            $rolUsuario = $existeUsuario[0]->rol_id;
                            if($rolUsuario == 12 || $rolUsuario == 13) {
                                //Rol es asistente/optometrista

                                $numContratosVacios = DB::select("SELECT COUNT(id) as totalids
                                                        FROM contratos WHERE id_franquicia = '$id' AND id_usuariocreacion = '" . $idUsuario . "' AND datos = '0'");

                                $numContratosACrear = 20 - $numContratosVacios[0]->totalids;
                                if ($numContratosACrear > 0) {
                                    //Se necesita crear mas contratos perzonalizados

                                    $globalesServicioWeb = new globalesServicioWeb;
                                    $nombreUsuario = $existeUsuario[0]->name;

                                    $anoActual = Carbon::now()->format('y'); //Obtener los ultimos 2 digitos del año 21, 22, 23, 24, etc

                                    //Obtener indice de la franquicia
                                    $franquicia = DB::select("SELECT indice FROM franquicias WHERE id = '$id'");
                                    $identificadorFranquicia = "";
                                    if ($franquicia != null) {
                                        //Existe franquicia
                                        $identificadorFranquicia = $globalesServicioWeb::obtenerIdentificadorFranquicia($franquicia[0]->indice);
                                    }
                                    $identificadorFranquicia = $anoActual . $identificadorFranquicia; //Seria el identificadorFranquicia completo = 22001, 22002, 22003, etc

                                    //Obtener el ultimo id generado en la tabla de contrato
                                    $contratoSelect = DB::select("SELECT id FROM contratos WHERE id_franquicia = '$id' AND id LIKE '%$identificadorFranquicia%' ORDER BY id DESC LIMIT 1");
                                    if ($contratoSelect != null) {
                                        //Existe registro (Significa que ya hay contratos personalizados creados)
                                        $idContrato = substr($contratoSelect[0]->id, -5);
                                        $ultimoIdContratoPerzonalizado = $idContrato;
                                    }else {
                                        //Sera el primer contrato perzonalizado a crear de la sucursal
                                        $ultimoIdContratoPerzonalizado = 0;
                                    }

                                    //Recorrido de contratos a crear
                                    for ($i = 0; $i < $numContratosACrear; $i++) {
                                        $arrayRespuesta = $globalesServicioWeb::generarIdContratoPersonalizado($identificadorFranquicia, $ultimoIdContratoPerzonalizado);
                                        DB::table("contratos")->insert(["id" => $arrayRespuesta[0], "id_franquicia" => $id, "id_usuariocreacion" => $idUsuario,
                                            "nombre_usuariocreacion" => $nombreUsuario, "poliza" => null]);
                                        $ultimoIdContratoPerzonalizado = $arrayRespuesta[1] + 1;
                                    }

                                }

                            }

                            //Actualizar fechaeliminacion en null
                            DB::table('users')->where('id', $idUsuario)->update([
                                'fechaeliminacion' => null
                            ]);

                            //Guardar contratos en tabla contratostemporalessincronizacion
                            if($rolUsuario == 4) {
                                $contratosGlobal = new contratosGlobal;
                                $contratosGlobal::insertarDatosTablaContratosTemporalesSincronizacion($id, $existeUsuario[0]->id, $existeUsuario[0]->id_zona, $rolUsuario);
                            }

                            return redirect()->route('editarUsuarioFranquicia', [$id, $idUsuarioP])->with('bien', 'El usuario se agrego correctamente');

                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e->getMessage());
                            return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                        }
                    }
                    return back()->with('alerta', 'El usuario ya esta asignado a esta franquicia');
                }
                return back()->with('alerta', 'No se encontro el usuario');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function eliminarsuariofranquicia($idfranquiciaactual, $idfranquicia, $usuario)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {
            try {
                $existeFranquicia = DB::select("SELECT * FROM franquicias WHERE id = '$idfranquicia'");
                if ($existeFranquicia != null) {
                    $existeUsuario = DB::select("SELECT * FROM users WHERE id = ' $usuario' ");
                    if ($existeUsuario != null) {
                        $existeUsuarioEnFranquicia = DB::select("SELECT * FROM usuariosfranquicia WHERE id_usuario = ' $usuario' AND id_franquicia = '$idfranquicia'");
                        if ($existeUsuarioEnFranquicia != null) {

                            DB::delete("DELETE FROM usuariosfranquicia WHERE id_usuario = '$usuario' AND id_franquicia = '$idfranquicia'");
                            DB::delete("DELETE FROM dispositivosusuarios WHERE id_usuario = '$usuario'");
                            DB::delete("DELETE FROM tokenlolatv WHERE usuario_id = '$usuario'");

                            //Agregar fechaeliminacion del usuario
                            DB::table('users')->where('id', $usuario)->update([
                                'fechaeliminacion' => Carbon::now()
                            ]);

                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idUsuario
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id_usuario = '$usuario'");

                            return redirect()->route('usuariosFranquicia', $idfranquiciaactual)->with('bien', 'El usuario se elimino correctamente de la franquicia');
                        }
                        return redirect()->route('usuariosFranquicia', $idfranquiciaactual)->with('alerta', 'No se encontro el usuario dentro de la franquicia');
                    }
                    return redirect()->route('usuariosFranquicia', $idfranquiciaactual)->with('alerta', 'No se encontro el usuario');
                }
                return redirect()->route('usuariosFranquicia', $idfranquiciaactual)->with('alerta', 'No se encontro la franquicia');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return redirect()->route('usuariosFranquicia', $idfranquiciaactual)->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function editarsuariofranquicia($idFranquicia, $idusuario)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {
            try {
                $existeFranquicia = DB::select("SELECT * FROM franquicias WHERE id = '$idFranquicia'");
                if ($existeFranquicia != null) {
                    $existeUsuario = DB::select("SELECT id,rol_id,name,email,foto,actanacimiento,identificacion,curp,comprobantedomicilio,segurosocial,solicitud,
                                                                tarjetapago,otratarjetapago,contratolaboral,contactoemergencia,id_zona,sueldo,codigoasistencia,renovacion,pagare,tarjeta,otratarjeta
                                                                FROM users WHERE id = ' $idusuario' ");
                    if ($existeUsuario != null) {
                        $existeUsuarioEnFranquicia = DB::select("SELECT * FROM usuariosfranquicia WHERE id_usuario = ' $idusuario' AND id_franquicia = '$idFranquicia'");
                        if ($existeUsuarioEnFranquicia != null) {
                            $roles = DB::select("SELECT * FROM roles");
                            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia' ORDER BY zona");
                            $dispositivosusuario = DB::select("SELECT * FROM dispositivosusuarios WHERE id_usuario = '$idusuario'");
                            $sucursales = DB::select("SELECT id,estado,ciudad,colonia,numero FROM franquicias");
                            $sucursalesSeleccionadas = DB::select("SELECT id_franquicia FROM sucursalesconfirmaciones WHERE id_usuario = '$idusuario'");
                            $controlentradasalidausuario = DB::select("SELECT horaini, horafin FROM controlentradasalidausuario WHERE id_usuario = '$idusuario'");
                            if($controlentradasalidausuario != null) {
                                //Existe usuario en tabla controlentradasalidausuario
                                $existeUsuario[0]->horaini = $controlentradasalidausuario[0]->horaini;
                                $existeUsuario[0]->horafin = $controlentradasalidausuario[0]->horafin;
                            }
                            return view('administracion.franquicia.editarusuario', ['idFranquicia' => $idFranquicia, 'id' => $idFranquicia, 'idusuario' => $idusuario, 'usuario' => $existeUsuario, 'roles' => $roles, 'zonas' => $zonas, 'dispositivosusuario' => $dispositivosusuario, "sucursalesSeleccionadas" => $sucursalesSeleccionadas, "sucursales" => $sucursales]);
                        }
                        return back()->with('alerta', 'No se encontro el usuario dentro de la franquicia');
                    }
                    return back()->with('alerta', 'No se encontro el usuario');
                }
                return back()->with('alerta', 'No se encontro la franquicia');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarsuariofranquicia($idFranquicia, $idUsuario, Request $request)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {

            $correo = request()->correo;
            $existeCorreo = DB::select("SELECT * FROM users WHERE id <> '$idUsuario' AND email = '$correo'");
            if ($existeCorreo != null) {
                return back()->with('alerta', 'El correo ya se encuentra en uso.');
            }

            $usuario = DB::select("SELECT * FROM users WHERE id = '$idUsuario'");
            $rol = request('rol');
            if ($rol == 12 || $rol == 13 || $rol == 14) {

                $fotoBool = false;
                if (strlen(request()->foto) > 0) {
                    if (strlen($usuario[0]->foto) > 0) {
                        $fotoBool = true;
                    }
                } else {
                    $fotoBool = true;
                }

                $actanacimientoBool = false;
                if (strlen(request()->actanacimiento) == 0) {
                    if (strlen($usuario[0]->actanacimiento) > 0) {
                        $actanacimientoBool = true;
                    }
                } else {
                    $actanacimientoBool = true;
                }

                $identificacionBool = false;
                if (strlen(request()->identificacion) == 0) {
                    if (strlen($usuario[0]->identificacion) > 0) {
                        $identificacionBool = true;
                    }
                } else {
                    $identificacionBool = true;
                }

                $curpBool = false;
                if (strlen(request()->curp) == 0) {
                    if (strlen($usuario[0]->curp) > 0) {
                        $curpBool = true;
                    }
                } else {
                    $curpBool = true;
                }

                $comprobanteBool = false;
                if (strlen(request()->comprobante) == 0) {
                    if (strlen($usuario[0]->comprobantedomicilio) > 0) {
                        $comprobanteBool = true;
                    }
                } else {
                    $comprobanteBool = true;
                }

                $seguroBool = false;
                if (strlen(request()->seguro) == 0) {
                    if (strlen($usuario[0]->segurosocial) > 0) {
                        $seguroBool = true;
                    }
                } else {
                    $seguroBool = true;
                }

                $solicitudBool = false;
                if (strlen(request()->solicitud) == 0) {
                    if (strlen($usuario[0]->solicitud) > 0) {
                        $solicitudBool = true;
                    }
                } else {
                    $solicitudBool = true;
                }

                $tarjetapagoBool = false;
                if (strlen(request()->tarjetapago) == 0) {
                    if (strlen($usuario[0]->tarjetapago) > 0) {
                        $tarjetapagoBool = true;
                    }
                } else {
                    $tarjetapagoBool = true;
                }

                $otratarjetapagoBool = false;
                if (strlen(request()->otratarjetapago) == 0) {
                    if (strlen($usuario[0]->otratarjetapago) > 0) {
                        $otratarjetapagoBool = true;
                    }
                } else {
                    $otratarjetapagoBool = true;
                }

                $contratolaboralBool = false;
                if (strlen(request()->contratolaboral) == 0) {
                    if (strlen($usuario[0]->contratolaboral) > 0) {
                        $contratolaboralBool = true;
                    }
                } else {
                    $contratolaboralBool = true;
                }

                $contactoemergenciaBool = false;
                if (strlen(request()->contactoemergencia) == 0) {
                    if (strlen($usuario[0]->contactoemergencia) > 0) {
                        $contactoemergenciaBool = true;
                    }
                } else {
                    $contactoemergenciaBool = true;
                }

                if (!$fotoBool || !$actanacimientoBool || !$identificacionBool || !$curpBool || !$comprobanteBool
                    || !$seguroBool || !$solicitudBool || !$tarjetapagoBool || !$otratarjetapagoBool || !$contratolaboralBool || !$contactoemergenciaBool) {
                    return back()->with('alerta', 'Para el rol seleccionado es necesario ingresar todos los documentos.');
                }
            }

            $contador = 0;
            $idsSucursales = array();
            if ($rol == 15) {
                $franquicias = DB::select("SELECT id FROM franquicias");
                foreach ($franquicias as $franquicia) {
                    $franquiciaEntrada = request("$franquicia->id");
                    if (!is_null($franquiciaEntrada) && $franquiciaEntrada > 0) {
                        array_push($idsSucursales, $franquicia->id);
                        $contador++;
                    }
                }
                if ($contador == 0) {
                    return back()->with('alerta', 'Debes seleccionar al menos una sucursal')->withInput($request->all());
                }
            }

            if (strlen(request()->contrasena) > 0) {
                if ($rol == 4) {
                    request()->validate([
                        'nombre' => 'required|string|min:5|max:255',
                        'correo' => 'email',
                        'contrasena' => ['required', 'string', 'min:8', 'regex:/[a-z]/', 'regex:/[A-Z]/', 'regex:/[0-9]/'],
                        'ccontrasena' => 'required|same:contrasena',
                        'rol' => 'required',
                        'idzona' => 'required',
                        'sueldo' => 'numeric|nullable',
                        'tarjeta' => 'required|string|min:16|max:20',
                        'otratarjeta' => 'required|string|min:16|max:20'
                    ]);
                } else {
                    request()->validate([
                        'nombre' => 'required|string|min:5|max:255',
                        'correo' => 'email',
                        'contrasena' => ['required', 'string', 'min:8', 'regex:/[a-z]/', 'regex:/[A-Z]/', 'regex:/[0-9]/'],
                        'ccontrasena' => 'required|same:contrasena',
                        'rol' => 'required',
                        'sueldo' => 'numeric|nullable',
                        'tarjeta' => 'required|string|min:16|max:20',
                        'otratarjeta' => 'required|string|min:16|max:20'
                    ]);
                }

                $archivosComprimir = [];
                $foto = "";
                if (strlen(request()->foto) == 0) {
                    if (strlen($usuario[0]->foto) > 0) {
                        $foto = $usuario[0]->foto;
                    }
                } else {
                    if (request()->hasFile('foto')) {
                        $fotoBruta = 'Foto-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('foto')->getClientOriginalExtension();
                        $foto = request()->file('foto')->storeAs('uploads/imagenes/usuarios/foto', $fotoBruta, 'disco');
                        $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->height();
                        $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->width();
                        if ($alto > $ancho) {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->resize(600, 800);
                        } else {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->resize(800, 600);
                        }
                        $imagenfoto->save();
                    }
                }
                $actanacimiento = "";
                if (strlen(request()->actanacimiento) == 0) {
                    if (strlen($usuario[0]->actanacimiento) > 0) {
                        $actanacimiento = $usuario[0]->actanacimiento;
                    }
                } else {
                    if (request()->hasFile('actanacimiento')) {
                        $actanacimientoBruta = 'Actanacimiento-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('actanacimiento')->getClientOriginalExtension();
                        $actanacimiento = request()->file('foto')->storeAs('uploads/imagenes/usuarios', $actanacimientoBruta, 'disco');
                        array_push($archivosComprimir, $actanacimientoBruta);

                    }
                }
                $identificacion = "";
                if (strlen(request()->identificacion) == 0) {
                    if (strlen($usuario[0]->identificacion) > 0) {
                        $identificacion = $usuario[0]->identificacion;
                    }
                } else {
                    if (request()->hasFile('identificacion')) {
                        $identificacionBruta = 'Identificacion-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('identificacion')->getClientOriginalExtension();
                        $identificacion = request()->file('identificacion')->storeAs('uploads/imagenes/usuarios', $identificacionBruta, 'disco');
                        array_push($archivosComprimir, $identificacionBruta);

                    }
                }
                $curp = "";
                if (strlen(request()->curp) == 0) {
                    if (strlen($usuario[0]->curp) > 0) {
                        $curp = $usuario[0]->curp;
                    }
                } else {
                    if (request()->hasFile('curp')) {
                        $curpBruta = 'Curp-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('curp')->getClientOriginalExtension();
                        $curp = request()->file('curp')->storeAs('uploads/imagenes/usuarios', $curpBruta, 'disco');
                        array_push($archivosComprimir, $curpBruta);

                    }
                }
                $comprobante = "";
                if (strlen(request()->comprobante) == 0) {
                    if (strlen($usuario[0]->comprobantedomicilio) > 0) {
                        $comprobante = $usuario[0]->comprobantedomicilio;
                    }
                } else {
                    if (request()->hasFile('comprobante')) {
                        $comprobanteBruta = 'Comprobante-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('comprobante')->getClientOriginalExtension();
                        $comprobante = request()->file('comprobante')->storeAs('uploads/imagenes/usuarios', $comprobanteBruta, 'disco');
                        array_push($archivosComprimir, $comprobanteBruta);

                    }
                }
                $seguro = "";
                if (strlen(request()->seguro) == 0) {
                    if (strlen($usuario[0]->segurosocial) > 0) {
                        $seguro = $usuario[0]->segurosocial;
                    }
                } else {
                    if (request()->hasFile('seguro')) {
                        $seguroBruta = 'Seguro-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('seguro')->getClientOriginalExtension();
                        $seguro = request()->file('seguro')->storeAs('uploads/imagenes/usuarios', $seguroBruta, 'disco');
                        array_push($archivosComprimir, $seguroBruta);

                    }
                }
                $solicitud = "";
                if (strlen(request()->solicitud) == 0) {
                    if (strlen($usuario[0]->solicitud) > 0) {
                        $solicitud = $usuario[0]->solicitud;
                    }
                } else {
                    if (request()->hasFile('solicitud')) {
                        $solicitudBruta = 'Solicitud-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('solicitud')->getClientOriginalExtension();
                        $solicitud = request()->file('solicitud')->storeAs('uploads/imagenes/usuarios', $solicitudBruta, 'disco');
                        array_push($archivosComprimir, $solicitudBruta);

                    }
                }
                $tarjetapago = "";
                if (strlen(request()->tarjetapago) == 0) {
                    if (strlen($usuario[0]->tarjetapago) > 0) {
                        $tarjetapago = $usuario[0]->tarjetapago;
                    }
                } else {
                    if (request()->hasFile('tarjetapago')) {
                        $tarjetapagoBruta = 'Tarjetapago-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('tarjetapago')->getClientOriginalExtension();
                        $tarjetapago = request()->file('tarjetapago')->storeAs('uploads/imagenes/usuarios', $tarjetapagoBruta, 'disco');
                        $alto7 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->height();
                        $ancho7 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->width();
                        if ($alto7 > $ancho7) {
                            $imagentarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->resize(600, 800);
                        } else {
                            $imagentarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->resize(800, 600);
                        }
                        $imagentarjetapago->save();
                    }
                    array_push($archivosComprimir, $tarjetapagoBruta);
                }

                $otratarjetapago = "";
                if (strlen(request()->otratarjetapago) == 0) {
                    if (strlen($usuario[0]->otratarjetapago) > 0) {
                        $otratarjetapago = $usuario[0]->otratarjetapago;
                    }
                } else {
                    if (request()->hasFile('otratarjetapago')) {
                        $otratarjetapagoBruta = 'Otratarjetapago-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('otratarjetapago')->getClientOriginalExtension();
                        $otratarjetapago = request()->file('otratarjetapago')->storeAs('uploads/imagenes/usuarios', $otratarjetapagoBruta, 'disco');
                        $alto9 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->height();
                        $ancho9 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->width();
                        if ($alto9 > $ancho9) {
                            $imagenotratarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->resize(600, 800);
                        } else {
                            $imagenotratarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->resize(800, 600);
                        }
                        $imagenotratarjetapago->save();
                    }
                    array_push($archivosComprimir, $otratarjetapagoBruta);
                }

                $contratolaboral = "";
                if (strlen(request()->contratolaboral) == 0) {
                    if (strlen($usuario[0]->contratolaboral) > 0) {
                        $contratolaboral = $usuario[0]->contratolaboral;
                    }
                } else {
                    if (request()->hasFile('contratolaboral')) {
                        $contratolaboralBruta = 'contratolaboral-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('contratolaboral')->getClientOriginalExtension();
                        $contratolaboral = request()->file('contratolaboral')->storeAs('uploads/imagenes/usuarios', $contratolaboralBruta, 'disco');
                        $alto8 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->height();
                        $ancho8 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->width();
                        if ($alto8 > $ancho8) {
                            $imagencontratolaboral = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->resize(600, 800);
                        } else {
                            $imagencontratolaboral = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->resize(800, 600);
                        }
                        $imagencontratolaboral->save();
                    }
                    array_push($archivosComprimir, $contratolaboralBruta);
                }
                $contactoemergencia = "";
                if (strlen(request()->contactoemergencia) == 0) {
                    if (strlen($usuario[0]->contactoemergencia) > 0) {
                        $contactoemergencia = $usuario[0]->contactoemergencia;
                    }
                } else {
                    if (request()->hasFile('contactoemergencia')) {
                        $contactoemergenciaBruta = 'Contactoemergencia-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('contactoemergencia')->getClientOriginalExtension();
                        $contactoemergencia = request()->file('contactoemergencia')->storeAs('uploads/imagenes/usuarios', $contactoemergenciaBruta, 'disco');
                        array_push($archivosComprimir, $contactoemergenciaBruta);

                    }
                }

                $pagare = "";
                if (strlen(request()->pagare) == 0) {
                    if (strlen($usuario[0]->pagare) > 0) {
                        $pagare = $usuario[0]->pagare;
                    }
                } else {
                    if (request()->hasFile('pagare')) {
                        $pagareBruta = 'Pagare-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $pagare = request()->file('pagare')->storeAs('uploads/imagenes/usuarios', $pagareBruta, 'disco');
                        array_push($archivosComprimir, $pagareBruta);

                    }
                }

                self::comprimirArchivosUsuarios($idUsuario, $archivosComprimir, 1);

                $sueldo = $usuario[0]->sueldo;
                if (request('sueldo') != null) {
                    if (strlen(request('sueldo')) > 0) {
                        $sueldo = request('sueldo');
                    }
                }

                $idZona = null;
                if ($rol == 4) {
                    $idZona = request('idzona');

                    //Guardar contratos en tabla contratostemporalessincronizacion y eliminar los anteriores
                    if($usuario[0]->id_zona != $idZona) {
                        //Se cambio la zona
                        if($usuario[0]->logueado == 0) {
                            //Ya se encuentra cerrada la sesion
                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idUsuario
                            DB::delete("DELETE FROM contratostemporalessincronizacion where id_usuario = '$idUsuario'");
                            $contratosGlobal = new contratosGlobal;
                            $contratosGlobal::insertarDatosTablaContratosTemporalesSincronizacion($idFranquicia, $idUsuario, $idZona, $rol);
                        }else {
                            //No se ha cerrado sesion
                            return back()->with('alerta', "Para cambiar de zona es necesario que " . $usuario[0]->name . " cierre sesión");
                        }
                    }

                }

                $fechaRenovacion = request('fecharenovacion');
                $sinRenovacion = request('sinrenovacion');

                if ($fechaRenovacion != null) {
                    if ($sinRenovacion != null) {
                        $fechaRenovacion = null;
                    }
                }

                $hoy = Carbon::now();
                if (!is_null($fechaRenovacion)) {
                    try {
                        $fechaRenovacion = Carbon::parse($fechaRenovacion);
                        if ($fechaRenovacion <= $hoy) {
                            return back()->withErrors(['fecharenovacion' => 'Fecha no valida'])->withInput($request->all());
                        }

                    } catch (\Exception $e) {
                        return back()->withErrors(['fecharenovacion' => 'Fecha no valida'])->withInput($request->all());
                    }
                }

                DB::table('users')->where('id', $idUsuario)->update([
                    'password' => Hash::make(request()->contrasena), 'rol_id' => request()->rol, 'email' => request()->correo, 'name' => request()->nombre, 'foto' => $foto, 'actanacimiento' => $actanacimiento,
                    'identificacion' => $identificacion, 'curp' => $curp, 'comprobantedomicilio' => $comprobante, 'segurosocial' => $seguro, 'solicitud' => $solicitud, 'tarjetapago' => $tarjetapago, 'otratarjetapago' => $otratarjetapago, 'contratolaboral' => $contratolaboral,
                    'contactoemergencia' => $contactoemergencia, 'updated_at' => Carbon::now(), 'id_zona' => $idZona, 'sueldo' => $sueldo, 'renovacion' => $fechaRenovacion,'tarjeta'=>request()->tarjeta,'otratarjeta'=>request()->otratarjeta,'pagare'=>$pagare
                ]);
                if ($contador > 0 && $rol == 15) {
                    DB::delete("DELETE FROM sucursalesconfirmaciones WHERE id_usuario = '$idUsuario'");
                    foreach ($idsSucursales as $idSucursal) {
                        DB::table("sucursalesconfirmaciones")->insert([
                            "id_usuario" => $idUsuario->id, "id_franquicia" => $idSucursal
                        ]);
                    }
                }

                return back()->with('bien', 'Los datos del usuario se actualizaron correctamente');

            } else {

                if ($rol == 4) {
                    request()->validate([
                        'nombre' => 'required|string|min:5|max:255',
                        'correo' => 'email',
                        'rol' => 'required',
                        'idzona' => 'required',
                        'sueldo' => 'numeric|nullable',
                        'tarjeta' => 'required|string|min:16|max:20',
                        'otratarjeta' => 'required|string|min:16|max:20'
                    ]);
                } else {
                    request()->validate([
                        'nombre' => 'required|string|min:5|max:255',
                        'correo' => 'email',
                        'rol' => 'required',
                        'sueldo' => 'numeric|nullable',
                        'tarjeta' => 'required|string|min:16|max:20',
                        'otratarjeta' => 'required|string|min:16|max:20'
                    ]);
                }


                $archivosComprimir = [];
                $foto = "";
                if (strlen(request()->foto) == 0) {
                    if (strlen($usuario[0]->foto) > 0) {
                        $foto = $usuario[0]->foto;
                    }
                } else {
                    if (request()->hasFile('foto')) {
                        $fotoBruta = 'Foto-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('foto')->getClientOriginalExtension();
                        $foto = request()->file('foto')->storeAs('uploads/imagenes/usuarios/foto', $fotoBruta, 'disco');
                        $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->height();
                        $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->width();
                        if ($alto > $ancho) {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->resize(600, 800);
                        } else {
                            $imagenfoto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/foto/' . $fotoBruta)->resize(800, 600);
                        }
                        $imagenfoto->save();
                    }
                }
                $actanacimiento = "";
                if (strlen(request()->actanacimiento) == 0) {
                    if (strlen($usuario[0]->actanacimiento) > 0) {
                        $actanacimiento = $usuario[0]->actanacimiento;
                    }
                } else {
                    if (request()->hasFile('actanacimiento')) {
                        $actanacimientoBruta = 'Actanacimiento-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('actanacimiento')->getClientOriginalExtension();
                        $actanacimiento = request()->file('actanacimiento')->storeAs('uploads/imagenes/usuarios', $actanacimientoBruta, 'disco');
                        array_push($archivosComprimir,$actanacimientoBruta);

                    }
                }
                $identificacion = "";
                if (strlen(request()->identificacion) == 0) {
                    if (strlen($usuario[0]->identificacion) > 0) {
                        $identificacion = $usuario[0]->identificacion;
                    }
                } else {
                    if (request()->hasFile('identificacion')) {
                        $identificacionBruta = 'Identificacion-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('identificacion')->getClientOriginalExtension();
                        $identificacion = request()->file('identificacion')->storeAs('uploads/imagenes/usuarios', $identificacionBruta, 'disco');
                        array_push($archivosComprimir,$identificacionBruta);

                    }
                }
                $curp = "";
                if (strlen(request()->curp) == 0) {
                    if (strlen($usuario[0]->curp) > 0) {
                        $curp = $usuario[0]->curp;
                    }
                } else {
                    if (request()->hasFile('curp')) {
                        $curpBruta = 'Curp-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('curp')->getClientOriginalExtension();
                        $curp = request()->file('curp')->storeAs('uploads/imagenes/usuarios', $curpBruta, 'disco');
                        $alto3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->height();
                        $ancho3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->width();
                        if ($alto3 > $ancho3) {
                            $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->resize(600, 800);
                        } else {
                            $imagencurp = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $curpBruta)->resize(800, 600);
                        }
                        $imagencurp->save();
                    }
                    array_push($archivosComprimir,$curpBruta);
                }
                $comprobante = "";
                if (strlen(request()->comprobante) == 0) {
                    if (strlen($usuario[0]->comprobantedomicilio) > 0) {
                        $comprobante = $usuario[0]->comprobantedomicilio;
                    }
                } else {
                    if (request()->hasFile('comprobante')) {
                        $comprobanteBruta = 'Comprobante-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('comprobante')->getClientOriginalExtension();
                        $comprobante = request()->file('comprobante')->storeAs('uploads/imagenes/usuarios', $comprobanteBruta, 'disco');
                        array_push($archivosComprimir,$comprobanteBruta);

                    }
                }
                $seguro = "";
                if (strlen(request()->seguro) == 0) {
                    if (strlen($usuario[0]->segurosocial) > 0) {
                        $seguro = $usuario[0]->segurosocial;
                    }
                } else {
                    if (request()->hasFile('seguro')) {
                        $seguroBruta = 'Seguro-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('seguro')->getClientOriginalExtension();
                        $seguro = request()->file('seguro')->storeAs('uploads/imagenes/usuarios', $seguroBruta, 'disco');
                        array_push($archivosComprimir,$seguroBruta);

                    }
                }
                $solicitud = "";
                if (strlen(request()->solicitud) == 0) {
                    if (strlen($usuario[0]->solicitud) > 0) {
                        $solicitud = $usuario[0]->solicitud;
                    }
                } else {
                    if (request()->hasFile('solicitud')) {
                        $solicitudBruta = 'Solicitud-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('solicitud')->getClientOriginalExtension();
                        $solicitud = request()->file('solicitud')->storeAs('uploads/imagenes/usuarios', $solicitudBruta, 'disco');
                        array_push($archivosComprimir,$solicitudBruta);

                    }
                }
                $tarjetapago = "";
                if (strlen(request()->tarjetapago) == 0) {
                    if (strlen($usuario[0]->tarjetapago) > 0) {
                        $tarjetapago = $usuario[0]->tarjetapago;
                    }
                } else {
                    if (request()->hasFile('tarjetapago')) {
                        $tarjetapagoBruta = 'Tarjetapago-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('tarjetapago')->getClientOriginalExtension();
                        $tarjetapago = request()->file('tarjetapago')->storeAs('uploads/imagenes/usuarios', $tarjetapagoBruta, 'disco');
                        $alto7 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->height();
                        $ancho7 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->width();
                        if ($alto7 > $ancho7) {
                            $imagentarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->resize(600, 800);
                        } else {
                            $imagentarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $tarjetapagoBruta)->resize(800, 600);
                        }
                        $imagentarjetapago->save();
                    }
                    array_push($archivosComprimir,$tarjetapagoBruta);
                }
                $otratarjetapago = "";
                if (strlen(request()->otratarjetapago) == 0) {
                    if (strlen($usuario[0]->otratarjetapago) > 0) {
                        $otratarjetapago = $usuario[0]->otratarjetapago;
                    }
                } else {
                    if (request()->hasFile('otratarjetapago')) {
                        $otratarjetapagoBruta = 'Otratarjetapago-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('otratarjetapago')->getClientOriginalExtension();
                        $otratarjetapago = request()->file('otratarjetapago')->storeAs('uploads/imagenes/usuarios', $otratarjetapagoBruta, 'disco');
                        $alto9 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->height();
                        $ancho9 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->width();
                        if ($alto9 > $ancho9) {
                            $imagenotratarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->resize(600, 800);
                        } else {
                            $imagenotratarjetapago = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $otratarjetapagoBruta)->resize(800, 600);
                        }
                        $imagenotratarjetapago->save();
                    }
                    array_push($archivosComprimir,$otratarjetapagoBruta);
                }
                $contratolaboral = "";
                if (strlen(request()->contratolaboral) == 0) {
                    if (strlen($usuario[0]->contratolaboral) > 0) {
                        $contratolaboral = $usuario[0]->contratolaboral;
                    }
                } else {
                    if (request()->hasFile('contratolaboral')) {
                        $contratolaboralBruta = 'contratolaboral-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('contratolaboral')->getClientOriginalExtension();
                        $contratolaboral = request()->file('contratolaboral')->storeAs('uploads/imagenes/usuarios', $contratolaboralBruta, 'disco');
                        $alto8 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->height();
                        $ancho8 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->width();
                        if ($alto8 > $ancho8) {
                            $imagencontratolaboral = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->resize(600, 800);
                        } else {
                            $imagencontratolaboral = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $contratolaboralBruta)->resize(800, 600);
                        }
                        $imagencontratolaboral->save();
                    }
                    array_push($archivosComprimir,$contratolaboralBruta);
                }
                $contactoemergencia = "";
                if (strlen(request()->contactoemergencia) == 0) {
                    if (strlen($usuario[0]->contactoemergencia) > 0) {
                        $contactoemergencia = $usuario[0]->contactoemergencia;
                    }
                } else {
                    if (request()->hasFile('contactoemergencia')) {
                        $contactoemergenciaBruta = 'Contactoemergencia-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('contactoemergencia')->getClientOriginalExtension();
                        $contactoemergencia = request()->file('contactoemergencia')->storeAs('uploads/imagenes/usuarios', $contactoemergenciaBruta, 'disco');
                        array_push($archivosComprimir,$contactoemergenciaBruta);

                    }
                }

                $pagare = "";
                if (strlen(request()->pagare) == 0) {
                    if (strlen($usuario[0]->pagare) > 0) {
                        $pagare = $usuario[0]->pagare;
                    }
                } else {
                    if (request()->hasFile('pagare')) {
                        $pagareBruta = 'Pagare-Usuario-' . $idUsuario . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $pagare = request()->file('pagare')->storeAs('uploads/imagenes/usuarios', $pagareBruta, 'disco');
                        array_push($archivosComprimir,$pagareBruta);
                    }
                }

                self::comprimirArchivosUsuarios($idUsuario, $archivosComprimir, 1);

                $sueldo = $usuario[0]->sueldo;
                if (request('sueldo') != null) {
                    if (strlen(request('sueldo')) > 0) {
                        $sueldo = request('sueldo');
                    }
                }

                $idZona = null;
                if ($rol == 4) {
                    $idZona = request('idzona');

                    //Guardar contratos en tabla contratostemporalessincronizacion y eliminar los anteriores
                    if($usuario[0]->id_zona != $idZona) {
                        //Se cambio la zona
                        if($usuario[0]->logueado == 0) {
                            //Ya se encuentra cerrada la sesion
                            DB::delete("DELETE FROM contratostemporalessincronizacion where id_usuario = '$idUsuario'"); //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idUsuario
                            $contratosGlobal = new contratosGlobal;
                            $contratosGlobal::insertarDatosTablaContratosTemporalesSincronizacion($idFranquicia, $idUsuario, $idZona, $rol);
                        }else {
                            //No se ha cerrado sesion
                            return back()->with('alerta', "Para cambiar de zona es necesario que " . $usuario[0]->name . " cierre sesión");
                        }
                    }

                }

                $fechaRenovacion = request('fecharenovacion');
                $sinRenovacion = request('sinrenovacion');

                if ($fechaRenovacion != null) {
                    if ($sinRenovacion != null) {
                        $fechaRenovacion = null;
                    }
                }

                $hoy = Carbon::now();
                if (!is_null($fechaRenovacion)) {
                    try {
                        $fechaRenovacion = Carbon::parse($fechaRenovacion);
                        if ($fechaRenovacion <= $hoy) {
                            return back()->withErrors(['fecharenovacion' => 'Fecha no valida'])->withInput($request->all());
                        }

                    } catch (\Exception $e) {
                        return back()->withErrors(['fecharenovacion' => 'Fecha no valida'])->withInput($request->all());
                    }
                }



                DB::table('users')->where('id', $idUsuario)->update([
                    'rol_id' => request()->rol, 'name' => request()->nombre, 'email' => request()->correo, 'foto' => $foto, 'actanacimiento' => $actanacimiento,
                    'identificacion' => $identificacion, 'curp' => $curp, 'comprobantedomicilio' => $comprobante, 'segurosocial' => $seguro, 'solicitud' => $solicitud, 'tarjetapago' => $tarjetapago, 'otratarjetapago' => $otratarjetapago, 'contratolaboral' => $contratolaboral,
                    'contactoemergencia' => $contactoemergencia, 'updated_at' => Carbon::now(), 'id_zona' => $idZona, 'sueldo' => $sueldo, 'renovacion' => $fechaRenovacion,'tarjeta'=>request('tarjeta'),'otratarjeta'=>request('otratarjeta'),'pagare'=> $pagare
                ]);

                DB::delete("DELETE FROM sucursalesconfirmaciones WHERE id_usuario = '$idUsuario'");
                if ($contador > 0 && $rol == 15) {
                    foreach ($idsSucursales as $idSucursal) {
                        DB::table("sucursalesconfirmaciones")->insert([
                            "id_usuario" => $idUsuario, "id_franquicia" => $idSucursal
                        ]);
                    }
                }

                return back()->with('bien', 'Los datos del usuario se actualizaron correctamente');
            }
            return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function actualizarsuariofranquiciadispositivo($idFranquicia, $idUsuario, $idDispositivo)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {
            $dispositivo = DB::select("SELECT estatus FROM dispositivosusuarios WHERE id_usuario = '$idUsuario' AND id = '$idDispositivo'");
            if($dispositivo != null){//Existe el dispositivo
                $estatus = 0;
                DB::table('dispositivosusuarios')->where('id_usuario', '=', $idUsuario)->update(['estatus' => $estatus]); //Desactivamos todos los dispositivos
                if($dispositivo[0]->estatus == 0){
                    $estatus = 1;
                }
                DB::update("UPDATE dispositivosusuarios SET estatus =  '$estatus' WHERE id_usuario = '$idUsuario' AND id = '$idDispositivo'");
                if($estatus == 1) {
                    //Se activo un nuevo dispositivo
                    DB::delete("DELETE FROM dispositivosusuarios WHERE id_usuario = '$idUsuario' AND estatus = '0'"); //Eliminar todos los dispositivos con estatus en 0
                }
                return back()->with('bien', 'El estatus del dispositivo se actualizo correctamente.');
            }
            return back()->with('alerta', 'Dispositivo no encontrato.');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function insumos()
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7) //ROL DEL DIRECTOR
        {

            $insumos = DB::select("SELECT * FROM insumos");
            return view('administracion.franquicia.administracion.insumos', ['insumos' => $insumos]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarinsumos()
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7) //ROL DEL DIRECTOR
        {
            request()->validate([
                'preciom' => 'required|integer|min:0',
                'precioa' => 'required|integer|min:0',
                'preciob' => 'required|integer|min:0',
                'preciot' => 'required|integer|min:0',
                'precioe' => 'required|integer|min:0'
            ]);

            try {
                DB::table('insumos')->where('id', '=', '1')->update([
                    'preciom' => request('preciom'), 'precioa' => request('precioa'), 'preciob' => request('preciob'), 'preciot' => request('preciot'), 'precioe' => request('precioe')
                ]);
                return redirect()->route('listafranquicia')->with('bien', 'Los insumos se actualizaron correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function descargarArchivo($idUsuario, $opcion)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {
            $existeUsuario = DB::select("SELECT foto,actanacimiento,identificacion,curp,comprobantedomicilio,segurosocial,solicitud,tarjetapago,contactoemergencia,contratolaboral,pagare,otratarjetapago FROM users WHERE id = '$idUsuario'");
            if ($existeUsuario != null) { //Existe el usuario?
                //Si existe el usuario
                if ($opcion != null && $opcion >= 0 && $opcion <= 11) {
                    $archivo = '';

                    if(self::descomprimirArchivoUsuario($idUsuario, $opcion) == true){

                        switch ($opcion) {
                            case 0://Foto
                                $archivo = $existeUsuario[0]->foto;
                                break;
                            case 1:
                                $archivo = $existeUsuario[0]->actanacimiento;
                                break;
                            case 2:
                                $archivo = $existeUsuario[0]->identificacion;
                                break;
                            case 3:
                                $archivo = $existeUsuario[0]->curp;
                                break;
                            case 4:
                                $archivo = $existeUsuario[0]->comprobantedomicilio;
                                break;
                            case 5:
                                $archivo = $existeUsuario[0]->segurosocial;
                                break;
                            case 6:
                                $archivo = $existeUsuario[0]->solicitud;
                                break;
                            case 7:
                                $archivo = $existeUsuario[0]->tarjetapago;
                                break;
                            case 8:
                                $archivo = $existeUsuario[0]->contactoemergencia;
                                break;
                            case 9:
                                $archivo = $existeUsuario[0]->contratolaboral;
                                break;
                            case 10:
                                $archivo = $existeUsuario[0]->pagare;
                                break;
                            case 11: // Nuevo archivo otratarjeta
                                $archivo = $existeUsuario[0]->otratarjetapago;
                                break;
                        }
                        return Storage::disk('disco')->download($archivo);

                    } else {
                        return back()->with('alerta', 'No se encontro el archivo.');
                    }

                } else {
                    return back()->with('alerta', 'No se encontro el archivo.');
                }

            } else {
                //No existe el usuario

                return back()->with('alerta', 'No se encontro el usuario.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function usuariosfranquiciatiemporeal(Request $request) {

        if ($request->has('filtro')) {
            $filtro = $request->input('filtro');
            $usuariosSinFranquicia = DB::select("SELECT u.id as ID, u.name as NOMBRE FROM users u WHERE (u.rol_id <> 7 AND u.rol_id <> 19) AND u.name LIKE '%" . $filtro . "%' AND u.id NOT IN (SELECT id_usuario FROM usuariosfranquicia WHERE u.id = id_usuario) ORDER BY u.name");
            $response = ['data' => $usuariosSinFranquicia];
        } else {
            $usuariosSinFranquicia = DB::select("SELECT u.id as ID, u.name as NOMBRE FROM users u WHERE (u.rol_id <> 7 AND u.rol_id <> 19) AND u.id NOT IN (SELECT id_usuario FROM usuariosfranquicia WHERE u.id = id_usuario) ORDER BY u.name");
            $response = ['data' => $usuariosSinFranquicia];
        }
        return response()->json($response);
    }

    public function usuariosfiltrosucursal($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7)) {

            $sucursalSeleccionada = request('sucursalSeleccionada');

            $ahora = Carbon::now();

            if(strlen($sucursalSeleccionada) > 0) {
                //Se eligio una sucursal
                $usuariosfranquicia = DB::select("SELECT u.id as ID, u.foto AS FOTO, u.name AS NOMBRE,u.email AS CORREO, r.rol AS ROL ,u.renovacion, u.codigoasistencia AS NOCONTROL, uf.id_franquicia as ID_FRANQUICIA, (SELECT ciudad FROM franquicias WHERE id = uf.id_franquicia) as CIUDADFRANQUICIA
                            FROM users u
                            INNER JOIN roles r
                            ON r.id = u.rol_id
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            WHERE uf.id_franquicia = '$sucursalSeleccionada'
                            ORDER BY u.name");
                $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND  uf.id_franquicia= '$sucursalSeleccionada' AND  STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
            }else {
                //Todas las sucursales
                if($idFranquicia == '00000') {
                    //Franquicia de prueba
                    $usuariosfranquicia = DB::select("SELECT u.id as ID, u.foto AS FOTO, u.name AS NOMBRE,u.email AS CORREO, r.rol AS ROL ,u.renovacion, u.codigoasistencia AS NOCONTROL, uf.id_franquicia as ID_FRANQUICIA, (SELECT ciudad FROM franquicias WHERE id = uf.id_franquicia) as CIUDADFRANQUICIA
                            FROM users u
                            INNER JOIN roles r
                            ON r.id = u.rol_id
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            ORDER BY u.name");
                    $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
                }else {
                    //Otra franquicia diferente a la de prueba
                    $usuariosfranquicia = DB::select("SELECT u.id as ID, u.foto AS FOTO, u.name AS NOMBRE,u.email AS CORREO, r.rol AS ROL ,u.renovacion, u.codigoasistencia AS NOCONTROL, uf.id_franquicia as ID_FRANQUICIA, (SELECT ciudad FROM franquicias WHERE id = uf.id_franquicia) as CIUDADFRANQUICIA
                            FROM users u
                            INNER JOIN roles r
                            ON r.id = u.rol_id
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            WHERE uf.id_franquicia != '00000'
                            ORDER BY u.name");
                    $totalRenovacion = DB::select("SELECT COUNT(u.id) AS total FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.renovacion IS NOT NULL AND  uf.id_franquicia != '00000' AND  STR_TO_DATE(u.renovacion,'%Y-%m-%d') <= ' $ahora'");
                }
            }

            $franquicia = DB::select("SELECT * FROM franquicias WHERE id='$idFranquicia'");
            $sucursales = DB::select("SELECT id,estado,ciudad,colonia,numero FROM franquicias WHERE id != '00000'");
            $roles = DB::select("SELECT * FROM roles WHERE id <> 7");
            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia'");

            return view('administracion.franquicia.usuarios', ['usuariosfranquicia' => $usuariosfranquicia,
                'franquicia' => $franquicia,
                'roles' => $roles,
                'id' => $idFranquicia,
                'zonas' => $zonas,
                'sucursales' => $sucursales,
                'idFranquicia' => $idFranquicia,
                'totalRenovacion' => $totalRenovacion,
                'sucursalSeleccionada' => $sucursalSeleccionada
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarControlEntradaSalidaUsuarioFranquicia($idFranquicia, $idUsuario, Request $request)
    {
        if (Auth::user()->rol_id == 7 || Auth::user()->rol_id == 6 || Auth::user()->rol_id == 8) //ROL DEL DIRECTOR
        {

            $horaini = request()->horaini;
            $horafin = request()->horafin;

            if($horaini != null && $horafin != null) {
                //horaini y horafin son diferentes de vacio

                if ($horaini > $horafin) {
                    return back()->with('alerta', 'El horario inicial/final no puede ser mayor/menor al horario final/inicial');
                }

                if(strlen($horaini) <= 5) {
                    $horaini = $horaini . ":00";
                }

                if(strlen($horafin) <= 5) {
                    $horafin = $horafin . ":00";
                }

                DB::table('controlentradasalidausuario')->where('id_usuario', $idUsuario)->update([
                    'horaini' => $horaini,
                    'horafin' => $horafin,
                    'updated_at' => Carbon::now()
                ]);

                return back()->with('bien', 'Se actualizaron los horarios del usuario correctamente');

            }

            return back()->with('alerta', 'El horario inicial o final estan vacios');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    /* -----------------------------Funciones para crear archivos ZIP al crear un nuevo usuario o actualizar -------------------*/

    //Funcion: comprimirArchivosUsuarios
    //Descripcion: Sube las imagenes adjuntas al formulario al servidor y porteriormente general el zip
    //Cuando se actualiza se rescribe dentro del archivo zip correspondiente al usuario editado

    public function comprimirArchivosUsuarios($idUsuario, $archivosComprimir, $opcion){

        //Opcion
        // Opcion 0 -> Crear zip por priemra vez e insertar todos los archivos enviados en el
        // Opcion 1 -> Actualizar archivos en zip, sobre-escribir

        switch ($opcion){
            case 0:
                //Crear Zip primera vez
                //Crear, inicializar y abrir un archivo zip nuevo (Flags: Si no existe el archivo crea uno nuevo)
                $zip = new ZipArchive;
                $zip->open('uploads/imagenes/usuarios/zip/'.'Archivos-Usuario'.'-'.$idUsuario.'.zip', ZipArchive::CREATE);

                //Recorremos el arreglo de archivos
                foreach ($archivosComprimir as $archivo){
                    //Agregamos cada uno de los archivos al archivo zip
                    $zip->addFile(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $archivo, ''.$archivo);
                }
                $zip->close(); //Cerrar el archivo zip

                //Se recorren nuevamente los archivos y se eliminan para solo dejar el archivo zip
                foreach ($archivosComprimir as $archivo){
                    unlink(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/' . $archivo);
                }
                break;

            case 1:
                //Actualizar Archivos en zip
                $zip = new ZipArchive;
                $zip->open('uploads/imagenes/usuarios/zip/'.'Archivos-Usuario'.'-'.$idUsuario.'.zip');

                //Recorremos el arreglo de archivos
                foreach ($archivosComprimir as $archivo){
                    //Agregamos cada uno de los archivos al archivo zip
                    $zip->addFile(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/zip/' . $archivo, ''.$archivo);
                }
                $zip->close(); //Cerrar el archivo zip

                //Se recorren nuevamente los archivos y se eliminan para solo dejar el archivo zip
                foreach ($archivosComprimir as $archivo){
                    unlink(config('filesystems.disks.disco.root') . '/uploads/imagenes/usuarios/zip/' . $archivo);
                }
                break;

        }


    }

    //Fucnion: descomprimirArchivoUsuario
    //Descripcion: Descomprime un archivo en especifico referente a un usuario para posteriormente descargarlo
    public function  descomprimirArchivoUsuario($idUsuario, $opcion){
        //Verificamos que existe el usuario y contenga el archivo a descomprimir
        $verificarArchivo = self::verificarExisteArchivoBD($idUsuario,$opcion);

        if($verificarArchivo != null || sizeof($verificarArchivo)>0){
            //si el resultado fue diferente de null
            $bandera = $verificarArchivo[0];
            $archivoDescomprimir = $verificarArchivo[1];

            //Verificamos si es una ruta antigua o un usuario de nuevo ingreso con nueva ruta de almacenamiento
            $archivo= explode("/", $archivoDescomprimir);

            if(sizeof($archivo) > 1){
                //Si tenia una subcarpeta en la ruta
                $nombreArchivo = $archivo[sizeof($archivo)-1]; // Extraemos solo el nombre del archivo a descomprimir
            } else {
                //Si no tiene subcarpetas es una ruta actual entoces dejamos el nombre recibido
                $nombreArchivo = $archivoDescomprimir;
            }
        }

        if($bandera == true){
            //Si bandera es verdadera -> el usuario tiene registrado su docuemnto correcatemente

            $zip = new ZipArchive();
            $zip->open('uploads/imagenes/usuarios/zip/'.'Archivos-Usuario'. '-' .$idUsuario. '.zip', ZipArchive::CREATE); // Abrimos el archivo ZIP correspondiente al usuario
            $zip->extractTo('uploads/imagenes/usuarios/', ''.$nombreArchivo); //Extraemos el archivo que fue seleccionado
            $zip->close(); //Cerrar el archivo zip

            return true; //Retornamos verdadero una vez que todo fue correcto
        }

        return false; //Si no existe el archivo retornamos falso

    }

    //Funcion: verificarExisteArchivoBD
    //Descripcion: Antes de intentar descargar el archivo se comprueba que exista ese documento para el usuario deseado
    public function verificarExisteArchivoBD($idUsuario, $opcion){
        //Almacenara la bandera true y el nombre del archivo en caso de que exista.
        $resultado = [];

        $existeArchivo = DB::select("SELECT actanacimiento,identificacion,curp,comprobantedomicilio,segurosocial,solicitud,tarjetapago,contactoemergencia,contratolaboral,pagare,otratarjetapago FROM users WHERE id = '$idUsuario'");
        switch ($opcion){
            //Casos: Verifican que tenga el registro de la BD no sea nulo y a demas que corresponda a la ruta de almacenamiento
            //Si es valido extraemos solo el nombre del archivo el cual se descomprime despues

            case 1:
                //Acta de nacimiento
                if($existeArchivo[0]->actanacimiento != null && str_contains($existeArchivo[0]->actanacimiento , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->actanacimiento,26)];
                }
                break;
            case 2:
                //Identificacion
                if($existeArchivo[0]->identificacion != null && str_contains($existeArchivo[0]->identificacion , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->identificacion,26)];
                }
                break;
            case 3:
                //CURP
                if($existeArchivo[0]->curp != null && str_contains($existeArchivo[0]->curp , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->curp,26)];
                }
                break;
            case 4:
                //Comprobante de domicilio
                if($existeArchivo[0]->comprobantedomicilio != null && str_contains($existeArchivo[0]->comprobantedomicilio , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->comprobantedomicilio,26)];
                }
                break;
            case 5:
                //Seguro Social
                if($existeArchivo[0]->segurosocial != null && str_contains($existeArchivo[0]->segurosocial , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->segurosocial,26)];
                }
                break;
            case 6:
                //Seguro Social
                if($existeArchivo[0]->solicitud != null && str_contains($existeArchivo[0]->solicitud , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->solicitud,26)];
                }
                break;
            case 7:
                //Tarje de Pago
                if($existeArchivo[0]->tarjetapago != null && str_contains($existeArchivo[0]->tarjetapago , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->tarjetapago,26)];
                }
                break;
            case 8:
                //Contacto de emergencia
                if($existeArchivo[0]->contactoemergencia != null && str_contains($existeArchivo[0]->contactoemergencia , 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->contactoemergencia,26)];
                }
                break;
            case 9:
                //Contrato laboral
                if($existeArchivo[0]->contratolaboral != null && str_contains($existeArchivo[0]->contratolaboral,'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->contratolaboral,26)];
                }
                break;
            case 10:
                //Pagare
                if($existeArchivo[0]->pagare != null && str_contains($existeArchivo[0]->pagare,'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->pagare,26)];
                }
                break;
            case 11:
                //Otra tarjeta
                if($existeArchivo[0]->otratarjetapago != null && str_contains($existeArchivo[0]->otratarjetapago, 'uploads/imagenes/usuarios/')){
                    $resultado = [true,substr($existeArchivo[0]->otratarjetapago,26)];
                }
                break;

        }
        return $resultado;

    }

    /*-------------------Funciones para vistas previas de archivos en ventana Ver Usuario-------------------------*/

    //Funcion: descomprimirZipUsuario
    //Descripcion: extraer un archivo dentro del zip por medio de un parametro recibido, es mandado a llamar cuando se desea hacer la vista previa del archivo
    public function descomprimirZipUsuario(Request $request){
        if (Auth::user()->rol_id == 7 ){
            //ROL DEL DIRECTOR

            $idUsuario = $request->input('idUsuario');
            $archivoDescomprimir = $request->input('archivoServidorFTP');

            //Obtenemos el nombre del archivo a descomprimir
            $archivo = explode("/", $archivoDescomprimir);
            $nombreArchivo = $archivo[sizeof($archivo)-1];

            //Validar si existe el archivo
            if(file_exists('uploads/imagenes/usuarios/zip/'.'Archivos-Usuario'. '-' .$idUsuario. '.zip')){
                //Si existe archivo zip
                $zip = new ZipArchive();
                $zip->open('uploads/imagenes/usuarios/zip/'.'Archivos-Usuario'. '-' .$idUsuario. '.zip', ZipArchive::CREATE); // Abrimos el archivo ZIP correspondiente al usuario
                $zip->extractTo('uploads/imagenes/usuarios/', ''.$nombreArchivo); //Extraemos el archivo deseado
                $zip->close(); //Cerrar el archivo zip

                $bandera = true;
            }else {
                //Si no existe el archivo zip
                $bandera = false;
            }

            //Retornamos nuestra bandera con el resultado si es correcto o no
            return response()->json(['bandera' => $bandera]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

}
