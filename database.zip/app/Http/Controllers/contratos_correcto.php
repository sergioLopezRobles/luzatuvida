<?php

namespace App\Http\Controllers;

use App\Mail\prueba;
use App\Mail\recordatorio;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use App\Clases\globales;
use App\Clases\contratosGlobal;
use Image;
use Illuminate\Support\Facades\Validator;


class contratos extends Controller
{
    /* Metodo/Funcion: listacontrato
    Descripcion: Carga la lista de contratos, ademas hace validaciones para actualizar los estados de los contratos por si se salen
    si realizar las modificaciones necesarias.
    */
    public function listacontrato($idFranquicia)
    {

        $contratoslaboratorio = null;
        $contratosconfirmaciones = null;
        $cbAtrasado = null;
        $cbPrioritario = null;
        $cbPeriodo = null;
        $cbEntrega = null;
        $cbLaboratorio = null;
        $cbConfirmacion = null;
        $cbTodos = null;
        $zonaU = null;

        $arrayCheckBox = array();

        $hoy = Carbon::now();
        $hoyparce = Carbon::parse($hoy)->format('Y-m-d');
        if (Auth::check() && ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4)) {
            $rol_id = Auth::user()->rol_id;
            $now = Carbon::now();
            $app = null;
            $idUsuario = Auth::user()->id;
            //Consulta para traer contratos que tengan algun abono de liquidado y su total no este en 0, esto para actualizar el tipo de abono y se pueda liquidar con uno de su tipo.
            $contratosliquidados = DB::select("SELECT c.id as contraid, c.total, a.tipoabono, c.entregaproducto, c.costoatraso, a.id as abonoid FROM abonos a inner join contratos c on a.id_contrato = c.id where a.tipoabono = 6 AND c.total > 0");
            //Consulta para traer contratos con la bandera de entregaproducto activada y que no fueron entregados desde el boton, para actualizar el estadoa  entregado.
            $contratosnoentregados = DB::select("SELECT id, entregaproducto, estatus_estadocontrato, total, subscripcion FROM contratos where entregaproducto = 1 and estatus_estadocontrato = 12");
            //Consulta para traer los contratos que esten pendientes de terminar o que si tienen promocion no terminada, se les actualiza la fecha a hoy para que aparezcan
            $contratospendientes = DB::select("SELECT id, idcontratorelacion FROM contratos where STR_TO_DATE(created_at,'%Y-%m-%d') < '$hoyparce'
            AND estatus_estadocontrato = 0
            AND COALESCE(id_promocion,0) < 1");
            //
            $contratohoypromo = DB::select("SELECT id FROM contratos WHERE id_usuariocreacion = '$idUsuario' AND STR_TO_DATE(created_at,'%Y-%m-%d') < '$hoyparce' AND id_promocion >= 1 AND ifnull(promocionterminada,0) < 1");
            if ($contratospendientes != null) {
                foreach ($contratospendientes as $cp) {
                    DB::table('contratos')->where([['id', '=', $cp->id], ['id_franquicia', '=', $idFranquicia]])->update([
                        'created_at' => $now
                    ]);
                }
            } // actualizar fecha de contratos no terminados
            if ($contratohoypromo != null) {
                foreach ($contratohoypromo as $cp) {
                    DB::table('contratos')->where([['id', '=', $cp->id], ['id_franquicia', '=', $idFranquicia]])->update([
                        'created_at' => $now
                    ]);
                    DB::table('contratos')->where([['idcontratorelacion', '=', $cp->id], ['id_franquicia', '=', $idFranquicia]])->update([
                        'created_at' => $now
                    ]);
                }
            } // Se les actualiza la fecha de creacion a los contratos que tengan promocion y aun no este completada
            if ($contratosnoentregados != null && $contratosnoentregados[0]->subscripcion == null) {
                foreach ($contratosnoentregados as $ce) {
                    if ($ce->total == 0) {
                        $estadodelcontrato = 5;
                    } else {
                        $estadodelcontrato = 2;
                    }


                    DB::table('contratos')->where([['id', '=', $ce->id], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus_estadocontrato' => $estadodelcontrato, 'fechaentrega' => $hoyparce
                    ]);
                }
            } // contratos con bandera de entrega de producto y que aun no estaban entregados
            if ($contratosliquidados != null) {
                foreach ($contratosliquidados as $ac) {
                    if ($ac->costoatraso > 0) {
                        $estadopreliquidado = 4;
                    }
                    if ($ac->entregaproducto > 0 && $ac->costoatraso < 1) {
                        $estadopreliquidado = 2;
                    }
                    if ($ac->entregaproducto < 1 && $ac->costoatraso < 1) {
                        $estadopreliquidado = 1;
                    }

                    DB::table('abonos')->where([['id', '=', $ac->abonoid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'tipoabono' => 0
                    ]);
                    DB::table('contratos')->where([['id', '=', $ac->contraid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus_estadocontrato' => $estadopreliquidado
                    ]);
                }
            }// actualiza el tipo de abono de los contratos no liquidados con algun abono de liquidado, los cambia a normales para que solo hay un liquidado
            $contratosgeneral = DB::select("SELECT * FROM contratos");
            if ((($rol_id) == 13) || (($rol_id) == 12)) {
                $idUsuario = Auth::user()->id;
                $contratosatrasados = "";
                $contratosprioritarios = "";
                $contratosperiodo = "";
                $contratosentregar = "";
                // Consulta para llenar la lista de contratos general para los asistentes y optometristas, con estado menos a entregado.
                $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion,  c.fechacobrofin, c.fechacobroini,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono, c.estatus_estadocontrato, c.diaseleccionado, c.total, c.fechaentrega, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT p.nombre from historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id limit 1) as paquete,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato < 2
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_usuariocreacion = '$idUsuario'
                AND (STR_TO_DATE(c.created_at,'%Y-%m-%d') = STR_TO_DATE('$now','%Y-%m-%d')
                OR c.estatus_estadocontrato = 0)
                order by c.created_at desc
                ");

                $app = DB::select("SELECT apk FROM dispositivos WHERE estatus = 1");

            } elseif ($rol_id == 4) {
                //Consulta para el rol de cobranza en la sección de contratos prioritarios, es decir, aquellos contratos que esten dentro del periodo
                //y que el dia seleccionado sea igual a la fecha de hoy para que le cobre en un dia determinado.

                $arrayContratos = self::obtenerListaContratosConOSinFiltro($idFranquicia, true, null, $arrayCheckBox);

                $contratosprioritarios = $arrayContratos[0];
                $contratosatrasados = $arrayContratos[1];
                $contratosperiodo = $arrayContratos[2];
                $contratosentregar = $arrayContratos[3];
                $contratos = $arrayContratos[4];

                $app = DB::select("SELECT apk FROM dispositivos WHERE estatus = 1");

            } else {
                //Consulta para el roles administrativos en la sección de contratos prioritarios, es decir, aquellos contratos que esten dentro del periodo
                //y que el dia seleccionado sea igual a la fecha de hoy para que le cobre en un dia determinado.

                $cbAtrasado = 1;
                $cbPrioritario = 1;
                $cbPeriodo = 1;
                $cbEntrega = 1;
                $cbLaboratorio = 1;
                $cbConfirmacion = 1;
                $cbTodos = 1;

                array_push($arrayCheckBox, $cbAtrasado);
                array_push($arrayCheckBox, $cbPrioritario);
                array_push($arrayCheckBox, $cbPeriodo);
                array_push($arrayCheckBox, $cbEntrega);
                array_push($arrayCheckBox, $cbLaboratorio);
                array_push($arrayCheckBox, $cbConfirmacion);
                array_push($arrayCheckBox, $cbTodos);
                array_push($arrayCheckBox, $zonaU);

                $arrayContratos = self::obtenerListaContratosConOSinFiltro($idFranquicia, false, null, $arrayCheckBox);

                $contratosprioritarios = $arrayContratos[0];
                $contratosatrasados = $arrayContratos[1];
                $contratosperiodo = $arrayContratos[2];
                $contratosentregar = $arrayContratos[3];
                $contratoslaboratorio = $arrayContratos[4];
                $contratosconfirmaciones = $arrayContratos[5];
                $contratos = $arrayContratos[6];

            }

            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia'");

            //Consulta paratraer los datos de la franquicia y mostrarlo en la seccion de arriba de los contratos.
            $franquiciaContratos = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.contrato.tabla', ['contratos' => $contratos, 'franquiciaContratos' => $franquiciaContratos, 'contratosperiodo' => $contratosperiodo,
                'contratosatrasados' => $contratosatrasados, 'contratosprioritarios' => $contratosprioritarios, 'contratosgeneral' => $contratosgeneral,
                'contratosentregar' => $contratosentregar, 'contratoslaboratorio' => $contratoslaboratorio, 'contratosconfirmaciones' => $contratosconfirmaciones,
                'zonas' => $zonas, 'cbAtrasado' => $cbAtrasado, 'cbPrioritario' => $cbPrioritario, 'cbPeriodo' => $cbPeriodo, 'cbEntrega' => $cbEntrega, 'cbLaboratorio' => $cbLaboratorio,
                'cbConfirmacion' => $cbConfirmacion, 'cbTodos' => $cbTodos, 'zonaU' => $zonaU,
                'idFranquicia' => $idFranquicia, 'now' => $now, 'app' => $app]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private static function obtenerListaContratosConOSinFiltro($idFranquicia, $cobranza, $filtro, $arrayCheckBox)
    {

        $now = Carbon::now();
        $arrayContratos = array();

        $contratosprioritarios = array();
        $contratosatrasados = array();
        $contratosperiodo = array();
        $contratosentregar = array();
        $contratoslaboratorio = array();
        $contratosconfirmaciones = array();
        $contratos = array();

        if($cobranza) {
            //Rol cobranza

            $zonauser = Auth::user()->id_zona;
            $cadenaFiltro = " ";

            if($filtro != null) {
                //Se buscara por filtro
                $cadenaFiltro = " AND (c.id LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%' OR c.colonia LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%') ";
            }

            $contratosTodos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                " . $cadenaFiltro . "
                order by c.localidad,c.colonia,c.calle,c.numero,c.nombre,c.id asc");

            foreach ($contratosTodos as $contrato) {

                //Contratos prioritarios
                if($contrato->diaseleccionado == Carbon::parse($now)->format('Y-m-d') && $contrato->total > 0
                    && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                    array_push($contratosprioritarios, $contrato);
                }

                //Contratos atrasados
                if($contrato->total > 0 && $contrato->estatus_estadocontrato == 4) {
                    array_push($contratosatrasados, $contrato);
                }

                //Contratos periodo
                if($contrato->fechacobroini != null
                    && $contrato->diaseleccionado != Carbon::parse($now)->format('Y-m-d')
                    && (Carbon::parse($now)->format('Y-m-d') >= $contrato->fechacobroini
                        && Carbon::parse($now)->format('Y-m-d') <= $contrato->fechacobrofin || $contrato->ultimoabono == Carbon::parse($now)->format('Y-m-d'))
                    && $contrato->total > 0
                    && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                    array_push($contratosperiodo, $contrato);
                }

                //Contratos enviados
                if($contrato->estatus_estadocontrato == 12) {
                    array_push($contratosentregar, $contrato);
                }

                //Contratos todos
                if($contrato->fechaentrega == Carbon::parse($now)->format('Y-m-d')
                    && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                    array_push($contratos, $contrato);
                }
            }

            /*$contratosprioritarios = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (2,5)
                AND c.diaseleccionado = STR_TO_DATE('$now','%Y-%m-%d')
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                AND c.total > 0
                order by c.localidad,c.colonia,c.calle,c.id asc");
                //Consulta en rol de cobranza para la sección de abonos con estatus de atraso, estos contratos siempre apareceran mientras se mantengan en ese estatus, una vez normalizados regresan a su correspondiente sección
                $contratosatrasados = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato = 4
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                AND c.total > 0
                order by c.localidad,c.colonia,c.calle,c.id asc
                ");
                //Consulta en rol de cobranza para la sección de contratos que su periodo de cobranza este dentro del rango de cobro.
                $contratosperiodo = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (2,5)
                AND (c.fechacobroini IS NOT NULL)
                AND COALESCE(c.diaseleccionado,0) != STR_TO_DATE('$now','%Y-%m-%d')
                AND (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
                    AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d') or
                    STR_TO_DATE(c.ultimoabono,'%Y-%m-%d')  = STR_TO_DATE('$now','%Y-%m-%d'))
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                AND c.total > 0
                order by c.localidad,c.colonia,c.calle,c.id asc
                ");
                //Consulta en rol de cobranza para la sección de contratos enviados, listos para ser entregados a los clientes.
                $contratosentregar = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato = 12
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                order by c.localidad,c.colonia,c.calle,c.id asc
                ");
                //Consulta en rol de cobranza para la sección de contratos generale mismos que son diferentes a los de las demas secciones
                $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (2,5,14)
                AND STR_TO_DATE(c.fechaentrega,'%Y-%m-%d') = STR_TO_DATE('$now','%Y-%m-%d')
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                GROUP BY c.id,c.datos,c.id_franquicia,c.id_usuariocreacion, c.nombre_usuariocreacion,z.zona, c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega, c.totalhistorial, c.totalproducto,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.ultimoabono
                order by c.localidad,c.colonia,c.calle,c.id asc");*/

            array_push($arrayContratos, $contratosprioritarios);
            array_push($arrayContratos, $contratosatrasados);
            array_push($arrayContratos, $contratosperiodo);
            array_push($arrayContratos, $contratosentregar);
            array_push($arrayContratos, $contratos);

        }else {
            //Rol administrador para arriba

            $cadenaFiltro = " ";
            if($filtro != null) {
                //Se buscara por filtro
                $cadenaFiltro = " AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%') ";
            }

            $cbAtrasado = $arrayCheckBox[0];
            $cbPrioritario = $arrayCheckBox[1];
            $cbPeriodo = $arrayCheckBox[2];
            $cbEntrega = $arrayCheckBox[3];
            $cbLaboratorio = $arrayCheckBox[4];
            $cbConfirmacion = $arrayCheckBox[5];
            $cbTodos = $arrayCheckBox[6];
            $zonaU = $arrayCheckBox[7];

            $cadenaZona = " ";
            if($zonaU != null) {
                $cadenaZona = " AND c.id_zona = '$zonaU' ";
            }

            $contratosTodos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.id_franquicia = '$idFranquicia'
                " . $cadenaFiltro . "
                " . $cadenaZona . "
                order by c.created_at, c.id_zona, c.localidad, c.colonia, c.calle, c.numero, c.nombre desc
                ");

            foreach ($contratosTodos as $contrato) {

                //Contratos prioritarios
                if($cbPrioritario != null) {
                    if ($contrato->diaseleccionado == Carbon::parse($now)->format('Y-m-d') && $contrato->total > 0
                        && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                        array_push($contratosprioritarios, $contrato);
                    }
                }

                //Contratos atrasados
                if($cbAtrasado != null) {
                    if ($contrato->total > 0 && $contrato->estatus_estadocontrato == 4) {
                        array_push($contratosatrasados, $contrato);
                    }
                }

                //Contratos periodo
                if($cbPeriodo != null) {
                    if ($contrato->fechacobroini != null
                        && $contrato->diaseleccionado != Carbon::parse($now)->format('Y-m-d')
                        && Carbon::parse($now)->format('Y-m-d') >= $contrato->fechacobroini
                        && Carbon::parse($now)->format('Y-m-d') <= $contrato->fechacobrofin && $contrato->total > 0
                        && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                        array_push($contratosperiodo, $contrato);
                    }
                }

                //Contratos enviados
                if($cbEntrega != null) {
                    if ($contrato->estatus_estadocontrato == 12) {
                        array_push($contratosentregar, $contrato);
                    }
                }

                //Contratos laboratorio
                if($cbLaboratorio != null) {
                    if ($contrato->estatus_estadocontrato == 7 || $contrato->estatus_estadocontrato == 10 || $contrato->estatus_estadocontrato == 11) {
                        array_push($contratoslaboratorio, $contrato);
                    }
                }

                //Contratos confirmaciones
                if($cbConfirmacion != null) {
                    if ($contrato->estatus_estadocontrato == 9) {
                        array_push($contratosconfirmaciones, $contrato);
                    }
                }

                //Contratos todos
                if($cbTodos != null) {
                    if ($contrato->diaseleccionado != Carbon::parse($now)->format('Y-m-d')
                        && ($contrato->estatus_estadocontrato == 0 || $contrato->estatus_estadocontrato == 1
                            || $contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 3
                            || $contrato->estatus_estadocontrato == 5 || $contrato->estatus_estadocontrato == 6
                            || $contrato->estatus_estadocontrato == 8)) {
                        array_push($contratos, $contrato);
                    }
                }
            }

            /*\Log::info('contratosprioritarios ' . count($contratosprioritarios));
            \Log::info('contratosatrasados ' . count($contratosatrasados));
            \Log::info('contratosperiodo ' . count($contratosperiodo));
            \Log::info('contratosentregar ' . count($contratosentregar));
            \Log::info('contratoslaboratorio ' . count($contratoslaboratorio));
            \Log::info('contratos ' . count($contratos));
            return;

            $contratosprioritarios = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
            (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
            (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
            (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN estadocontrato e
            ON e.estatus = c.estatus_estadocontrato
            WHERE c.datos = 1
            AND c.estatus_estadocontrato IN (2,5)
            AND c.diaseleccionado = STR_TO_DATE('$now','%Y-%m-%d')
            AND c.id_franquicia = '$idFranquicia'
            AND c.total > 0
            order by c.created_at desc
            ");
            //Consulta en roles administrativos para la sección de abonos con estatus de atraso, estos contratos siempre apareceran mientras se mantengan en ese estatus, una vez normalizados regresan a su correspondiente sección
            $contratosatrasados = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
            (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
            (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
            (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN estadocontrato e
            ON e.estatus = c.estatus_estadocontrato
            WHERE c.datos = 1
            AND c.estatus_estadocontrato = 4
            AND c.id_franquicia = '$idFranquicia'
            AND c.total > 0
            order by c.created_at desc
            ");
            //Consulta en roles administrativos para la sección de contratos que su periodo de cobranza este dentro del rango de cobro
            $contratosperiodo = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
            (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
            (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
            (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN estadocontrato e
            ON e.estatus = c.estatus_estadocontrato
            WHERE c.datos = 1
            AND c.estatus_estadocontrato IN (2,5)
            AND (c.fechacobroini IS NOT NULL)
            AND COALESCE(c.diaseleccionado,0) != STR_TO_DATE('$now','%Y-%m-%d')
            AND STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
            AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
            AND c.id_franquicia = '$idFranquicia'
            AND c.total > 0
            order by c.created_at desc
            ");
            //Consulta en roles administrativos para la sección de contratos enviados, listos para ser entregados a los clientes.
            $contratosentregar = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
            (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
            (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
            (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN estadocontrato e
            ON e.estatus = c.estatus_estadocontrato
            WHERE c.datos = 1
            AND c.estatus_estadocontrato = 12
            AND c.id_franquicia = '$idFranquicia'
            order by c.created_at desc
            ");

            //Consulta en roles administrativos para la sección de contratos laboratorio, manofactura, proceso de envio, aprobado
            $contratoslaboratorio = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
            (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
            (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
            (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN estadocontrato e
            ON e.estatus = c.estatus_estadocontrato
            WHERE c.datos = 1
            AND c.estatus_estadocontrato IN (7,10,11)
            AND c.id_franquicia = '$idFranquicia'
            order by c.created_at desc
            ");

            //Consulta en roles administrativos para la sección de contratos generale mismos que son diferentes a los de las demas secciones
            $contratos = DB::table('contratos as c')
                ->join('zonas', 'zonas.id', '=', 'c.id_zona')
                ->join('estadocontrato', 'estadocontrato.estatus', '=', 'c.estatus_estadocontrato')
                ->select('c.id', 'c.datos', 'c.id_franquicia', 'c.id_usuariocreacion', 'c.nombre_usuariocreacion', 'zonas.zona', 'c.nombre', 'c.calle', 'c.numero', 'c.estatus', 'c.totalpromocion', 'estadocontrato.descripcion', 'c.fechacobrofin', 'c.fechacobroini',
                    'c.depto', 'c.alladode', 'c.frentea', 'c.entrecalles', 'c.colonia', 'c.localidad', 'c.telefono', 'c.casatipo', 'c.casacolor', 'c.created_at', 'c.updated_at', 'c.idcontratorelacion', 'c.totalabono', 'c.estatus_estadocontrato', 'c.diaseleccionado', 'c.total', 'c.fechaentrega', 'c.ultimoabono',
                    (DB::raw("(SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias")),
                    (DB::raw("(SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo")),
                    (DB::raw("(SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha")))
                ->where('c.datos', '=', '1')
                ->whereRaw("c.estatus_estadocontrato IN (0,1,2,3,5,6,8,14,15)")
                ->whereRaw("COALESCE(c.diaseleccionado,0) != STR_TO_DATE('$now','%Y-%m-%d')")
                ->whereRaw("c.id_franquicia = '$idFranquicia'")
                ->orderBy('c.created_at', 'DESC')
                ->paginate(20);*/

            array_push($arrayContratos, $contratosprioritarios);
            array_push($arrayContratos, $contratosatrasados);
            array_push($arrayContratos, $contratosperiodo);
            array_push($arrayContratos, $contratosentregar);
            array_push($arrayContratos, $contratoslaboratorio);
            array_push($arrayContratos, $contratosconfirmaciones);
            array_push($arrayContratos, $contratos);

        }

        return $arrayContratos;

    }

    /* Metodo/Funcion: getAbonosId
     Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
     */
    private function getAbonosId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from abonos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    /* Metodo/Funcion: getPromocionContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getPromocionContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from promocioncontrato where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    /* Metodo/Funcion: getContratoContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getContratoContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from contratoproducto where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    /* Metodo/Funcion: getHistorialContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getHistorialContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from historialcontrato where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }    // Comparar si ya existe el id en la base de datos

    /* Metodo/Funcion: generadorRandom2
    Descripcion: Esta función crea un ID alfanumerico de 5 digitos para registros
    */
    private function generadorRandom2($length = 5)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    /* Metodo/Funcion: nuevocontrato
    Descripcion: Esta función  carga los datos necesarios para la vista de crear contratos
    */
    public function nuevocontrato($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $idUsuario = Auth::user()->id;
            //Consulta para traer el ultimo optometrista que registro el usuario en su ultimo contrato
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            //Consulta para traer la ultima zona registrada por el usuario en su ultimo contrato
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            //Consulta para llenar el campo de select de zonas en la vista para crear contratos
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            //Consulta para llenar el campo de select de zonas en la vista para crear contratos
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            return view('administracion.contrato.nuevo', ['idFranquicia' => $idFranquicia, 'zonas' => $zonas, 'optometristas' => $optometristas, 'ultimaZona' => $ultimaZona, 'ultimoOptometrista' => $ultimoOptometrista]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    /* Metodo/Funcion: nuevocontrato2
    Descripcion: Esta función se manda a llamar en terminar contrato de los contratos padres con promocion o los que no tienen, se hacen lso calculos necsarios para los totales y mandara a llamar la creación de nuevos contratos si es necesario.
    */
    public function nuevocontrato2($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $idUsuario = Auth::user()->id;
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            //Consulta para traer los datos necesarios del contrato y con ello poder realizar divorsos movimientos en la vista y el controlador
            $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, pr.armazones, c.totalproducto, c.totalhistorial, c.totalpromocion, c.correo, c.estatus,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador, pr.preciop, c.total, c.totalabono, c.nombrereferencia, pr.preciouno,pr.tipopromocion, c.telefonoreferencia,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN users u
            ON u.id = c.id_optometrista
			INNER JOIN promocion pr
			ON pr.id = c.id_promocion
            WHERE c.datos = 1
            AND c.id = '$idContrato'
            AND c.id_franquicia = '$idFranquicia'");
            //Consulta para traer los datos del tratamiento fotocromatico en la tabla de tratamientos
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            //Consulta para traer los datos del tratamiento A/R en la tabla de tratamientos
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            //Consulta para traer los datos del tratamiento Tinte en la tabla de tratamientos
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            //Consulta para traer los datos del tratamiento Blueray en la tabla de tratamientos
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            //Consulta para traer los datos de los paquetes en la tabla de paquetes
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            //Consulta para traer los registros de los productos de tipo armazon para el select en la creacion de historialclinico
            $armazones = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id_tipoproducto = '1' order by nombre");
            //Consulta de los datos del contrato
            $ct = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            //Consulta de los datos de los historiales clinicos del contrato
            $historialesclinicos = DB::select("SELECT nombre, h.edad, h.fechaentrega, c.telefono, h.id_paquete, h.created_at, h.diagnostico FROM historialclinico h
            inner join contratos c
            on c.id = h.id_contrato
            WHERE id_contrato ='$idContrato'");
            //Consulta de los contratos hijos de una promocion que aun no esten terminados.
            $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato' AND estatus_estadocontrato = 0 limit 1");
            $Hi = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $Hi2 = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato'");
            $relacion = $Hi[0]->id;
            $idPadre = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonoproducto = DB::select("SELECT * FROM abonos  WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = '7'");
            $contratoproducto = DB::select("SELECT * FROM contratoproducto  WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");
            $contratohijo = $ct[0]->idcontratorelacion;
            $contador = $ct[0]->contador;
            $totalhistorial = $ct[0]->totalhistorial;
            $totalabonos = $ct[0]->totalabono;
            $estatus = $ct[0]->estatus_estadocontrato;
            $totalproductos = $ct[0]->totalproducto;
            $promo = $ct[0]->id_promocion;
            $pago = $ct[0]->pago;
            $total = $ct[0]->total;
            if ($abonoproducto == null && $totalproductos > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($abonoproducto != null && $abonoproducto[0]->abono != $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($totalabonos < $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Abonar el total de productos');
            }
            if ($pago === null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de elegir una forma de pago');
            }
            if ($contratohijo != null && $pago == 0 && $estatus >= 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratohijo])->with('bien', 'El contrato se terminara al final de los demas, cuANDo tenga el costo promoción');
            }
            if ($abonoproducto != null && $contratoproducto == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El contrato tiene abono de producto y no hay productos registrados, favor de eliminarlos');
            }
            if ($contratohijo != null && $promo == null) {
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus' => 1, 'estatus_estadocontrato' => 1,
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratohijo])->with('bien', 'El contrato se termino correcatemente');
            }
            if ($historialesclinicos == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de llenar los historiales clinicos necesarios');
            }

            if ($pago == 0 && $total == 0 && $Hi2 == null) {

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 1,
                ]);
                return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'No hay contratos pendientes por completar');
            }
            if ($promo == null) {
                $totalcontrato = $totalhistorial + $totalproductos - $totalabonos;
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $totalcontrato, 'estatus' => 1, 'estatus_estadocontrato' => 1,
                ]);
                return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'No hay contratos pendientes por completar');
            } else {
                if ($contrashijos != null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrashijos[0]->id])->with('alerta', 'Favor de completar el contrato pendiente');
                }
                $cant = $contratos[0]->armazones;
                $cont = $contratos[0]->contador;
                $tothistorial = $contratos[0]->totalhistorial;
                $porcentaje = $contratos[0]->preciop;
                $preciounico = $contratos[0]->preciouno;
                $tipopro = $contratos[0]->tipopromocion;
                $estado = $contratos[0]->estatus;

                if ($cont == $cant) {

                    if ($contratohijo == null && $promo != null && $contador == 1 && $estado == 0) {
                        if ($tipopro == 1) {
                            $totalporcentaje = $preciounico;
                        } else {
                            $totalporcentaje = (($tothistorial * $porcentaje) / 100);
                        }
                        $totalporcentaje = number_format($totalporcentaje, 1, '.', '');
                        $totalnuevo = $tothistorial - $totalporcentaje;
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $totalnuevo, 'totalpromocion' => $totalnuevo, 'estatus' => 1, 'estatus_estadocontrato' => 1, 'promocionterminada' => 1
                        ]);
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se realizo el calculo del contrato con promoción');
                    }

                    $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato' AND estatus_estadocontrato = 0 limit 1");
                    if ($contrashijos != null && $contrashijos[0]->estatus == 1) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 1, 'promocionterminada' => 1
                        ]);
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrashijos[0]->id])->with('bien', 'Favor de completar el contrato pendiente');
                    }
                    if ($contrashijos != null && $contrashijos[0]->estatus == 0) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrashijos[0]->id])->with('bien', 'Favor de completar el contrato pendiente');
                    }
                    if ($contrashijos == null) {

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 1, 'promocionterminada' => 1
                        ]);
                        return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'No hay contratos pendientes por completar');
                    }
                }
            }
            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                'estatus_estadocontrato' => 1,
            ]);
            return view('administracion.historialclinico.nuevohijo', ['idFranquicia' => $idFranquicia, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'armazones' => $armazones, 'contratos' => $contratos,
                'ultimoOptometrista' => $ultimoOptometrista, 'ultimaZona' => $ultimaZona, 'zonas' => $zonas, 'idContrato' => $idContrato, 'idcontratopadre' => $relacion]);


        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratoHijos($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $idUsuario = Auth::user()->id;
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $armazones = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id_tipoproducto = '1' order by nombre");
            $ct = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $historialesclinicos = DB::select("SELECT nombre, h.edad, h.fechaentrega, c.telefono, h.id_paquete, h.created_at, h.diagnostico FROM historialclinico h
            inner join contratos c
            on c.id = h.id_contrato
            WHERE id_contrato ='$idContrato'");
            $Hi = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonoproducto = DB::select("SELECT * FROM abonos  WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = '7'");
            $relacion = $Hi[0]->idcontratorelacion;
            $pagohijofinal = $Hi[0]->pago;
            $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, pr.armazones, c.totalproducto, c.totalhistorial, c.totalpromocion, c.correo,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador, pr.preciop, c.total, c.totalabono, pr.preciouno, pr.tipopromocion, c.nombrereferencia, c.telefonoreferencia,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN users u
            ON u.id = c.id_optometrista
            INNER JOIN promocion pr
            ON pr.id = c.id_promocion
            WHERE c.datos = 1
            AND c.id = '$relacion'
            AND c.id_franquicia = '$idFranquicia'");
            $estadocontrato = $ct[0]->estatus_estadocontrato;
            $contratohijo = $ct[0]->idcontratorelacion;
            $totalhistorial = $ct[0]->totalhistorial;
            $totalabonos = $ct[0]->totalabono;
            $estatus = $ct[0]->estatus;
            $totalproductos = $ct[0]->totalproducto;
            $promo = $ct[0]->id_promocion;
            $pago = $ct[0]->pago;
            $total = $ct[0]->total;
            if ($abonoproducto == null && $totalproductos > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($abonoproducto != null && $abonoproducto[0]->abono != $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($totalabonos < $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de abonar el total de los productos');
            }
            $cant = $contratos[0]->armazones;
            $cont = $contratos[0]->contador;
            $tothistorial = $contratos[0]->totalhistorial;
            if ($cont == $cant) {

                $contras = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'
                    order by totalhistorial asc
                    limit 1;");

                $cantmenor = $contras[0]->totalhistorial;
                $cantpadre = $contratos[0]->totalhistorial;
                $cantpromo = $contratos[0]->totalpromocion;
                $porcentaje = $contratos[0]->preciop;
                $preciounico = $contratos[0]->preciouno;
                $tipopro = $contratos[0]->tipopromocion;

                if ($cantmenor >= $cantpadre) {
                    if ($tipopro == 1) {
                        $totalporcentaje = $preciounico;
                    } else {
                        $totalporcentaje = (($cantpadre * $porcentaje) / 100);
                    }
                    $totalporcentaje = number_format($totalporcentaje, 1, '.', '');
                } else {
                    if ($tipopro == 1) {
                        $totalporcentaje = $preciounico;
                    } else {
                        $totalporcentaje = (($cantmenor * $porcentaje) / 100) + $cantpromo;
                    }
                    $totalporcentaje = number_format($totalporcentaje, 1, '.', '');
                }

                $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'");
                $contraspadre = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$relacion'");

                $sumahijos = DB::select("SELECT SUM(totalhistorial) AS sumahijos FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'");
                $canthijos = DB::select("SELECT COUNT(id) AS canthijos FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'");
                $floatsumahijos = intval($sumahijos[0]->sumahijos);
                $floatcanthijos = intval($canthijos[0]->canthijos);
                $totalpromofinal = (($contraspadre[0]->totalhistorial + $floatsumahijos - $totalporcentaje) / ($floatcanthijos + 1));
                $totalpromofinal = number_format($totalpromofinal, 1, '.', '');
                $totalfinalhijos = $contrashijos[0]->totalproducto + $totalpromofinal - $contrashijos[0]->totalabono;
                $totalfinal = $contraspadre[0]->totalproducto + $totalpromofinal - $contraspadre[0]->totalabono;
                if ($contrashijos[0]->pago == 0) {
                    $totalfinalhijos = $totalpromofinal;
                    $totalfinal = $totalpromofinal;
                }
                if ($contraspadre[0]->pago == 0) {
                    $totalfinalhijos = $totalpromofinal;
                    $totalfinal = $totalpromofinal;
                }

                $hijocontra = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion' AND estatus_estadocontrato = 0");
                $pagohijo = $hijocontra[0]->pago;
                $estatushijo = $hijocontra[0]->estatus;

                if ($estatushijo == 0) {
                    DB::table('contratos')->where([['id', '=', $relacion], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus' => 1, 'total' => $totalfinal, 'totalpromocion' => $totalpromofinal, 'promocionterminada' => 1
                    ]);
                    DB::table('contratos')->where([['idcontratorelacion', '=', $relacion], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus' => 1, 'total' => $totalfinalhijos, 'totalpromocion' => $totalpromofinal, 'promocionterminada' => 1
                    ]);
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus' => 1, 'estatus_estadocontrato' => 1, 'total' => $totalfinalhijos, 'totalpromocion' => $totalpromofinal, 'promocionterminada' => 1
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $relacion])->with('bien', 'Se han creado todos los contratos ');
                }
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $relacion])->with('bien', 'Se han creado todos los contratos');
            } else {

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 1,
                ]);
                return view('administracion.historialclinico.nuevohijo', ['idFranquicia' => $idFranquicia, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                    'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'armazones' => $armazones, 'contratos' => $contratos,
                    'ultimoOptometrista' => $ultimoOptometrista, 'ultimaZona' => $ultimaZona, 'zonas' => $zonas, 'idContrato' => $idContrato, 'idcontratopadre' => $relacion]);
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function agregarpromocion($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $rules = [
                'promocion' => 'required|integer',
            ];
            if (request('promocion') == 0) {
                return back()->withErrors(['promocion' => 'Elegir una promoción'])->withInput($request->all());

            }
            request()->validate($rules);
            $abonospromo = DB::select("SELECT COUNT(a.id) as conteo FROM abonos a INNER JOIN contratos c ON a.id_contrato = c.id
            WHERE CAST(a.tipoabono as SIGNED) != 7 AND (c.id = '$idContrato' OR c.idcontratorelacion = '$idContrato')");
            if ($abonospromo[0]->conteo > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede agregar con abonos ya registrados en los contratos de la promoción');
            }
            $randomId = $this->getPromocionContratoId();

            $promo = request('promocion');
            $creacion = Carbon::now();
            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                'id_promocion' => $promo
            ]);
            DB::table('promocion')->where([['id', '=', $promo], ['id_franquicia', '=', $idFranquicia]])->update([
                'asignado' => 1
            ]);
            DB::table('promocioncontrato')->insert([
                'id' => $randomId, 'id_contrato' => $idContrato, 'id_franquicia' => $idFranquicia, 'id_promocion' => $promo, 'estado' => 1, 'created_at' => $creacion
            ]);
            return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'la promoción se agrego correctamente.');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function getContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom();
            $existente = DB::select("select id from contratos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }   // Comparar si ya existe el id en la base de datos

    private function generadorRandom($length = 10)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rAND(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    // Generador rANDom

    public function crearcontrato($idFranquiciaContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $rules = [
                'zona' => 'required',
                'nombre' => 'required|string|max:255',
                'optometrista' => 'required|integer',
                'calle' => 'required|string|max:255',
                'numero' => 'required|string|min:1|max:255',
                'formapago' => 'required|string|min:1|max:255',
                'departamento' => 'required|string|max:255',
                'alladode' => 'required|string|max:255',
                'frentea' => 'required|string|max:255',
                'entrecalles' => 'required|string|max:255',
                'colonia' => 'required|string|max:255',
                'localidad' => 'required|string|max:255',
                'telefono' => 'required|string|size:10|regex:/[0-9]/',
                'tr' => 'required|string|size:10|regex:/[0-9]/',
                'casatipo' => 'required|string|max:255',
                'nr' => 'required|string|max:255',
                'casacolor' => 'required|string|max:255',
                'fotoine' => 'required|image|mimes:png',
                'fotoineatras' => 'required|image|mimes:png',
                'fotocasa' => 'required|image|mimes:png',
                'comprobantedomicilio' => 'required|image|mimes:png',
            ];
            if (request('tarjetapension') != null && request('formapago') != 'Mensual') {
                return back()->withErrors(['tarjetapension' => 'Solo se permite con forma de pago mensual'])->withInput($request->all());
            }
            if (request('formapago') == 'Seleccionar') {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago'])->withInput($request->all());
            }
            if (request('tarjetapensionatras') != null && request('formapago') != 'Mensual') {
                return back()->withErrors(['tarjetapensionatras' => 'Solo se permite con forma de pago mensual'])->withInput($request->all());
            }
            if (request('tarjetapension') != null && request('tarjetapensionatras') == null) {
                return back()->withErrors(['tarjetapensionatras' => 'Llenar ambos campos de la tarjeta'])->withInput($request->all());
            }
            if (request('tarjetapension') == null && request('tarjetapensionatras') != null) {
                return back()->withErrors(['tarjetapensionatras' => 'Llenar ambos campos de la tarjeta'])->withInput($request->all());
            }
            if (request('zona') == 'Seleccionar') {
                return back()->withErrors(['zona' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
            }
            if (request('optometrista') == 'Seleccionar') {
                return back()->withErrors(['optometrista' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
            }
            request()->validate($rules);
            if (strlen(request('zona')) > 0 && strlen(request('optometrista')) && strlen(request('formapago')) > 0 && strlen(request('nombre')) > 0 && strlen(request('calle')) > 0 && strlen(request('numero')) > 0
                && strlen(request('alladode')) > 0 && strlen(request('frentea')) > 0 && strlen(request('entrecalles')) > 0 && strlen(request('colonia')) > 0
                && strlen(request('localidad')) > 0 && strlen(request('telefono')) > 0 && strlen(request('casatipo')) > 0 && strlen(request('casacolor')) > 0
                && strlen(request('fotoine')) && strlen(request('fotocasa')) && strlen(request('comprobantedomicilio'))) {


                try {

                    $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                    $randomId = $this->getContratoId();


                    $fotoBruta = 'Foto-Ine-Frente-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                    $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');

                    $fotoBruta = 'Foto-Ine-Atras-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                    $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');

                    $fotoBruta = 'Foto-Casa-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                    $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta, 'disco');

                    $fotoBruta = 'Foto-comprobantedomicilio-Contrato-' . $randomId . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                    $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedomicilio', $fotoBruta, 'disco');

                    $tarjetapension = '';   // by default empty
                    if (request('tarjetapension') != null && request('formapago') == 'Mensual') {
                        $fotoBruta = 'Foto-Tarjetapension-Frente-Contrato-' . $randomId . '-' . time() . '.' . request()->file('tarjetapension')->getClientOriginalExtension();
                        $tarjetapension = request()->file('tarjetapension')->storeAs('uploads/imagenes/contratos/tarjetapension', $fotoBruta, 'disco');
                    }

                    $tarjetapensionatras = '';   // by default empty
                    if (request('tarjetapensionatras') != null && request('formapago') == 'Mensual') {
                        $fotoBruta = 'Foto-Tarjetapension-Atras-Contrato-' . $randomId . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta, 'disco');
                    }


                    $datos = 1;
                    $creacion = Carbon::now();
                    $usuarioId = Auth::user()->id;
                    $usuarioNombre = Auth::user()->name;
                    DB::table('contratos')->insert([
                        'id' => $randomId, 'datos' => $datos, 'id_franquicia' => $idFranquiciaContrato, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => request('zona'), 'id_promocion' => request('promocion'), 'id_optometrista' => request('optometrista'),
                        'nombre' => request('nombre'), 'pago' => request('formapago'), 'calle' => request('calle'), 'numero' => request('numero'), 'depto' => request('departamento'), 'alladode' => request('alladode'), 'frentea' => request('frentea'),
                        'entrecalles' => request('entrecalles'), 'colonia' => request('colonia'), 'localidad' => request('localidad'), 'telefono' => request('telefono'), 'casatipo' => request('casatipo'), 'casacolor' => request('casacolor'), 'created_at' => $creacion,
                        'nombrereferencia' => request('nr'), 'telefonoreferencia' => request('tr'), 'fotoine' => $fotoine, 'fotocasa' => $fotocasa, 'comprobantedomicilio' => $comprobantedomicilio, 'tarjeta' => $tarjetapension, 'fotoineatras' => $fotoineatras, 'tarjetapensionatras' => $tarjetapensionatras, 'contador' => 1
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquiciaContrato, 'idContrato' => $randomId])->with('bien', 'El contrato se actualizo correctamente.');
                } catch (\Exception $e) {
                    \Log::info("Error: " . $e->getMessage());
                    return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                }
            } else {
                return back()->with('alerta', 'Para continuar es necesario llenar todos los campos.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function crearcontrato2($idFranquiciaContrato, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                // 'nombre'=>'required|string|max:255',
                // 'telefono' => 'required|string|size:10|regex:/[0-9]/',
            ];
            request()->validate($rules);

            try {

                $contra = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, c.telefonoreferencia, c.nombrereferencia,
                    c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador,
                    (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
                    FROM contratos c
                    INNER JOIN zonas z
                    ON z.id = c.id_zona
                    INNER JOIN users u
                    ON u.id = c.id_optometrista
                    INNER JOIN promocion pr
                    ON pr.id = c.id_promocion
                    WHERE c.datos = 1
                    AND c.id = '$idContrato'
                    AND c.id_franquicia = '$idFranquiciaContrato'");
                $zona = $contra[0]->zona;
                $optometrista = $contra[0]->id_optometrista;
                $calle = $contra[0]->calle;
                $pago = $contra[0]->pago;
                $numero = $contra[0]->numero;
                $depto = $contra[0]->depto;
                $alladode = $contra[0]->alladode;
                $frentea = $contra[0]->frentea;
                $entrecalles = $contra[0]->entrecalles;
                $colonia = $contra[0]->colonia;
                $localidad = $contra[0]->localidad;
                $casatipo = $contra[0]->casatipo;
                $casacolor = $contra[0]->casacolor;
                $contador = $contra[0]->contador;
                $telefonoR = $contra[0]->telefonoreferencia;
                $nombreR = $contra[0]->nombrereferencia;
                $suma = $contador + 1;

                $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                $randomId = $this->getContratoId();
                $datos = 1;
                $creacion = Carbon::now();
                $usuarioId = Auth::user()->id;
                $usuarioNombre = Auth::user()->name;

                DB::table('contratos')->insert([
                    'id' => $randomId, 'datos' => $datos, 'id_franquicia' => $idFranquiciaContrato, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => $zona, 'id_optometrista' => $optometrista,
                    'nombre' => request('nombre'), 'pago' => $pago, 'calle' => $calle, 'numero' => $numero, 'depto' => $depto, 'alladode' => $alladode, 'frentea' => $frentea,
                    'entrecalles' => $entrecalles, 'colonia' => $colonia, 'localidad' => $localidad, 'telefono' => request('telefono'), 'casatipo' => $casatipo, 'casacolor' => $casacolor, 'created_at' => $creacion,
                    'idcontratorelacion' => $idContrato, 'nombrereferencia' => $nombreR, 'telefonoreferencia' => $telefonoR
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquiciaContrato]])->update([
                    'contador' => $suma
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquiciaContrato, 'idContrato' => $randomId])->with('bien', 'El contrato se actualizo correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function filtrarlistacontrato($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4)) {
            $contratoslaboratorio = null;
            $contratosconfirmaciones = null;
            $cbAtrasado = null;
            $cbPrioritario = null;
            $cbPeriodo = null;
            $cbEntrega = null;
            $cbLaboratorio = null;
            $cbConfirmacion = null;
            $cbTodos = null;
            $zonaU = null;

            $arrayCheckBox = array();

            $filtro = request('filtro');
            $now = Carbon::now();
            $contratosgeneral = DB::select("SELECT * FROM contratos ");
            if (((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) {
                $idUsuario = Auth::user()->id;
                $contratosatrasados = "";
                $contratosprioritarios = "";
                $contratosperiodo = "";
                $contratosentregar = "";

                $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion,  c.fechacobrofin, c.fechacobroini,
                 c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono, c.estatus_estadocontrato, c.diaseleccionado, c.total, c.fechaentrega, c.ultimoabono,
                 (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                 (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                 (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                 (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                 (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                 (SELECT p.nombre from historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id limit 1) as paquete,
                 (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                 FROM contratos c
                 INNER JOIN zonas z
                 ON z.id = c.id_zona
                 INNER JOIN estadocontrato e
                 ON e.estatus = c.estatus_estadocontrato
                 WHERE c.datos = 1
                 AND c.estatus_estadocontrato  < 2
                 AND c.id_franquicia = '$idFranquicia'
                 AND (c.id LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%')
                 AND c.id_usuariocreacion = '$idUsuario'
                 order by c.created_at desc
                 ");
            } elseif (((Auth::user()->rol_id) == 4)) {

                $arrayContratos = self::obtenerListaContratosConOSinFiltro($idFranquicia, true, $filtro, $arrayCheckBox);

                $contratosprioritarios = $arrayContratos[0];
                $contratosatrasados = $arrayContratos[1];
                $contratosperiodo = $arrayContratos[2];
                $contratosentregar = $arrayContratos[3];
                $contratos = $arrayContratos[4];

            } else {

                $cbAtrasado = 1;
                $cbPrioritario = 1;
                $cbPeriodo = 1;
                $cbEntrega = 1;
                $cbLaboratorio = 1;
                $cbConfirmacion = 1;
                $cbTodos = 1;

                array_push($arrayCheckBox, $cbAtrasado);
                array_push($arrayCheckBox, $cbPrioritario);
                array_push($arrayCheckBox, $cbPeriodo);
                array_push($arrayCheckBox, $cbEntrega);
                array_push($arrayCheckBox, $cbLaboratorio);
                array_push($arrayCheckBox, $cbConfirmacion);
                array_push($arrayCheckBox, $cbTodos);
                array_push($arrayCheckBox, $zonaU);

                $arrayContratos = self::obtenerListaContratosConOSinFiltro($idFranquicia, false, $filtro, $arrayCheckBox);

                $contratosprioritarios = $arrayContratos[0];
                $contratosatrasados = $arrayContratos[1];
                $contratosperiodo = $arrayContratos[2];
                $contratosentregar = $arrayContratos[3];
                $contratoslaboratorio = $arrayContratos[4];
                $contratosconfirmaciones = $arrayContratos[5];
                $contratos = $arrayContratos[6];
                /*$zonauser = Auth::user()->id_zona;
                $semana = $now->weekOfYear;
                $contratosprioritarios = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (2,5)
                AND c.diaseleccionado = STR_TO_DATE('$now','%Y-%m-%d')
                AND c.id_franquicia = '$idFranquicia'
                AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%')
                AND c.total > 0
                order by c.created_at desc
                ");
                $contratosatrasados = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato = 4
                AND c.id_franquicia = '$idFranquicia'
                AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%')
                AND c.total > 0
                order by c.created_at desc
                ");
                $contratosperiodo = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (2,5)
                AND (c.fechacobroini IS NOT NULL)
                AND COALESCE(c.diaseleccionado,0) != STR_TO_DATE('$now','%Y-%m-%d')
                AND (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
                AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d') or
                STR_TO_DATE(c.ultimoabono,'%Y-%m-%d')  = STR_TO_DATE('$now','%Y-%m-%d'))
                AND c.id_franquicia = '$idFranquicia'
                AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%')
                AND c.total > 0
                order by c.created_at desc
                ");
                $contratosentregar = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato = 12
                AND c.id_franquicia = '$idFranquicia'
                AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%')
                order by c.created_at desc
                ");
                $contratoslaboratorio = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso,   c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.ultimoabono,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias,
                (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (7,10,11)
                AND c.id_franquicia = '$idFranquicia'
                AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%')
                order by c.created_at desc
                ");
                $contratos = DB::table('contratos as c')
                    ->join('zonas', 'zonas.id', '=', 'c.id_zona')
                    ->join('estadocontrato', 'estadocontrato.estatus', '=', 'c.estatus_estadocontrato')
                    ->select('c.id', 'c.datos', 'c.id_franquicia', 'c.id_usuariocreacion', 'c.nombre_usuariocreacion', 'zonas.zona', 'c.nombre', 'c.calle', 'c.numero', 'c.estatus', 'c.totalpromocion', 'estadocontrato.descripcion', 'c.fechacobrofin', 'c.fechacobroini',
                        'c.depto', 'c.alladode', 'c.frentea', 'c.entrecalles', 'c.colonia', 'c.localidad', 'c.telefono', 'c.casatipo', 'c.casacolor', 'c.created_at', 'c.updated_at', 'c.idcontratorelacion', 'c.totalabono', 'c.estatus_estadocontrato', 'c.diaseleccionado', 'c.total', 'c.fechaentrega', 'c.ultimoabono',
                        (DB::raw("(SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id)   AS dias")),
                        (DB::raw("(SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo")),
                        (DB::raw("(SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha")))
                    ->where('c.datos', '=', '1')
                    ->whereRaw("c.estatus_estadocontrato IN (0,1,2,3,5,6,8,14)")
                    ->whereRaw("COALESCE(c.diaseleccionado,0) != STR_TO_DATE('$now','%Y-%m-%d')")
                    ->whereRaw("(c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR zonas.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR STR_TO_DATE(c.created_at,'%Y-%m-%d') LIKE '%$filtro%')")
                    ->whereRaw("c.id_franquicia = '$idFranquicia'")
                    ->orderBy('c.created_at', 'DESC')
                    ->paginate(20);*/
            }

            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia'");
            $franquiciaContratos = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.contrato.tabla', ['contratos' => $contratos, 'franquiciaContratos' => $franquiciaContratos, 'contratosgeneral' => $contratosgeneral,
                'contratosperiodo' => $contratosperiodo, 'now' => $now, 'contratosatrasados' => $contratosatrasados, 'contratosprioritarios' => $contratosprioritarios,
                'contratosentregar' => $contratosentregar, 'contratoslaboratorio' => $contratoslaboratorio, 'contratosconfirmaciones' => $contratosconfirmaciones,
                'zonas' => $zonas, 'cbAtrasado' => $cbAtrasado, 'cbPrioritario' => $cbPrioritario, 'cbPeriodo' => $cbPeriodo, 'cbEntrega' => $cbEntrega, 'cbLaboratorio' => $cbLaboratorio,
                'cbConfirmacion' => $cbConfirmacion, 'cbTodos' => $cbTodos, 'zonaU' => $zonaU, 'idFranquicia' => $idFranquicia]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function filtrarlistacontratocheckbox($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            $arrayCheckBox = array();

            $cbAtrasado = request('cbAtrasado');
            $cbPrioritario = request('cbPrioritario');
            $cbPeriodo = request('cbPeriodo');
            $cbEntrega = request('cbEntrega');
            $cbLaboratorio = request('cbLaboratorio');
            $cbConfirmacion = request('cbConfirmacion');
            $cbTodos = request('cbTodos');
            $zonaU = request('$zonaU');

            array_push($arrayCheckBox, $cbAtrasado);
            array_push($arrayCheckBox, $cbPrioritario);
            array_push($arrayCheckBox, $cbPeriodo);
            array_push($arrayCheckBox, $cbEntrega);
            array_push($arrayCheckBox, $cbLaboratorio);
            array_push($arrayCheckBox, $cbConfirmacion);
            array_push($arrayCheckBox, $cbTodos);
            array_push($arrayCheckBox, $zonaU);

            $now = Carbon::now();
            $contratosgeneral = DB::select("SELECT * FROM contratos");

            $arrayCheckBox = self::obtenerListaContratosConOSinFiltro($idFranquicia, false, null, $arrayCheckBox);

            $contratosprioritarios = $arrayCheckBox[0];
            $contratosatrasados = $arrayCheckBox[1];
            $contratosperiodo = $arrayCheckBox[2];
            $contratosentregar = $arrayCheckBox[3];
            $contratoslaboratorio = $arrayCheckBox[4];
            $contratosconfirmaciones = $arrayCheckBox[5];
            $contratos = $arrayCheckBox[6];

            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia'");
            $franquiciaContratos = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.contrato.tabla', ['contratos' => $contratos, 'franquiciaContratos' => $franquiciaContratos, 'contratosgeneral' => $contratosgeneral,
                'contratosperiodo' => $contratosperiodo, 'now' => $now, 'contratosatrasados' => $contratosatrasados, 'contratosprioritarios' => $contratosprioritarios, 'contratosentregar' => $contratosentregar,
                'contratoslaboratorio' => $contratoslaboratorio, 'contratosconfirmaciones' => $contratosconfirmaciones, 'zonas' => $zonas,
                'cbAtrasado' => $cbAtrasado, 'cbPrioritario' => $cbPrioritario, 'cbPeriodo' => $cbPeriodo, 'cbEntrega' => $cbEntrega, 'cbLaboratorio' => $cbLaboratorio,
                'cbConfirmacion' => $cbConfirmacion, 'cbTodos' => $cbTodos, 'zonaU' => $zonaU, 'idFranquicia' => $idFranquicia]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function vercontrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 13 || (Auth::user()->rol_id) == 12 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 4) {
            $now = Carbon::now();
            $nowparce = Carbon::parse($now)->format('Y-m-d');

            $this->calculoTotal($idContrato, $idFranquicia);

            $historialesclinicos = DB::select("SELECT h.id, c.nombre, h.observaciones , h.edad, h.fechaentrega, c.telefono, h.id_paquete, h.created_at, h.diagnostico,h.observaciones,h.observacionesinterno FROM historialclinico h
                                                inner join contratos c
                                                on c.id = h.id_contrato
                                                WHERE id_contrato ='$idContrato'
                                                ORDER BY created_at ASC");
            $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato' AND estatus_estadocontrato = 0 limit 1");

            if (((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {
                $promociones = DB::select("SELECT * FROM promocion where id_franquicia = '$idFranquicia' AND status != 2 AND id_tipopromocionusuario >= 0");
            } else {
                $promociones = DB::select("SELECT * FROM promocion where id_franquicia = '$idFranquicia' AND status != 2 AND id_tipopromocionusuario = 0");
            }

            $abonos = DB::select("SELECT * FROM abonos where id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' order by created_at desc");

            $abonostarjetameses = DB::select("SELECT count(id) as cont FROM abonos where id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' AND tipoabono != 7");

            $abonoperiodo = DB::select("SELECT COALESCE(SUM(a.abono),0) as total
        FROM abonos a
        INNER JOIN contratos c
        ON c.id = a.id_contrato
        WHERE a.id_franquicia = '$idFranquicia' AND a.id_contrato = '$idContrato'
        AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
        AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
        AND tipoabono = 3");
            $dentroRango = DB::select("SELECT id FROM contratos where id = '$idContrato' AND
         ((STR_TO_DATE('$now','%Y-%m-%d') = STR_TO_DATE(diaseleccionado,'%Y-%m-%d')) OR
        (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(fechacobroini,'%Y-%m-%d')) AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(fechacobrofin,'%Y-%m-%d'))");
            $promocioncontrato = DB::select("SELECT id_promocion as id, p.titulo, p.asignado, p.inicio, p.fin, p.status,pr.id_contrato, pr.estado
        FROM promocioncontrato  pr
        inner join promocion p on pr.id_promocion = p.id
        WHERE id_contrato = '$idContrato'");
            $historialcontrato = DB::select("SELECT id_usuarioC, h.id, h.cambios, u.name, h.created_at, h.id_contrato
        from historialcontrato h
        inner join users u on h.id_usuarioC = u.id
        WHERE id_contrato = '$idContrato' order by created_at desc");
            $productos = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id_tipoproducto != 1");
            $contratoproducto = DB::select("SELECT c.id, c.id_contrato, c.created_at, c.id_franquicia, p.nombre, p.precio, c.piezas, c.total, p.preciop
        FROM contratoproducto c
        inner join producto p on c.id_producto = p.id
        WHERE id_contrato = '$idContrato'");


            if (((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) {
                \Log::info("Entro a VER CONTRATO");
                $idUsuario = Auth::user()->id;
                $contrato = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero,c.total, c.contador, c.id_promocion, c.totalproducto, c.fechacobroini, c.fechacobrofin, c.totalabono, c.costoatraso, c.promocionterminada, c.subscripcion,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.nombrereferencia,c.telefonoreferencia,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.pago,c.tarjeta,u.name,c.id_optometrista,c.created_at,c.updated_at,c.idcontratorelacion, c.estatus_estadocontrato, c.ultimoabono, c.enganche, c.entregaproducto,
            (IFNULL(costoatraso,0) + 150) as semanaatraso,
            (IFNULL(costoatraso,0) + 300) as quincenaatraso,
            (IFNULL(costoatraso,0) + 450) as mesatraso,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as tiemporeal
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN users u
            ON u.id = c.id_optometrista
            WHERE c.datos = 1
            AND c.id_franquicia = '$idFranquicia'
            AND c.id_usuariocreacion = '$idUsuario'
            AND c.id = '$idContrato'
            AND c.estatus_estadocontrato NOT IN(3,6)
            ");
                $promo = DB::select("SELECT c.id,c.datos,c.id_promocion, p.armazones
            FROM contratos c
            INNER JOIN promocion p
            ON p.id = c.id_promocion
            WHERE c.datos = 1
            AND c.id_franquicia = '$idFranquicia'
            AND c.id_usuariocreacion = '$idUsuario'
            AND c.id = '$idContrato'
            ");
            } else {
                $contrato = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero,c.total, c.contador,  c.id_promocion, c.estatus,  c.totalproducto, c.fechacobroini, c.fechacobrofin, c.totalabono, c.costoatraso,  c.promocionterminada, c.subscripcion,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.nombrereferencia,c.telefonoreferencia,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.pago,c.tarjeta,u.name,c.id_optometrista,c.created_at,c.updated_at, c.idcontratorelacion, c.estatus_estadocontrato, c.ultimoabono, c.enganche, c.entregaproducto,
              -- (IFNULL((SELECT CASE WHEN TOTALPROMOCION < 0 THEN NULL ELSE TOTALPROMOCION END FROM contratos co WHERE co.id = c.id),TOTALHISTORIAL) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as tiemporeal
            (IFNULL(costoatraso,0) + 150) as semanaatraso,
            (IFNULL(costoatraso,0) + 300) as quincenaatraso,
            (IFNULL(costoatraso,0) + 450) as mesatraso,
            (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
            (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as tiemporeal
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN users u
            ON u.id = c.id_optometrista
            WHERE c.datos = 1
            AND c.id_franquicia = '$idFranquicia'
            AND c.id = '$idContrato'
            ");
                $promo = DB::select("SELECT c.id,c.datos,c.id_promocion, p.armazones
              FROM contratos c
              INNER JOIN promocion p
              ON p.id = c.id_promocion
              INNER JOIN users u
              ON u.id = c.id_optometrista
              WHERE c.datos = 1
              AND c.id_franquicia = '$idFranquicia'
              AND c.id = '$idContrato'
              ");
            }
            if ($contrato == null) {
                return back()->with("alerta", "No tienes acceso al contrato en este momento.");
            }
            $rela = $contrato[0]->idcontratorelacion;
            $contraspadre5 = DB::select("SELECT c.id, c.contador, c.id_promocion, pr.armazones FROM contratos c INNER JOIN promocion pr
        ON pr.id = c.id_promocion
        WHERE c.id_franquicia = '$idFranquicia'
        AND c.id = '$rela'");
            $contraspadre2 = DB::select("SELECT c.id, c.contador, pr.armazones FROM contratos c INNER JOIN promocion pr
        ON pr.id = c.id_promocion
        WHERE c.id_franquicia = '$idFranquicia'
        AND c.id = '$idContrato'");
            $contratosterminadostodos = DB::select("SELECT id FROM contratos
        WHERE id_franquicia = '$idFranquicia'
        AND (idcontratorelacion = '$idContrato'
        OR id = '$idContrato')
        AND  estatus_estadocontrato = 0");
            $contratohoy = DB::select("SELECT created_at FROM contratos WHERE id = '$idContrato' AND STR_TO_DATE(created_at,'%Y-%m-%d') = '$nowparce'");
            if ((((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) && $contratohoy == null && $contrato[0]->estatus_estadocontrato != 0) {
                return redirect()->route('listacontrato', $idFranquicia)->with('alerta', 'Ya no puedes consultar el contrato terminado');
            }
            if (((Auth::user()->rol_id) == 4) && $contrato[0]->estatus_estadocontrato == 0) {
                return redirect()->route('listacontrato', $idFranquicia)->with('alerta', 'No puedes ingresar a contratos no terminados');
            }

            $historialC = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.otroM, h.molestiaotro, h.ultimoexamen, p.nombre, p.id
        FROM historialclinico h
        INNER JOIN paquetes p
        ON p.id = h.id_paquete
        WHERE id_contrato = '$idContrato'");
            $hc2 = DB::select("SELECT COUNT(id) as canti FROM historialclinico WHERE id_contrato = '$idContrato'");
            if ($hc2[0]->canti == 1 && $historialC[0]->id == 6) {

                $optometristas = DB::select("SELECT u.id,u.name
            FROM users u
            INNER JOIN usuariosfranquicia uf
            ON u.id = uf.id_usuario
            WHERE u.rol_id = 12
            AND uf.id_franquicia = '$idFranquicia' ");
                $datosContrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato'");

                $historialC = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.otroM, h.molestiaotro, h.ultimoexamen, p.nombre
            FROM historialclinico h
            INNER JOIN paquetes p
            ON p.id = h.id_paquete
            WHERE id_contrato = '$idContrato'");
                $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
                $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
                $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
                $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
                $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
                $armazones = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id_tipoproducto = '1'");

                return view('administracion.historialclinico.nuevo2', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico, 'dentroRango' => $dentroRango,
                    'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'datosContrato' => $datosContrato, 'armazones' => $armazones, 'historialC' => $historialC, 'contratosterminadostodos' => $contratosterminadostodos]);

            }
            return view('administracion.historialclinico.tabla', ['historialesclinicos' => $historialesclinicos, 'historialcontrato' => $historialcontrato, 'abonos' => $abonos, 'promociones' => $promociones, 'promocioncontrato' => $promocioncontrato, 'idFranquicia' => $idFranquicia, 'contratoproducto' => $contratoproducto,
                'idContrato' => $idContrato, 'contrato' => $contrato, 'productos' => $productos, 'now' => $now, 'contrashijos' => $contrashijos, 'promo' => $promo, 'abonoperiodo' => $abonoperiodo, 'contraspadre5' => $contraspadre5,
                'contraspadre2' => $contraspadre2, 'contratosterminadostodos' => $contratosterminadostodos, 'dentroRango' => $dentroRango, 'abonostarjetameses' => $abonostarjetameses]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function atrasarContrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {
            $existeContrato = DB::select("SELECT id,estatus_estadocontrato,pago FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");
            if ($existeContrato != null) { //Existe el contrato?
                if ($existeContrato[0]->estatus_estadocontrato == 2) { //EL estatus el contrato es ENTREGADO?
                    if ($existeContrato[0]->pago == 1) { // La forma de pago es semanal?
                        DB::table("contratos")->where("id", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                            "costoatraso" => "150",
                            'estatus_estadocontrato' => 4
                        ]);
                        $randomId2 = $this->getHistorialContratoId();
                        $usuarioId = Auth::user()->id;
                        $fechaActual = Carbon::now();
                        DB::table('historialcontrato')->insert([
                            'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $fechaActual, 'cambios' => "Se cambio el estatus del contrato a 'atrasado'"
                        ]);
                        return back()->with("bien", "El estatus del contrato se actualizo correctamente y ya pueden abonar menos de la cantidad recomendada.");
                    }
                    //La forma de pago no es semanal
                    return back()->with("alerta", "Para atrasar el contrato debe tener una forma de pago semanal.");
                }
                // EL estatus del contrato es diferente al de entregado
                return back()->with("alerta", "Para atrasar el contrato es necesario tener un estatus de 'Entregado'");
            }
            //EL contrato no existe
            return back()->with("alerta", "No se encontro el contrato.");
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratoactualizar($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {

            $zonas = DB::select("SELECT * FROM zonas where id_franquicia = '$idFranquicia'");
            $promociones = DB::select("SELECT * FROM promocion where id_franquicia = '$idFranquicia' AND status != 2");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");

            //Historiales clinicos
            $historiales =  DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon, hc.id_producto,
                                                    hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,hc.observacionesinterno,
                                                    (SELECT color FROM producto p WHERE p.id = hc.id_producto) as colorarmazon,
                                                    (SELECT p.nombre FROM paquetes p WHERE p.id = hc.id_paquete AND p.id_franquicia = '$idFranquicia' LIMIT 1) as paquete
                                                    FROM historialclinico hc WHERE id_contrato = '$idContrato'");
            //Productos tipo armazon
            $armazones = DB::select("SELECT * FROM producto WHERE id_tipoproducto = '1' order by nombre");

            return view('administracion.contrato.actualizarcontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato, 'contrato' => $contrato, 'promociones' => $promociones, 'franquiciaAdmin' => $franquiciaAdmin, 'zonas' => $zonas, 'optometristas' => $optometristas, 'historiales' => $historiales, 'armazones' => $armazones]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratoeditar($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {

            request()->validate([
                'zona' => 'required',
                'nombre' => 'required|string|max:255',
                'optometrista' => 'required|integer',
                'calle' => 'required|string|max:255',
                'numero' => 'required|string|min:1|max:255',
                'departamento' => 'required|string|max:255',
                'alladode' => 'required|string|max:255',
                'frentea' => 'required|string|max:255',
                'entrecalles' => 'required|string|max:255',
                'colonia' => 'required|string|max:255',
                'localidad' => 'required|string|max:255',
                'telefono' => 'required|string|size:10|regex:/[0-9]/',
                'tr' => 'required|string|size:10|regex:/[0-9]/',
                'casatipo' => 'required|string|max:255',
                'nr' => 'required|string|max:255',
                'casacolor' => 'required|string|max:255',
                'fotoine' => 'nullable|image|mimes:jpg',
                'fotocasa' => 'nullable|image|mimes:jpg',
                'tarjeta' => 'nullable|image|mimes:jpg',
                'pagare' => 'nullable|image|mimes:jpg',
                // 'promocion'=>'nullable|inte',
                'comprobantedomicilio' => 'nullable|image|mimes:jpg',
            ]);

            try {

                $contrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");
                $fotoine = "";
                $fotoineatras = "";
                $fotocasa = "";
                $comprobantedomicilio = "";
                $fotopagare = "";
                $tarjeta = "";
                $tarjetapensionatras = "";
                $ine = false;
                $ineatras = false;
                $casa = false;
                $comprobante = false;
                $tarjetaP = false;
                $tarjetaPatras = false;
                $randomId2 = $this->getHistorialContratoId();

                //foto ine frente
                if (strlen($contrato[0]->fotoine) > 0) {
                    if (request()->hasFile('fotoine')) {
                        Storage::disk('disco')->delete($contrato[0]->fotoine);
                        $fotoBruta = 'Foto-ine-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                        $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');
                        $ine = true;
                    } else {
                        $fotoine = $contrato[0]->fotoine;
                        $ine = true;
                    }
                } else {
                    if (request()->hasFile('fotoine')) {
                        $fotoBruta = 'Foto-ine-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                        $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');
                        $ine = true;
                    } else {
                        $foto = false;
                    }
                }

                //foto ine atras
                if (strlen($contrato[0]->fotoineatras) > 0) {
                    if (request()->hasFile('fotoineatras')) {
                        Storage::disk('disco')->delete($contrato[0]->fotoineatras);
                        $fotoBruta = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                        $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');
                        $ineatras = true;
                    } else {
                        $fotoineatras = $contrato[0]->fotoineatras;
                        $ineatras = true;
                    }
                } else {
                    if (request()->hasFile('fotoineatras')) {
                        $fotoBruta = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                        $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');
                        $ineatras = true;
                    } else {
                        $ineatras = false;
                    }
                }

                //foto pagare
                if (strlen($contrato[0]->pagare) > 0) {
                    if (request()->hasFile('pagare')) {
                        Storage::disk('disco')->delete($contrato[0]->pagare);
                        $fotoBruta5 = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta5, 'disco');
                        $pagare2 = true;
                    } else {
                        $fotopagare = $contrato[0]->pagare;
                        $pagare2 = true;
                    }
                } else {
                    if (request()->hasFile('pagare')) {
                        $fotoBruta5 = 'Foto-pagare-' . $contrato[0]->id . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta, 'disco');
                        $pagare2 = true;
                    } else {
                        $pagare2 = false;
                    }
                }

                //foto casa
                if (strlen($contrato[0]->fotocasa) > 0) {
                    if (request()->hasFile('fotocasa')) {
                        Storage::disk('disco')->delete($contrato[0]->fotocasa);
                        $fotoBruta1 = 'Foto-casa-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                        $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta1, 'disco');
                        $casa = true;
                    } else {
                        $fotocasa = $contrato[0]->fotocasa;
                        $casa = true;
                    }
                } else {
                    if (request()->hasFile('fotocasa')) {
                        $fotoBruta1 = 'Foto-casa-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                        $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta1, 'disco');
                        $casa = true;
                    } else {
                        $casa = false;
                    }
                }
                //comprobante de domicilio
                if (strlen($contrato[0]->comprobantedomicilio) > 0) {
                    if (request()->hasFile('comprobantedomicilio')) {
                        Storage::disk('disco')->delete($contrato[0]->comprobantedomicilio);
                        $fotoBruta2 = 'Foto-comprobantedomicilio-' . $contrato[0]->id . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                        $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedocmicilio', $fotoBruta2, 'disco');
                        $comprobante = true;
                    } else {
                        $comprobantedomicilio = $contrato[0]->comprobantedomicilio;
                        $comprobante = true;
                    }
                } else {
                    if (request()->hasFile('comprobantedocmicilio')) {
                        $fotoBruta2 = 'Foto-comprobantedomicilio-' . $contrato[0]->id . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                        $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedocmicilio', $fotoBruta2, 'disco');
                        $comprobante = true;
                    } else {
                        $comprobante = false;
                    }
                }

                // tarjeta de pension frente
                if (strlen($contrato[0]->tarjeta) > 0) {
                    if (request()->hasFile('tarjeta')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjeta);
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjeta')->getClientOriginalExtension();
                        $tarjeta = request()->file('tarjeta')->storeAs('uploads/imagenes/contratos/tarjeta', $fotoBruta3, 'disco');
                        $tarjetaP = true;
                    } else {
                        $tarjeta = $contrato[0]->tarjeta;
                        $tarjetaP = true;
                    }
                } else {
                    if (request()->hasFile('tarjeta')) {
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjeta')->getClientOriginalExtension();
                        $tarjeta = request()->file('tarjeta')->storeAs('uploads/imagenes/contratos/tarjeta', $fotoBruta3, 'disco');
                        $tarjetaP = true;
                    } else {
                        $tarjetaP = false;
                    }
                }
                // tarjeta de pension atras
                if (strlen($contrato[0]->tarjetapensionatras) > 0) {
                    if (request()->hasFile('tarjetapensionatras')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjetapensionatras);
                        $fotoBruta3 = 'Foto-tarjetapensionatras' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta3, 'disco');
                        $tarjetaPatras = true;
                    } else {
                        $tarjetapensionatras = $contrato[0]->tarjetapensionatras;
                        $tarjetaPatras = true;
                    }
                } else {
                    if (request()->hasFile('tarjetapensionatras')) {
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta3, 'disco');
                        $tarjetaPatras = true;
                    } else {
                        $tarjetaPatras = false;
                    }
                }
                $datos = 1;
                $actualizar = Carbon::now();
                $usuarioId = Auth::user()->id;
                $usuarioNombre = Auth::user()->name;

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'datos' => $datos, 'id_franquicia' => $idFranquicia, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => request('zona'), 'id_optometrista' => request('optometrista'),
                    'nombre' => request('nombre'), 'calle' => request('calle'), 'numero' => request('numero'), 'depto' => request('departamento'), 'alladode' => request('alladode'), 'frentea' => request('frentea'),
                    'entrecalles' => request('entrecalles'), 'colonia' => request('colonia'), 'localidad' => request('localidad'), 'telefono' => request('telefono'), 'casatipo' => request('casatipo'), 'casacolor' => request('casacolor'),
                    'fotoine' => $fotoine, 'fotocasa' => $fotocasa, 'pagare' => $fotopagare, 'comprobantedomicilio' => $comprobantedomicilio, 'tarjeta' => $tarjeta, 'updated_at' => $actualizar, 'nombrereferencia' => request('nr'), 'telefonoreferencia' => request('tr'), 'correo' => request('correo'),
                    'fotoineatras' => $fotoineatras, 'tarjetapensionatras' => $tarjetapensionatras
                ]);

                //historial de contrato
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'Actualizo el contrato'
                ]);

                return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'El contrato se actualizo correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function desactivarPromocion($idFranquicia, $idContrato, $idPromocion)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $sql = "SELECT id_promocion as id, p.titulo, p.asignado, p.inicio, p.fin, p.status, pr.estado,pr.id as idpromo
            FROM promocioncontrato  pr
            inner join promocion p on pr.id_promocion = p.id
            WHERE id_contrato = '$idContrato'";
            $promocioncontrato = DB::select($sql);
            if ($promocioncontrato == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se actualizo correctamente.');
            }
            $promocioncontratoid = $promocioncontrato[0]->idpromo;
            $randomId2 = $this->getHistorialContratoId();
            try {
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $estado = $promocioncontrato[0]->estado;
                $abonos = $contrato[0]->totalabono;
                $totalcontra = $contrato[0]->total;
                $fechacontrato = DB::select("SELECT created_at FROM contratos where id = '$idContrato'");
                $abonospromo = DB::select("SELECT COUNT(a.id) as conteo FROM abonos a INNER JOIN contratos c ON a.id_contrato = c.id
                WHERE CAST(a.tipoabono as SIGNED) != 7 AND (c.id = '$idContrato' OR c.idcontratorelacion = '$idContrato')");
                $now = Carbon::now();
                $nowparce = Carbon::parse($now)->format('Y-m-d');
                $todayparce = Carbon::parse($fechacontrato[0]->created_at)->format('Y-m-d');
                if ($estado == 0 && $abonospromo[0]->conteo > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede agregar con abonos ya registrados en los contratos de la promoción');
                }
                if ($estado == 0 && $nowparce != $todayparce) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede activar la promoción, solo el dia de creación del contrato');
                }
                if ($estado == 1) {
                    DB::table('promocioncontrato')->where([['id', '=', $promocioncontratoid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estado' => 0
                    ]);
                    $this->calculoTotal($idContrato, $idFranquicia);
                    $estado = 0;
                } else if ($estado == 0) {
                    DB::table('promocioncontrato')->where([['id', '=', $promocioncontratoid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estado' => 1
                    ]);
                    $this->calculoTotal($idContrato, $idFranquicia);
                    $estado = 1;
                }
                $usuarioId = Auth::user()->id;
                $actualizar = Carbon::now();

                if ($estado == 0) {
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'Desactivo la promoción en el contrato'
                    ]);
                } else {
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'Activo la promoción en el contrato'
                    ]);
                }

                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'La promoción actualizo correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function calculoTotal($idContrato, $idFranquicia)
    {
        if($this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
            //Tiene promocion y esta activa
            $promocionterminada = DB::select("SELECT promocionterminada FROM contratos where id = '$idContrato'");
            if($promocionterminada != null) {
                if($promocionterminada[0]->promocionterminada == 1) {
                    //Promocion ha sido terminada
                    DB::update("UPDATE contratos
                        SET total = coalesce(totalpromocion,0)  + coalesce(totalproducto,0) - coalesce(totalabono,0)
                        WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                }else {
                    //Promocion no ha sido terminada
                    DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                }
            }
        }else {
            //No tiene promocion o existe la promocion pero esta desactivada
            DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
        }
    }

    public function eliminarPromocion($idFranquicia, $idContrato, $idPromocion)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $sql = "SELECT id_promocion as id, p.titulo, p.asignado, p.inicio, p.fin, p.status, pr.estado,pr.id as idpromo
            FROM promocioncontrato  pr
            inner join promocion p on pr.id_promocion = p.id
            WHERE id_contrato = '$idContrato'";
            $promocioncontrato = DB::select($sql);
            if ($idPromocion == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se encontro el registro de la promoción en el contrato');
            }
            if ($promocioncontrato == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se encontro el registro de la promoción en el contrato');
            }

            $promocioncontrato = DB::select($sql);
            $promotitulo = $promocioncontrato[0]->titulo;
            $promocioncontratoid = $promocioncontrato[0]->idpromo;
            $randomId2 = $this->getHistorialContratoId();
            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $existepromo = DB::delete("SELECT * FROM promocioncontrato WHERE id = '$promocioncontratoid' AND id_franquicia = '$idFranquicia'");


            try {
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'id_promocion' => null
                ]);
                DB::delete("DELETE FROM promocioncontrato WHERE id = '$promocioncontratoid' AND id_franquicia = '$idFranquicia'");
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'se elimino la promoción en el contrato ' . $promotitulo
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'La promoción se elimino correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function entregarContrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            try {
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $totalabono = $contrato[0]->totalabono;
                $total = $contrato[0]->total;
                $entregaproducto = $contrato[0]->entregaproducto;
                $estadocontrato = $contrato[0]->estatus_estadocontrato;
                $pago = $contrato[0]->pago;
                $estatus = $contrato[0]->estatus;
                $totalproductos = $contrato[0]->totalproducto;
                $diapago = $contrato[0]->diaseleccionado;
                $abono = request('abono');
                $adelanto = request('adelanto');
                $tot = $totalabono + $abono;
                $now = carbon::now();
                $nowparce = Carbon::parse($now)->format('Y-m-d');


                if ($pago == 0 && $estadocontrato == 12 && $total > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El pago es de contado favor de completar el saldo del contrato');
                }
                if ($totalabono == null && $contrato[0]->subscripcion == null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes abonar 150 al menos para entregar el producto');
                }
                if ($pago == 0 && $estatus == 1 && $estadocontrato == 1 && $total > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El pago es de contado favor de completar el saldo del contrato');
                }

                if ($entregaproducto == 1 || ($entregaproducto == 0 && $total == 0) || $contrato[0]->subscripcion != null) {
                    if ($total > 0) {
                        $estatuscontrato = 2;
                    } else {
                        $estatuscontrato = 5;
                    }
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus_estadocontrato' => $estatuscontrato, 'entregaproducto' => 1, 'fechaentrega' => $nowparce
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se entrego el producto al cliente correctamente.');

                } else {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes abonar al menos 150 para entregar el producto');
                }


            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function abonoAtrasado($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 4)) {

            try {
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 4, 'fechaatraso' => Carbon::now()
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se agrego el retraso en abonos de este contrato');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function cancelarContrato($idFranquicia, $idContrato)
    {
        $contrato = DB::select("SELECT estatus_estadocontrato, id_promocion,idcontratorelacion,poliza, subscripcion FROM contratos WHERE id='$idContrato'");
        $promocontra = $contrato[0]->id_promocion;
        if($contrato != null) {

            if (((Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13) && ($contrato[0]->estatus_estadocontrato == 0)) && $contrato[0]->idcontratorelacion == null) { //Si es opto/asistente solo pueden PRE-CANCERLAR si esta en NO TERMINADO y que sea PADRE

                request()->validate([
                    'comentarios' => 'required|string|max:500'
                ]);

                $comentarios = request('comentarios');
                $actualizar = Carbon::now();
                $usuarioId = Auth::user()->id;

                $randomId2 = $this->getHistorialContratoId();
                try {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus_estadocontrato' => 3, 'poliza' => 3, 'estatusanteriorcontrato' => $contrato[0]->estatus_estadocontrato
                    ]);
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Contrato pre-cancelado con la siguiente descripcion: '$comentarios'"
                    ]);
                    return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'El contrato se cancelo correctamente.');

                } catch (\Exception $e) {
                    \Log::info("Error: " . $e->getMessage());
                    return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                }

            }elseif(((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && //Administrador / Principal / Director
                ($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 3
                    || $contrato[0]->estatus_estadocontrato == 4 || $contrato[0]->estatus_estadocontrato == 12))
                && $contrato[0]->idcontratorelacion == null){ // Contrato padre

                request()->validate([
                    'comentarios' => 'required|string|max:500'
                ]);

                $comentarios = request('comentarios');
                $actualizar = Carbon::now();
                $usuarioId = Auth::user()->id;

                $estatusContrato = $contrato[0]->estatus_estadocontrato;
                $valorPoliza = $contrato[0]->poliza;
                if($contrato[0]->estatus_estadocontrato == 3){ //Si el estatus del contrato es Pre-Cancelado
                    $estatusContrato =  0; // El estatus sera NO TERMINADO
                    $valorPoliza = 3;
                }

                $randomId2 = $this->getHistorialContratoId();

                try {
                    if($promocontra >= 1) { //Tiene Promocion

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 6,'poliza' => $valorPoliza, 'estatusanteriorcontrato' => $estatusContrato
                        ]);

                        if($contrato[0]->estatus_estadocontrato != 3) { //Contrato con estatus diferente de PRE-CANCELADO
                            $contratosHijos = DB::select("SELECT id,estatus_estadocontrato,poliza,estatusanteriorcontrato FROM contratos where idcontratorelacion = '$idContrato' AND id_franquicia = '$idFranquicia'");
                            foreach ($contratosHijos as $hijo) {
                                $estatusContratoHijo = $hijo->estatus_estadocontrato; // OBtenermos el estatus del hijo para guardarlo como el anterior
                                $valorPolizaHijo = $hijo->poliza; //GUardamos el valor de poliza en caso de que ya este agregado
                                if ($hijo->estatus_estadocontrato == 3) {
                                    $estatusContratoHijo = $contrato[0]->estatusanteriorcontrato;
                                    $valorPolizaHijo = 3;
                                }

                                DB::table('contratos')->where([['id', '=', $hijo->id], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'estatus_estadocontrato' => 6, 'poliza' => $valorPolizaHijo, 'estatusanteriorcontrato' => $estatusContratoHijo
                                ]);
                            }
                        }

                    }else { //NO tiene promocion

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 6,'poliza' => $valorPoliza, 'estatusanteriorcontrato' => $estatusContrato
                        ]);

                    }
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Contrato cancelado con la siguiente descripcion: '$comentarios'"
                    ]);
                    return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'El contrato se cancelo correctamente.');

                } catch (\Exception $e) {
                    \Log::info("Error: " . $e->getMessage());
                    return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                }

            } else {
                if (Auth::check()) {
                    return redirect()->route('redireccionar');
                } else {
                    return redirect()->route('login');
                }
            }

        }
        return back()->with('alerta', 'No se encontro el contrato.');
    }

    public function validarContrato($idFranquicia, $idContrato)
    {
        $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id='$idContrato'");
        if ((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && $contrato[0]->estatus_estadocontrato == 3) {

            try {
                $usuarioId = Auth::user()->id;
                $randomId2 = $this->getHistorialContratoId();
                $ahora = Carbon::now();
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 0, 'poliza' => 0
                ]);
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $ahora, 'cambios' => "El contrato fue declarado como valido."
                ]);
                return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'Se declaro el contrato como valido.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function eliminarAbono($idFranquicia, $idContrato, $idAbono)
    {
        if (Auth::check()) {

            try {
                $usuarioId = Auth::user()->id;
                $actualizar = Carbon::now();
                $contratoabono = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id = '$idAbono'");
                if ($contratoabono == null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se encontro el abono');
                }
                $contratonum = $contratoabono[0]->id_contrato;
                $abonocant = $contratoabono[0]->abono;
                $tipoabono = $contratoabono[0]->tipoabono;
                $metodopago = $contratoabono[0]->metodopago;
                $user = $contratoabono[0]->id_usuario;
                $fecha = $contratoabono[0]->created_at;
                $cosatraso = $contratoabono[0]->atraso;
                $hoy = Carbon::parse($actualizar)->format('Y-m-d');
                $fechaabono = Carbon::parse($fecha)->format('Y-m-d');
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$contratonum'");
                $totalabono = $contrato[0]->totalabono;
                $entregadeproducto = $contrato[0]->entregaproducto;
                $fechaentrega = $contrato[0]->fechaentrega;
                $contratoestatus = $contrato[0]->estatus_estadocontrato;
                $costoatraso = $contrato[0]->costoatraso;
                $pagosadelantar = $contrato[0]->pagosadelantar;
                $pro = $contrato[0]->id_promocion;
                $engancheactivo = $contrato[0]->enganche;
                $totalcontrato = $contrato[0]->total;
                $th = $contrato[0]->totalhistorial;
                $totalhistorial = $contrato[0]->totalhistorial + 100;
                $totalhistorial2 = $contrato[0]->totalhistorial + 200;
                $totalhistorial3 = $contrato[0]->totalhistorial + 300;
                $totalpromocion = $contrato[0]->totalpromocion + 100;
                $resta = $totalabono - $abonocant;
                $totalliquidado = $totalcontrato + $abonocant;
                $suma = $totalcontrato + $abonocant + 100;
                $sumacontadoenganche = $abonocant + 200;
                $sumacontadosinenganche = $abonocant + 300;
                $suma2 = $totalcontrato + $abonocant;


                $randomId2 = $this->getHistorialContratoId();
                $randomId3 = $this->getHistorialContratoId();

                if ($usuarioId != $user) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este abono solo lo puede eliminar la persona que lo registró');
                }
                if ($hoy != $fechaabono) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este abono ya no se puede eliminar, solo el dia de registro');
                }
                if ($tipoabono == 7 && $contratoestatus > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este abono ya no se puede eliminar, ya que corresponde a productos');
                }
                if ($metodopago == 1) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Los abonos con tarjeta no se puede eliminar');
                }
                if ($tipoabono == 2 && $contratoestatus > 1 && $contratoestatus < 12) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este abono ya no se puede eliminar, Solo antes de entregarlo');
                }
                if ($tipoabono == 1) {
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma,
                        'totalabono' => $resta,
                        'totalhistorial' => $totalhistorial,
                        'totalpromocion' => $totalpromocion,
                        'enganche' => 0,
                        'entregaproducto' => 0

                    ]);
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                if ($tipoabono == 2) {
                    // $abonoenganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 1");
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma2,
                        'totalabono' => $resta,
                        'entregaproducto' => 0,
                        'fechaentrega' => null
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                if ($tipoabono == 3) {
                    $abonoretraso2 = DB::select("SELECT atraso FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND id = '$idAbono'");
                    $recuperaratraso2 = $abonoretraso2[0]->atraso + $costoatraso;
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");
                    if ($abonoretraso2[0]->atraso > 0) {
                        DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $suma2,
                            'totalabono' => $resta,
                            'costoatraso' => $recuperaratraso2,
                            'estatus_estadocontrato' => 4
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $suma2,
                            'totalabono' => $resta,
                        ]);
                    }
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                if ($tipoabono == 4) {
                    $abonoenganche5 = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 5");
                    if ($abonoenganche5 != null) {
                        $eng = 1;
                    } else {
                        $eng = 0;
                    }
                    if ($contratoestatus < 1) {
                        //No se ha terminado el contrato
                        $contratoestatus2 = 0;
                    } else {
                        if($entregadeproducto == 1) {
                            //Ya fue entregado el contrato
                            $contratoestatus2 = 12;
                        }else {
                            //No ha sido entregado el contrato
                            $contratoestatus2 = 1;
                        }
                    }
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma,
                        'totalabono' => $resta,
                        'totalhistorial' => $totalhistorial,
                        'totalpromocion' => $totalpromocion,
                        'enganche' => $eng,
                        'estatus_estadocontrato' => $contratoestatus2,
                        'entregaproducto' => 0

                    ]);
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                if ($tipoabono == 5) {
                    $abonoenganche4 = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 4");
                    if ($abonoenganche4 != null) {
                        $eng = 1;
                    } else {
                        $eng = 0;
                    }
                    if ($engancheactivo == 1) {
                        $sumacontadosinenganche = $abonocant + 200;
                        $totalhistorial3 = $contrato[0]->totalhistorial + 200;
                    }
                    if ($contratoestatus < 1) {
                        //No se ha terminado el contrato
                        $contratoestatus2 = 0;
                    } else {
                        if($entregadeproducto == 1) {
                            //Ya fue entregado el contrato
                            $contratoestatus2 = 12;
                        }else {
                            //No ha sido entregado el contrato
                            $contratoestatus2 = 1;
                        }
                    }
                    $suma3 = $sumacontadosinenganche + $totalcontrato;
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma3,
                        'totalhistorial' => $totalhistorial3,
                        'totalabono' => $resta,
                        'entregaproducto' => 0,
                        'enganche' => $eng,
                        'estatus_estadocontrato' => $contratoestatus2
                    ]);


                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                if ($tipoabono == 6) {
                    // $abonoenganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 1");
                    $abonodeproducto = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' and tipoabono = 7");
                    if ($abonodeproducto == null) {
                        $entregaP = 0;
                    } else {
                        $entregaP = 1;
                    }

                    if ($cosatraso > 0) {
                        DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $totalliquidado,
                            'totalabono' => $resta,
                            'estatus_estadocontrato' => 4
                        ]);
                        DB::table('historialcontrato')->insert([
                            'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                        ]);
                        DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");
                        return back()->with('bien', 'El abono se elimino correctamente del contrato');
                    }
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");
                    if ($pro != null) {
                        if (((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13)) {

                            $estado = null;
                            if($entregadeproducto == 1) {
                                //Se entrego el producto
                                $estado = 12;
                            }else {
                                if($contratoestatus < 1) {
                                    //No ha sido terminado el contrato
                                    $estado = 0;
                                }else {
                                    //Ya se encuentra terminado el contrato
                                    $estado = 1;
                                }
                            }

                            DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                                'total' => $totalliquidado,
                                'totalabono' => $resta,
                                'estatus_estadocontrato' => $estado
                            ]);
                        } else {
                            DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                                'total' => $totalliquidado,
                                'totalabono' => $resta,
                                'estatus_estadocontrato' => 0
                            ]);
                        }
                        DB::table('historialcontrato')->insert([
                            'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                        ]);

                        return back()->with('bien', 'El abono se elimino correctamente del contrato');
                    }
                    if ($abonocant == $th) {
                        DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $totalliquidado,
                            'totalabono' => $resta,
                            'estatus_estadocontrato' => 12,
                            'entregaproducto' => $entregaP
                        ]);
                    } elseif (((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13) && $fechaentrega != null) {
                        DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $totalliquidado,
                            'totalabono' => $resta,
                            'estatus_estadocontrato' => 2
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $totalliquidado,
                            'totalabono' => $resta,
                            'entregaproducto' => $entregaP,
                        ]);
                    }
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                if ($tipoabono == 7) {
                    // $abonoenganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 1");
                    DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma2,
                        'totalabono' => $resta,
                        'entregaproducto' => 0,
                        'fechaentrega' => null
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                    ]);

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');
                }
                $abonoretraso = DB::select("SELECT atraso, adelantos FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND id = '$idAbono'");
                $recuperaratraso = $abonoretraso[0]->atraso + $costoatraso;
                $recuperaradelantos = $pagosadelantar - $abonoretraso[0]->adelantos;
                if ($recuperaratraso > 0) {
                    $contratoestado = 4;
                } elseif ($contratoestatus == 5 && $recuperaratraso < 1) {
                    $contratoestado = 2;
                } else {
                    $contratoestado = $contratoestatus;
                }


                DB::delete("DELETE FROM abonos WHERE id = '$idAbono' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");
                if ($contratoestatus >= 2) {
                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma2, 'totalabono' => $resta, 'costoatraso' => $recuperaratraso, 'estatus_estadocontrato' => $contratoestado, 'pagosadelantar' => $recuperaradelantos
                    ]);
                } else {
                    DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $suma2, 'totalabono' => $resta
                    ]);
                }
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un abono con la cantidad: '$abonocant'"
                ]);

                return back()->with('bien', 'El abono se elimino correctamente del contrato');
                // return redirect()->route('vercontrato',['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien','Se agrego el retraso en abonos de este contrato');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function eliminarProductoContrato($idFranquicia, $idProducto)
    {
        if (Auth::check()) {

            try {
                $usuarioId = Auth::user()->id;
                $actualizar = Carbon::now();
                $contratoproducto = DB::select("SELECT * FROM contratoproducto WHERE id_franquicia = '$idFranquicia' AND id = '$idProducto'");
                if ($contratoproducto == null) {
                    return back()->with('alerta', 'No se encontro el registro del producto');
                }
                $contratonum = $contratoproducto[0]->id_contrato;
                $productocant = $contratoproducto[0]->total;
                $productocontarjeta = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 7 AND metodopago = 1");
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$contratonum'");
                $totalproducto = $contrato[0]->totalproducto;
                $totalcontrato = $contrato[0]->total;
                $resta = $totalcontrato - $productocant;
                $resta2 = $totalproducto - $productocant;
                $user = $contratoproducto[0]->id_usuario;
                $fecha = $contratoproducto[0]->created_at;
                $hoy = Carbon::parse($actualizar)->format('Y-m-d');
                $fechaabono = Carbon::parse($fecha)->format('Y-m-d');
                $randomId2 = $this->getHistorialContratoId();

                if ($usuarioId != $user) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este producto solo lo puede eliminar la persona que lo registró');
                }
                if ($hoy != $fechaabono) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este producto ya no se puede eliminar, solo el dia de registro');
                }
                if ($productocontarjeta) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este producto no se puede eliminar, se pago con tarjeta');
                }
                if ($resta2 == 0) {
                    $resta2 = null;
                }
                DB::delete("DELETE FROM contratoproducto WHERE id = '$idProducto' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $resta, 'totalproducto' => $resta2
                ]);
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un registro de producto con valor de: '$productocant'"
                ]);

                return back()->with('bien', 'El Producto se elimino correctamente del contrato');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function entregarDiaPago($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 6)) {

            try {

                $dia = request('diapago');
                if ($dia == '0') {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes elegir un dia para abonar');
                }
                if ($dia == 'Todos') {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'diapago' => null, 'diaseleccionado' => null
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Podras abonar todos los dias del rango que toca el siguiente abono');
                }

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'diapago' => $dia
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se agrego un dia en especifico para abonar');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function agregarproducto($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'piezas' => 'required|integer'
            ];
            if (request('piezas') < 1) {
                // return back()->withErrors(['precio' =>  'La cantidad de piezas no puede ser menor a 0']);
                return back()->with('error', 'El numero de piezas es obligatorio, intenta de nuevo');
            }
            if (request('producto') == 'nada') {
                // return back()->withErrors(['producto' => 'Campo obligatorio']);
                return back()->with('alerta', 'El producto es obligatorio, intenta de nuevo');
            }
            if (request('piezas') == null) {
                // return back()->withErrors(['precio' =>  'La cantidad de piezas no puede ser menor a 0']);
                return back()->with('error', 'El numero de piezas es obligatorio, intenta de nuevo');
            }
            request()->validate($rules);
            $idpro = request('producto');
            $piezas = request('piezas');
            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $operacion = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id = '$idpro'");
            $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonos = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");
            $precio1 = $operacion[0]->precio;
            $nombre = $operacion[0]->nombre;
            $precio2 = $operacion[0]->preciop;
            $arma = $operacion[0]->id;
            $armapz = $operacion[0]->piezas - 1;
            if ($precio2 == null) {
                $total = $precio1 * $piezas;
            } else {
                $total = $precio2 * $piezas;
            }
            $sumacontrato = $total + $contrato[0]->total;
            $randomId2 = $this->getHistorialContratoId();
            $randomIdP = $this->getContratoContratoId();

            if ($abonos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Necesitas eliminar los abonos para agregar productos');
            }
            try {
                DB::table('contratoproducto')->insert([
                    'id' => $randomIdP, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'id_producto' => request('producto'), 'piezas' => request('piezas'), 'total' => $total, 'created_at' => Carbon::now()
                ]);

                DB::table('producto')->where([['id', '=', $arma], ['id_franquicia', '=', $idFranquicia]])->update([
                    'piezas' => $armapz
                ]);


                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $sumacontrato
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar,
                    'cambios' => " Se agrego el producto: '$idpro'-'$nombre' cantidad de piezas: '$piezas' con total de: $'$total'"
                ]);

                $contratos2 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $valor = $contratos2[0]->totalproducto + $total;
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalproducto' => $valor
                ]);

                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El producto se agrego correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function agregarabono($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'abono' => 'required|numeric',
                'metodopago' => 'required|numeric'
            ];
            if (request('abono') <= 0) {
                return back()->with('alerta', 'Ingresar la cantidad del abono');
            }
            if (request('abono') == null) {
                return back()->with('alerta', 'La cantidad de abono es obligaoria, intenta de nuevo');
            }
            if (request('folio') == null && ((Auth::user()->rol_id) == 4)) {
                return back()->with('alerta', 'El Folio es obligatorio, favor de ingresarlo')->withInput($request->all());
            }
            if (request('adelanto') != null && request('adelanto') < 1 || request('adelanto') != null && request('adelanto') > 3) {
                return back()->with('alerta', 'La cantidad maxima a adelantar son 3');
            }
            request()->validate($rules);
            $abono2 = request('abono');
            $metodopago = request('metodopago');
            $tarjetameses = request('meses');
            $abono = number_format($abono2, 1, ".", "");
            $adelantar = request('adelantar');
            $adelanto = request('adelanto');
            $adelanto = intval($adelanto);
            $folio = request('folio');
            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $nowparce = Carbon::parse($actualizar)->format('Y-m-d');
            $now = Carbon::now();
            $semana = $now->weekOfYear;
            $contra = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonoperiodo = DB::select("SELECT a.id, a.adelantos, a.id_contrato, c.fechacobroini, a.created_at
            FROM abonos a
            INNER JOIN contratos c
            ON c.id = a.id_contrato
            WHERE a.id_franquicia = '$idFranquicia' AND a.id_contrato = '$idContrato'
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
            AND tipoabono = 3");
            $abonosPeriodo = DB::select("SELECT COALESCE(SUM(a.abono),0) as total
            FROM abonos a
            INNER JOIN contratos c
            ON c.id = a.id_contrato
            WHERE a.id_franquicia = '$idFranquicia' AND a.id_contrato = '$idContrato'
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
            AND tipoabono = 3");
            $ec = $contra[0]->idcontratorelacion;
            $costoatraso = $contra[0]->costoatraso;
            $promocionterminada = $contra[0]->promocionterminada;
            $iniantes = $contra[0]->fechacobroini;
            $finantes = $contra[0]->fechacobrofin;
            $totalA = $contra[0]->totalabono;
            $enganche = $contra[0]->enganche;
            $fechaentrega = $contra[0]->fechaentrega;
            $creacion = $contra[0]->created_at;
            $creacionparce = Carbon::parse($creacion)->format('Y-m-d');
            $adelantados = $contra[0]->pagosadelantar + $adelanto;
            $entregaproducto = $contra[0]->entregaproducto;
            $es = $contra[0]->estatus;
            $costoatraso = $contra[0]->costoatraso;
            $estadocontrato = $contra[0]->estatus_estadocontrato;
            $totalproductos = $contra[0]->totalproducto;
            $totalhistorial = $contra[0]->totalhistorial;
            $totalpromocion = $contra[0]->totalpromocion;
            $totalengancheresta = $totalhistorial - 100;
            $totalenganchepromo = $totalpromocion - 100;
            $pago = $contra[0]->pago;
            $totaladelantos = $contra[0]->pagosadelantar + $adelanto;
            $ultimoabono = $contra[0]->ultimoabono;
            $tot2 = $totalA + $abono;
            $tot = number_format($tot2, 1, ".", "");
            $costo2 = $abono + $totalA;
            $costo = number_format($costo2, 1, ".", "");
            $totalcontrato = $contra[0]->total;
            $totalhistorialconenganche = $contra[0]->totalhistorial - 200;
            $totalhistorialsinenganche = $contra[0]->totalhistorial - 300;
            $totalconenganche10 = $contra[0]->total - 200;
            $totalconenganche = number_format($totalconenganche10, 1, ".", "");
            $totalsinenganche10 = $contra[0]->total - 300;
            $totalsinenganche = number_format($totalsinenganche10, 1, ".", "");
            $totalnocontado = $contra[0]->total - 100;
            $totalcr = $totalengancheresta + $totalproductos - $tot;
            $totalcontratoresta = number_format($totalcr, 1, ".", "");
            $totalpresta = $totalenganchepromo + $totalproductos - $tot;
            $totalpromoresta = number_format($totalpresta, 1, ".", "");
            $totalcontra2 = $totalcontrato - $abono;
            $totalcontratoresta2 = number_format($totalcontra2, 1, ".", "");
            $totabono = $totalcontrato + $totalproductos;
            $nowparce = Carbon::parse($now)->format('Y-m-d');
            $ultimoabonoparce = Carbon::parse($ultimoabono)->format('Y-m-d');
            $totalfinal = $totalhistorial + $totalproductos - $tot;
            $descuento = 0;
            $nuevoabono = 0;
            $cantidadsubscripcion = 0;
            if ($metodopago == 1 && $tarjetameses > 0) {
                if ($tarjetameses == 1) {
                    $nuevoabono = $totalcontrato;
                    $cantidadsubscripcion = 3;
                }
                if ($tarjetameses == 2) {
                    $nuevoabono = $totalcontrato;
                    $cantidadsubscripcion = 6;
                }
                if ($tarjetameses == 3) {
                    $nuevoabono = $totalcontrato;
                    $cantidadsubscripcion = 9;
                }
                $nuevoabono = number_format($nuevoabono, 1, ".", "");
            }
            if ($pago == 0) {
                if ($enganche == 1) {
                    $descuento = 200;
                } else {
                    $descuento = 300;
                }
            }
            $sumadescuento = $descuento + $abono;
            $existente = DB::select("SELECT * FROM abonos where folio = '$folio'");
            $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
            $contaenganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 5");
            $contaenganche2 = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 4");
            $abonoprod = DB::select("SELECT COALESCE(SUM(abono),0) as suma FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 7");
            $dentroRango = DB::select("SELECT id FROM contratos where id = '$idContrato' AND
            ((STR_TO_DATE('$now','%Y-%m-%d') = STR_TO_DATE(diaseleccionado,'%Y-%m-%d')) OR
           (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(fechacobroini,'%Y-%m-%d')) AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(fechacobrofin,'%Y-%m-%d'))");
            $randomId = $this->getAbonosId();
            $randomId2 = $this->getHistorialContratoId();

            if ($ec != null) {
                $contra2 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$ec'");
                $pr = $contra2[0]->id_promocion;
            } else {
                $pr = $contra[0]->id_promocion;
            }
            if ($pago === null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes elegir una forma de pago para poder abonar');
            }
            if ($totaladelantos > 3) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede adelantar mas de 3 en el mismo dia');
            }
            if (sizeof($existente) > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Este folio ya esta registrado en un contrato');
            }
            if ($abono > $totalcontrato) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar mas del total del contrato');
            }
            if (($estadocontrato <= 1 || $estadocontrato == 12) && $abono == $totalcontrato && $enganche <= 1 && $contaenganche != null && $contaenganche2 == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Para hacer valido el enganche abonar la cantidad :' . ($totalcontrato - 100));
            }
            if ($estadocontrato == 0 && $abonoprod[0]->suma < $totalproductos && $abono < $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Abonar al menos el total de productos');
            }
            if ($estadocontrato == 0 && $abono > $totalproductos && $abonoprod[0]->suma < $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Abonar el total de productos');
            }
            if (($estadocontrato <= 1 || $estadocontrato == 12) && $totalA >= $totalproductos && $abono < 100 && $sumadescuento != $totalcontrato) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El abono minimo es de 100 pesos');
            }
            if ($estadocontrato == 0 && $tot > $totalproductos && $ec != null && $es == 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de los contratos');
            }
            if ($estadocontrato == 0 && $this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $es == 0 && $tot > $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de los contratos');
            }
            if ($estadocontrato == 1 && $ec != null && $promocionterminada != 1) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de completar y terminar los contratos');
            }
            if ($estadocontrato == 1 && $this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $promocionterminada != 1) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de completar y terminar los contratos');
            }
            if ($estadocontrato == 12 && ((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13) && $abono < 150 && $entregaproducto < 1 && $pago != 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 150 en contratos enviados');
            }
            if ($pago != 0 && $estadocontrato <= 1 && $enganche < 1 && $abono > $totalnocontado && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Para liquidar el contrato pagar la cantidad: $ ' . $totalnocontado);
            }
            if ($metodopago == 1 && $tarjetameses > 0) {
                $banderacase = 13;
                return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
            }
            if ($pago == 0 && $estadocontrato >= 0 && $enganche == 1 && $contaenganche == null && $abono > $totalconenganche) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalconenganche);
            }

            if ($pago == 0 && $estadocontrato == 4 && $abono < $totalcontrato) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalcontrato);
            }

            if ($pago == 0 && $estadocontrato >= 0 && $estadocontrato != 4 && $enganche < 1 && $abono > $totalsinenganche && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $contaenganche == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalsinenganche);
            }
            if ($pago == 0 && ($estadocontrato == 1 || $estadocontrato == 12) && $enganche == 1 && $abono < $totalconenganche) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalconenganche);
            }
            if ($pago == 0 && $estadocontrato == 12 && $enganche < 1 && $abono < $totalsinenganche && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalsinenganche);
            }
            if ($pago == 0 && $metodopago == 1 && $tarjetameses == 0 && $enganche < 1 && $abono != $totalsinenganche && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado en pago con tarjeta, con la cantidad: $ ' . $totalsinenganche);
            }
            if ($pago == 0 && $metodopago == 1 && $tarjetameses == 0 && $enganche == 1 && $abono != $totalconenganche && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado en pago con tarjeta, con la cantidad: $ ' . $totalconenganche);
            }

            //Validacion para promociones de contado
            if($pago == 0 && ((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13) && $estadocontrato == 12 && $abono != $totalcontrato && $this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalcontrato);
            }

            $polizaEs2 = null;
            if ((Auth::user()->rol_id) == 4) {
                $polizaEs2 = 0;
            }
            if ($pago == 0 && $estadocontrato >= 0 && $enganche == 1 && $abono == $totalconenganche) {
                if ($estadocontrato == 0) {
                    $numeroentrega = 0;
                } else {
                    if($estadocontrato == 12) {
                        $numeroentrega = 1;
                    }else {
                        $numeroentrega = 0;
                    }
                }

                if ($metodopago == 1) {
                    $banderacase = 1;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }
                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 5, 'abono' => $abono, 'poliza' => $polizaEs2, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalabono' => $tot, 'ultimoabono' => $actualizar, 'totalhistorial' => $totalhistorialconenganche, 'entregaproducto' => $numeroentrega
                ]);
                $contra5 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $totalfinal = $contra5[0]->total - $abono - 200;
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $totalfinal
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se liquido el costo del contrato con descuento de 200 pesos');
            }
            if ($pago == 0 && $estadocontrato >= 0 && $enganche < 1 && $abono == $totalsinenganche) {
                if ($estadocontrato == 0) {
                    $numeroentrega = 0;
                } else {
                    if($estadocontrato == 12) {
                        $numeroentrega = 1;
                    }else {
                        $numeroentrega = 0;
                    }
                }

                if ($metodopago == 1) {
                    $banderacase = 2;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }
                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 5, 'abono' => $abono, 'poliza' => $polizaEs2, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalabono' => $costo, 'ultimoabono' => $actualizar, 'totalhistorial' => $totalhistorialsinenganche, 'entregaproducto' => $numeroentrega
                ]);
                $contra5 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $totalfinal = $contra5[0]->total - $abono - 300;
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $totalfinal
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se liquido el costo del contrato con descuento de 300 pesos');
            }
            if ($abono == $totalcontrato && $pago != 0) {
                if ($estadocontrato > 1) {
                    $estadocontra = 5;
                    $ent = 1;
                } else {
                    $estadocontra = $estadocontrato;
                    $ent = 0;
                }

                if ($costoatraso > 0) {
                    $cantidadatraso = $costoatraso;
                    $restaatrasocontrato = $costoatraso - $cantidadatraso;
                } else {
                    $cantidadatraso = null;
                    $restaatrasocontrato = $costoatraso;
                }
                $abonosliquidados = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 6");
                if ($abonosliquidados != null) {
                    foreach ($abonosliquidados as $ab) {
                        DB::table('abonos')->where([['id', '=', $ab->id], ['id_franquicia', '=', $idFranquicia]])->update([
                            'tipoabono' => 0
                        ]);
                    }
                }
                if ($metodopago == 1) {
                    $banderacase = 3;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }
                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'atraso' => $cantidadatraso, 'abono' => $abono, 'metodopago' => $metodopago, 'tipoabono' => 6, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalabono' => $costo, 'ultimoabono' => $actualizar, 'total' => 0, 'estatus_estadocontrato' => $estadocontra, 'costoatraso' => $restaatrasocontrato, 'entregaproducto' => $ent
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agregó correctamente y se liquidó el costo del contrato.');
            }
            if ($abono == $totalcontrato && $pago == 0 && $es == 1 && $this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                if ($metodopago == 1) {
                    $banderacase = 4;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }
                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'tipoabono' => 6, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalabono' => $costo, 'ultimoabono' => $actualizar, 'total' => 0, 'entregaproducto' => 1
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agrego correctamente y se liquido el costo del contrato.');
            }
            if ($pago != 0 && $estadocontrato < 1 && $enganche < 1 && $abono == ($totalcontrato - 100) && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                if ($metodopago == 1) {
                    $banderacase = 5;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }

                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'tipoabono' => 1, 'poliza' => $polizaEs2, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalabono' => $costo, 'ultimoabono' => $actualizar, 'total' => 0, 'entregaproducto' => 1, 'enganche' => 1, 'totalhistorial' => $totalengancheresta
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agrego correctamente y se liquido el costo del contrato.');
            }
            $totalenganche = 100;
            if ($totalproductos > 0 && $totalA < $totalproductos) {
                $totalenganche = $totalproductos + 100;
            }
            switch ($pago) {
                case 0:
                    if($pago == 0 && $estadocontrato == 4 ){
                        $minimo = $totalcontrato;
                    }else {
                        $totalcontrato = $totalcontrato - 100;
                    }
                    break;
                case 1:
                    if ($abonosPeriodo[0]->total >= 150 && $estadocontrato != 4) {
                        $minimoadelanto = $adelanto * 150;
                    } else {
                        $minimoadelanto = ($adelanto * 150) + 150;
                    }
                    if ($estadocontrato == 4) {
                        if ($abonosPeriodo[0]->total >= 150) {
                            $minimoadelanto = ($adelanto * 150) + $costoatraso;
                        } else {
                            $minimoadelanto = ($adelanto * 150) + 150 + $costoatraso;
                        }
                    }
                    $minimo = 150;
                    break;
                case 2:
                    if ($abonosPeriodo[0]->total >= 300 && $estadocontrato != 4) {
                        $minimoadelanto = $adelanto * 300;
                    } else {
                        $minimoadelanto = ($adelanto * 300) + 300;
                    }
                    if ($estadocontrato == 4) {
                        if ($abonosPeriodo[0]->total >= 300) {
                            $minimoadelanto = ($adelanto * 300) + $costoatraso;
                        } else {
                            $minimoadelanto = ($adelanto * 300) + 300 + $costoatraso;
                        }
                    }
                    $minimo = 300;
                    break;
                case 4:
                    if ($abonosPeriodo[0]->total >= 450 && $estadocontrato != 4) {
                        $minimoadelanto = $adelanto * 450;
                    } else {
                        $minimoadelanto = ($adelanto * 450) + 450;
                    }
                    if ($estadocontrato == 4) {
                        if ($abonosPeriodo[0]->total >= 450) {
                            $minimoadelanto = ($adelanto * 450) + $costoatraso;
                        } else {
                            $minimoadelanto = ($adelanto * 450) + 450 + $costoatraso;
                        }
                    }
                    $minimo = 450;
                    break;
            }

            if ($estadocontrato >= 2 && $estadocontrato < 12) {
                if ($pago == 1 && $adelanto > 0 && $abono < $minimoadelanto) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Respecto a los abonos que quieres adelantar, abonar minimo la cantida: $' . $minimoadelanto);
                }
                if ($pago == 1 && $abono < 150 && $abonoperiodo == null && $costoatraso == 0 && $fechaentrega != $nowparce) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 150 en pago semanal');
                }
                if ($pago == 2 && $adelanto > 0 && $abono < $minimoadelanto) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Respecto a los abonos que quieres adelantar, abonar minimo la cantida: $' . $minimoadelanto);
                }
                if ($pago == 2 && $abono < 300 && $abonoperiodo == null && $costoatraso == 0 && $fechaentrega != $nowparce) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 300 en pago Quincenal');
                }
                if ($pago == 4 && $adelanto > 0 && $abono < $minimoadelanto) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Respecto a los abonos que quieres adelantar, abonar minimo la cantida: $' . $minimoadelanto);
                }
                if ($pago == 4 && $abono < 450 && $abonoperiodo == null && $costoatraso == 0 && $fechaentrega != $nowparce) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 450 en pago Mensual');
                }

            }
            if ($adelantar == 1 && $adelanto == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de elegir una cantidad de semanas a adelantar');
            }
            if ($adelantar == null && $adelanto != null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Solo permitido si elige la opcion de adelantar abono');
            }

            if ($estadocontrato == 4) {
                //CONTRATO CON ABONO ATRASADO
                if ($metodopago == 1) {
                    $banderacase = 12;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }
                $dentroRango = DB::select("SELECT id FROM contratos where id = '$idContrato' AND
              ((STR_TO_DATE('$now','%Y-%m-%d') = STR_TO_DATE(diaseleccionado,'%Y-%m-%d')) OR
                (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(fechacobroini,'%Y-%m-%d')) AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(fechacobrofin,'%Y-%m-%d'))");
                $contratosGlobal = new contratosGlobal;
                $totaladeudo = $minimo + $costoatraso;
                $restoadeudo = $totaladeudo - $abono;
                $atrasocorto = $costoatraso - $abono;
                $diaseleccionado = false;
                if ($contra[0]->diaseleccionado != null || strlen($contra[0]->diaseleccionado) > 0) { //VALIDAMOS SI TENEMOS UN DIA SELECCIONADO
                    if ($now == Carbon::parse($contra[0]->diaseleccionado)) { // VALIDAMOS SI EL DIA SELECCIONADO ES IGUAL AL DIA DE ACTUAL
                        $diaseleccionado = true;
                    }
                }

                //Tabla de abonos ->  periodo
                $insertarAbono = 0;
                $insertarTipoAbono = 0; // 0 -> Abono normal
                $insertarAtraso = 0;
                $adelantarpagos = 0;
                $adelantarpagos2 = 0;
                //Tabla de abonos -> atrasos
                $insertarAbono2 = null;
                $insertarTipoAbono2 = null; // 0 -> Abono normal
                $insertarAtraso2 = null;
                //Tabla de contrato
                $atrasoMenosAbono = 0;
                $atrasoMenosAbono2 = null;
                $estadodelcontrato = 4;
                $fechaatraso = null; //para saber los dias de atraso

                if (($now >= Carbon::parse($contra[0]->fechacobroini) && $now <= Carbon::parse($contra[0]->fechacobrofin)) || $diaseleccionado) { //VALIDAMOS SI EL DIA ACTUAL SE ENCUENTRA ENTRE LA FECHAINI Y FECHA FIN / DIA ACTUAL IGUAL AL DIA SELECCIONADO EN CASO DE EXISTIR

                    if ($abonosPeriodo[0]->total >= $contratosGlobal::calculoCantidadFormaDePago($pago)) { //Validamos si se encuentra cubierto lo del periodo
                        if ($atrasocorto <= 0) { //Si el abono supero lo que ya se tiene de atraso.
                            $insertarAbono = $abono;
                            $insertarTipoAbono = 0; // 0 -> Abono normal
                            $insertarAtraso = $costoatraso; // Lo que se tiene de atraso
                            $atrasoMenosAbono = 0; //Como el abono supero lo que tenia de atraso entonces se deja en 0.
                            $estadodelcontrato = 2; //Se elimina el atraso del contrato y vuelve a un estado de entregado.
                            $fechaatraso = null; // se regresa al campo para el contado de dias atrasados en null
                            $adelantarpagos = $adelanto;

                        } else {
                            $insertarAbono = $abono;
                            $insertarTipoAbono = 0; // 0 -> Abono normal
                            $insertarAtraso = $abono;
                            $atrasoMenosAbono = $costoatraso - $abono;
                            //Lo que tenemos de atraso menos el abono.
                        }

                    } else if (($abonosPeriodo[0]->total + $abono) >= $contratosGlobal::calculoCantidadFormaDePago($pago)) { //Validamos si los abonos del periodo + el abono ya cubren lo del periodo
                        $restanPorPagarPeriodo = $contratosGlobal::calculoCantidadFormaDePago($pago) - $abonosPeriodo[0]->total; //abono del periodo menos el total de abonos del periodo
                        $faltaPorPagarMenosElAbonoPeriodo = $restanPorPagarPeriodo - $abono; // Lo que resta por pagar del periodo - el abono.
                        if ($faltaPorPagarMenosElAbonoPeriodo >= 0) { // Validamos si sigue quedANDo lo del periodo sin pagar
                            $insertarAbono = $abono;
                            $insertarTipoAbono = 3; // 0 -> Abono del periodo
                            $insertarAtraso = 0;
                            $atrasoMenosAbono = $costoatraso;
                        } else {
                            // Se dio dinero de mas de lo del periodo
                            $insertarAbono = $restanPorPagarPeriodo;
                            $insertarTipoAbono = 3; //  Abono del periodo
                            $insertarAtraso = 0;
                            // $atrasoMenosAbono = $atrasocorto;

                            if (($costoatraso - abs($faltaPorPagarMenosElAbonoPeriodo)) == 0) { //Validamos si el costo atraso menos el sobrante cubre todo lo atrasado
                                $insertarAbono2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                $insertarTipoAbono2 = 0; // 0 -> Abono normal
                                $insertarAtraso2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                $atrasoMenosAbono2 = 0;
                                $estadodelcontrato = 2;
                                $fechaatraso = null; // se regresa al campo para el contado de dias atrasados en null

                            } else if (($costoatraso - abs($faltaPorPagarMenosElAbonoPeriodo)) > 0) { //Valida si aun queda costo atraso
                                $insertarAbono2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                $insertarTipoAbono2 = 0; // Abono  normal
                                $insertarAtraso2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                $atrasoMenosAbono2 = $costoatraso - abs($faltaPorPagarMenosElAbonoPeriodo);
                            } else {//Si el costo atraso se supero y ademas sobro para abonar
                                $insertarAbono2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                $insertarTipoAbono2 = 0; //  Abono normal
                                $insertarAtraso2 = $costoatraso;
                                $atrasoMenosAbono2 = 0;
                                $estadodelcontrato = 2;
                                $adelantarpagos2 = $adelanto;
                                $fechaatraso = null; // se regresa al campo para el contado de dias atrasados en null
                            }
                        }
                    } else if (($abonosPeriodo[0]->total + $abono) < $contratosGlobal::calculoCantidadFormaDePago($pago)) { // Validamos si aun no se cubre lo del periodo
                        $insertarAbono = $abono;
                        $insertarTipoAbono = 3; //Abono del periodo
                        $insertarAtraso = 0;
                        $atrasoMenosAbono = $costoatraso;
                    }


                } else if ($now > Carbon::parse($contra[0]->fechacobrofin) || $now < Carbon::parse($contra[0]->fechacobroini)) {

                    if ($abono >= $costoatraso) {
                        $insertarAbono = $abono;
                        $insertarTipoAbono = 0; // Abono normal
                        $insertarAtraso = $costoatraso;
                        $atrasoMenosAbono = 0;
                        if($totalcontrato - $abono == 0){
                            $estadodelcontrato = 5;
                            $insertarTipoAbono = 6; // Abono liquidado
                        }

                    } else {
                        $insertarAbono = $abono;
                        $insertarTipoAbono = 0; // Abono normal
                        $insertarAtraso = $abono;
                        $atrasoMenosAbono = $costoatraso - $abono;
                    }
                }

                $insertarAbono = number_format($insertarAbono, 1, ".", "");
                $insertarAtraso = number_format($insertarAtraso, 1, ".", "");
                $insertarAbono2 = number_format($insertarAbono2, 1, ".", "");
                $insertarAtraso2 = number_format($insertarAtraso2, 1, ".", "");
                $ID2 = $contratosGlobal::getFolioId();
                $ID3 = $contratosGlobal::getFolioId();


                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'adelantos' => $adelantarpagos, 'poliza' => $polizaEs2, 'metodopago' => $metodopago,
                    'tipoabono' => $insertarTipoAbono, 'abono' => $insertarAbono, 'atraso' => $insertarAtraso, 'created_at' => Carbon::now()
                ]);


                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$insertarAbono'"
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalabono' => $tot, 'pagosadelantar' => $adelantados, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'costoatraso' => $atrasoMenosAbono,
                    'estatus_estadocontrato' => $estadodelcontrato, 'fechaatraso' => $fechaatraso
                ]);


                if ($insertarAbono2 != null && $insertarAbono2 > 0) {
                    DB::table('abonos')->insert([
                        'id' => $ID2, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'adelantos' => $adelantarpagos2, 'poliza' => $polizaEs2, 'metodopago' => $metodopago,
                        'tipoabono' => $insertarTipoAbono2, 'abono' => $insertarAbono2, 'atraso' => $insertarAtraso2, 'created_at' => Carbon::now()
                    ]);


                    DB::table('historialcontrato')->insert([
                        'id' => $ID3, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : ' $insertarAbono2'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'costoatraso' => $atrasoMenosAbono2,
                        'estatus_estadocontrato' => $estadodelcontrato, 'fechaatraso' => $fechaatraso
                    ]);
                }


                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se agrego el abono correctamente');


            }

            if ($enganche < 1 && $abono >= $totalenganche && $estadocontrato <= 1 && !$this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $contaenganche2 == null) {
                if ($estadocontrato == 1) {
                    $tipoabonocontado = 4;

                    if ($pago != 0) {
                        $tipoabonocontado = 1;
                    }

                    if ($metodopago == 1) {
                        $banderacase = 6;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'tipoabono' => $tipoabonocontado, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'poliza' => $polizaEs2, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad con enganche: '$abono'"
                    ]);

                    if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $es == 1 || $ec != null) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                            'total' => $totalpromoresta,
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                            'total' => $totalcontratoresta,
                        ]);
                    }

                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono y el enganche se agregaron correctamente');
                } elseif ($estadocontrato == 0 && $enganche < 1) {
                    $tipoabonocontado = 1;

                    if ($pago == 0) {
                        $tipoabonocontado = 4;
                        $polizaabo = null;
                    }
                    if ($metodopago == 1) {
                        $banderacase = 7;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'tipoabono' => $tipoabonocontado, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'poliza' => $polizaEs2, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad con enganche: '$abono'"
                    ]);

                    if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $es == 1 || $ec != null) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                            'total' => $totalpromoresta,
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                            'total' => $totalcontratoresta,
                        ]);
                    }

                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono y el enganche se agregaron correctamente');
                }
            }
            if ($abono >= 150 && $entregaproducto == 0 && $pago != 0 && $estadocontrato == 12 && ((Auth::user()->rol_id) != 12 || (Auth::user()->rol_id) == 13)) {
                if ($metodopago == 1) {
                    $banderacase = 8;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }

                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 2, 'abono' => $abono, 'poliza' => $polizaEs2, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad para poder entregar el producto: '$abono'"
                ]);

                if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $es == 1 || $ec != null) {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'entregaproducto' => 1, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                        'total' => $totalcontratoresta2, 'fechaentrega' => $nowparce
                    ]);
                } else {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'entregaproducto' => 1, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                        'total' => $totalcontratoresta2, 'fechaentrega' => $nowparce
                    ]);
                }
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono para la entrega de producto se agrego correctamente');
            }
            if (((Auth::user()->rol_id) == 4) && $pago != 0 && $abono >= $minimo && $abonoperiodo == null && $dentroRango != null && $estadocontrato >= 2) {
                if ($metodopago == 1) {
                    $banderacase = 9;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }

                DB::table('abonos')->insert([
                    'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 3, 'abono' => $abono, 'poliza' => $polizaEs2, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad para poder entregar el producto: '$abono'"
                ]);

                if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $es == 1 || $ec != null) {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                        'total' => $totalcontratoresta2,
                    ]);
                } else {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                        'total' => $totalcontratoresta2,
                    ]);
                }
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono del periodo se agrego correctamente');
            }

            try {

                if ($abono == $totalproductos && $abonoprod[0]->suma != $totalproductos) {
                    if ($metodopago == 1) {
                        $banderacase = 10;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 7, 'abono' => $abono, 'adelantos' => $adelanto, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                    ]);
                } else {
                    if ($metodopago == 1) {
                        $banderacase = 11;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    if ($estadocontrato >= 2) {
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 0, 'abono' => $abono, 'adelantos' => $adelanto, 'poliza' => $polizaEs2, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                        ]);
                    } else {
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 0, 'abono' => $abono, 'adelantos' => $adelanto, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                        ]);
                    }
                }


                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad: '$abono'"
                ]);

                if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $es == 1 || $ec != null) {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'pagosadelantar' => $adelantados,
                    ]);
                } else {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'pagosadelantar' => $adelantados,
                    ]);
                }


                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agrego correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function obtenerEstadoPromocion($idContrato, $idFranquicia)
    {
        $respuesta = false;

        $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
        if($contrato[0]->idcontratorelacion != null) {
            //Es un contrato hijo
            $idContrato = $contrato[0]->idcontratorelacion;
        }

        $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");

        if($promocioncontrato != null) {
            if ($promocioncontrato[0]->estado == 1) {
                //Promocion esta activa
                $respuesta = true;
            }
        }
        return $respuesta;
    }

    public function agregarformapago($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'formapago' => 'required|string',
            ];
            if (request('tarjetapension') != null && request('formapago') != 4) {
                return back()->withErrors(['tarjetapension' => 'Solo se permite con forma de pago mensual']);
            }
            if (request('formapago') != 0 && request('formapago') != 1 && request('formapago') != 2 && request('formapago') != 4) {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago correcta']);
            }
            if (request('formapago') == 'nada') {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago']);
            }
            if (request('tarjetapensionatras') != null && request('formapago') != 4) {
                return back()->withErrors(['tarjetapensionatras' => 'Solo se permite con forma de pago mensual']);
            }
            if (request('tarjetapension') != null && request('tarjetapensionatras') == null) {
                return back()->withErrors(['tarjetapensionatras' => 'Llenar ambos campos de la tarjeta']);
            }
            if (request('tarjetapension') == null && request('tarjetapensionatras') != null) {
                return back()->withErrors(['tarjetapensionatras' => 'Llenar ambos campos de la tarjeta']);
            }
            request()->validate($rules);
            $actualizar = Carbon::now();
            $nowparce = Carbon::parse($actualizar)->format('Y-m-d');
            $contra = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $tarjetaverificacion = $contra[0]->tarjeta;
            $formapago = $contra[0]->pago;
            $abonos = DB::select("SELECT * FROM abonos a WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'
            AND STR_TO_DATE(a.created_at,'%Y-%m-%d') = '$nowparce'");
            if (request('formapago') > 0 && $contra[0]->pago == 0 && $contra[0]->enganche == 1) {
                return back()->withErrors(['formapago' => 'No se puede modificar con el abono de enganche']);
            }
            if (request('formapago') == 0 && $contra[0]->pago > 0 && $contra[0]->enganche == 1) {
                return back()->withErrors(['formapago' => 'No se puede modificar con el abono de enganche']);
            }

            //Validacion de cambiar forma de pago el administrador, director etc en estado ENVIADO
            if($contra[0]->estatus_estadocontrato == 12 && $contra[0]->pago != 0 && request('formapago') != 0) {
                return back()->withErrors(['formapago' => 'No se puede modificar la forma de pago']);
            }

            $totalabonohoy = 0;
            foreach ($abonos as $abc) {
                $totalabonohoy += $abc->abono;
            }
            $promo = $contra[0]->id_promocion;
            $pago = $contra[0]->pago;
            $estadoC = $contra[0]->estatus_estadocontrato;
            $promocion = DB::select("SELECT * FROM promocion WHERE id_franquicia = '$idFranquicia' AND id = '$promo'");
            if ($promocion != null) {
                $tipopromo = $promocion[0]->contado;
            } else {
                $tipopromo = "";
            }
            $forma = request('formapago');
            $semanal = 150;
            $quincenal = 300;
            $mensual = 450;
            $minimo = '';
            switch ($pago) {
                case 0:
                    if ($forma == 1) {
                        $minimo = $semanal;
                    }
                    if ($forma == 2) {
                        $minimo = $quincenal;
                    }
                    if ($forma == 4) {
                        $minimo = $mensual;
                    }
                    break;
                case 1:
                    if ($forma == 0) {
                        $minimo = $semanal;
                    }
                    if ($forma == 2) {
                        $minimo = $quincenal;
                    }
                    if ($forma == 4) {
                        $minimo = $mensual;
                    }
                    break;
                case 2:
                    if ($forma == 1) {
                        $minimo = $semanal;
                    }
                    if ($forma == 0) {
                        $minimo = $quincenal;
                    }
                    if ($forma == 4) {
                        $minimo = $mensual;
                    }
                    break;
                case 4:
                    if ($forma == 1) {
                        $minimo = $semanal;
                    }
                    if ($forma == 2) {
                        $minimo = $quincenal;
                    }
                    if ($forma == 0) {
                        $minimo = $mensual;
                    }
                    break;
            }
            if ($tipopromo == 1 && $pago != null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede cambiar la forma de pago con una promoción de poliza');
            }
//            if ($estadoC > 0 && $totalabonohoy < $minimo) {
//                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes abonar el minimo a la forma de pago para cambiarla');
//            }

            if (request('formapago') == 4) {
                $validacion = Validator::make($request->all(), [
                    'tarjetapension' => 'required|image|mimes:jpg',
                    'tarjetapensionatras' => 'required|image|mimes:jpg',
                ]);


                if ($validacion->fails()) {
                    return back()->withErrors([
                        'tarjetapension' => 'Campo requerido',
                        'tarjetapensionatras' => 'Campo requerido',
                    ]);
                }
            }

            $forma = request('formapago');

            $now = Carbon::now();
            $semana = $now->weekOfYear;
            $siguienteabono = $forma + $semana;

            $tarjetapension = '';   // by default empty
            if (request('tarjetapension') != null && request('formapago') == 4) {
                $fotoBruta = 'Foto-Tarjetapension-Frente-Contrato-' . $idContrato . '-' . time() . '.' . request()->file('tarjetapension')->getClientOriginalExtension();
                $tarjetapension = request()->file('tarjetapension')->storeAs('uploads/imagenes/contratos/tarjetapension', $fotoBruta, 'disco');
                $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapension/' . $fotoBruta)->height();
                $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapension/' . $fotoBruta)->width();
                if ($alto > $ancho) {
                    $imagentarjetapension = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapension/' . $fotoBruta)->resize(600, 800);
                } else {
                    $imagentarjetapension = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapension/' . $fotoBruta)->resize(800, 600);
                }
                $imagentarjetapension->save();
            }

            $tarjetapensionatras = '';   // by default empty
            if (request('tarjetapensionatras') != null && request('formapago') == 4) {
                $fotoBruta = 'Foto-Tarjetapension-Atras-Contrato-' . $idContrato . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta, 'disco');
                $alto1 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapensionatras/' . $fotoBruta)->height();
                $ancho1 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapensionatras/' . $fotoBruta)->width();
                if ($alto1 > $ancho1) {
                    $imagentarjetapensionatras = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapensionatras/' . $fotoBruta)->resize(600, 800);
                } else {
                    $imagentarjetapensionatras = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/tarjetapensionatras/' . $fotoBruta)->resize(800, 600);
                }
                $imagentarjetapensionatras->save();
            }
            if ($pago == 4 && $forma != 4) {
                Storage::disk('disco')->delete($contra[0]->tarjeta);
                Storage::disk('disco')->delete($contra[0]->tarjetapensionatras);
            }

            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                'pago' => $forma, 'tarjeta' => $tarjetapension, 'tarjetapensionatras' => $tarjetapensionatras,

            ]);

            //Guardar en tabla historialcontrato
            $randomId2 = $this->getHistorialContratoId();
            $usuarioId = Auth::user()->id;
            $formaPagoTexto = null;
            if($forma == 0) {
                $formaPagoTexto = 'Contado';
            }elseif ($forma == 1) {
                $formaPagoTexto = 'Semanal';
            }elseif ($forma == 2) {
                $formaPagoTexto = 'Quicenal';
            }elseif ($forma == 4) {
                $formaPagoTexto = 'Mensual';
            }
            DB::table('historialcontrato')->insert([
                'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => "Se actualizo la forma de pago '$formaPagoTexto'"
            ]);
            return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'la forma de pago se agrego correctamente.');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function correo()
    {

        $datos = [
            "usuario" => "Christian",
            "Fecha" => Carbon::now(),
            "Saldo" => "1600"
        ];
        Mail::to("marcosyera10@gmail.com")->queue(new prueba($datos));
    }

    public function agregarArchivoExcel()
    {
        \Log::info("Entro");
        $jsonDatos = request("datos");
        //dd($jsonDatos); //Asi es como llegaria
        $todosLosDatos = base64_decode($jsonDatos);//Obtenemos todos los datos
        $jsonContratos = json_decode($todosLosDatos, true);
        //dd($jsonContratos);

        //RECORRIDO DE CONTRATOS PARA INSERTAR REGISTRO EN TABLA CONTRATOS Y HISTORIALCLINICO
        if(!empty($jsonContratos)) {
            //jsonContratos es diferente a vacio

            foreach ($jsonContratos as $contrato) {

                $fechaActual = Carbon::now()->format('Y-m-d H:i:s');

                $IDCONTRATO = $this->getContratoId();
                $IDFRANQUICIA = self::validacionDeNulo($contrato['IDFRANQUICIA']);
                $IDZONA = self::validacionDeNulo($contrato['IDZONA']);
                $NOMBRE = self::validacionDeNulo($contrato['NOMBRE']);
                $CALLE = self::validacionDeNulo($contrato['CALLE']);
                $NUMERO = self::validacionDeNulo($contrato['NUMERO']);
                $COLONIA = self::validacionDeNulo($contrato['COLONIA']);
                $LOCALIDAD = self::validacionDeNulo($contrato['LOCALIDAD']);
                $TELEFONO = self::validacionDeNulo($contrato['TELEFONO']);
                $TELEFONOREFERENCIA = self::validacionDeNulo($contrato['TELEFONOREFERENCIA']);
                $FORMADEPAGO = self::validacionDeNulo($contrato['FORMADEPAGO']);
                $TOTAL = self::validacionDeNulo($contrato['TOTAL']);
                $ESTATUS_ESTADOCONTRATO = 2;
                if($TOTAL == null || $TOTAL  == 0 ) {
                    $ESTATUS_ESTADOCONTRATO = 5;
                }
                \Log::info( $IDCONTRATO);

                //Crear contrato
                DB::table("contratos")->insert([
                    "id" => $IDCONTRATO,
                    "datos" => '1',
                    "id_franquicia" => $IDFRANQUICIA,
                    "id_usuariocreacion" => '334', //Agregar el id_usuariocreacion
                    "nombre_usuariocreacion" => 'SISTEMAS MEZCALES', //Agregar el nombre_usuariocreacion
                    "id_zona" => $IDZONA,
                    "nombre" => $NOMBRE,
                    "calle" => $CALLE,
                    "numero" => $NUMERO,
                    "colonia" => $COLONIA,
                    "localidad" => $LOCALIDAD,
                    "telefono" => $TELEFONO,
                    "telefonoreferencia" => $TELEFONOREFERENCIA,
                    "id_optometrista" => '334', //Agregar el id_optometrista
                    "pago" => $FORMADEPAGO,
                    "total" => $TOTAL,
                    "contador" => '1',
                    "totalhistorial" => $TOTAL,
                    "estatus_estadocontrato" => $ESTATUS_ESTADOCONTRATO,
                    "fechaentrega" => $fechaActual,
                    "enganche" => 1,
                    "entregaproducto" => 1,
                    "poliza" => 1,
                    "created_at" => $fechaActual,
                    "updated_at" => $fechaActual,
                    'fechacobroini'=> '2021-10-08',
                    'fechacobrofin'=> '2021-10-15',
                ]);

                //Crear historial clinico
                $IDHISTORIAL = $this->getHistorialContratoId();
                $FECHAENTREGA = Carbon::now()->format('Y-m-d');
                DB::table("historialclinico")->insert([
                    "id" => $IDHISTORIAL,
                    "id_contrato" => $IDCONTRATO,
                    "edad" => '0',
                    "fechaentrega" => $FECHAENTREGA,
                    "diagnostico" => '?????',
                    "hipertension" => '?????',
                    "id_producto" => '1', //Agregar el idproducto
                    "id_paquete" => '1', //Agregar el idpaquete
                    "created_at" => $fechaActual,
                    "updated_at" => $fechaActual
                ]);

            }

        }//CONTRATOS

    }

    private static function validacionDeNulo($valor){
        $respuesta = null;
        if(strlen($valor) > 0) {
            $respuesta = $valor;
        }
        return $respuesta;
    }


    public function darFormatoContratos(){
        $contratos  = DB::select("SELECT id as ID,created_at as CREADOEL,fechacobroini as FECHAINICIAL,fechacobrofin as FECHAFINAL,ultimoabono as ULTIMOABONO,pago as FORMAPAGO, estatus_estadocontrato as ESTATUS,
                                        fechaentrega as FECHAENTREGA,fechaatraso as FECHAATRASO,costoatraso as ATRASO,total as TOTAL
                                        FROM contratos
                                        WHERE estatus_estadocontrato in (2,4)
                                        ORDER BY pago,ultimoabono,estatus_estadocontrato ASC");


        foreach ($contratos as $contrato){

            try {
                $idContrato = $contrato->ID;
                if ($contrato->ULTIMOABONO == null) { //El contrato tiene un abono?
                    //El contrato no tiene abonos
                    $fecha = "fechaentrega";
                    $actualizarFecha = $contrato->FECHAENTREGA;
                } else {
                    //El contrato tiene un abono
                    $fecha = "ultimoabono";
                    $actualizarFecha = $contrato->ULTIMOABONO;
                }

                $pagar = 0;

                //Forma de pago
                switch ($contrato->FORMAPAGO) {
                    case 1: //Semanal
                        $semanas = DB::select("SELECT ROUND(DATEDIFF(CURDATE(), ".$fecha.")/7, 0) as numero FROM contratos WHERE id = '$idContrato'");
                        if ($semanas[0]->numero != null) {
                            $pagar = 150;
                            $pagar = self::totalApagar($semanas[0]->numero, $pagar);
                        }
                        break;
                    case 2://Quincenal
                        $semanas = DB::select("SELECT ROUND(DATEDIFF(CURDATE(), ".$fecha.")/14, 0) as numero FROM contratos WHERE id = '$idContrato'");
                        if ($semanas[0]->numero != null) {
                            $pagar = 300;
                            $pagar = self::totalApagar($semanas[0]->numero, $pagar);
                        }
                        break;
                    case 4: //Mensual
                        $semanas = DB::select("SELECT ROUND(DATEDIFF(CURDATE(), ".$fecha.")/28, 0) as numero FROM contratos WHERE id = '$idContrato'");
                        if ($semanas[0]->numero != null) {
                            $pagar = 450;
                            $pagar = self::totalApagar($semanas[0]->numero, $pagar);
                        }
                        break;
                }

                if ($pagar > $contrato->TOTAL) {
                    $pagar = $contrato->TOTAL;
                }
                $estatus = "4";
                if ($pagar == 0) {
                    $estatus = "2";
                }else if( $contrato->TOTAL == 0){
                    $estatus = "5";
                }


                DB::table("contratos")->where("id", "=", $contrato->ID)->update([
                    "estatus_estadocontrato" => $estatus,
                    "ultimoabono" => $actualizarFecha,
                    "fechaatraso" => $actualizarFecha,
                    "costoatraso" => $pagar
                ]);

                \Log::info($contrato->ID.": Terminado");

            }catch(\Exception $e){
                \Log::info("Error:".$e);
            }
        }
    }

    public static function totalApagar($semanas,$pagar){
        switch($semanas){
            case 2:
                $pagar = $pagar * 2;
                break;
            case 3:
                $pagar = $pagar * 3;
                break;
            case 4:
                $pagar = $pagar * 4;
                break;
            case 5:
                $pagar = $pagar * 5;
                break;
            case 6:
                $pagar = $pagar * 6;
                break;
            case 7:
                $pagar = $pagar * 7;
                break;
            case 8:
                $pagar = $pagar * 8;
                break;
            case 9:
                $pagar = $pagar * 9;
                break;
            case 10:
                $pagar = $pagar * 10;
                break;
            case 11:
                $pagar = $pagar * 11;
                break;
            case 12:
                $pagar = $pagar * 12;
                break;
            default:
                break;
        }
        return $pagar;
    }
}


































