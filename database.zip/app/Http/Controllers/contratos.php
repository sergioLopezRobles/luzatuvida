<?php

namespace App\Http\Controllers;

use App\Clases\calculofechaspago;
use App\Clases\polizaGlobales;
use App\Mail\prueba;
use App\Mail\recordatorio;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use App\Clases\globales;
use App\Clases\contratosGlobal;
use Image;
use Illuminate\Support\Facades\Validator;
use App\Imports\CsvImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Clases\globalesServicioWeb;
use phpDocumentor\Reflection\Types\Array_;


class contratos extends Controller
{
    /* Metodo/Funcion: listacontrato
    Descripcion: Carga la lista de contratos, ademas hace validaciones para actualizar los estados de los contratos por si se salen
    si realizar las modificaciones necesarias.
    */
    public function listacontrato($idFranquicia)
    {
        $hoy = Carbon::now();
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {
            $cbGarantias = 0;
            $cbSupervision = 0;
            $cbAtrasado = 0;
            $cbEntrega = 0;
            $cbLaboratorio = 0;
            $cbConfirmacion = 0;
            $cbTodos = 0;

            $zonaU = null;
            $contratosgeneral = null;
            $contratosprioritarios = null;
            $contratosatrasados = null;
            $contratosperiodo = null;
            $contratosentregar = null;
            $contratoslaboratorio = null;
            $contratosconfirmaciones = null;
            $contratos = null;
            $contratosreportesgarantia = null;
            $contratossupervision = null;
            $contratosnoenviados = null;
            $contratosgarantiascreadas = null;
            $totalRegistros = 0;



            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia' ORDER BY zona");

            //Consulta paratraer los datos de la franquicia y mostrarlo en la seccion de arriba de los contratos.
            $franquiciaContratos = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.contrato.tabla', ['contratos' => $contratos, 'franquiciaContratos' => $franquiciaContratos, 'contratosperiodo' => $contratosperiodo,
                'contratosatrasados' => $contratosatrasados, 'contratosprioritarios' => $contratosprioritarios, 'contratosgeneral' => $contratosgeneral,
                'contratosentregar' => $contratosentregar, 'contratoslaboratorio' => $contratoslaboratorio, 'contratosconfirmaciones' => $contratosconfirmaciones,
                'contratosreportesgarantia' => $contratosreportesgarantia, 'contratossupervision' => $contratossupervision, 'contratosnoenviados' => $contratosnoenviados,
                'contratosgarantiascreadas' => $contratosgarantiascreadas,'zonas' => $zonas, 'cbGarantias' => $cbGarantias, 'cbSupervision' => $cbSupervision,
                'cbAtrasado' => $cbAtrasado, 'cbEntrega' => $cbEntrega, 'cbLaboratorio' => $cbLaboratorio,
                'cbConfirmacion' => $cbConfirmacion, 'cbTodos' => $cbTodos, 'zonaU' => $zonaU,
                'idFranquicia' => $idFranquicia, 'now' => $hoy, 'totalRegistros' => $totalRegistros]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private static function obtenerListaContratosConOSinFiltro($idFranquicia, $cobranza, $filtro, $arrayCheckBox)
    {

        $now = Carbon::now();
        $arrayContratos = array();

        $contratosprioritarios = array();
        $contratosatrasados = array();
        $contratosperiodo = array();
        $contratosentregar = array();
        $contratoslaboratorio = array();
        $contratosconfirmaciones = array();
        $contratos = array();
        $contratosreportesgarantia = array();
        $contratossupervision = array();
        $contratosnoenviados = array();
        $contratosgarantiascreadas = array();

        if ($cobranza) {
            //Rol cobranza

            $zonauser = Auth::user()->id_zona;
            $cadenaFiltro = " ";

            if ($filtro != null) {
                //Se buscara por filtro
                $cadenaFiltro = " AND (c.id LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%' OR c.colonia LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%') ";
            }

            $contratosTodos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion, c.fechacobrofin, c.fechacobroini,  c.fechaentrega,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono,  c.estatus_estadocontrato, c.diaseleccionado, c.fechaatraso,  c.total, c.totalreal,
                (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,c.localidad,c.colonia,c.calle,
                (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ultimoabono
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.id_franquicia = '$idFranquicia'
                AND c.id_zona = '$zonauser'
                " . $cadenaFiltro . "
                order by c.localidad,c.colonia,c.calle,c.numero,c.nombre,c.id asc");

            foreach ($contratosTodos as $contrato) {

                //Contratos prioritarios
                if ($contrato->diaseleccionado != null
                    && Carbon::parse($contrato->diaseleccionado)->format('Y-m-d') == Carbon::parse($now)->format('Y-m-d')
                    && $contrato->total > 0
                    && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                    array_push($contratosprioritarios, $contrato);
                }

                //Contratos atrasados
                if ($contrato->total > 0 && $contrato->estatus_estadocontrato == 4) {
                    array_push($contratosatrasados, $contrato);
                }

                //Contratos periodo
                if ($contrato->fechacobroini != null
                    && (Carbon::parse($now)->format('Y-m-d') >= Carbon::parse($contrato->fechacobroini)->format('Y-m-d')
                        && Carbon::parse($now)->format('Y-m-d') <= Carbon::parse($contrato->fechacobrofin)->format('Y-m-d') || ($contrato->ultimoabono != null && Carbon::parse($contrato->ultimoabono)->format('Y-m-d') == Carbon::parse($now)->format('Y-m-d')))
                    && $contrato->total > 0
                    && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)
                    && ($contrato->diaseleccionado == null || Carbon::parse($contrato->diaseleccionado)->format('Y-m-d') != Carbon::parse($now)->format('Y-m-d'))) {
                    array_push($contratosperiodo, $contrato);
                }

                //Contratos enviados
                if ($contrato->estatus_estadocontrato == 12) {
                    array_push($contratosentregar, $contrato);
                }

                //Contratos todos
                if ($contrato->fechaentrega != null
                    && Carbon::parse($contrato->fechaentrega)->format('Y-m-d') == Carbon::parse($now)->format('Y-m-d')
                    && ($contrato->estatus_estadocontrato == 2 || $contrato->estatus_estadocontrato == 5)) {
                    array_push($contratos, $contrato);
                }
            }

            array_push($arrayContratos, $contratosprioritarios);
            array_push($arrayContratos, $contratosatrasados);
            array_push($arrayContratos, $contratosperiodo);
            array_push($arrayContratos, $contratosentregar);
            array_push($arrayContratos, $contratos);

        } else {
            //Rol administrador para arriba

            $cbGarantias = $arrayCheckBox[0];
            $cbSupervision = $arrayCheckBox[1];
            $cbAtrasado = $arrayCheckBox[2];
            $cbEntrega = $arrayCheckBox[3];
            $cbLaboratorio = $arrayCheckBox[4];
            $cbConfirmacion = $arrayCheckBox[5];
            $cbTodos = $arrayCheckBox[6];
            $zonaU = $arrayCheckBox[7];
            $fechainibuscar = $arrayCheckBox[8];
            $fechafinbuscar = $arrayCheckBox[9];

            $cadenaZona = " ";
            if ($zonaU != null) {
                $cadenaZona = " AND c.id_zona = '$zonaU' ";
            }

            if ($fechainibuscar == null && $fechafinbuscar == null) {
                $fechainibuscar = Carbon::yesterday()->format('Y-m-d');
                $fechafinbuscar = Carbon::parse($now)->format('Y-m-d');
            }

            $cadenaFiltro = " ";
            $cadenaFechaIniYFechaFin = " ";
            if ($filtro != null) {
                //Se buscara por filtro
                $cadenaFiltro = " AND (c.id LIKE '%$filtro%' OR c.nombre_usuariocreacion LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%'
                OR z.zona LIKE '%$filtro%' OR c.calle LIKE '%$filtro%' OR c.numero LIKE '%$filtro%' OR c.localidad LIKE '%$filtro%'
                OR c.total LIKE '%$filtro%' OR c.totalabono LIKE '%$filtro%' OR c.telefono LIKE '%$filtro%'
                OR c.colonia LIKE '%$filtro%' OR c.telefonoreferencia LIKE '%$filtro%' OR c.idcontratorelacion LIKE '%$filtro%'
                OR c.nombrereferencia LIKE '%$filtro%') ";
            } else {
                //Se hace caso a las fechas
                $cadenaFechaIniYFechaFin = " AND c.id IN (SELECT r.id_contrato  FROM registroestadocontrato r WHERE (STR_TO_DATE(r.created_at ,'%Y-%m-%d') >= STR_TO_DATE('$fechainibuscar','%Y-%m-%d') AND STR_TO_DATE(r.created_at ,'%Y-%m-%d') <= STR_TO_DATE('$fechafinbuscar','%Y-%m-%d')) AND r.estatuscontrato = c.estatus_estadocontrato)";
            }

            if ($cbGarantias != null) {
                //cbGarantias esta checkeado

                $contratosgarantia = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso, c.fechaentrega, c.pago,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.totalreal,
                g.estadogarantia as estadogarantia,
                g.created_at as fechagarantia,
                COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ultimoabono
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                INNER JOIN garantias g
                ON g.id_contrato = c.id
                WHERE c.datos = 1
                AND c.id_franquicia = '$idFranquicia'
                " . $cadenaFiltro . "
                " . $cadenaZona . "
                AND g.estadogarantia IN (0,1)
                AND c.estatus_estadocontrato IN (2,5,12,4)
                order by g.created_at desc
                ");

                $array = array(); //Bandera de ids contratos para que no se mande 2 veces
                if ($contratosgarantia != null) {
                    //Tiene contratos
                    foreach ($contratosgarantia as $contrato) {
                        //Recorrido contratosgarantia
                        $idContrato = $contrato->id;

                        if (!in_array($idContrato, $array)) {
                            //No existe id_contrato en el arreglo $array
                            $contrato->dias = "";
                            $contrato->promo = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 0);
                            $contrato->fechaentregahistorial = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 1);

                            array_push($contratosreportesgarantia, $contrato); //Agregacion del contrato al arreglo de contratosreportesgaratia
                            array_push($array, $idContrato); //Se agrega el id_contrato al array para que este no vuelva a insertarse de nuevo
                        }

                    }
                }

                $garantiascreadas = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso, c.fechaentrega, c.pago,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.totalreal,
                g.estadogarantia as estadogarantia,
                g.created_at as fechagarantia,
                COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ultimoabono
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                INNER JOIN garantias g
                ON g.id_contrato = c.id
                WHERE c.datos = 1
                AND c.id_franquicia = '$idFranquicia'
                " . $cadenaFiltro . "
                " . $cadenaZona . "
                AND g.estadogarantia IN (2)
                AND c.estatus_estadocontrato IN (1)
                order by g.created_at desc
                ");

                $array = array(); //Bandera de ids contratos para que no se mande 2 veces
                if ($garantiascreadas != null) {
                    //Tiene contratos
                    foreach ($garantiascreadas as $contrato) {
                        //Recorrido $garantiascreadas
                        $idContrato = $contrato->id;

                        if (!in_array($idContrato, $array)) {
                            //No existe id_contrato en el arreglo $array
                            $contrato->dias = "";
                            $contrato->promo = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 0);
                            $contrato->fechaentregahistorial = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 1);

                            array_push($contratosgarantiascreadas, $contrato); //Agregacion del contrato al arreglo de contratosgarantiascreadas
                            array_push($array, $idContrato); //Se agrega el id_contrato al array para que este no vuelva a insertarse de nuevo
                        }

                    }
                }

            }

            $validacionEstados = "";
            if ($cbAtrasado != null || $cbTodos != null) {
                //Alguno de los 2 cb estan checkeados
                if ($cbAtrasado != null && $cbTodos != null) {
                    //Los 2 cb estan checkeados
                    $validacionEstados = "0,2,3,4,5,6,8,14";
                } else {
                    //1 de los 2 cb esta checkeado
                    if ($cbTodos != null) {
                        //cbTodos esta checkeado
                        $validacionEstados = "0,2,3,5,6,8,14";
                    } else {
                        //cbAtrasado esta checkeado
                        $validacionEstados = "4";
                    }
                }
            }

            $array = array(); //Bandera de ids contratos para que no se mande 2 veces
            if (strlen($validacionEstados) > 0) {
                //Alguno de los 2 cb (cbAtrasado o cbTodos) estan checkeados

                $query = "SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso, c.fechaentrega, c.pago,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.totalreal,
                COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ultimoabono
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.estatus_estadocontrato IN (" . $validacionEstados . ")
                AND c.id_franquicia = '$idFranquicia'
                " . $cadenaFiltro . "
                " . $cadenaZona . "
                " . $cadenaFechaIniYFechaFin . "
                order by c.created_at, c.id_zona, c.localidad, c.colonia, c.calle, c.numero, c.nombre DESC;
                ";
                $contratosTodos = DB::select($query);

                foreach ($contratosTodos as $contrato) {

                    $idContrato = $contrato->id;

                    if (!in_array($idContrato, $array)) {
                        //No existe id_contrato en el arreglo $array

                        $dias = "";
                        $contrato->promo = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 0);
                        $contrato->fechaentregahistorial = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 1);

                        //Contratos atrasados
                        if ($cbAtrasado != null) {
                            if ($contrato->total > 0 && $contrato->estatus_estadocontrato == 4) {
                                if ($contrato->fechaatraso != null) {
                                    $dias = Carbon::parse(Carbon::now())->diffInDays($contrato->fechaatraso);
                                }
                                $contrato->dias = $dias;
                                array_push($contratosatrasados, $contrato);
                                array_push($array, $idContrato); //Se agrega el id_contrato al array para que este no vuelva a insertarse de nuevo
                                continue;
                            }
                        }

                        //Contratos todos
                        if ($cbTodos != null) {
                            if ($contrato->estatus_estadocontrato != 4 && $contrato->estatus_estadocontrato != 12 && ($contrato->estatus_estadocontrato == 0 || $contrato->estatus_estadocontrato == 2
                                    || $contrato->estatus_estadocontrato == 3 || $contrato->estatus_estadocontrato == 5 || $contrato->estatus_estadocontrato == 6 || $contrato->estatus_estadocontrato == 8 || $contrato->estatus_estadocontrato == 14)) {
                                $contrato->dias = $dias;
                                array_push($contratos, $contrato);
                                array_push($array, $idContrato); //Se agrega el id_contrato al array para que este no vuelva a insertarse de nuevo
                            }
                        }

                    }

                }

            }

            $validacionEstados = "";
            if ($cbEntrega != null || $cbLaboratorio != null || $cbConfirmacion != null || $cbSupervision != null) {
                //Alguno de los 4 cb estan checkeados
                if ($cbEntrega != null && $cbLaboratorio != null && $cbConfirmacion != null && $cbSupervision != null) {
                    //Los 4 cb estan checkeados
                    $validacionEstados = "1,7,9,10,11,12,15";
                } else {
                    //Alguno de los 4 cb no esta checkeado
                    if ($cbLaboratorio != null) {
                        //cbLaboratorio esta checkeado
                        $validacionEstados = "7,10,11";
                        if ($cbConfirmacion != null || $cbEntrega != null || $cbSupervision != null) {
                            //Hay mas de uno checkeado
                            if ($cbConfirmacion != null) {
                                //cbConfirmacion esta checkeado
                                $validacionEstados = "1,7,9,10,11";
                                if ($cbEntrega != null || $cbSupervision != null) {
                                    //Hay mas de uno checkeado
                                    if ($cbEntrega != null) {
                                        //cbEntrega esta checkeado
                                        $validacionEstados = "1,7,9,10,11,12";
                                    } else {
                                        //cbSupervision esta checkeado
                                        $validacionEstados = "1,7,9,10,11,15";
                                    }
                                }
                            } else {
                                //cbConfirmacion no esta checkeado
                                if ($cbEntrega != null) {
                                    //cbEntrega esta checkeado
                                    $validacionEstados = "7,10,11,12";
                                    if ($cbSupervision != null) {
                                        //cbSupervision esta checkeado
                                        $validacionEstados = "7,10,11,12,15";
                                    }
                                } else {
                                    //cbEntrega no esta checkeado
                                    //cbSupervision esta checkeado
                                    $validacionEstados = "7,10,11,15";
                                }
                            }
                        }
                    } else {
                        //cbLaboratorio no esta checkeado
                        if ($cbConfirmacion != null) {
                            //cbConfirmacion esta checkeado
                            $validacionEstados = "1,9";
                            if ($cbEntrega != null || $cbSupervision != null) {
                                //Hay mas de uno checkeado
                                if ($cbEntrega != null) {
                                    //cbEntrega esta checkeado
                                    $validacionEstados = "1,9,12";
                                } else {
                                    //cbSupervision esta checkeado
                                    $validacionEstados = "1,9,15";
                                }
                            }
                        } else {
                            //cbConfirmacion no esta checkeado
                            if ($cbEntrega != null) {
                                //cbEntrega esta checkeado
                                $validacionEstados = "12";
                                if ($cbSupervision != null) {
                                    //cbSupervision esta checkeado
                                    $validacionEstados = "12,15";
                                }
                            } else {
                                //cbEntrega no esta checkeado
                                if ($cbSupervision != null) {
                                    //cbSupervision esta checkeado
                                    $validacionEstados = "15";
                                }
                            }
                        }
                    }
                }
            }

            if (strlen($validacionEstados) > 0) {
                //Alguno de los 4 cb (cbEntrega, cbLaboratorio, cbConfirmacion, cbSupervision) estan checkeados

                $consultacontratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus,  c.totalpromocion, e.descripcion, c.diaseleccionado, c.fechaatraso, c.fechaentrega, c.pago,
                c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion,  c.totalabono, c.estatus_estadocontrato, c.diaseleccionado,  c.fechacobrofin, c.fechacobroini,  c.total, c.totalreal,
                COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ultimoabono
                FROM contratos c
                INNER JOIN zonas z
                ON z.id = c.id_zona
                INNER JOIN estadocontrato e
                ON e.estatus = c.estatus_estadocontrato
                WHERE c.datos = 1
                AND c.id_franquicia = '$idFranquicia'
                " . $cadenaFiltro . "
                " . $cadenaZona . "
                AND c.estatus_estadocontrato IN (" . $validacionEstados . ")
                order by c.created_at, c.id_zona, c.localidad, c.colonia, c.calle, c.numero, c.nombre DESC;
                ");

                foreach ($consultacontratos as $contrato) {

                    $idContrato = $contrato->id;

                    $contrato->dias = "";
                    $contrato->promo = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 0);
                    $contrato->fechaentregahistorial = self::subquerysConsultaContratosLista($idContrato, $idFranquicia, 1);

                    //Contratos enviados
                    if ($cbEntrega != null) {
                        if ($contrato->estatus_estadocontrato == 12) {
                            if (Carbon::parse($now)->format('Y-m-d') > Carbon::parse($contrato->fechaentregahistorial)->format('Y-m-d')) {
                                //Ya paso la fecha de entrega
                                array_push($contratosnoenviados, $contrato);
                            } else {
                                //No ha pasado la fecha de entrega
                                array_push($contratosentregar, $contrato);
                            }
                            continue;
                        }
                    }

                    //Contratos laboratorio
                    if ($cbLaboratorio != null) {
                        if ($contrato->estatus_estadocontrato == 7 || $contrato->estatus_estadocontrato == 10 || $contrato->estatus_estadocontrato == 11) {
                            array_push($contratoslaboratorio, $contrato);
                            continue;
                        }
                    }

                    //Contratos confirmaciones
                    if ($cbConfirmacion != null) {
                        if ($contrato->estatus_estadocontrato == 1 || $contrato->estatus_estadocontrato == 9) {
                            array_push($contratosconfirmaciones, $contrato);
                            continue;
                        }
                    }

                    //Contratos supervision
                    if ($cbSupervision != null) {
                        if ($contrato->estatus_estadocontrato == 15) {
                            array_push($contratossupervision, $contrato);
                        }
                    }

                }

            }


            array_push($arrayContratos, $contratosprioritarios);
            array_push($arrayContratos, $contratosatrasados);
            array_push($arrayContratos, $contratosperiodo);
            array_push($arrayContratos, $contratosentregar);
            array_push($arrayContratos, $contratoslaboratorio);
            array_push($arrayContratos, $contratosconfirmaciones);
            array_push($arrayContratos, $contratos);
            array_push($arrayContratos, $contratosreportesgarantia);
            array_push($arrayContratos, $contratossupervision);
            array_push($arrayContratos, $contratosnoenviados);
            array_push($arrayContratos, $contratosgarantiascreadas);

        }

        return $arrayContratos;

    }

    private static function subquerysConsultaContratosLista($idContrato, $idFranquicia, $opcion)
    {
        $respuesta = "";

        switch ($opcion) {
            case 0:
                $respuesta = 0;
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                if ($contrato[0]->idcontratorelacion == null) {
                    //Es un contrato padre
                    $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");

                    if ($promocioncontrato != null) {
                        if ($promocioncontrato[0]->estado == 1) {
                            //Promocion esta activa
                            $respuesta = 1;
                        }
                    }
                }
                break;
            case 1:
                $historialclinico = DB::select("SELECT hc.fechaentrega FROM historialclinico hc WHERE hc.id_contrato = '$idContrato' ORDER BY hc.created_at LIMIT 1");
                if ($historialclinico != null) {
                    $respuesta = $historialclinico[0]->fechaentrega;
                }
                break;
        }

        return $respuesta;
    }

    /* Metodo/Funcion: getAbonosId
     Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
     */
    private function getAbonosId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from abonos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    /* Metodo/Funcion: getPromocionContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getPromocionContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from promocioncontrato where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    /* Metodo/Funcion: getContratoContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getContratoContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom2();
            $existente = DB::select("select id from contratoproducto where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    private static function getAbonosContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = self::generadorRandom2();
            $existente = DB::select("select id from abonos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }    // Comparar si ya existe el id en la base de datos


    /* Metodo/Funcion: getHistorialContratoId
    Descripcion: Esta función revisa si el ID alfanumerico que crea la funcion random no esta repetido en la BD es decir busca que sea unico.
    */
    private function getHistorialContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = self::generadorRandom2();
            $existente = DB::select("select id from historialcontrato where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }    // Comparar si ya existe el id en la base de datos

    /* Metodo/Funcion: generadorRandom2
    Descripcion: Esta función crea un ID alfanumerico de 5 digitos para registros
    */
    private static function generadorRandom2($length = 5)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    /* Metodo/Funcion: nuevocontrato
    Descripcion: Esta función  carga los datos necesarios para la vista de crear contratos
    */
    public function nuevocontrato($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $idUsuario = Auth::user()->id;
            //Consulta para traer el ultimo optometrista que registro el usuario en su ultimo contrato
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            //Consulta para traer la ultima zona registrada por el usuario en su ultimo contrato
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            //Consulta para llenar el campo de select de zonas en la vista para crear contratos
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            //Consulta para llenar el campo de select de zonas en la vista para crear contratos
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            return view('administracion.contrato.nuevo', ['idFranquicia' => $idFranquicia, 'zonas' => $zonas, 'optometristas' => $optometristas, 'ultimaZona' => $ultimaZona, 'ultimoOptometrista' => $ultimoOptometrista]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    /* Metodo/Funcion: nuevocontrato2
    Descripcion: Esta función se manda a llamar en terminar contrato de los contratos padres con promocion o los que no tienen, se hacen lso calculos necsarios para los totales y mandara a llamar la creación de nuevos contratos si es necesario.
    */
    public function nuevocontrato2($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $idUsuario = Auth::user()->id;
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            //Consulta para traer los datos necesarios del contrato y con ello poder realizar divorsos movimientos en la vista y el controlador
            $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, pr.armazones, c.totalproducto, c.totalhistorial, c.totalpromocion, c.correo, c.estatus,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador, pr.preciop, c.total, c.totalabono, c.nombrereferencia, pr.preciouno,pr.tipopromocion, c.telefonoreferencia,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN users u
            ON u.id = c.id_optometrista
			INNER JOIN promocion pr
			ON pr.id = c.id_promocion
            WHERE c.datos = 1
            AND c.id = '$idContrato'
            AND c.id_franquicia = '$idFranquicia'");
            //Consulta para traer los datos del tratamiento fotocromatico en la tabla de tratamientos
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            //Consulta para traer los datos del tratamiento A/R en la tabla de tratamientos
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            //Consulta para traer los datos del tratamiento Tinte en la tabla de tratamientos
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            //Consulta para traer los datos del tratamiento Blueray en la tabla de tratamientos
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            //Consulta para traer los datos de los paquetes en la tabla de paquetes
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            //Consulta para traer los registros de los productos de tipo armazon para el select en la creacion de historialclinico
            $armazones = DB::select("SELECT * FROM producto WHERE  id_tipoproducto = '1' order by nombre");
            //Consulta de los datos del contrato
            $ct = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            //Consulta de los datos de los historiales clinicos del contrato
            $historialesclinicos = DB::select("SELECT nombre, h.edad, h.fechaentrega, c.telefono, h.id_paquete, h.created_at, h.diagnostico FROM historialclinico h
            inner join contratos c
            on c.id = h.id_contrato
            WHERE id_contrato ='$idContrato'");
            //Consulta de los contratos hijos de una promocion que aun no esten terminados.
            $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato' AND estatus_estadocontrato = 0 limit 1");
            $Hi = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $Hi2 = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato'");
            $relacion = $Hi[0]->id;
            $idPadre = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonoproducto = DB::select("SELECT * FROM abonos  WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = '7'");
            $contratoproducto = DB::select("SELECT * FROM contratoproducto  WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");
            $contratohijo = $ct[0]->idcontratorelacion;
            $contador = $ct[0]->contador;
            $totalhistorial = $ct[0]->totalhistorial;
            $totalabonos = $ct[0]->totalabono;
            $estatus = $ct[0]->estatus_estadocontrato;
            $totalproductos = $ct[0]->totalproducto;
            $promo = $ct[0]->id_promocion;
            $pago = $ct[0]->pago;
            $total = $ct[0]->total;
            if ($abonoproducto == null && $totalproductos > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($abonoproducto != null && $abonoproducto[0]->abono != $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($totalabonos < $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Abonar el total de productos');
            }
            if ($pago === null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de elegir una forma de pago');
            }
            if ($contratohijo != null && $pago == 0 && $estatus >= 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratohijo])->with('bien', 'El contrato se terminara al final de los demas, cuANDo tenga el costo promoción');
            }
            if ($abonoproducto != null && $contratoproducto == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El contrato tiene abono de producto y no hay productos registrados, favor de eliminarlos');
            }
            if ($contratohijo != null && $promo == null) {
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus' => 1, 'estatus_estadocontrato' => 1,
                ]);
                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 1,
                    'created_at' => Carbon::now()
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratohijo])->with('bien', 'El contrato se termino correcatemente');
            }
            if ($historialesclinicos == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de llenar los historiales clinicos necesarios');
            }

            if ($pago == 0 && $total == 0 && $Hi2 == null) {

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 1,
                ]);
                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 1,
                    'created_at' => Carbon::now()
                ]);
                return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'No hay contratos pendientes por completar');
            }
            if ($promo == null) {
                $totalcontrato = $totalhistorial + $totalproductos - $totalabonos;
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $totalcontrato, 'estatus' => 1, 'estatus_estadocontrato' => 1,
                ]);
                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 1,
                    'created_at' => Carbon::now()
                ]);
                return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'No hay contratos pendientes por completar');
            } else {
                if ($contrashijos != null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrashijos[0]->id])->with('alerta', 'Favor de completar el contrato pendiente');
                }
                $cant = $contratos[0]->armazones;
                $cont = $contratos[0]->contador;
                $tothistorial = $contratos[0]->totalhistorial;
                $porcentaje = $contratos[0]->preciop;
                $preciounico = $contratos[0]->preciouno;
                $tipopro = $contratos[0]->tipopromocion;
                $estado = $contratos[0]->estatus;

                if ($cont == $cant) {

                    if ($contratohijo == null && $promo != null && $contador == 1 && $estado == 0) {
                        if ($tipopro == 1) {
                            $totalporcentaje = $preciounico;
                        } else {
                            $totalporcentaje = (($tothistorial * $porcentaje) / 100);
                        }
                        $totalporcentaje = number_format($totalporcentaje, 1, '.', '');
                        $totalnuevo = $tothistorial - $totalporcentaje;
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $totalnuevo, 'totalpromocion' => $totalnuevo, 'estatus' => 1, 'estatus_estadocontrato' => 1, 'promocionterminada' => 1
                        ]);
                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => 1,
                            'created_at' => Carbon::now()
                        ]);
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se realizo el calculo del contrato con promoción');
                    }

                    $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato' AND estatus_estadocontrato = 0 limit 1");
                    if ($contrashijos != null && $contrashijos[0]->estatus == 1) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 1, 'promocionterminada' => 1
                        ]);
                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => 1,
                            'created_at' => Carbon::now()
                        ]);
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrashijos[0]->id])->with('bien', 'Favor de completar el contrato pendiente');
                    }
                    if ($contrashijos != null && $contrashijos[0]->estatus == 0) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrashijos[0]->id])->with('bien', 'Favor de completar el contrato pendiente');
                    }
                    if ($contrashijos == null) {

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 1, 'promocionterminada' => 1
                        ]);
                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => 1,
                            'created_at' => Carbon::now()
                        ]);
                        return redirect()->route('listacontrato', $idFranquicia)->with('bien', 'No hay contratos pendientes por completar');
                    }
                }
            }
            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                'estatus_estadocontrato' => 1,
            ]);
            //Insertar en tabla registroestadocontrato
            DB::table('registroestadocontrato')->insert([
                'id_contrato' => $idContrato,
                'estatuscontrato' => 1,
                'created_at' => Carbon::now()
            ]);
            return view('administracion.historialclinico.nuevohijo', ['idFranquicia' => $idFranquicia, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'armazones' => $armazones, 'contratos' => $contratos,
                'ultimoOptometrista' => $ultimoOptometrista, 'ultimaZona' => $ultimaZona, 'zonas' => $zonas, 'idContrato' => $idContrato, 'idcontratopadre' => $relacion]);


        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratoHijos($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $idUsuario = Auth::user()->id;
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $armazones = DB::select("SELECT * FROM producto WHERE  id_tipoproducto = '1' order by nombre");
            $ct = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $historialesclinicos = DB::select("SELECT nombre, h.edad, h.fechaentrega, c.telefono, h.id_paquete, h.created_at, h.diagnostico FROM historialclinico h
            inner join contratos c
            on c.id = h.id_contrato
            WHERE id_contrato ='$idContrato'");
            $Hi = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonoproducto = DB::select("SELECT * FROM abonos  WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = '7'");
            $relacion = $Hi[0]->idcontratorelacion;
            $pagohijofinal = $Hi[0]->pago;
            $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, pr.armazones, c.totalproducto, c.totalhistorial, c.totalpromocion, c.correo,
            c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador, pr.preciop, c.total, c.totalabono, pr.preciouno, pr.tipopromocion, c.nombrereferencia, c.telefonoreferencia,
            (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
            FROM contratos c
            INNER JOIN zonas z
            ON z.id = c.id_zona
            INNER JOIN users u
            ON u.id = c.id_optometrista
            INNER JOIN promocion pr
            ON pr.id = c.id_promocion
            WHERE c.datos = 1
            AND c.id = '$relacion'
            AND c.id_franquicia = '$idFranquicia'");
            $estadocontrato = $ct[0]->estatus_estadocontrato;
            $contratohijo = $ct[0]->idcontratorelacion;
            $totalhistorial = $ct[0]->totalhistorial;
            $totalabonos = $ct[0]->totalabono;
            $estatus = $ct[0]->estatus;
            $totalproductos = $ct[0]->totalproducto;
            $promo = $ct[0]->id_promocion;
            $pago = $ct[0]->pago;
            $total = $ct[0]->total;
            if ($abonoproducto == null && $totalproductos > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($abonoproducto != null && $abonoproducto[0]->abono != $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Los abonos de producto no concuerdan con el total de productos');
            }
            if ($totalabonos < $totalproductos) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de abonar el total de los productos');
            }
            $cant = $contratos[0]->armazones;
            $cont = $contratos[0]->contador;
            $tothistorial = $contratos[0]->totalhistorial;
            if ($cont == $cant) {

                $contras = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'
                    order by totalhistorial asc
                    limit 1;");

                $cantmenor = $contras[0]->totalhistorial;
                $cantpadre = $contratos[0]->totalhistorial;
                $cantpromo = $contratos[0]->totalpromocion;
                $porcentaje = $contratos[0]->preciop;
                $preciounico = $contratos[0]->preciouno;
                $tipopro = $contratos[0]->tipopromocion;

                if ($cantmenor >= $cantpadre) {
                    if ($tipopro == 1) {
                        $totalporcentaje = $preciounico;
                    } else {
                        $totalporcentaje = (($cantpadre * $porcentaje) / 100);
                    }
                    $totalporcentaje = number_format($totalporcentaje, 1, '.', '');
                } else {
                    if ($tipopro == 1) {
                        $totalporcentaje = $preciounico;
                    } else {
                        $totalporcentaje = (($cantmenor * $porcentaje) / 100) + $cantpromo;
                    }
                    $totalporcentaje = number_format($totalporcentaje, 1, '.', '');
                }

                $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'");
                $contraspadre = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$relacion'");

                $sumahijos = DB::select("SELECT SUM(totalhistorial) AS sumahijos FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'");
                $canthijos = DB::select("SELECT COUNT(id) AS canthijos FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion'");
                $floatsumahijos = intval($sumahijos[0]->sumahijos);
                $floatcanthijos = intval($canthijos[0]->canthijos);
                $totalpromofinal = (($contraspadre[0]->totalhistorial + $floatsumahijos - $totalporcentaje) / ($floatcanthijos + 1));
                $totalpromofinal = number_format($totalpromofinal, 1, '.', '');
                $totalfinalhijos = $contrashijos[0]->totalproducto + $totalpromofinal - $contrashijos[0]->totalabono;
                $totalfinal = $contraspadre[0]->totalproducto + $totalpromofinal - $contraspadre[0]->totalabono;
                if ($contrashijos[0]->pago == 0) {
                    $totalfinalhijos = $totalpromofinal;
                    $totalfinal = $totalpromofinal;
                }
                if ($contraspadre[0]->pago == 0) {
                    $totalfinalhijos = $totalpromofinal;
                    $totalfinal = $totalpromofinal;
                }

                $hijocontra = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$relacion' AND estatus_estadocontrato = 0");
                $pagohijo = $hijocontra[0]->pago;
                $estatushijo = $hijocontra[0]->estatus;

                if ($estatushijo == 0) {
                    DB::table('contratos')->where([['id', '=', $relacion], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus' => 1, 'total' => $totalfinal, 'totalpromocion' => $totalpromofinal, 'promocionterminada' => 1
                    ]);
                    DB::table('contratos')->where([['idcontratorelacion', '=', $relacion], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus' => 1, 'total' => $totalfinalhijos, 'totalpromocion' => $totalpromofinal, 'promocionterminada' => 1
                    ]);
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus' => 1, 'estatus_estadocontrato' => 1, 'total' => $totalfinalhijos, 'totalpromocion' => $totalpromofinal, 'promocionterminada' => 1
                    ]);
                    //Insertar en tabla registroestadocontrato
                    DB::table('registroestadocontrato')->insert([
                        'id_contrato' => $idContrato,
                        'estatuscontrato' => 1,
                        'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $relacion])->with('bien', 'Se han creado todos los contratos ');
                }
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $relacion])->with('bien', 'Se han creado todos los contratos');
            } else {

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 1,
                ]);
                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 1,
                    'created_at' => Carbon::now()
                ]);
                return view('administracion.historialclinico.nuevohijo', ['idFranquicia' => $idFranquicia, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                    'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'armazones' => $armazones, 'contratos' => $contratos,
                    'ultimoOptometrista' => $ultimoOptometrista, 'ultimaZona' => $ultimaZona, 'zonas' => $zonas, 'idContrato' => $idContrato, 'idcontratopadre' => $relacion]);
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function agregarpromocion($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $rules = [
                'promocion' => 'required|integer',
            ];
            if (request('promocion') == 0) {
                return back()->withErrors(['promocion' => 'Elegir una promoción'])->withInput($request->all());

            }
            request()->validate($rules);
            $abonospromo = DB::select("SELECT COUNT(a.id) as conteo FROM abonos a INNER JOIN contratos c ON a.id_contrato = c.id
            WHERE CAST(a.tipoabono as SIGNED) != 7 AND (c.id = '$idContrato' OR c.idcontratorelacion = '$idContrato')");
            if ($abonospromo[0]->conteo > 0) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede agregar con abonos ya registrados en los contratos de la promoción');
            }
            $randomId = $this->getPromocionContratoId();

            $promo = request('promocion');
            $creacion = Carbon::now();
            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                'id_promocion' => $promo
            ]);
            DB::table('promocion')->where([['id', '=', $promo], ['id_franquicia', '=', $idFranquicia]])->update([
                'asignado' => 1
            ]);
            DB::table('promocioncontrato')->insert([
                'id' => $randomId, 'id_contrato' => $idContrato, 'id_franquicia' => $idFranquicia, 'id_promocion' => $promo, 'estado' => 1, 'created_at' => $creacion
            ]);
            return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'la promoción se agrego correctamente.');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function getContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom();
            $existente = DB::select("select id from contratos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }   // Comparar si ya existe el id en la base de datos

    private function generadorRandom($length = 10)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rAND(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    // Generador rANDom

    public function crearcontrato($idFranquiciaContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $rules = [
                'zona' => 'required',
                'nombre' => 'required|string|max:255',
                'optometrista' => 'required|integer',
                'calle' => 'required|string|max:255',
                'numero' => 'required|string|min:1|max:255',
                'formapago' => 'required|string|min:1|max:255',
                'departamento' => 'required|string|max:255',
                'alladode' => 'required|string|max:255',
                'frentea' => 'required|string|max:255',
                'entrecalles' => 'required|string|max:255',
                'colonia' => 'required|string|max:255',
                'localidad' => 'required|string|max:255',
                'telefono' => 'required|string|size:10|regex:/[0-9]/',
                'tr' => 'required|string|size:10|regex:/[0-9]/',
                'casatipo' => 'required|string|max:255',
                'nr' => 'required|string|max:255',
                'casacolor' => 'required|string|max:255',
                'fotoine' => 'required|image|mimes:png',
                'fotoineatras' => 'required|image|mimes:png',
                'fotocasa' => 'required|image|mimes:png',
                'comprobantedomicilio' => 'required|image|mimes:png',
            ];
            if (request('tarjetapension') != null && request('formapago') != 'Mensual') {
                return back()->withErrors(['tarjetapension' => 'Solo se permite con forma de pago mensual'])->withInput($request->all());
            }
            if (request('formapago') == 'Seleccionar') {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago'])->withInput($request->all());
            }
            if (request('tarjetapensionatras') != null && request('formapago') != 'Mensual') {
                return back()->withErrors(['tarjetapensionatras' => 'Solo se permite con forma de pago mensual'])->withInput($request->all());
            }
            if (request('tarjetapension') != null && request('tarjetapensionatras') == null) {
                return back()->withErrors(['tarjetapensionatras' => 'Llenar ambos campos de la tarjeta'])->withInput($request->all());
            }
            if (request('tarjetapension') == null && request('tarjetapensionatras') != null) {
                return back()->withErrors(['tarjetapensionatras' => 'Llenar ambos campos de la tarjeta'])->withInput($request->all());
            }
            if (request('zona') == 'Seleccionar') {
                return back()->withErrors(['zona' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
            }
            if (request('optometrista') == 'Seleccionar') {
                return back()->withErrors(['optometrista' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
            }
            request()->validate($rules);
            if (strlen(request('zona')) > 0 && strlen(request('optometrista')) && strlen(request('formapago')) > 0 && strlen(request('nombre')) > 0 && strlen(request('calle')) > 0 && strlen(request('numero')) > 0
                && strlen(request('alladode')) > 0 && strlen(request('frentea')) > 0 && strlen(request('entrecalles')) > 0 && strlen(request('colonia')) > 0
                && strlen(request('localidad')) > 0 && strlen(request('telefono')) > 0 && strlen(request('casatipo')) > 0 && strlen(request('casacolor')) > 0
                && strlen(request('fotoine')) && strlen(request('fotocasa')) && strlen(request('comprobantedomicilio'))) {


                try {

                    $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                    $randomId = $this->getContratoId();


                    $fotoBruta = 'Foto-Ine-Frente-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                    $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');

                    $fotoBruta = 'Foto-Ine-Atras-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                    $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');

                    $fotoBruta = 'Foto-Casa-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                    $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta, 'disco');

                    $fotoBruta = 'Foto-comprobantedomicilio-Contrato-' . $randomId . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                    $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedomicilio', $fotoBruta, 'disco');

                    $tarjetapension = '';   // by default empty
                    if (request('tarjetapension') != null && request('formapago') == 'Mensual') {
                        $fotoBruta = 'Foto-Tarjetapension-Frente-Contrato-' . $randomId . '-' . time() . '.' . request()->file('tarjetapension')->getClientOriginalExtension();
                        $tarjetapension = request()->file('tarjetapension')->storeAs('uploads/imagenes/contratos/tarjetapension', $fotoBruta, 'disco');
                    }

                    $tarjetapensionatras = '';   // by default empty
                    if (request('tarjetapensionatras') != null && request('formapago') == 'Mensual') {
                        $fotoBruta = 'Foto-Tarjetapension-Atras-Contrato-' . $randomId . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta, 'disco');
                    }


                    $datos = 1;
                    $creacion = Carbon::now();
                    $usuarioId = Auth::user()->id;
                    $usuarioNombre = Auth::user()->name;
                    DB::table('contratos')->insert([
                        'id' => $randomId, 'datos' => $datos, 'id_franquicia' => $idFranquiciaContrato, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => request('zona'), 'id_promocion' => request('promocion'), 'id_optometrista' => request('optometrista'),
                        'nombre' => request('nombre'), 'pago' => request('formapago'), 'calle' => request('calle'), 'numero' => request('numero'), 'depto' => request('departamento'), 'alladode' => request('alladode'), 'frentea' => request('frentea'),
                        'entrecalles' => request('entrecalles'), 'colonia' => request('colonia'), 'localidad' => request('localidad'), 'telefono' => request('telefono'), 'casatipo' => request('casatipo'), 'casacolor' => request('casacolor'), 'created_at' => $creacion,
                        'nombrereferencia' => request('nr'), 'telefonoreferencia' => request('tr'), 'fotoine' => $fotoine, 'fotocasa' => $fotocasa, 'comprobantedomicilio' => $comprobantedomicilio, 'tarjeta' => $tarjetapension, 'fotoineatras' => $fotoineatras, 'tarjetapensionatras' => $tarjetapensionatras, 'contador' => 1
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquiciaContrato, 'idContrato' => $randomId])->with('bien', 'El contrato se actualizo correctamente.');
                } catch (\Exception $e) {
                    \Log::info("Error: " . $e->getMessage());
                    return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                }
            } else {
                return back()->with('alerta', 'Para continuar es necesario llenar todos los campos.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function crearcontrato2($idFranquiciaContrato, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                // 'nombre'=>'required|string|max:255',
                // 'telefono' => 'required|string|size:10|regex:/[0-9]/',
            ];
            request()->validate($rules);

            try {

                $contra = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, c.telefonoreferencia, c.nombrereferencia,
                    c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador,
                    (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
                    FROM contratos c
                    INNER JOIN zonas z
                    ON z.id = c.id_zona
                    INNER JOIN users u
                    ON u.id = c.id_optometrista
                    INNER JOIN promocion pr
                    ON pr.id = c.id_promocion
                    WHERE c.datos = 1
                    AND c.id = '$idContrato'
                    AND c.id_franquicia = '$idFranquiciaContrato'");
                $zona = $contra[0]->zona;
                $optometrista = $contra[0]->id_optometrista;
                $calle = $contra[0]->calle;
                $pago = $contra[0]->pago;
                $numero = $contra[0]->numero;
                $depto = $contra[0]->depto;
                $alladode = $contra[0]->alladode;
                $frentea = $contra[0]->frentea;
                $entrecalles = $contra[0]->entrecalles;
                $colonia = $contra[0]->colonia;
                $localidad = $contra[0]->localidad;
                $casatipo = $contra[0]->casatipo;
                $casacolor = $contra[0]->casacolor;
                $contador = $contra[0]->contador;
                $telefonoR = $contra[0]->telefonoreferencia;
                $nombreR = $contra[0]->nombrereferencia;
                $suma = $contador + 1;

                $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                $randomId = $this->getContratoId();
                $datos = 1;
                $creacion = Carbon::now();
                $usuarioId = Auth::user()->id;
                $usuarioNombre = Auth::user()->name;

                DB::table('contratos')->insert([
                    'id' => $randomId, 'datos' => $datos, 'id_franquicia' => $idFranquiciaContrato, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => $zona, 'id_optometrista' => $optometrista,
                    'nombre' => request('nombre'), 'pago' => $pago, 'calle' => $calle, 'numero' => $numero, 'depto' => $depto, 'alladode' => $alladode, 'frentea' => $frentea,
                    'entrecalles' => $entrecalles, 'colonia' => $colonia, 'localidad' => $localidad, 'telefono' => request('telefono'), 'casatipo' => $casatipo, 'casacolor' => $casacolor, 'created_at' => $creacion,
                    'idcontratorelacion' => $idContrato, 'nombrereferencia' => $nombreR, 'telefonoreferencia' => $telefonoR
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquiciaContrato]])->update([
                    'contador' => $suma
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquiciaContrato, 'idContrato' => $randomId])->with('bien', 'El contrato se actualizo correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function filtrarlistacontrato($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4)) {
            $contratoslaboratorio = null;
            $contratosconfirmaciones = null;
            $contratosreportesgarantia = null;
            $contratossupervision = null;
            $contratosnoenviados = null;
            $contratosgarantiascreadas = null;
            $cbGarantias = null;
            $cbSupervision = null;
            $cbAtrasado = null;
            $cbEntrega = null;
            $cbLaboratorio = null;
            $cbConfirmacion = null;
            $cbTodos = null;
            $zonaU = null;
            $fechainibuscar = null;
            $fechafinbuscar = null;

            $arrayCheckBox = array();

            $filtro = request('filtro');
            $now = Carbon::now();
            $contratosgeneral = DB::select("SELECT * FROM contratos ");
            if (((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) {
                $idUsuario = Auth::user()->id;
                $contratosatrasados = "";
                $contratosprioritarios = "";
                $contratosperiodo = "";
                $contratosentregar = "";

                $contratos = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.estatus, c.totalpromocion, e.descripcion,  c.fechacobrofin, c.fechacobroini,
                 c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at, c.idcontratorelacion, c.totalabono, c.estatus_estadocontrato, c.diaseleccionado, c.total, c.fechaentrega,
                 (ifnull(totalhistorial,0) + ifnull(totalproducto,0)) as totalsinabono,
                 (ifnull(totalpromocion,0) + ifnull(totalproducto,0)) as totalsinabonopromo,
                 (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as resta ,
                 (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                 (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo,
                 (SELECT p.nombre from historialclinico hc INNER JOIN paquetes p ON p.id = hc.id_paquete WHERE hc.id_contrato = c.id limit 1) as paquete,
                 (SELECT ab.created_at FROM abonos ab WHERE ab.id_contrato = c.id ORDER BY ab.id DESC LIMIT 1) as ultfecha,
                 COALESCE((SELECT a.created_at FROM abonos a WHERE a.id_contrato = c.id ORDER BY a.created_at DESC LIMIT 1), '') as ultimoabono
                 FROM contratos c
                 INNER JOIN zonas z
                 ON z.id = c.id_zona
                 INNER JOIN estadocontrato e
                 ON e.estatus = c.estatus_estadocontrato
                 WHERE c.datos = 1
                 AND c.estatus_estadocontrato  < 2
                 AND c.id_franquicia = '$idFranquicia'
                 AND (c.id LIKE '%$filtro%' OR c.nombre LIKE '%$filtro%')
                 AND c.id_usuariocreacion = '$idUsuario'
                 order by c.created_at desc
                 ");
            } elseif (((Auth::user()->rol_id) == 4)) {

                $arrayContratos = self::obtenerListaContratosConOSinFiltro($idFranquicia, true, $filtro, $arrayCheckBox);

                $contratosprioritarios = $arrayContratos[0];
                $contratosatrasados = $arrayContratos[1];
                $contratosperiodo = $arrayContratos[2];
                $contratosentregar = $arrayContratos[3];
                $contratos = $arrayContratos[4];

            } else {

                $cbGarantias = 0;
                $cbSupervision = 0;
                $cbAtrasado = 0;
                $cbEntrega = 0;
                $cbLaboratorio = 0;
                $cbConfirmacion = 0;
                $cbTodos = 0;

                if ($filtro != null) {
                    $cbGarantias = 1;
                    $cbSupervision = 1;
                    $cbAtrasado = 1;
                    $cbEntrega = 1;
                    $cbLaboratorio = 1;
                    $cbConfirmacion = 1;
                    $cbTodos = 1;
                }

                array_push($arrayCheckBox, $cbGarantias);
                array_push($arrayCheckBox, $cbSupervision);
                array_push($arrayCheckBox, $cbAtrasado);
                array_push($arrayCheckBox, $cbEntrega);
                array_push($arrayCheckBox, $cbLaboratorio);
                array_push($arrayCheckBox, $cbConfirmacion);
                array_push($arrayCheckBox, $cbTodos);
                array_push($arrayCheckBox, $zonaU);
                array_push($arrayCheckBox, $fechainibuscar);
                array_push($arrayCheckBox, $fechafinbuscar);

                $arrayContratos = self::obtenerListaContratosConOSinFiltro($idFranquicia, false, $filtro, $arrayCheckBox);

                $contratosprioritarios = $arrayContratos[0];
                $contratosatrasados = $arrayContratos[1];
                $contratosperiodo = $arrayContratos[2];
                $contratosentregar = $arrayContratos[3];
                $contratoslaboratorio = $arrayContratos[4];
                $contratosconfirmaciones = $arrayContratos[5];
                $contratos = $arrayContratos[6];
                $contratosreportesgarantia = $arrayContratos[7];
                $contratossupervision = $arrayContratos[8];
                $contratosnoenviados = $arrayContratos[9];
                $contratosgarantiascreadas = $arrayContratos[10];

                //Unir arrelos para contar registros sin repetir contratos
                $contratosGeneral = array_merge($contratosprioritarios, $contratosatrasados, $contratosperiodo, $contratosentregar, $contratoslaboratorio, $contratosconfirmaciones, $contratos,
                    $contratosreportesgarantia, $contratossupervision, $contratosnoenviados, $contratosgarantiascreadas);
                $idContratos = [];

                //Extraemos el id de cada contrato
                foreach ($contratosGeneral as $contratoGeneral){
                    array_push($idContratos, $contratoGeneral->id);
                }

                //Eliminamos contratos repetidos
                $idContratosUnicos = array_unique($idContratos);
                $totalRegistros = sizeof($idContratosUnicos);

            }

            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia'");
            $franquiciaContratos = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.contrato.tabla', ['contratos' => $contratos, 'franquiciaContratos' => $franquiciaContratos, 'contratosgeneral' => $contratosgeneral,
                'contratosperiodo' => $contratosperiodo, 'now' => $now, 'contratosatrasados' => $contratosatrasados, 'contratosprioritarios' => $contratosprioritarios,
                'contratosentregar' => $contratosentregar, 'contratoslaboratorio' => $contratoslaboratorio, 'contratosconfirmaciones' => $contratosconfirmaciones, 'contratosreportesgarantia' => $contratosreportesgarantia, 'contratossupervision' => $contratossupervision, 'contratosnoenviados' => $contratosnoenviados, 'contratosgarantiascreadas' => $contratosgarantiascreadas,
                'zonas' => $zonas, 'cbGarantias' => $cbGarantias, 'cbSupervision' => $cbSupervision, 'cbAtrasado' => $cbAtrasado, 'cbEntrega' => $cbEntrega, 'cbLaboratorio' => $cbLaboratorio,
                'cbConfirmacion' => $cbConfirmacion, 'cbTodos' => $cbTodos, 'zonaU' => $zonaU, 'idFranquicia' => $idFranquicia, 'totalRegistros' => $totalRegistros]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function filtrarlistacontratocheckbox($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            $arrayCheckBox = array();

            $cbGarantias = request('cbGarantias');
            $cbSupervision = request('cbSupervision');
            $cbAtrasado = request('cbAtrasado');
            $cbEntrega = request('cbEntrega');
            $cbLaboratorio = request('cbLaboratorio');
            $cbConfirmacion = request('cbConfirmacion');
            $cbTodos = request('cbTodos');
            $zonaU = request('zonaU');
            $fechainibuscar = request('fechainibuscar');
            $fechafinbuscar = request('fechafinbuscar');

            if (strlen($fechafinbuscar) > 0 && strlen($fechainibuscar) == 0) {
                //fechafin diferente de vacio y fechaini vacio
                return back()->with('alerta', 'Debes agregar una fecha inicial.');
            }

            if (strlen($fechainibuscar) > 0) {
                //fechaini diferente de vacio
                $fechainibuscar = Carbon::parse($fechainibuscar)->format('Y-m-d');
                if (strlen($fechafinbuscar) > 0) {
                    //fechafin diferente de vacio
                    $fechafinbuscar = Carbon::parse($fechafinbuscar)->format('Y-m-d');
                } else {
                    //fechafin vacio
                    $fechafinbuscar = Carbon::parse(Carbon::now())->format('Y-m-d');
                }
                if ($fechafinbuscar < $fechainibuscar) {
                    //fechafin menor a fechaini
                    return back()->with('alerta', 'La fecha inicial debe ser menor o igual a la final.');
                }
            }

            array_push($arrayCheckBox, $cbGarantias);
            array_push($arrayCheckBox, $cbSupervision);
            array_push($arrayCheckBox, $cbAtrasado);
            array_push($arrayCheckBox, $cbEntrega);
            array_push($arrayCheckBox, $cbLaboratorio);
            array_push($arrayCheckBox, $cbConfirmacion);
            array_push($arrayCheckBox, $cbTodos);
            array_push($arrayCheckBox, $zonaU);
            array_push($arrayCheckBox, $fechainibuscar);
            array_push($arrayCheckBox, $fechafinbuscar);

            $now = Carbon::now();
            $contratosgeneral = DB::select("SELECT * FROM contratos");

            $arrayCheckBox = self::obtenerListaContratosConOSinFiltro($idFranquicia, false, null, $arrayCheckBox);

            $contratosprioritarios = $arrayCheckBox[0];
            $contratosatrasados = $arrayCheckBox[1];
            $contratosperiodo = $arrayCheckBox[2];
            $contratosentregar = $arrayCheckBox[3];
            $contratoslaboratorio = $arrayCheckBox[4];
            $contratosconfirmaciones = $arrayCheckBox[5];
            $contratos = $arrayCheckBox[6];
            $contratosreportesgarantia = $arrayCheckBox[7];
            $contratossupervision = $arrayCheckBox[8];
            $contratosnoenviados = $arrayCheckBox[9];
            $contratosgarantiascreadas = $arrayCheckBox[10];

            //Unir arrelos para contar registros sin repetir contratos
            $contratosGeneral = array_merge($contratosprioritarios, $contratosatrasados, $contratosperiodo, $contratosentregar, $contratoslaboratorio, $contratosconfirmaciones, $contratos,
            $contratosreportesgarantia, $contratossupervision, $contratosnoenviados, $contratosgarantiascreadas);
            $idContratos = [];

            //Extraemos el id de cada contrato
            foreach ($contratosGeneral as $contratoGeneral){
                 array_push($idContratos, $contratoGeneral->id);
            }

            //Eliminamos contratos repetidos
            $idContratosUnicos = array_unique($idContratos);
            $totalRegistros = sizeof($idContratosUnicos);

            $zonas = DB::select("SELECT id,zona FROM zonas WHERE id_franquicia = '$idFranquicia'");
            $franquiciaContratos = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");
            return view('administracion.contrato.tabla', ['contratos' => $contratos, 'franquiciaContratos' => $franquiciaContratos, 'contratosgeneral' => $contratosgeneral,
                'contratosperiodo' => $contratosperiodo, 'now' => $now, 'contratosatrasados' => $contratosatrasados, 'contratosprioritarios' => $contratosprioritarios, 'contratosentregar' => $contratosentregar,
                'contratoslaboratorio' => $contratoslaboratorio, 'contratosconfirmaciones' => $contratosconfirmaciones, 'zonas' => $zonas, 'contratosreportesgarantia' => $contratosreportesgarantia, 'contratossupervision' => $contratossupervision, 'contratosnoenviados' => $contratosnoenviados, 'contratosgarantiascreadas' => $contratosgarantiascreadas,
                'cbGarantias' => $cbGarantias, 'cbSupervision' => $cbSupervision, 'cbAtrasado' => $cbAtrasado, 'cbEntrega' => $cbEntrega, 'cbLaboratorio' => $cbLaboratorio,
                'cbConfirmacion' => $cbConfirmacion, 'cbTodos' => $cbTodos, 'zonaU' => $zonaU, 'idFranquicia' => $idFranquicia, 'totalRegistros' => $totalRegistros]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function vercontrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 13 || (Auth::user()->rol_id) == 12 || (Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 4) {

            $existeContrato = DB::select("SELECT id FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");
            if ($existeContrato != null) {

                $now = Carbon::now();
                $nowparce = Carbon::parse($now)->format('Y-m-d');
                $hoyNumero = $now->dayOfWeekIso;

                $this->calculoTotal($idContrato, $idFranquicia);

                //Validacion de si quedo con estado liquidado y total es mayor a 0
                $estadoActualizadoContrato = DB::select("SELECT estatus_estadocontrato, total FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                if($estadoActualizadoContrato != null) {
                    //Existe contrato
                    if($estadoActualizadoContrato[0]->estatus_estadocontrato == 5 && $estadoActualizadoContrato[0]->total > 0) {
                        //Estado contrato es LIQUIDADO y total es mayor a 0
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 2,
                            'costoatraso' => 0
                        ]);
                    }

                    if(($estadoActualizadoContrato[0]->estatus_estadocontrato == 2 || $estadoActualizadoContrato[0]->estatus_estadocontrato == 4)
                        && $estadoActualizadoContrato[0]->total <= 0) {
                        //Estado contrato es ENTREGADO o ABONO ATRASADO y total es menor o igual a 0
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 5,
                            'costoatraso' => 0
                        ]);
                    }
                }

                //Actualizar contrato en tabla contratostemporalessincronizacion
                $contratosGlobal = new contratosGlobal;
                $contratosGlobal::actualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato);

                //Verificamos si tiene solicitud de cancelar contrato
                $solicitudCancelar = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato  = '$idContrato' AND a.tipo = 1 ORDER BY a.created_at DESC LIMIT 1");

                //Verificamos si tiene solicitud de aumetar/disminuir
                $solicitudAumentarDisminuir = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato  = '$idContrato' AND (a.tipo = 2 OR a.tipo = 3) ORDER BY a.created_at DESC LIMIT 1");

                //Verificar si tiene fecha inicial y fecha final
                $periodo = null;
                $fechasPeriodo = DB::select("SELECT c.fechacobroini AS fechaIni, c.fechacobrofin AS fechaFin FROM contratos c WHERE c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'");
                if(($fechasPeriodo != null) && ($fechasPeriodo[0]->fechaIni != null && $fechasPeriodo[0]->fechaFin != null )){
                    //Si tiene periodo de fechas
                    $periodo = Carbon::parse($fechasPeriodo[0]->fechaIni)->format('d') . "-" . Carbon::parse($fechasPeriodo[0]->fechaFin)->format('d');
                }

                $historialesclinicos = DB::select("SELECT h.id, c.nombre, h.observaciones , h.edad, h.fechaentrega, c.telefono, h.id_paquete, h.created_at, h.diagnostico,h.observaciones,h.observacionesinterno FROM historialclinico h
                                                    inner join contratos c
                                                    on c.id = h.id_contrato
                                                    WHERE id_contrato ='$idContrato'
                                                    ORDER BY created_at ASC");
                $contrashijos = DB::select("SELECT * FROM contratos  WHERE id_franquicia = '$idFranquicia' AND idcontratorelacion = '$idContrato' AND estatus_estadocontrato = 0 limit 1");

                if (((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {
                    $promociones = DB::select("SELECT * FROM promocion where id_franquicia = '$idFranquicia' AND status != 2 AND id_tipopromocionusuario >= 0");
                } else {
                    $promociones = DB::select("SELECT * FROM promocion where id_franquicia = '$idFranquicia' AND status != 2 AND id_tipopromocionusuario = 0");
                }

                $abonos = DB::select("SELECT * FROM abonos where id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' order by created_at desc");

                $abonostarjetameses = DB::select("SELECT count(id) as cont FROM abonos where id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' AND tipoabono != 7");

                $abonoperiodo = DB::select("SELECT COALESCE(SUM(a.abono),0) as total
                                                FROM abonos a
                                                INNER JOIN contratos c
                                                ON c.id = a.id_contrato
                                                WHERE a.id_franquicia = '$idFranquicia' AND a.id_contrato = '$idContrato'
                                                AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
                                                AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
                                                AND tipoabono = 3");

                $dentroRango = DB::select("SELECT id FROM contratos where id = '$idContrato' AND
                                                ((STR_TO_DATE('$now','%Y-%m-%d') = STR_TO_DATE(diaseleccionado,'%Y-%m-%d')) OR
                                                (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(fechacobroini,'%Y-%m-%d')) AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(fechacobrofin,'%Y-%m-%d'))");
                $promocioncontrato = DB::select("SELECT id_promocion as id, p.titulo, p.asignado, p.inicio, p.fin, p.status,pr.id_contrato, pr.estado
                                                FROM promocioncontrato  pr
                                                inner join promocion p on pr.id_promocion = p.id
                                                WHERE id_contrato = '$idContrato'");

                $historialcontrato = DB::select("SELECT id_usuarioC, h.id, h.cambios, u.name, h.created_at, h.id_contrato
                                                        from historialcontrato h
                                                        inner join users u on h.id_usuarioC = u.id
                                                        WHERE id_contrato = '$idContrato' order by created_at desc");
                $productos = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id_tipoproducto != 1");
                $contratoproducto = DB::select("SELECT c.id, c.id_contrato, c.created_at, c.id_franquicia, p.nombre, p.precio, c.piezas, c.total, p.preciop
                                                        FROM contratoproducto c
                                                        inner join producto p on c.id_producto = p.id
                                                        WHERE id_contrato = '$idContrato'");


                if (((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) {

                    $idUsuario = Auth::user()->id;
                    $contrato = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero,c.total, c.contador, c.id_promocion, c.totalproducto, c.fechacobroini, c.fechacobrofin, c.totalabono, c.costoatraso, c.promocionterminada, c.subscripcion, c.diapago,
                                                    c.depto,c.alladode,c.frentea,c.entrecalles,c.nombrereferencia,c.telefonoreferencia,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.pago,c.tarjeta,u.name,c.id_optometrista,c.created_at,c.updated_at,c.idcontratorelacion, c.estatus_estadocontrato, c.ultimoabono, c.enganche, c.entregaproducto, c.totalreal,
                                                    (IFNULL(costoatraso,0) + 150) as semanaatraso,
                                                    (IFNULL(costoatraso,0) + 300) as quincenaatraso,
                                                    (IFNULL(costoatraso,0) + 450) as mesatraso,
                                                    (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                                                    (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as tiemporeal
                                                    FROM contratos c
                                                    INNER JOIN zonas z
                                                    ON z.id = c.id_zona
                                                    INNER JOIN users u
                                                    ON u.id = c.id_optometrista
                                                    WHERE c.datos = 1
                                                    AND c.id_franquicia = '$idFranquicia'
                                                    AND c.id_usuariocreacion = '$idUsuario'
                                                    AND c.id = '$idContrato'
                                                    AND c.estatus_estadocontrato NOT IN(3,6)
                                                    ");
                    $promo = DB::select("SELECT c.id,c.datos,c.id_promocion, p.armazones
                                                FROM contratos c
                                                INNER JOIN promocion p
                                                ON p.id = c.id_promocion
                                                WHERE c.datos = 1
                                                AND c.id_franquicia = '$idFranquicia'
                                                AND c.id_usuariocreacion = '$idUsuario'
                                                AND c.id = '$idContrato'
                                                ");
                } else {
                    $contrato = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero,c.total, c.contador,  c.id_promocion, c.estatus,  c.totalproducto, c.fechacobroini, c.fechacobrofin, c.totalabono, c.costoatraso,  c.promocionterminada, c.subscripcion, c.totalpromocion, c.diapago,
                                                    c.depto,c.alladode,c.frentea,c.entrecalles,c.nombrereferencia,c.telefonoreferencia,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.pago,c.tarjeta,u.name,c.id_optometrista,c.created_at,c.updated_at, c.idcontratorelacion, c.estatus_estadocontrato, c.ultimoabono, c.enganche, c.entregaproducto, c.totalreal,
                                                      -- (IFNULL((SELECT CASE WHEN TOTALPROMOCION < 0 THEN NULL ELSE TOTALPROMOCION END FROM contratos co WHERE co.id = c.id),TOTALHISTORIAL) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as tiemporeal
                                                    (IFNULL(costoatraso,0) + 150) as semanaatraso,
                                                    (IFNULL(costoatraso,0) + 300) as quincenaatraso,
                                                    (IFNULL(costoatraso,0) + 450) as mesatraso,
                                                    (SELECT TIMESTAMPDIFF(DAY, co.fechaatraso ,'$now') FROM contratos co WHERE co.id = c.id LIMIT 1)   AS dias,
                                                    (IFNULL(total,0) + ifnull(totalproducto,0) - ifnull(totalabono,0)) as tiemporeal,
                                                    (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia,
                                                    (SELECT SUM(a.abono) FROM abonos a WHERE a.id_contrato = c.id) as totalabonos,
                                                    (SELECT SUM(prod.total) FROM contratoproducto prod WHERE prod.id_contrato = c.id) as totalproductos,
                                                    (SELECT (SELECT promoc.id FROM promocion promoc WHERE promoc.id = pc.id_promocion) FROM promocioncontrato pc WHERE pc.id_contrato = c.id AND pc.estado = '1') AS promocion
                                                    FROM contratos c
                                                    INNER JOIN zonas z
                                                    ON z.id = c.id_zona
                                                    INNER JOIN users u
                                                    ON u.id = c.id_optometrista
                                                    WHERE c.datos = 1
                                                    AND c.id_franquicia = '$idFranquicia'
                                                    AND c.id = '$idContrato'
                                                    ");
                    $promo = DB::select("SELECT c.id,c.datos,c.id_promocion, p.armazones
                                                  FROM contratos c
                                                  INNER JOIN promocion p
                                                  ON p.id = c.id_promocion
                                                  INNER JOIN users u
                                                  ON u.id = c.id_optometrista
                                                  WHERE c.datos = 1
                                                  AND c.id_franquicia = '$idFranquicia'
                                                  AND c.id = '$idContrato'
                                                  ");
                }
                if ($contrato == null) {
                    return back()->with("alerta", "No tienes acceso al contrato en este momento.");
                }
                $rela = $contrato[0]->idcontratorelacion;
                $contraspadre5 = DB::select("SELECT c.id, c.contador, c.id_promocion, pr.armazones FROM contratos c INNER JOIN promocion pr
                                                    ON pr.id = c.id_promocion
                                                    WHERE c.id_franquicia = '$idFranquicia'
                                                    AND c.id = '$rela'");

                $contraspadre2 = DB::select("SELECT c.id, c.contador, pr.armazones FROM contratos c INNER JOIN promocion pr
                                                    ON pr.id = c.id_promocion
                                                    WHERE c.id_franquicia = '$idFranquicia'
                                                    AND c.id = '$idContrato'");

                $contratosterminadostodos = DB::select("SELECT id FROM contratos
                                                                WHERE id_franquicia = '$idFranquicia'
                                                                AND (idcontratorelacion = '$idContrato'
                                                                OR id = '$idContrato')
                                                                AND  estatus_estadocontrato = 0");

                $contratohoy = DB::select("SELECT created_at FROM contratos WHERE id = '$idContrato' AND STR_TO_DATE(created_at,'%Y-%m-%d') = '$nowparce'");

                if ((((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) && $contratohoy == null && $contrato[0]->estatus_estadocontrato != 0) {
                    return redirect()->route('listacontrato', $idFranquicia)->with('alerta', 'Ya no puedes consultar el contrato terminado');
                }
                if (((Auth::user()->rol_id) == 4) && $contrato[0]->estatus_estadocontrato == 0) {
                    return redirect()->route('listacontrato', $idFranquicia)->with('alerta', 'No puedes ingresar a contratos no terminados');
                }

                $historialC = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.otroM, h.molestiaotro, h.ultimoexamen, p.nombre, p.id
                                                    FROM historialclinico h
                                                    INNER JOIN paquetes p
                                                    ON p.id = h.id_paquete
                                                    WHERE id_contrato = '$idContrato'");

                $hc2 = DB::select("SELECT COUNT(id) as canti FROM historialclinico WHERE id_contrato = '$idContrato'");
                if ($hc2[0]->canti == 1 && $historialC[0]->id == 6) {

                    $optometristas = DB::select("SELECT u.id,u.name
                                                        FROM users u
                                                        INNER JOIN usuariosfranquicia uf
                                                        ON u.id = uf.id_usuario
                                                        WHERE u.rol_id = 12
                                                        AND uf.id_franquicia = '$idFranquicia' ");
                    $datosContrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato'");

                    $historialC = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.otroM, h.molestiaotro, h.ultimoexamen, p.nombre
                                                    FROM historialclinico h
                                                    INNER JOIN paquetes p
                                                    ON p.id = h.id_paquete
                                                    WHERE id_contrato = '$idContrato'");

                    $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
                    $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
                    $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
                    $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
                    $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
                    $armazones = DB::select("SELECT * FROM producto WHERE id_tipoproducto = '1'");

                    return view('administracion.historialclinico.nuevo2', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico, 'dentroRango' => $dentroRango,
                        'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'datosContrato' => $datosContrato, 'armazones' => $armazones, 'historialC' => $historialC, 'contratosterminadostodos' => $contratosterminadostodos]);

                }

                $folioOIdUltimoAbonoEliminar = DB::select("SELECT id, folio FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' AND metodopago != '1' ORDER BY created_at DESC LIMIT 1");

                if($folioOIdUltimoAbonoEliminar != null) {
                    //Existe por lo menos un abono
                    if($folioOIdUltimoAbonoEliminar[0]->folio != null) {
                        //Tiene folio el ultimo abono
                        $folioOIdUltimoAbonoEliminar = $folioOIdUltimoAbonoEliminar[0]->folio;
                    }else {
                        //No tiene folio el ultimo abono
                        $folioOIdUltimoAbonoEliminar = $folioOIdUltimoAbonoEliminar[0]->id;
                    }
                }

                return view('administracion.historialclinico.tabla', ['historialesclinicos' => $historialesclinicos, 'historialcontrato' => $historialcontrato, 'abonos' => $abonos,
                    'promociones' => $promociones, 'promocioncontrato' => $promocioncontrato, 'idFranquicia' => $idFranquicia, 'contratoproducto' => $contratoproducto,
                    'idContrato' => $idContrato, 'contrato' => $contrato, 'productos' => $productos, 'now' => $now, 'contrashijos' => $contrashijos, 'promo' => $promo,
                    'contraspadre5' => $contraspadre5, 'contraspadre2' => $contraspadre2, 'contratosterminadostodos' => $contratosterminadostodos,
                    'abonostarjetameses' => $abonostarjetameses, 'hoyNumero' => $hoyNumero, 'folioOIdUltimoAbonoEliminar' => $folioOIdUltimoAbonoEliminar,
                    'solicitudCancelar' => $solicitudCancelar, 'solicitudAumentarDisminuir' => $solicitudAumentarDisminuir, 'periodo' => $periodo]);

            } else {

                if (((Auth::user()->rol_id) == 7)) {
                    //Rol director
                    $contratoOtraSucursal = DB::select("SELECT id_franquicia FROM contratos WHERE id = '$idContrato'");

                    if ($contratoOtraSucursal != null) {
                        //Existe el contrato en otra sucursal
                        $idFranquiciaOtraSucursal = $contratoOtraSucursal[0]->id_franquicia;
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquiciaOtraSucursal, 'idContrato' => $idContrato]);
                    } else {
                        //El contrato no existe en otra sucursal
                        return back()->with("alerta", "El contrato no existe/ esta mal escrito");
                    }

                } else {
                    //Rol diferente de director
                    return back()->with("alerta", "El contrato no existe/ esta mal escrito/ no pertenece a esta sucursal.");
                }

            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function atrasarContrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            $tieneGarantiaPendiente = DB::select("SELECT id FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia IN (0,1)");

            if ($tieneGarantiaPendiente != null) {
                return back()->with('alerta', 'No se puede atrasar el contrato (Tiene una garantia pendiente/Tiene reportada una garantia)');
            } else {

                $existeContrato = DB::select("SELECT id,estatus_estadocontrato,pago FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");
                if ($existeContrato != null) { //Existe el contrato?
                    if ($existeContrato[0]->estatus_estadocontrato == 2) { //EL estatus el contrato es ENTREGADO?
                        if (!$existeContrato[0]->pago == 0) { //Forma de pago es diferente a de contado?
                            // La forma de pago es semanal, quincenal o mensual
                            $contratosGlobal = new contratosGlobal;
                            $costoatraso = $contratosGlobal::calculoCantidadFormaDePago($existeContrato[0]->pago);
                            DB::table("contratos")->where("id", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                                "costoatraso" => $costoatraso,
                                'estatus_estadocontrato' => 4
                            ]);
                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 4,
                                'created_at' => Carbon::now()
                            ]);
                            $randomId2 = $this->getHistorialContratoId();
                            $usuarioId = Auth::user()->id;
                            $fechaActual = Carbon::now();
                            DB::table('historialcontrato')->insert([
                                'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $fechaActual, 'cambios' => "Se cambio el estatus del contrato a 'atrasado'"
                            ]);
                            return back()->with("bien", "El estatus del contrato se actualizo correctamente y ya pueden abonar menos de la cantidad recomendada.");
                        }
                        //La forma de pago no es semanal
                        return back()->with("alerta", "Para atrasar el contrato debe tener una forma de pago semanal, quicenal o mensual");
                    }
                    // EL estatus del contrato es diferente al de entregado
                    return back()->with("alerta", "Para atrasar el contrato es necesario tener un estatus de 'Entregado'");
                }
                //EL contrato no existe
                return back()->with("alerta", "No se encontro el contrato.");

            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratoactualizar($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {

            $garantia = DB::select("SELECT id, indice FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = '2' ORDER BY created_at ASC limit 1");

            $solicitudAutorizacion = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato = '$idContrato' AND a.tipo = '0' ORDER BY a.created_at DESC LIMIT 1");

            //Solicitud de cambio de paquete
            $solicitudCambioPaquete = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato  = '$idContrato' AND (a.tipo = 4 OR a.tipo = 5) ORDER BY a.created_at DESC LIMIT 1");

            if ($garantia != null) {
                //Tiene garantia en estado 2
                $idGarantia = $garantia[0]->id;
                $indice = $garantia[0]->indice;
                //Eliminar garantia con estado en 2 si es que las hay excepto la elegida anteriormente
                DB::delete("DELETE FROM garantias WHERE id = '$idGarantia' AND estadogarantia = '2' AND indice != '$indice'");
            }

            //Actualizar contrato en tabla contratostemporalessincronizacion
            $contratosGlobal = new contratosGlobal;
            $contratosGlobal::actualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato);

            $contrato = DB::select("SELECT c.nombre,c.calle,c.numero,c.depto,c.alladode,c.frentea,c.coordenadas,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.nombrereferencia,
                                          c.telefonoreferencia,c.correo,c.fotoine,c.fotoineatras,c.pagare, c.fotootros, c.fotocasa,c.comprobantedomicilio,c.tarjeta,c.fotoine,c.fotoineatras,c.fotocasa,c.comprobantedomicilio,
                                          c.tarjetapensionatras,c.id,c.nota,c.estatus_estadocontrato,(SELECT u.name FROM users u WHERE u.id = c.id_optometrista) as nombreopto,c.id_optometrista,c.id_zona,
                                          (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia,
                                          c.id_usuariocreacion,c.nombre_usuariocreacion, c.fechaentrega
                                          FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");
            if ($contrato != null) {

                $zonas = DB::select("SELECT * FROM zonas where id_franquicia = '$idFranquicia' ORDER BY zona");
                $promociones = DB::select("SELECT * FROM promocion where id_franquicia = '$idFranquicia' AND status != 2");
                $optometristas = DB::select("SELECT u.ID,u.NAME
                                    FROM users u
                                    INNER JOIN usuariosfranquicia uf
                                    ON uf.id_usuario = u.id
                                    WHERE uf.id_franquicia = '$idFranquicia'
                                    AND u.rol_id = 12 ORDER BY u.name");

                $asistentes = DB::select("SELECT u.ID,u.NAME
                                    FROM users u
                                    INNER JOIN usuariosfranquicia uf
                                    ON uf.id_usuario = u.id
                                    WHERE uf.id_franquicia = '$idFranquicia'
                                    AND u.rol_id = 13 ORDER BY u.name");

                $franquiciaAdmin = DB::select("SELECT id as idFranquicia,estado,ciudad,colonia,numero FROM franquicias WHERE id = '$idFranquicia'");

                if ($contrato[0]->fechaentrega != null) {
                    $contrato[0]->cuentaregresivafechaentrega = 15 - Carbon::parse($contrato[0]->fechaentrega)->diffInDays(Carbon::now()->format('Y-m-d'));
                } else {
                    $contrato[0]->cuentaregresivafechaentrega = -1;
                }

                $contrato[0]->garantiacanceladaelmismodia = false;

                //Obtener garantias
                $garantias = DB::select("SELECT estadogarantia, updated_at FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia IN (0,1,2,4) ORDER BY created_at DESC LIMIT 1");
                $bandera = true;
                if ($garantias != null) {
                    foreach ($garantias as $garantia) {
                        $estadogarantia = $garantia->estadogarantia;
                        switch ($estadogarantia) {
                            case 0: //Reportada
                                $bandera = false;
                                break;
                            case 1: //Asignada
                                //Se utiliza para paquetes DORADO 2 que ha sido asignada una garantia a un historial y para que se pueda asignar la otra garantia al otro historial
                                $historial = DB::select("SELECT (SELECT p.nombre FROM paquetes p WHERE p.id = hc.id_paquete AND p.id_franquicia = '$idFranquicia' LIMIT 1) as paquete
                                                        FROM historialclinico hc WHERE hc.id_contrato = '$idContrato' ORDER BY hc.created_at");
                                if ($historial != null) {
                                    //Existe historial
                                    if ($historial[0]->paquete = 'DORADO 2') {
                                        //Es paquete DORADO 2
                                        $contrato[0]->garantiacanceladaelmismodia = true;
                                    }
                                }
                                break;
                            case 4: //Cancelada
                                if (Carbon::parse($garantia->updated_at)->format('Y-m-d') == Carbon::now()->format('Y-m-d')) {
                                    //La fecha de cancelacion es igual al dia actual
                                    $contrato[0]->garantiacanceladaelmismodia = true;
                                }
                                break;
                        }
                    }
                }

                //Historiales clinicos
                if (!$bandera) {
                    $historiales = DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon, hc.id_producto,
                                                        hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,hc.observacionesinterno,hc.tipo,hc.bifocalotro,
                                                        (SELECT color FROM producto p WHERE p.id = hc.id_producto) as colorarmazon,
                                                        (SELECT p.nombre FROM paquetes p WHERE p.id = hc.id_paquete AND p.id_franquicia = '$idFranquicia' LIMIT 1) as paquete,
                                                        (SELECT COUNT(g.id) FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historial = hc.id) as numGarantias,
                                                        (SELECT g.id_historial FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id) as idhistorialpadre,
                                                        (SELECT u.name FROM users u WHERE id = (SELECT g.id_optometrista FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historial = hc.id AND g.estadogarantia = 1)) as optometristaasignado,
                                                        (SELECT hsc.esfericoder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscesfericoder,
                                                        (SELECT hsc.cilindroder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) AS hsccilindroder,
                                                        (SELECT hsc.ejeder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscejeder,
                                                        (SELECT hsc.addder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscaddder,
                                                        (SELECT hsc.esfericoizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscesfericoizq,
                                                        (SELECT hsc.cilindroizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hsccilindroizq,
                                                        (SELECT hsc.ejeizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscejeizq,
                                                        (SELECT hsc.addizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscaddizq
                                                        FROM historialclinico hc WHERE hc.id_contrato = '$idContrato' ORDER BY hc.created_at");

                } else {
                    $historiales = DB::select("SELECT hc.id,hc.esfericoder,hc.cilindroder,hc.ejeder,hc.addder,hc.altder,hc.esfericoizq,hc.cilindroizq,hc.ejeizq,hc.addizq,hc.altizq,(SELECT nombre FROM producto p WHERE p.id = hc.id_producto) as armazon, hc.id_producto,
                                                        hc.material,hc.materialotro,hc.bifocal,hc.fotocromatico,hc.ar,hc.tinte,hc.blueray,hc.otroT,hc.tratamientootro,hc.observaciones,hc.observacionesinterno,hc.tipo,hc.bifocalotro,
                                                        (SELECT color FROM producto p WHERE p.id = hc.id_producto) as colorarmazon,
                                                        (SELECT p.nombre FROM paquetes p WHERE p.id = hc.id_paquete AND p.id_franquicia = '$idFranquicia' LIMIT 1) as paquete,
                                                        (SELECT COUNT(g.id) FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historial = hc.id) as numGarantias,
                                                        (SELECT g.id_historial FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historialgarantia = hc.id) as idhistorialpadre,
                                                        (SELECT u.name FROM users u WHERE id = (SELECT g.id_optometrista FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historial = hc.id AND g.estadogarantia IN (1,2))) as optometristaasignado,
                                                        (SELECT g.id FROM garantias g WHERE g.id_contrato = hc.id_contrato AND g.id_historial = hc.id AND g.estadogarantia IN (1,2)) as cancelargarantia,
                                                        (SELECT hsc.esfericoder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscesfericoder,
                                                        (SELECT hsc.cilindroder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) AS hsccilindroder,
                                                        (SELECT hsc.ejeder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscejeder,
                                                        (SELECT hsc.addder FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscaddder,
                                                        (SELECT hsc.esfericoizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscesfericoizq,
                                                        (SELECT hsc.cilindroizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hsccilindroizq,
                                                        (SELECT hsc.ejeizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscejeizq,
                                                        (SELECT hsc.addizq FROM historialsinconversion hsc WHERE hsc.id_historial = hc.id) as hscaddizq
                                                        FROM historialclinico hc WHERE hc.id_contrato = '$idContrato' ORDER BY hc.created_at");
                }

                //Productos tipo armazon
                $armazones = DB::select("SELECT * FROM producto WHERE id_tipoproducto = '1' order by nombre");

                $numTotalGarantias = DB::select("SELECT COUNT(id) as numTotalGarantias FROM garantias WHERE id_contrato = '$idContrato'");

                $paquetes = DB::select("SELECT id, nombre FROM paquetes WHERE id_franquicia = '$idFranquicia'");

                $datosDiagnosticoHistorial = DB::select("SELECT hc.edad, hc.diagnostico, hc.ocupacion, hc.diabetes, hc.hipertension,
                                                    hc.embarazada, hc.durmioseisochohoras, hc.actividaddia, hc.problemasojos, hc.dolor,
                                                    hc.ardor, hc.golpeojos, hc.otroM, hc.molestiaotro, hc.ultimoexamen
                                                    FROM historialclinico hc
                                                    WHERE id_contrato = '$idContrato' ORDER BY created_at ASC LIMIT 1");

                return view('administracion.contrato.actualizarcontrato',
                    [
                        'idFranquicia' => $idFranquicia,
                        'idContrato' => $idContrato,
                        'contrato' => $contrato,
                        'promociones' => $promociones,
                        'franquiciaAdmin' => $franquiciaAdmin,
                        'zonas' => $zonas,
                        'optometristas' => $optometristas,
                        'historiales' => $historiales,
                        'armazones' => $armazones,
                        'numTotalGarantias' => $numTotalGarantias,
                        'bandera' => $bandera,
                        'paquetes' => $paquetes,
                        'asistentes' => $asistentes,
                        'datosDiagnosticoHistorial' => $datosDiagnosticoHistorial,
                        'solicitudAutorizacion' => $solicitudAutorizacion,
                        'solicitudCambioPaquete' => $solicitudCambioPaquete
                    ]);
            } else {

                if (((Auth::user()->rol_id) == 7)) {
                    //Rol director
                    $contratoOtraSucursal = DB::select("SELECT id_franquicia FROM contratos WHERE id = '$idContrato'");

                    if ($contratoOtraSucursal != null) {
                        //Existe el contrato en otra sucursal
                        $idFranquiciaOtraSucursal = $contratoOtraSucursal[0]->id_franquicia;
                        return redirect()->route('contratoactualizar', ['idFranquicia' => $idFranquiciaOtraSucursal, 'idContrato' => $idContrato]);
                    } else {
                        //El contrato no existe en otra sucursal
                        return back()->with("alerta", "El contrato no existe/ esta mal escrito");
                    }

                } else {
                    //Rol diferente de director
                    return back()->with("alerta", "El contrato no existe/ esta mal escrito/ no pertenece a esta sucursal.");
                }

            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function contratoeditar($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {

            request()->validate([
                'zona' => 'required',
                'nombre' => 'required|string|max:255',
                'calle' => 'required|string|max:255',
                'numero' => 'required|string|min:1|max:255',
                'departamento' => 'required|string|max:255',
                'alladode' => 'required|string|max:255',
                'frentea' => 'required|string|max:255',
                'entrecalles' => 'required|string|max:255',
                'colonia' => 'required|string|max:255',
                'localidad' => 'required|string|max:255',
                'telefono' => 'required|string|size:10|regex:/[0-9]/',
                'tr' => 'required|string|size:10|regex:/[0-9]/',
                'casatipo' => 'required|string|max:255',
                'nr' => 'required|string|max:255',
                'casacolor' => 'required|string|max:255',
                'fotoine' => 'nullable|image|mimes:jpg',
                'fotocasa' => 'nullable|image|mimes:jpg',
                'tarjeta' => 'nullable|image|mimes:jpg',
                'pagare' => 'nullable|image|mimes:jpg',
                // 'promocion'=>'nullable|inte',
                'comprobantedomicilio' => 'nullable|image|mimes:jpg',
                'tarjeta' => 'nullable|image|mimes:jpg',
                'tarjetapensionatras' => 'nullable|image|mimes:jpg',
                'fotootros' => 'nullable|image|mimes:jpg'
            ]);

            try {

                $contrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");
                $fotoine = "";
                $fotoineatras = "";
                $fotocasa = "";
                $comprobantedomicilio = "";
                $fotopagare = "";
                $tarjeta = "";
                $tarjetapensionatras = "";
                $fotootros = "";
                $ine = false;
                $ineatras = false;
                $casa = false;
                $comprobante = false;
                $tarjetaP = false;
                $tarjetaPatras = false;
                $otros = false;
                $randomId2 = $this->getHistorialContratoId();

                //foto ine frente
                if (strlen($contrato[0]->fotoine) > 0) {
                    if (request()->hasFile('fotoine')) {
                        Storage::disk('disco')->delete($contrato[0]->fotoine);
                        $fotoBruta = 'Foto-ine-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                        $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');
                        $ine = true;
                    } else {
                        $fotoine = $contrato[0]->fotoine;
                        $ine = true;
                    }
                } else {
                    if (request()->hasFile('fotoine')) {
                        $fotoBruta = 'Foto-ine-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                        $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');
                        $ine = true;
                    } else {
                        $foto = false;
                    }
                }

                //foto ine atras
                if (strlen($contrato[0]->fotoineatras) > 0) {
                    if (request()->hasFile('fotoineatras')) {
                        Storage::disk('disco')->delete($contrato[0]->fotoineatras);
                        $fotoBruta = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                        $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');
                        $ineatras = true;
                    } else {
                        $fotoineatras = $contrato[0]->fotoineatras;
                        $ineatras = true;
                    }
                } else {
                    if (request()->hasFile('fotoineatras')) {
                        $fotoBruta = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                        $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta, 'disco');
                        $ineatras = true;
                    } else {
                        $ineatras = false;
                    }
                }

                //foto pagare
                if (strlen($contrato[0]->pagare) > 0) {
                    if (request()->hasFile('pagare')) {
                        Storage::disk('disco')->delete($contrato[0]->pagare);
                        $fotoBruta5 = 'Foto-ine-atras-' . $contrato[0]->id . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta5, 'disco');
                        $pagare2 = true;
                    } else {
                        $fotopagare = $contrato[0]->pagare;
                        $pagare2 = true;
                    }
                } else {
                    if (request()->hasFile('pagare')) {
                        $fotoBruta5 = 'Foto-pagare-' . $contrato[0]->id . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                        $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta, 'disco');
                        $pagare2 = true;
                    } else {
                        $pagare2 = false;
                    }
                }

                //foto casa
                if (strlen($contrato[0]->fotocasa) > 0) {
                    if (request()->hasFile('fotocasa')) {
                        Storage::disk('disco')->delete($contrato[0]->fotocasa);
                        $fotoBruta1 = 'Foto-casa-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                        $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta1, 'disco');
                        $casa = true;
                    } else {
                        $fotocasa = $contrato[0]->fotocasa;
                        $casa = true;
                    }
                } else {
                    if (request()->hasFile('fotocasa')) {
                        $fotoBruta1 = 'Foto-casa-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                        $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta1, 'disco');
                        $casa = true;
                    } else {
                        $casa = false;
                    }
                }
                //comprobante de domicilio
                if (strlen($contrato[0]->comprobantedomicilio) > 0) {
                    if (request()->hasFile('comprobantedomicilio')) {
                        Storage::disk('disco')->delete($contrato[0]->comprobantedomicilio);
                        $fotoBruta2 = 'Foto-comprobantedomicilio-' . $contrato[0]->id . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                        $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedocmicilio', $fotoBruta2, 'disco');
                        $comprobante = true;
                    } else {
                        $comprobantedomicilio = $contrato[0]->comprobantedomicilio;
                        $comprobante = true;
                    }
                } else {
                    if (request()->hasFile('comprobantedocmicilio')) {
                        $fotoBruta2 = 'Foto-comprobantedomicilio-' . $contrato[0]->id . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                        $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedocmicilio', $fotoBruta2, 'disco');
                        $comprobante = true;
                    } else {
                        $comprobante = false;
                    }
                }

                // tarjeta de pension frente
                if (strlen($contrato[0]->tarjeta) > 0) {
                    if (request()->hasFile('tarjeta')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjeta);
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjeta')->getClientOriginalExtension();
                        $tarjeta = request()->file('tarjeta')->storeAs('uploads/imagenes/contratos/tarjeta', $fotoBruta3, 'disco');
                        $tarjetaP = true;
                    } else {
                        $tarjeta = $contrato[0]->tarjeta;
                        $tarjetaP = true;
                    }
                } else {
                    if (request()->hasFile('tarjeta')) {
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjeta')->getClientOriginalExtension();
                        $tarjeta = request()->file('tarjeta')->storeAs('uploads/imagenes/contratos/tarjeta', $fotoBruta3, 'disco');
                        $tarjetaP = true;
                    } else {
                        $tarjetaP = false;
                    }
                }
                // tarjeta de pension atras
                if (strlen($contrato[0]->tarjetapensionatras) > 0) {
                    if (request()->hasFile('tarjetapensionatras')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjetapensionatras);
                        $fotoBruta3 = 'Foto-tarjetapensionatras' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta3, 'disco');
                        $tarjetaPatras = true;
                    } else {
                        $tarjetapensionatras = $contrato[0]->tarjetapensionatras;
                        $tarjetaPatras = true;
                    }
                } else {
                    if (request()->hasFile('tarjetapensionatras')) {
                        $fotoBruta3 = 'Foto-tarjeta-' . $contrato[0]->id . '-' . time() . '.' . request()->file('tarjetapensionatras')->getClientOriginalExtension();
                        $tarjetapensionatras = request()->file('tarjetapensionatras')->storeAs('uploads/imagenes/contratos/tarjetapensionatras', $fotoBruta3, 'disco');
                        $tarjetaPatras = true;
                    } else {
                        $tarjetaPatras = false;
                    }
                }
                // Foto Otros
                if (strlen($contrato[0]->fotootros) > 0) {
                    if (request()->hasFile('fotootros')) {
                        Storage::disk('disco')->delete($contrato[0]->tarjetapensionatras);
                        $fotoBrutaOtros = 'Foto-Otros' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotootros')->getClientOriginalExtension();
                        $fotootros = request()->file('fotootros')->storeAs('uploads/imagenes/contratos/fotootros', $fotoBrutaOtros, 'disco');
                        $otros = true;
                    } else {
                        $fotootros = $contrato[0]->fotootros;
                        $otros = true;
                    }
                } else {
                    if (request()->hasFile('fotootros')) {
                        $fotoBrutaOtros = 'Foto-Otros-' . $contrato[0]->id . '-' . time() . '.' . request()->file('fotootros')->getClientOriginalExtension();
                        $fotootros = request()->file('fotootros')->storeAs('uploads/imagenes/contratos/fotootros', $fotoBrutaOtros, 'disco');
                        $otros = true;
                    } else {
                        $otros = false;
                    }
                }
                $datos = 1;
                $actualizar = Carbon::now();
                $usuarioId = Auth::user()->id;

                $idAsistenteActualizar = $contrato[0]->id_usuariocreacion;
                $nombreAsistenteActualizar = $contrato[0]->nombre_usuariocreacion;
                $idOptometristaActualizar = $contrato[0]->id_optometrista;
                if ($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9) {
                    $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");
                    if ($tieneHistorialGarantia == null) {
                        //No tiene garantias
                        $consultaAsistenteActualizar = DB::select("SELECT name FROM users WHERE id = '" . request('asistente') . "'");
                        if ($consultaAsistenteActualizar != null) {
                            $idAsistenteActualizar = request('asistente');
                            $nombreAsistenteActualizar = $consultaAsistenteActualizar[0]->name;
                            $idOptometristaActualizar = request('optometrista');
                        }
                    }
                }

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'datos' => $datos, 'id_franquicia' => $idFranquicia, 'id_zona' => request('zona'), 'id_optometrista' => $idOptometristaActualizar, 'id_usuariocreacion' => $idAsistenteActualizar, 'nombre_usuariocreacion' => $nombreAsistenteActualizar,
                    'nombre' => request('nombre'), 'calle' => request('calle'), 'numero' => request('numero'), 'depto' => request('departamento'), 'alladode' => request('alladode'), 'frentea' => request('frentea'),
                    'entrecalles' => request('entrecalles'), 'colonia' => request('colonia'), 'localidad' => request('localidad'), 'telefono' => request('telefono'), 'casatipo' => request('casatipo'), 'casacolor' => request('casacolor'),
                    'fotoine' => $fotoine, 'fotocasa' => $fotocasa, 'pagare' => $fotopagare, 'comprobantedomicilio' => $comprobantedomicilio, 'tarjeta' => $tarjeta, 'updated_at' => $actualizar, 'nombrereferencia' => request('nr'), 'telefonoreferencia' => request('tr'), 'correo' => request('correo'),
                    'fotoineatras' => $fotoineatras, 'tarjetapensionatras' => $tarjetapensionatras, 'coordenadas' => request('coordenadas'), 'fotootros' => $fotootros
                ]);

                //historial de contrato
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'Actualizo el contrato'
                ]);

                $contratosGlobal = new contratosGlobal;

                $idZonaActualizarAprobados = $contrato[0]->id_zona;
                if($contrato[0]->id_zona != request('zona')) {
                    //Es por que se cambio la zona del contrato
                    $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $contrato[0]->id_zona . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona anterior

                    if ($cobradoresAsignadosAZona != null) {
                        //Existen cobradores
                        foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                            //Recorrido cobradores
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato' AND id_usuario = '" . $cobradorAsignadoAZona->id . "'");
                        }
                    }

                    $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . request('zona') . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona nueva

                    if ($cobradoresAsignadosAZona != null) {
                        //Existen cobradores
                        foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                            //Recorrido cobradores
                            $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                        }
                    }

                    $idZonaActualizarAprobados = request('zona');
                }

                //Validacion de si es garantia o no
                $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1 ORDER BY created_at LIMIT 1");

                switch ($contrato[0]->estatus_estadocontrato) {
                    case 0:
                    case 1:
                    case 9: //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION
                        //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                        if ($tieneHistorialGarantia != null) {
                            //Tiene garantia
                            $ultimaGarantiaCreada = DB::select("SELECT id_optometrista FROM garantias WHERE id_contrato = '$idContrato'
                                                                                AND id_historialgarantia = '" . $tieneHistorialGarantia[0]->id . "'
                                                                                ORDER BY created_at LIMIT 1");
                            if($ultimaGarantiaCreada != null) {
                                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $ultimaGarantiaCreada[0]->id_optometrista);
                            }
                        }else {
                            //No tiene garantia
                            $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $idAsistenteActualizar);
                        }
                        break;
                    case 2:
                    case 4:
                    case 5:
                    case 10:
                    case 11:
                    case 12: //ENTREGADO, ABONO ATRASADO, LIQUIDADO, MANOFACTURA, EN PROCESO DE ENVIO Y ENVIADO
                        $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, Auth::id());
                        break;
                    case 7: //APROBADO
                        //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato (Opcional lo puse en caso de que no se haga en confirmaciones)
                        DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                        //Agregar contrato a cobradores si tiene garantia el contrato
                        if ($tieneHistorialGarantia != null) {
                            //Tiene garantia
                            $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $idZonaActualizarAprobados . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona

                            if ($cobradoresAsignadosAZona != null) {
                                //Existen cobradores
                                foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                    //Recorrido cobradores
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                                }
                            }
                        }
                        break;
                    case 3:
                    case 6:
                    case 8:
                    case 14:
                    case 15: //PRE-CANCELADO, CANCELADO, RECHAZADO, LIO/FUGA Y SUPERVISION
                        //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                        DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");
                        break;
                }

                return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('bien', 'El contrato se actualizo correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function desactivarPromocion($idFranquicia, $idContrato, $idPromocion)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $sql = "SELECT id_promocion as id, p.titulo, p.asignado, p.inicio, p.fin, p.status, pr.estado,pr.id as idpromo
            FROM promocioncontrato  pr
            inner join promocion p on pr.id_promocion = p.id
            WHERE id_contrato = '$idContrato'";
            $promocioncontrato = DB::select($sql);
            if ($promocioncontrato == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se actualizo correctamente.');
            }
            $promocioncontratoid = $promocioncontrato[0]->idpromo;
            $randomId2 = $this->getHistorialContratoId();
            try {
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $estado = $promocioncontrato[0]->estado;
                $abonos = $contrato[0]->totalabono;
                $totalcontra = $contrato[0]->total;
                $fechacontrato = DB::select("SELECT created_at FROM contratos where id = '$idContrato'");
                $abonospromo = DB::select("SELECT COUNT(a.id) as conteo FROM abonos a INNER JOIN contratos c ON a.id_contrato = c.id
                WHERE CAST(a.tipoabono as SIGNED) != 7 AND (c.id = '$idContrato' OR c.idcontratorelacion = '$idContrato')");
                $now = Carbon::now();
                $nowparce = Carbon::parse($now)->format('Y-m-d');
                $todayparce = Carbon::parse($fechacontrato[0]->created_at)->format('Y-m-d');
                if ($estado == 0 && $abonospromo[0]->conteo > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede agregar con abonos ya registrados en los contratos de la promoción');
                }
                if ($estado == 0 && $nowparce != $todayparce) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede activar la promoción, solo el dia de creación del contrato');
                }
                if ($estado == 1) {
                    DB::table('promocioncontrato')->where([['id', '=', $promocioncontratoid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estado' => 0
                    ]);
                    $this->calculoTotal($idContrato, $idFranquicia);
                    $estado = 0;
                } else if ($estado == 0) {
                    DB::table('promocioncontrato')->where([['id', '=', $promocioncontratoid], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estado' => 1
                    ]);
                    $this->calculoTotal($idContrato, $idFranquicia);
                    $estado = 1;
                }
                $usuarioId = Auth::user()->id;
                $actualizar = Carbon::now();

                if ($estado == 0) {
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'Desactivo la promoción en el contrato'
                    ]);
                } else {
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'Activo la promoción en el contrato'
                    ]);
                }

                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'La promoción actualizo correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function calculoTotal($idContrato, $idFranquicia)
    {

        $this->actualizarTotalProductoContrato($idContrato, $idFranquicia);
        $this->actualizarTotalAbonoContrato($idContrato, $idFranquicia);

        if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
            //Tiene promocion y esta activa
            $promocionterminada = DB::select("SELECT promocionterminada FROM contratos where id = '$idContrato'");
            if ($promocionterminada != null) {
                if ($promocionterminada[0]->promocionterminada == 1) {
                    //Promocion ha sido terminada
                    DB::update("UPDATE contratos
                        SET total = coalesce(totalpromocion,0)  + coalesce(totalproducto,0) - coalesce(totalabono,0)
                        WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                } else {
                    //Promocion no ha sido terminada
                    DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                }
            }
        } else {
            //No tiene promocion o existe la promocion pero esta desactivada
            DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
        }
    }

    private function actualizarTotalProductoContrato($idContrato, $idFranquicia)
    {
        DB::update("UPDATE contratos c
                    SET c.totalproducto = coalesce((SELECT SUM(cp.total) FROM contratoproducto cp WHERE cp.id_contrato = c.id), 0)
                    WHERE c.id = '$idContrato' AND c.id_franquicia ='$idFranquicia'");
    }

    private function actualizarTotalAbonoContrato($idContrato, $idFranquicia)
    {
        DB::update("UPDATE contratos c
                    SET c.totalabono = coalesce((SELECT SUM(a.abono) FROM abonos a WHERE a.id_contrato = c.id), 0)
                    WHERE c.id = '$idContrato' AND c.id_franquicia ='$idFranquicia'");
    }

    public function eliminarPromocion($idFranquicia, $idContrato, $idPromocion)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {
            $sql = "SELECT id_promocion as id, p.titulo, p.asignado, p.inicio, p.fin, p.status, pr.estado,pr.id as idpromo
            FROM promocioncontrato  pr
            inner join promocion p on pr.id_promocion = p.id
            WHERE id_contrato = '$idContrato'";
            $promocioncontrato = DB::select($sql);
            if ($idPromocion == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se encontro el registro de la promoción en el contrato');
            }
            if ($promocioncontrato == null) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se encontro el registro de la promoción en el contrato');
            }

            $promocioncontrato = DB::select($sql);
            $promotitulo = $promocioncontrato[0]->titulo;
            $promocioncontratoid = $promocioncontrato[0]->idpromo;
            $randomId2 = $this->getHistorialContratoId();
            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $existepromo = DB::delete("SELECT * FROM promocioncontrato WHERE id = '$promocioncontratoid' AND id_franquicia = '$idFranquicia'");


            try {
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'id_promocion' => null
                ]);
                DB::delete("DELETE FROM promocioncontrato WHERE id = '$promocioncontratoid' AND id_franquicia = '$idFranquicia'");
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => 'se elimino la promoción en el contrato ' . $promotitulo
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'La promoción se elimino correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function entregarContrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            try {
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $totalabono = $contrato[0]->totalabono;
                $total = $contrato[0]->total;
                $entregaproducto = $contrato[0]->entregaproducto;
                $estadocontrato = $contrato[0]->estatus_estadocontrato;
                $pago = $contrato[0]->pago;
                $estatus = $contrato[0]->estatus;
                $totalproductos = $contrato[0]->totalproducto;
                $diapago = $contrato[0]->diaseleccionado;
                $abono = request('abono');
                $adelanto = request('adelanto');
                $tot = $totalabono + $abono;
                $now = carbon::now();
                $nowparce = Carbon::parse($now)->format('Y-m-d');


                if ($pago == 0 && $estadocontrato == 12 && $total > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El pago es de contado favor de completar el saldo del contrato');
                }
                if ($totalabono == null && $contrato[0]->subscripcion == null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes abonar 150 al menos para entregar el producto');
                }
                if ($pago == 0 && $estatus == 1 && $estadocontrato == 1 && $total > 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El pago es de contado favor de completar el saldo del contrato');
                }

                if ($entregaproducto == 1 || ($entregaproducto == 0 && $total == 0) || $contrato[0]->subscripcion != null) {
                    if ($total > 0) {
                        $estatuscontrato = 2;
                    } else {
                        $estatuscontrato = 5;
                    }
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'estatus_estadocontrato' => $estatuscontrato, 'entregaproducto' => 1, 'fechaentrega' => $nowparce
                    ]);
                    //Insertar en tabla registroestadocontrato
                    DB::table('registroestadocontrato')->insert([
                        'id_contrato' => $idContrato,
                        'estatuscontrato' => $estatuscontrato,
                        'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se entrego el producto al cliente correctamente.');

                } else {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes abonar al menos 150 para entregar el producto');
                }


            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function abonoAtrasado($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 4)) {

            try {
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 4, 'fechaatraso' => Carbon::now()
                ]);
                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 4,
                    'created_at' => Carbon::now()
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se agrego el retraso en abonos de este contrato');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function cancelarContrato($idFranquicia, $idContrato)
    {

        $now = Carbon::now();
        $hoyNumero = $now->dayOfWeekIso;

        if ($hoyNumero >= 6 || $hoyNumero <= 2) {
            //Dia es sabado, domingo, lunes o martes

            $tieneGarantiaPendiente = DB::select("SELECT id FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia IN (0,1)");

            if ($tieneGarantiaPendiente != null) {
                return back()->with('alerta', 'No se puede cancelar el contrato (Tiene una garantia pendiente/Tiene reportada una garantia)');
            } else {

                $contrato = DB::select("SELECT estatus_estadocontrato, promocionterminada,idcontratorelacion,poliza, subscripcion FROM contratos WHERE id='$idContrato'");
                $promocionterminada = $contrato[0]->promocionterminada;

                if ($contrato != null) {

                    $comentarios = request('comentarios');

                    if (strlen($comentarios) == 0) {
                        //Comentarios vacio
                        return back()->with('alerta', 'Campo especificaciónes obligatorio');
                    }

                    $actualizar = Carbon::now();
                    $usuarioId = Auth::user()->id;
                    $cbLioFuga = request('cbLioFuga');

                    $estatusContratoActualizar = 6;
                    $mensajeCambios = "Contrato cancelado con la siguiente descripcion: '$comentarios'";
                    $tipoMensaje = 0;
                    if ((Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13)) {
                        //Asiste/Opto
                        $estatusContratoActualizar = 3;
                        $mensajeCambios = "Contrato pre-cancelado con la siguiente descripcion: '$comentarios'";
                    }

                    if ($cbLioFuga != null) { //cbLioFuga esta checkeado?
                        //Esta checkeado (Se cambiara a estatus Lio/Fuga)
                        $estatusContratoActualizar = 14;
                        $mensajeCambios = $comentarios;
                        $tipoMensaje = 1;
                    }

                    $randomId2 = $this->getHistorialContratoId();

                    if (((Auth::user()->rol_id == 12 || Auth::user()->rol_id == 13) && ($contrato[0]->estatus_estadocontrato == 0)) && $contrato[0]->idcontratorelacion == null) { //Si es opto/asistente solo pueden PRE-CANCERLAR si esta en NO TERMINADO y que sea PADRE

                        try {
                            //Antes del cambio de poliza
                            /*DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'estatus_estadocontrato' => 3, 'poliza' => 3, 'estatusanteriorcontrato' => $contrato[0]->estatus_estadocontrato
                            ]);*/
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'estatus_estadocontrato' => $estatusContratoActualizar, 'estatusanteriorcontrato' => $contrato[0]->estatus_estadocontrato
                            ]);
                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => $estatusContratoActualizar,
                                'created_at' => Carbon::now()
                            ]);
                            DB::table('historialcontrato')->insert([
                                'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => $mensajeCambios, 'tipomensaje' => $tipoMensaje
                            ]);

                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                            return back()->with('bien', 'El contrato se cancelo correctamente.');

                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e->getMessage());
                            return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                        }

                    } elseif (((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && //Administrador / Principal / Director
                        ($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 3
                            || $contrato[0]->estatus_estadocontrato == 4 || $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12))) {

                        $estatusContrato = $contrato[0]->estatus_estadocontrato;

                        if ($estatusContrato == 5 && $cbLioFuga == null) {
                            return back()->with('alerta', 'No se puede cancelar el contrato, solo levantar lio/fuga');
                        }

                        $valorPoliza = $contrato[0]->poliza;

                        try {

                            if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia) && $promocionterminada == 0) { //Tiene Promocion y aun no ha sido terminada
                                return back()->with('alerta', 'No se puede cancelar el contrato en este momento, ya que tiene una promocion y aun no ha sido terminada');
                            }

                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'estatus_estadocontrato' => $estatusContratoActualizar, 'poliza' => $valorPoliza, 'estatusanteriorcontrato' => $estatusContrato
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => $estatusContratoActualizar,
                                'created_at' => Carbon::now()
                            ]);

                            DB::table('historialcontrato')->insert([
                                'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => $mensajeCambios, 'tipomensaje' => $tipoMensaje
                            ]);

                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                            return back()->with('bien', 'El contrato se cancelo correctamente.');

                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e->getMessage());
                            return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                        }

                    } else {
                        if (Auth::check()) {
                            return redirect()->route('redireccionar');
                        } else {
                            return redirect()->route('login');
                        }
                    }

                }
                return back()->with('alerta', 'No se encontro el contrato.');

            }

        } else {
            //Dia es miercoles, jueves, o viernes
            return back()->with('alerta', 'El contrato solo se puede cancelar de sabado a martes.');
        }

    }

    public function validarContrato($idFranquicia, $idContrato)
    {
        $contrato = DB::select("SELECT estatus_estadocontrato, id_usuariocreacion FROM contratos WHERE id='$idContrato'");
        if ((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && $contrato[0]->estatus_estadocontrato == 3) {

            try {
                $usuarioId = Auth::user()->id;
                $randomId2 = $this->getHistorialContratoId();
                $ahora = Carbon::now();
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'estatus_estadocontrato' => 0, 'poliza' => null
                ]);
                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 0,
                    'created_at' => Carbon::now()
                ]);
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $ahora, 'cambios' => "El contrato fue declarado como valido."
                ]);

                //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                $contratosGlobal = new contratosGlobal;
                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $contrato[0]->id_usuariocreacion);

                return back()->with('bien', 'Se declaro el contrato como valido.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function eliminarAbono($idFranquicia, $idContrato, $idAbono)
    {
        if (Auth::check()) {

            try {

                $abono = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND id = '$idAbono'");
                if ($abono == null) {
                    return back()->with('alerta', 'No se encontro el abono');
                }

                $abonocant = $abono[0]->abono;
                $folioabono = $abono[0]->folio;
                $tipoabono = $abono[0]->tipoabono;
                $metodopago = $abono[0]->metodopago;
                $user = $abono[0]->id_usuario;
                $fecha = $abono[0]->created_at;
                $cosatraso = $abono[0]->atraso;
                $fechaabono = Carbon::parse($fecha)->format('Y-m-d');
                $contrato = DB::select("SELECT c.totalabono, c.entregaproducto, c.fechaentrega, c.estatus_estadocontrato, c.costoatraso, c.pagosadelantar, c.pago,
                                                c.id_promocion, c.enganche, c.total, c.totalhistorial, c.totalpromocion,
                                                (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia
                                                FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");
                $totalabono = $contrato[0]->totalabono;
                $entregadeproducto = $contrato[0]->entregaproducto;
                $fechaentrega = $contrato[0]->fechaentrega;
                $contratoestatus = $contrato[0]->estatus_estadocontrato;
                $costoatraso = $contrato[0]->costoatraso;
                $pagosadelantar = $contrato[0]->pagosadelantar;
                $formapago = $contrato[0]->pago;
                $pro = $contrato[0]->id_promocion;
                $engancheactivo = $contrato[0]->enganche;
                $totalcontrato = $contrato[0]->total;
                $th = $contrato[0]->totalhistorial;
                $totalhistorial = $contrato[0]->totalhistorial + 100;
                $totalhistorial2 = $contrato[0]->totalhistorial + 200;
                $totalhistorial3 = $contrato[0]->totalhistorial + 300;
                $totalpromocion = $contrato[0]->totalpromocion + 100;
                $resta = $totalabono - $abonocant;
                $totalliquidado = $totalcontrato + $abonocant;
                $suma = $totalcontrato + $abonocant + 100;
                $sumacontadoenganche = $abonocant + 200;
                $sumacontadosinenganche = $abonocant + 300;
                $suma2 = $totalcontrato + $abonocant;

                $folioOIdUltimoAbonoEliminar = DB::select("SELECT id, folio FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' AND metodopago != '1' ORDER BY created_at DESC LIMIT 1");

                if($folioOIdUltimoAbonoEliminar != null) {
                    //Existe por lo menos un abono
                    if($folioOIdUltimoAbonoEliminar[0]->folio != null) {
                        //Tiene folio el ultimo abono
                        $folioOIdUltimoAbonoEliminar = $folioOIdUltimoAbonoEliminar[0]->folio;
                    }else {
                        //No tiene folio el ultimo abono
                        $folioOIdUltimoAbonoEliminar = $folioOIdUltimoAbonoEliminar[0]->id;
                    }
                }

                if((Auth::user()->rol_id == 6 || Auth::user()->rol_id == 7 || Auth::user()->rol_id == 8) && ($tipoabono != 7) && ($metodopago != 1)
                    && ($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1
                        || $contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 4
                        || $contrato[0]->estatus_estadocontrato == 5 || $contrato[0]->estatus_estadocontrato == 12)
                    && ($contrato[0]->estadogarantia == null || ($contrato[0]->estadogarantia != 1 && $contrato[0]->estadogarantia != 2))
                    && ($folioOIdUltimoAbonoEliminar != null && ($folioOIdUltimoAbonoEliminar == $idAbono || $folioOIdUltimoAbonoEliminar == $folioabono))) {

                    if ($tipoabono == 1) {
                        //ENGANCHE

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $suma,
                            'totalabono' => $resta,
                            'totalhistorial' => $totalhistorial,
                            'totalpromocion' => $totalpromocion,
                            'enganche' => 0,
                            'entregaproducto' => 0
                        ]);

                    }
                    if ($tipoabono == 2) {
                        //ENTREGA DE PRODUCTO

                        //ACTUALIZAR EL ESTADO A ENVIADO
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'estatus_estadocontrato' => 12
                        ]);

                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => 12,
                            'created_at' => Carbon::now()
                        ]);

                        if($contrato[0]->estadogarantia == null || $contrato[0]->estadogarantia == 0 || $contrato[0]->estadogarantia == 3) {
                            //NO TIENE NINGUN REGISTRO EN LA TABLA GARANTIAS, ESTADOGARANTIA ES IGUAL A REPORTADA O ENVIADA EN LABORATORIO
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'fechacobroini' => null,
                                'fechacobrofin' => null,
                                'entregaproducto' => 0,
                                'fechaentrega' => null
                            ]);
                        }

                    }
                    if ($tipoabono == 4) {
                        //CONTADOENGANCHE

                        $abonoenganche5 = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 5");
                        if ($abonoenganche5 != null) {
                            $eng = 1;
                        } else {
                            $eng = 0;
                        }
                        if ($contratoestatus < 1) {
                            //No se ha terminado el contrato
                            $contratoestatus2 = 0;
                        } else {
                            if ($entregadeproducto == 1) {
                                //Ya fue entregado el contrato
                                $contratoestatus2 = 12;
                            } else {
                                //No ha sido entregado el contrato
                                if ($contratoestatus == 7 || $contratoestatus == 10 || $contratoestatus == 11 || $contratoestatus == 9) {
                                    //Estado del contrato es APROBADO, MANUFACTURA, EN PROCESO DE ENVIO o EN PROCESO DE APROBACION
                                    $contratoestatus2 = $contratoestatus;
                                } else {
                                    //Estado del contrato es diferente a APROBADO, MANUFACTURA, EN PROCESO DE ENVIO o EN PROCESO DE APROBACION
                                    if($contratoestatus == 12) {
                                        //Sigue estando en ENVIADO el contrato
                                        $contratoestatus2 = $contratoestatus;
                                    }else {
                                        //El estado es diferente a ENVIADO
                                        $contratoestatus2 = 1;
                                    }
                                }
                            }
                        }

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $suma,
                            'totalabono' => $resta,
                            'totalhistorial' => $totalhistorial,
                            'totalpromocion' => $totalpromocion,
                            'enganche' => $eng,
                            'estatus_estadocontrato' => $contratoestatus2,
                            'entregaproducto' => 0
                        ]);

                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => $contratoestatus2,
                            'created_at' => Carbon::now()
                        ]);

                    }
                    if ($tipoabono == 5) {
                        //CONTADOSINENGANCHE

                        $abonoenganche4 = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 4");
                        if ($abonoenganche4 != null) {
                            $eng = 1;
                        } else {
                            $eng = 0;
                        }
                        if ($engancheactivo == 1) {
                            $sumacontadosinenganche = $abonocant + 200;
                            $totalhistorial3 = $contrato[0]->totalhistorial + 200;
                        }
                        if ($contratoestatus < 1) {
                            //No se ha terminado el contrato
                            $contratoestatus2 = 0;
                        } else {
                            if ($entregadeproducto == 1) {
                                //Ya fue entregado el contrato
                                $contratoestatus2 = 12;
                            } else {
                                //No ha sido entregado el contrato
                                if ($contratoestatus == 7 || $contratoestatus == 10 || $contratoestatus == 11 || $contratoestatus == 9) {
                                    //Estado del contrato es APROBADO, MANUFACTURA, EN PROCESO DE ENVIO o EN PROCESO DE APROBACION
                                    $contratoestatus2 = $contratoestatus;
                                } else {
                                    //Estado del contrato es diferente a APROBADO, MANUFACTURA, EN PROCESO DE ENVIO o EN PROCESO DE APROBACION
                                    if($contratoestatus == 12) {
                                        //Sigue estando en ENVIADO el contrato
                                        $contratoestatus2 = $contratoestatus;
                                    }else {
                                        //El estado es diferente a ENVIADO
                                        $contratoestatus2 = 1;
                                    }
                                }
                            }
                        }
                        $suma3 = $sumacontadosinenganche + $totalcontrato;

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'total' => $suma3,
                            'totalhistorial' => $totalhistorial3,
                            'totalabono' => $resta,
                            'entregaproducto' => 0,
                            'enganche' => $eng,
                            'estatus_estadocontrato' => $contratoestatus2
                        ]);

                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => $contratoestatus2,
                            'created_at' => Carbon::now()
                        ]);

                    }
                    if ($tipoabono == 6) {

                        $abonodeproducto = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 2");
                        if ($abonodeproducto == null) {
                            $entregaP = 0;
                        } else {
                            $entregaP = 1;
                        }

                        if ($cosatraso > 0) {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'total' => $totalliquidado,
                                'totalabono' => $resta,
                                'estatus_estadocontrato' => 4
                            ]);
                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 4,
                                'created_at' => Carbon::now()
                            ]);
                        }
                        if ($pro != null) {
                            if (((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13)) {

                                $estado = null;
                                if ($entregadeproducto == 1) {
                                    //Se entrego el producto
                                    $estado = 12;
                                } else {
                                    if ($contratoestatus < 1) {
                                        //No ha sido terminado el contrato
                                        $estado = 0;
                                    } else {
                                        //Ya se encuentra terminado el contrato
                                        $estado = 1;
                                    }
                                }

                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'total' => $totalliquidado,
                                    'totalabono' => $resta,
                                    'estatus_estadocontrato' => $estado
                                ]);
                                //Insertar en tabla registroestadocontrato
                                DB::table('registroestadocontrato')->insert([
                                    'id_contrato' => $idContrato,
                                    'estatuscontrato' => $estado,
                                    'created_at' => Carbon::now()
                                ]);
                            } else {
                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'total' => $totalliquidado,
                                    'totalabono' => $resta,
                                    'estatus_estadocontrato' => 0
                                ]);
                                //Insertar en tabla registroestadocontrato
                                DB::table('registroestadocontrato')->insert([
                                    'id_contrato' => $idContrato,
                                    'estatuscontrato' => 0,
                                    'created_at' => Carbon::now()
                                ]);
                            }
                        }
                        if ($abonocant == $th) {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'total' => $totalliquidado,
                                'totalabono' => $resta,
                                'estatus_estadocontrato' => 12,
                                'entregaproducto' => $entregaP
                            ]);
                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 12,
                                'created_at' => Carbon::now()
                            ]);
                        } elseif (((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13) && $fechaentrega != null) {
                            if($cosatraso <= 0) {
                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'total' => $totalliquidado,
                                    'totalabono' => $resta,
                                    'estatus_estadocontrato' => 2
                                ]);
                                //Insertar en tabla registroestadocontrato
                                DB::table('registroestadocontrato')->insert([
                                    'id_contrato' => $idContrato,
                                    'estatuscontrato' => 2,
                                    'created_at' => Carbon::now()
                                ]);
                            }
                        } else {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'total' => $totalliquidado,
                                'totalabono' => $resta,
                                'entregaproducto' => $entregaP,
                            ]);
                        }

                    }

                    if ($formapago == 0 && ($contrato[0]->estatus_estadocontrato == 12 || $contrato[0]->estatus_estadocontrato == 5)) {
                        //Forma de pago es de contado y estado es igual a ENVIADO o LIQUIDADO
                        $abonocontadosinenganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 5");
                        if($abonocontadosinenganche == null) {
                            //No se tiene el abonocontadosinenganche

                            //ACTUALIZAR EL ESTADO A ENVIADO
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'estatus_estadocontrato' => 12
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 12,
                                'created_at' => Carbon::now()
                            ]);

                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'fechacobroini' => null,
                                'fechacobrofin' => null,
                                'entregaproducto' => 0,
                                'fechaentrega' => null
                            ]);

                        }
                    }

                    $abonosFolio = DB::select("SELECT abono FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' AND (id = '$folioOIdUltimoAbonoEliminar' OR folio = '$folioOIdUltimoAbonoEliminar')");

                    foreach ($abonosFolio as $abonoFolio) {
                        DB::table('historialcontrato')->insert([
                            'id' => $this->getHistorialContratoId(),
                            'id_usuarioC' => Auth::user()->id,
                            'id_contrato' => $idContrato,
                            'created_at' => Carbon::now(),
                            'cambios' => " Se elimino un abono con la cantidad: '" . $abonoFolio->abono . "'"
                        ]);
                    }

                    DB::delete("DELETE FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND (id = '$folioOIdUltimoAbonoEliminar' OR folio = '$folioOIdUltimoAbonoEliminar')");

                    //Actualizar ultimo abono
                    $respuesta = $this->obtenerFechaUltimoAbonoDadoEnContrato($idFranquicia, $idContrato);
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'ultimoabono' => $respuesta
                    ]);

                    //CALCULO DE FECHAS
                    $contratoActualizado = DB::select("SELECT c.fechacobroini, c.fechacobrofin, c.estatus_estadocontrato, c.pago, c.diapago
                                                FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                    if($contratoActualizado != null) {
                        //EXISTE EL CONTRATO

                        $ultimoAbono = DB::select("SELECT created_at FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato ='$idContrato' AND tipoabono != '7' ORDER BY created_at DESC LIMIT 1");
                        $fechaCobroIniActualizar = null;
                        $fechaCobroFinActualizar = null;
                        $fechaDiaSeleccionadoActualizar = null;

                        if ($ultimoAbono != null) {
                            //EXISTE POR LO MENOS UN ABONO DIFERENTE A PRODUCTO

                            if($contratoActualizado[0]->estatus_estadocontrato != 0 && $contratoActualizado[0]->estatus_estadocontrato != 1) {
                                //ENTREGADO, ATRASADO, LIQUIDADO O ENVIADO

                                if($contratoActualizado[0]->pago != 0 && $contratoActualizado[0]->fechacobroini != null && $contratoActualizado[0]->fechacobrofin != null) {
                                    //FORMA DE PAGO SEMANAL, QUICENAL O MENSUAL Y YA SE TIENEN FECHAS

                                    $fechaCreacionUltimoAbono = $ultimoAbono[0]->created_at;

                                    $fechaActual = Carbon::now();
                                    //$fechaActual = Carbon::parse('2022-12-02 00:00:00');
                                    $fechaActual = Carbon::parse($fechaActual)->format('Y-m-d');
                                    $diaActual = Carbon::parse($fechaActual)->format('d');
                                    $calculofechaspago = new calculofechaspago;
                                    $hoyNumero = Carbon::parse($fechaActual)->dayOfWeekIso;

                                    switch ($contratoActualizado[0]->pago) { //VALIDAMOS QUE FORMA DE PAGO
                                        case 1: //SEMANAL
                                            //Calculo fechaCobroIniActual y fechaCobroIniSiguiente
                                            if ($hoyNumero != 6) {
                                                //Lunes, Martes, Miercoles, Jueves, Viernes o Domingo
                                                if($hoyNumero == 7) {
                                                    //Domingo
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->subDays(1)->format('Y-m-d'); //Se obtiene el sabado anterior
                                                    $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Parsear fechaCobroIniActual para obtener Ejem. 2022-08-13 00:00:00

                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->addDays(6); //Se obtiene el sabado siguiente
                                                }else {
                                                    //Lunes, Martes, Miercoles, Jueves, Viernes
                                                    $fechaCobroIniActual = $calculofechaspago::obtenerDia($fechaActual, $hoyNumero, 0); //Se obtiene el sabado anterior
                                                    $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Se da formato ejemplo: 2022-01-02 00:00:00

                                                    $fechaCobroIniSiguiente = $calculofechaspago::obtenerDia($fechaActual, $hoyNumero, 2); //Se obtiene el sabado siguiente
                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaCobroIniSiguiente); //Se da formato ejemplo: 2022-01-02 00:00:00
                                                }
                                            } else {
                                                //Sabado
                                                $fechaCobroIniActual = Carbon::parse($fechaActual)->format('Y-m-d'); //Se obtiene el sabado actual
                                                $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Parsear fechaCobroIniActual para obtener Ejem. 2022-08-13 00:00:00

                                                $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->addWeek(); //Se obtiene el sabado siguiente
                                            }

                                            //Calculo fechaCobroFinActual y fechaCobroFinSiguiente
                                            $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->addDays(6); //Se obtiene el viernes siguiente de las fechas actuales
                                            $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->addDays(6); //Se obtiene el viernes siguiente de las fechas siguientes
                                            break;
                                        case 2: //QUINCENAL
                                            if ($diaActual > 15) {
                                                //diaActual es del 15 en adelante

                                                //Calculo fechaCobroIniActual y fechaCobroFinActual
                                                $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth()->addDays(15); //Se pondra el primer dia del mes actual y se sumaran quince dias
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroFinActual); //Parsear fechaCobroFinActual para obtener Ejem. 2022-08-31 00:00:00

                                                //Calculo fechaCobroIniSiguiente y fechaCobroFinSiguiente
                                                $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addMonth(); //Se pondra el primer dia del mes actual y se sumara un mes
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->addDays(14); //Se le sumaran 14 dias a fechaCobroIniSiguiente
                                            } else {
                                                //diaActual es menor o igual a 15

                                                //Calculo fechaCobroIniActual y fechaCobroFinActual
                                                $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth();
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->addDays(14);

                                                //Calculo fechaCobroIniSiguiente y fechaCobroFinSiguiente
                                                $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addDays(15);
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroFinSiguiente); //Parsear fechaCobroFinSiguiente para obtener Ejem. 2022-08-31 00:00:00
                                            }
                                            break;
                                        case 4: //MENSUAL
                                            //Calculo fechaCobroIniActual y $fechaCobroFinActual
                                            $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth(); //Se pondra el primer dia del mes actual
                                            $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                            $fechaCobroFinActual = Carbon::parse($fechaCobroFinActual); //Parsear fechaCobroFinActual para obtener Ejem. 2022-08-31 00:00:00

                                            //Calculo fechaCobroIniSiguiente y $fechaCobroFinSiguiente
                                            $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addMonth(); //Se pondra el primer dia del mes actual y se sumara un mes
                                            $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                            $fechaCobroFinSiguiente = Carbon::parse($fechaCobroFinSiguiente); //Parsear fechaCobroFinSiguiente para obtener Ejem. 2022-08-31 00:00:00
                                            break;
                                    }

                                    if(Carbon::parse($fechaCreacionUltimoAbono)->format('Y-m-d') >= Carbon::parse($fechaCobroIniActual)->format('Y-m-d')
                                            && Carbon::parse($fechaCreacionUltimoAbono)->format('Y-m-d') <= Carbon::parse($fechaCobroFinActual)->format('Y-m-d')) {
                                        $fechaCobroIniActualizar = $fechaCobroIniSiguiente;
                                        $fechaCobroFinActualizar = $fechaCobroFinSiguiente;
                                    }else {
                                        $fechaCobroIniActualizar = $fechaCobroIniActual;
                                        $fechaCobroFinActualizar = $fechaCobroFinActual;
                                    }

                                    //OBTENER DIASELECCIONADO
                                    if(strlen($contratoActualizado[0]->diapago) > 0) {
                                        //Se tiene un dia de pago
                                        $fechaDiaSeleccionadoActualizar = $calculofechaspago::obtenerDiaSeleccionado($contratoActualizado[0]->diapago, $fechaCobroIniActualizar, $fechaCobroFinActualizar);
                                    }
                                }
                            }

                        }

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'fechacobroini' => $fechaCobroIniActualizar,
                            'fechacobrofin' => $fechaCobroFinActualizar,
                            'diaseleccionado' => $fechaDiaSeleccionadoActualizar
                        ]);

                    }

                    return back()->with('bien', 'El abono se elimino correctamente del contrato');

                }
                //NO CUMPLIO CON LAS VALIDACIONES
                return back()->with('bien', 'No se puede eliminar el abono');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function eliminarProductoContrato($idFranquicia, $idProducto)
    {
        if (Auth::check()) {

            try {
                $usuarioId = Auth::user()->id;
                $actualizar = Carbon::now();
                $contratoproducto = DB::select("SELECT * FROM contratoproducto WHERE id_franquicia = '$idFranquicia' AND id = '$idProducto'");
                if ($contratoproducto == null) {
                    return back()->with('alerta', 'No se encontro el registro del producto');
                }
                $contratonum = $contratoproducto[0]->id_contrato;
                $productocant = $contratoproducto[0]->total;
                $productocontarjeta = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum' AND tipoabono = 7 AND metodopago = 1");
                $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$contratonum'");
                $totalproducto = $contrato[0]->totalproducto;
                $totalcontrato = $contrato[0]->total;
                $resta = $totalcontrato - $productocant;
                $resta2 = $totalproducto - $productocant;
                $user = $contratoproducto[0]->id_usuario;
                $fecha = $contratoproducto[0]->created_at;
                $hoy = Carbon::parse($actualizar)->format('Y-m-d');
                $fechaabono = Carbon::parse($fecha)->format('Y-m-d');
                $randomId2 = $this->getHistorialContratoId();

                if ($usuarioId != $user) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este producto solo lo puede eliminar la persona que lo registró');
                }
                if ($hoy != $fechaabono) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este producto ya no se puede eliminar, solo el dia de registro');
                }
                if ($productocontarjeta) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contratonum])->with('alerta', 'Este producto no se puede eliminar, se pago con tarjeta');
                }
                if ($resta2 == 0) {
                    $resta2 = null;
                }
                DB::delete("DELETE FROM contratoproducto WHERE id = '$idProducto' AND id_franquicia = '$idFranquicia' AND id_contrato = '$contratonum'");

                DB::table('contratos')->where([['id', '=', $contratonum], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $resta, 'totalproducto' => $resta2
                ]);
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contratonum, 'created_at' => $actualizar, 'cambios' => " Se elimino un registro de producto con valor de: '$productocant'"
                ]);

                return back()->with('bien', 'El Producto se elimino correctamente del contrato');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function entregarDiaPago($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 6)) {

            try {

                $diaPagoActualizar = request('diapago');
                if ($diaPagoActualizar == '0') {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes elegir un dia para abonar');
                }

                $contrato = DB::select("SELECT c.estatus_estadocontrato, c.fechacobroini, c.fechacobrofin, c.pago, c.diapago
                                            FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                if($contrato != null) {
                    //EXISTE EL CONTRATO

                    if($contrato[0]->pago != 0) {
                        //FORMA DE PAGO SEMANAL, QUICENAL O MENSUAL

                        if ($contrato[0]->diapago != $diaPagoActualizar) {
                            //DIAPAGO ES DIFERENTE AL QUE SE QUIERE CAMBIAR

                            if ($contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 4 || $contrato[0]->estatus_estadocontrato == 12) {
                                //ENTREGADO, ABONO ATRASADO O ENVIADO

                                $diaSeleccionadoActualizar = null;

                                if($contrato[0]->fechacobroini != null && $contrato[0]->fechacobrofin != null) {
                                    //YA SE TIENE FECHACOBROINI Y FECHACOBROFIN
                                    $calculofechaspago = new calculofechaspago;
                                    $diaSeleccionadoActualizar = $calculofechaspago::obtenerDiaSeleccionado($diaPagoActualizar, $contrato[0]->fechacobroini, $contrato[0]->fechacobrofin);
                                }

                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'diapago' => $diaPagoActualizar, 'diaseleccionado' => $diaSeleccionadoActualizar
                                ]);
                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se actualizó correctamente el dia de pago.');

                            }
                            //ESTADO DIFERENTE A ENTREGADO, ABONO ATRASADO O ENVIADO
                            return back()->with('alerta', 'No se puede cambiar el dia de pago al contrato.');

                        }
                        //DIAPAGO ES EL MISMO AL QUE SE QUIERE CAMBIAR
                        return back()->with('alerta', 'Se esta cambiando al mismo dia de pago.');

                    }
                    //FORMA DE PAGO CONTADO
                    return back()->with('alerta', 'No se puede agregar un dia de pago por que esta de contado el contrato.');

                }
                //NO EXISTE EL CONTRATO
                return back()->with('alerta', 'El contrato no existe.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function agregarproducto($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'piezas' => 'required|integer'
            ];
            if (request('piezas') < 1) {
                // return back()->withErrors(['precio' =>  'La cantidad de piezas no puede ser menor a 0']);
                return back()->with('error', 'El numero de piezas es obligatorio, intenta de nuevo');
            }
            if (request('producto') == 'nada') {
                // return back()->withErrors(['producto' => 'Campo obligatorio']);
                return back()->with('alerta', 'El producto es obligatorio, intenta de nuevo');
            }
            if (request('piezas') == null) {
                // return back()->withErrors(['precio' =>  'La cantidad de piezas no puede ser menor a 0']);
                return back()->with('error', 'El numero de piezas es obligatorio, intenta de nuevo');
            }
            request()->validate($rules);
            $idpro = request('producto');
            $piezas = request('piezas');
            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $operacion = DB::select("SELECT * FROM producto WHERE id_franquicia = '$idFranquicia' AND id = '$idpro'");
            $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonos = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");
            $precio1 = $operacion[0]->precio;
            $nombre = $operacion[0]->nombre;
            $precio2 = $operacion[0]->preciop;
            $arma = $operacion[0]->id;
            $armapz = $operacion[0]->piezas - 1;
            if ($precio2 == null) {
                $total = $precio1 * $piezas;
            } else {
                $total = $precio2 * $piezas;
            }
            $sumacontrato = $total + $contrato[0]->total;
            $randomId2 = $this->getHistorialContratoId();
            $randomIdP = $this->getContratoContratoId();

            $estadoContrato = $contrato[0]->estatus_estadocontrato;
            if ($estadoContrato == 0) {
                if ($abonos) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Necesitas eliminar los abonos para agregar productos');
                }
            }

            try {
                DB::table('contratoproducto')->insert([
                    'id' => $randomIdP, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'id_producto' => request('producto'), 'piezas' => request('piezas'), 'total' => $total, 'created_at' => Carbon::now()
                ]);

                DB::table('producto')->where([['id', '=', $arma], ['id_franquicia', '=', $idFranquicia]])->update([
                    'piezas' => $armapz
                ]);


                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'total' => $sumacontrato
                ]);

                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar,
                    'cambios' => " Se agrego el producto: '$idpro'-'$nombre' cantidad de piezas: '$piezas' con total de: $'$total'"
                ]);

                if (((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {
                    //Rol administrador, director o principal
                    $idAbono = $this->getAbonosId();
                    $idHistorialContrato = $this->getHistorialContratoId();

                    $contratoproductos = DB::select("SELECT COALESCE(SUM(total),0) as suma FROM contratoproducto WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");
                    $sumaabonostipoproducto = DB::select("SELECT COALESCE(SUM(abono),0) as suma FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = '7'");

                    $sumacontratoproducto = $contratoproductos[0]->suma;
                    $sumacontratoabonosproducto = $sumaabonostipoproducto[0]->suma;
                    $sumatotalabono = $sumacontratoproducto - $sumacontratoabonosproducto;

                    //Agregar abono al contrato
                    DB::table('abonos')->insert([
                        'id' => $idAbono,
                        'folio' => null,
                        'id_franquicia' => $idFranquicia,
                        'id_contrato' => $idContrato,
                        'id_usuario' => $usuarioId,
                        'tipoabono' => 7,
                        'abono' => $sumatotalabono,
                        'metodopago' => 0,
                        'adelantos' => 0,
                        'corte' => 2,
                        'created_at' => Carbon::now()
                    ]);

                    //Guardar en historial de movimientos el abono
                    DB::table('historialcontrato')->insert([
                        'id' => $idHistorialContrato,
                        'id_usuarioC' => $usuarioId,
                        'id_contrato' => $idContrato,
                        'created_at' => Carbon::now(),
                        'cambios' => " Se agrego el abono : '$sumatotalabono'"
                    ]);

                }

                $contratos2 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                $valor = $contratos2[0]->totalproducto + $total;
                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalproducto' => $valor
                ]);

                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El producto se agrego correctamente.');
            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function agregarabono($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'abono' => 'required|numeric',
                'metodopago' => 'required|numeric'
            ];
            if (request('abono') <= 0) {
                return back()->with('alerta', 'Ingresar la cantidad del abono');
            }
            if (request('abono') == null) {
                return back()->with('alerta', 'La cantidad de abono es obligaoria, intenta de nuevo');
            }
            if (request('adelanto') != null && request('adelanto') < 1 || request('adelanto') != null && request('adelanto') > 3) {
                return back()->with('alerta', 'La cantidad maxima a adelantar son 3');
            }

            $contratosGlobal = new contratosGlobal;

            request()->validate($rules);
            $abono2 = request('abono');
            $metodopago = request('metodopago');
            $tarjetameses = request('meses');
            $abono = number_format($abono2, 1, ".", "");
            $adelantar = request('adelantar');
            $adelanto = request('adelanto');
            $adelanto = intval($adelanto);

            $folio = null;
            if (((Auth::user()->rol_id) == 4)) {
                $folio = $contratosGlobal::validarSiExisteFolioAlfanumericoEnAbonosContrato($idContrato);
            }

            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $nowparce = Carbon::parse($actualizar)->format('Y-m-d');
            $now = Carbon::now();
            $semana = $now->weekOfYear;
            $contra = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
            $abonoperiodo = DB::select("SELECT a.id, a.adelantos, a.id_contrato, c.fechacobroini, a.created_at
            FROM abonos a
            INNER JOIN contratos c
            ON c.id = a.id_contrato
            WHERE a.id_franquicia = '$idFranquicia' AND a.id_contrato = '$idContrato'
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
            AND tipoabono = 3");
            $abonosPeriodo = DB::select("SELECT COALESCE(SUM(a.abono),0) as total
            FROM abonos a
            INNER JOIN contratos c
            ON c.id = a.id_contrato
            WHERE a.id_franquicia = '$idFranquicia' AND a.id_contrato = '$idContrato'
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') >= STR_TO_DATE(c.fechacobroini,'%Y-%m-%d')
            AND  STR_TO_DATE(a.created_at,'%Y-%m-%d') <= STR_TO_DATE(c.fechacobrofin,'%Y-%m-%d')
            AND tipoabono = 3");
            $ec = $contra[0]->idcontratorelacion;
            $costoatraso = $contra[0]->costoatraso;
            $promocionterminada = $contra[0]->promocionterminada;
            $iniantes = $contra[0]->fechacobroini;
            $finantes = $contra[0]->fechacobrofin;
            $totalA = $contra[0]->totalabono;
            $enganche = $contra[0]->enganche;
            $fechaentrega = $contra[0]->fechaentrega;
            $creacion = $contra[0]->created_at;
            $creacionparce = Carbon::parse($creacion)->format('Y-m-d');
            $adelantados = $contra[0]->pagosadelantar + $adelanto;
            $entregaproducto = $contra[0]->entregaproducto;
            $es = $contra[0]->estatus;
            $costoatraso = $contra[0]->costoatraso;
            $estadocontrato = $contra[0]->estatus_estadocontrato;
            $totalproductos = $contra[0]->totalproducto;
            $totalhistorial = $contra[0]->totalhistorial;
            $totalpromocion = $contra[0]->totalpromocion;
            $totalengancheresta = $totalhistorial - 100;
            $totalenganchepromo = $totalpromocion - 100;
            $pago = $contra[0]->pago;
            $totaladelantos = $contra[0]->pagosadelantar + $adelanto;
            $ultimoabono = $contra[0]->ultimoabono;
            $tot2 = $totalA + $abono;
            $tot = number_format($tot2, 1, ".", "");
            $costo2 = $abono + $totalA;
            $costo = number_format($costo2, 1, ".", "");
            $totalcontrato = $contra[0]->total;
            $totalhistorialconenganche = $contra[0]->totalhistorial - 200;
            $totalhistorialsinenganche = $contra[0]->totalhistorial - 300;
            $totalconenganche10 = $contra[0]->total - 200;
            $totalconenganche = number_format($totalconenganche10, 1, ".", "");
            $totalsinenganche10 = $contra[0]->total - 300;
            $totalsinenganche = number_format($totalsinenganche10, 1, ".", "");
            $totalnocontado = $contra[0]->total - 100;
            $totalcr = $totalengancheresta + $totalproductos - $tot;
            $totalcontratoresta = number_format($totalcr, 1, ".", "");
            $totalpresta = $totalenganchepromo + $totalproductos - $tot;
            $totalpromoresta = number_format($totalpresta, 1, ".", "");
            $totalcontra2 = $totalcontrato - $abono;
            $totalcontratoresta2 = number_format($totalcontra2, 1, ".", "");
            $totabono = $totalcontrato + $totalproductos;
            $nowparce = Carbon::parse($now)->format('Y-m-d');
            $ultimoabonoparce = Carbon::parse($ultimoabono)->format('Y-m-d');
            $totalfinal = $totalhistorial + $totalproductos - $tot;
            $descuento = 0;
            $nuevoabono = 0;
            $cantidadsubscripcion = 0;
            if ($metodopago == 1 && $tarjetameses > 0) {
                if ($tarjetameses == 1) {
                    $nuevoabono = $totalcontrato;
                    $cantidadsubscripcion = 3;
                }
                if ($tarjetameses == 2) {
                    $nuevoabono = $totalcontrato;
                    $cantidadsubscripcion = 6;
                }
                if ($tarjetameses == 3) {
                    $nuevoabono = $totalcontrato;
                    $cantidadsubscripcion = 9;
                }
                $nuevoabono = number_format($nuevoabono, 1, ".", "");
            }
            if ($pago == 0) {
                if ($enganche == 1) {
                    $descuento = 200;
                } else {
                    $descuento = 300;
                }
            }
            $sumadescuento = $descuento + $abono;
            $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
            $contaenganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 5");
            $contaenganche2 = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 4");
            $abonoprod = DB::select("SELECT COALESCE(SUM(abono),0) as suma FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 7");
            $dentroRango = DB::select("SELECT id FROM contratos where id = '$idContrato' AND
            ((STR_TO_DATE('$now','%Y-%m-%d') = STR_TO_DATE(diaseleccionado,'%Y-%m-%d')) OR
           (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(fechacobroini,'%Y-%m-%d')) AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(fechacobrofin,'%Y-%m-%d'))");
            $randomId = $this->getAbonosId();
            $randomId2 = $this->getHistorialContratoId();
            $tienePromocion = $this->obtenerEstadoPromocion($idContrato, $idFranquicia);

            if ($ec != null) {
                $contra2 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$ec'");
                $pr = $contra2[0]->id_promocion;
            } else {
                $pr = $contra[0]->id_promocion;
            }

            $abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche = false;
            if($pago == 0 && $totalcontrato < 400 && $contaenganche == null && $contaenganche2 == null) {
                //TOTALCONTRATO ES MENOR A 400 Y NO SE TIENE EL ABONO CONTADOENGACHE NI TAMPOCO EL CONTADOSINENGANCHE (CUANDO ES UNA POLIZA DE SEGURO Y ES SEMANAL, QUICENAL O MENSUAL Y SE PASA A CONTADO)
                $abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche = true;
            }

            $consultaPaqueteHistorialContrato = DB::select("SELECT id_paquete FROM historialclinico WHERE id_contrato ='$idContrato' ORDER BY created_at DESC LIMIT 1");
            $paqueteHistorialContrato = false;
            if($consultaPaqueteHistorialContrato != null) {
                //Tiene paquete el contarto
                if ($consultaPaqueteHistorialContrato[0]->id_paquete == 1 || $consultaPaqueteHistorialContrato[0]->id_paquete == 2 || $consultaPaqueteHistorialContrato[0]->id_paquete == 6) {
                    //PAQUETE DE LECTURA, PROTECCION O DORADO 2
                    $paqueteHistorialContrato = true;
                }
            }

            if ($estadocontrato == 7 || $estadocontrato == 10 || $estadocontrato == 11 || $estadocontrato == 9 || $abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche ||
                    ($paqueteHistorialContrato && $estadocontrato != 12)) {
                //Estado del contrato es APROBADO, MANUFACTURA, EN PROCESO DE ENVIO, EN PROCESO DE APROBACION, abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche = true
                //o (paqueteHistorialContrato = true y es diferente  a ENVIADO)

                $mensajeAlerta = "";

                if ($abono > $totalcontrato) {
                    //Abono es mayor al total del contrato
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar mas del total del contrato');
                }

                if ($pago != 0 && $abono < 100) {
                    //Semanal, quicenal o mensual y abono es menor a 100 pesos
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El abono minimo es de 100 pesos');
                }

                $tieneHistorialGarantia = DB::select("SELECT id FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = 1");

                if ($pago == 0 && !$tienePromocion && $tieneHistorialGarantia == null && !$abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche && !$paqueteHistorialContrato) {
                    //Forma de pago es de contado, no tiene promocion y no tiene historiales con garantia y abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche = false && paqueteHistorialContrato = false

                    if ($enganche == 1 && $abono < $totalconenganche) {
                        //Tiene solo el abono de contadoenganche
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalconenganche);
                    }

                    if ($enganche == 1 && $contaenganche == null && $abono > $totalconenganche) {
                        //Tiene solo el abono de contadoengache y esta dando el total exacto del contrato
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalconenganche);
                    }

                    if ($enganche < 1 && $abono < $totalsinenganche) {
                        //No tiene el abono de contadoenganche y contadosinenganche
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalsinenganche);
                    }

                    if ($enganche < 1 && $abono > $totalsinenganche && $contaenganche == null) {
                        //No tiene el abono de contadoenganche y contadosinenganche y esta dando el total exacto del contrato
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalsinenganche);
                    }

                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 5, 'abono' => $abono, 'poliza' => null, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                    ]);

                    $contra5 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                    $totalfinal = 0;

                    if ($enganche < 1 && $abono == $totalsinenganche) {
                        //No tiene contado enganche
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $costo, 'ultimoabono' => $actualizar, 'totalhistorial' => $totalhistorialsinenganche
                        ]);
                        $totalfinal = $contra5[0]->total - $abono - 300;
                        $mensajeAlerta = "Se liquido el costo del contrato con descuento de 300 pesos.";
                    } else {
                        //Tiene contado enganche
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'ultimoabono' => $actualizar, 'totalhistorial' => $totalhistorialconenganche
                        ]);
                        $totalfinal = $contra5[0]->total - $abono - 200;
                        $mensajeAlerta = "Se liquido el costo del contrato con descuento de 200 pesos.";
                    }

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $totalfinal
                    ]);

                } else {
                    //Forma de pago es Semanal, Quincenal, Mesual o de contado con promocion

                    if ($pago == 0 && $abono != $totalcontrato) {
                        //Contado, tiene promocion y abono no es igual al total del contrato
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalcontrato);
                    }

                    if($abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche) {
                        //abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche == true
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 6, 'abono' => $abono, 'adelantos' => $adelanto, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                        ]);
                    }else {
                        //abonoContadoLiquidadoContadoEngancheYSinContadoSinEnganche == false
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 0, 'abono' => $abono, 'adelantos' => $adelanto, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                        ]);
                    }
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se abono la cantidad: '$abono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => Carbon::now(), 'total' => $totalcontratoresta2, 'pagosadelantar' => $adelantados,
                    ]);

                    $mensajeAlerta = "El Abono se agrego correctamente.";

                }

                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', $mensajeAlerta);

            } else {
                //Estado del contrato es diferente a APROBADO, MANUFACTURA, EN PROCESO DE ENVIO o EN PROCESO DE APROBACION

                if ($pago === null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Debes elegir una forma de pago para poder abonar');
                }
                if ($totaladelantos > 3) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede adelantar mas de 3 en el mismo dia');
                }
                if ($abono > $totalcontrato) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar mas del total del contrato');
                }
                if (($estadocontrato <= 1 || $estadocontrato == 12) && $abono == $totalcontrato && $enganche <= 1 && $contaenganche != null && $contaenganche2 == null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Para hacer valido el enganche abonar la cantidad :' . ($totalcontrato - 100));
                }
                if ($estadocontrato == 0 && $abonoprod[0]->suma < $totalproductos && $abono < $totalproductos) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Abonar al menos el total de productos');
                }
                if ($estadocontrato == 0 && $abono > $totalproductos && $abonoprod[0]->suma < $totalproductos) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Abonar el total de productos');
                }
                if (($estadocontrato <= 1 || $estadocontrato == 12) && $totalA >= $totalproductos && $abono < 100 && $sumadescuento != $totalcontrato) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'El abono minimo es de 100 pesos');
                }
                if ($estadocontrato == 0 && $tot > $totalproductos && $ec != null && $es == 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de los contratos');
                }
                if ($estadocontrato == 0 && $tienePromocion && $es == 0 && $tot > $totalproductos) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de los contratos');
                }
                if ($estadocontrato == 1 && $ec != null && $promocionterminada != 1) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de completar y terminar los contratos');
                }
                if ($estadocontrato == 1 && $tienePromocion && $promocionterminada != 1) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Existe promocion, abonar al final de completar y terminar los contratos');
                }
                if ($estadocontrato == 12 && ((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13) && $abono < 150 && $entregaproducto < 1 && $pago != 0) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 150 en contratos enviados');
                }
                if ($pago != 0 && $estadocontrato <= 1 && $enganche < 1 && $abono > $totalnocontado && !$tienePromocion) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Para liquidar el contrato pagar la cantidad: $ ' . $totalnocontado);
                }
                if ($metodopago == 1 && $tarjetameses > 0) {
                    $banderacase = 13;
                    return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                }
                if ($pago == 0 && $estadocontrato >= 0 && $enganche == 1 && $contaenganche == null && $abono > $totalconenganche) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalconenganche);
                }

                if ($pago == 0 && $estadocontrato == 4 && $abono < $totalcontrato) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalcontrato);
                }

                if ($pago == 0 && $estadocontrato >= 0 && $estadocontrato != 4 && $enganche < 1 && $abono > $totalsinenganche && !$tienePromocion && $contaenganche == null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalsinenganche);
                }
                if ($pago == 0 && ($estadocontrato == 1 || $estadocontrato == 12) && $enganche == 1 && $abono < $totalconenganche) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalconenganche);
                }
                if ($pago == 0 && $estadocontrato == 12 && $enganche < 1 && $abono < $totalsinenganche && !$tienePromocion) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado para entregar el producto, con la cantidad: $ ' . $totalsinenganche);
                }
                if ($pago == 0 && $metodopago == 1 && $tarjetameses == 0 && $enganche < 1 && $abono != $totalsinenganche && !$tienePromocion) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado en pago con tarjeta, con la cantidad: $ ' . $totalsinenganche);
                }
                if ($pago == 0 && $metodopago == 1 && $tarjetameses == 0 && $enganche == 1 && $abono != $totalconenganche && !$tienePromocion) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado en pago con tarjeta, con la cantidad: $ ' . $totalconenganche);
                }

                //Validacion para promociones de contado
                if ($pago == 0 && ((Auth::user()->rol_id) != 12 && (Auth::user()->rol_id) != 13) && $estadocontrato == 12 && $abono != $totalcontrato && $tienePromocion) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de liquidar el total del contrato de contado, con la cantidad: $ ' . $totalcontrato);
                }

                if ($pago == 0 && $estadocontrato >= 0 && $enganche == 1 && $abono == $totalconenganche) {
                    if ($estadocontrato == 0) {
                        $numeroentrega = 0;
                    } else {
                        if ($estadocontrato == 12) {
                            $numeroentrega = 1;
                        } else {
                            $numeroentrega = 0;
                        }
                    }

                    if ($metodopago == 1) {
                        $banderacase = 1;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 5, 'abono' => $abono, 'poliza' => null, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'ultimoabono' => $actualizar, 'totalhistorial' => $totalhistorialconenganche, 'entregaproducto' => $numeroentrega
                    ]);
                    $contra5 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                    $totalfinal = $contra5[0]->total - $abono - 200;
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $totalfinal
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se liquido el costo del contrato con descuento de 200 pesos');
                }
                if ($pago == 0 && $estadocontrato >= 0 && $enganche < 1 && $abono == $totalsinenganche) {
                    //Aqui
                    if ($estadocontrato == 0) {
                        $numeroentrega = 0;
                    } else {
                        if ($estadocontrato == 12) {
                            $numeroentrega = 1;
                        } else {
                            $numeroentrega = 0;
                        }
                    }

                    if ($metodopago == 1) {
                        $banderacase = 2;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 5, 'abono' => $abono, 'poliza' => null, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $costo, 'ultimoabono' => $actualizar, 'totalhistorial' => $totalhistorialsinenganche, 'entregaproducto' => $numeroentrega
                    ]);
                    $contra5 = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
                    $totalfinal = $contra5[0]->total - $abono - 300;
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'total' => $totalfinal
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se liquido el costo del contrato con descuento de 300 pesos');
                }
                if ($abono == $totalcontrato && $pago != 0) {
                    if ($estadocontrato > 1) {
                        $estadocontra = 5;
                        $ent = 1;
                    } else {
                        $estadocontra = $estadocontrato;
                        $ent = 0;
                    }

                    if ($costoatraso > 0) {
                        $cantidadatraso = $costoatraso;
                        $restaatrasocontrato = $costoatraso - $cantidadatraso;
                    } else {
                        $cantidadatraso = null;
                        $restaatrasocontrato = $costoatraso;
                    }
                    $abonosliquidados = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato' AND tipoabono = 6");
                    if ($abonosliquidados != null) {
                        foreach ($abonosliquidados as $ab) {
                            DB::table('abonos')->where([['id', '=', $ab->id], ['id_franquicia', '=', $idFranquicia]])->update([
                                'tipoabono' => 0
                            ]);
                        }
                    }
                    if ($metodopago == 1) {
                        $banderacase = 3;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'atraso' => $cantidadatraso, 'abono' => $abono, 'metodopago' => $metodopago, 'tipoabono' => 6, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $costo, 'ultimoabono' => $actualizar, 'total' => 0, 'estatus_estadocontrato' => $estadocontra, 'costoatraso' => $restaatrasocontrato, 'entregaproducto' => $ent
                    ]);
                    //Insertar en tabla registroestadocontrato
                    DB::table('registroestadocontrato')->insert([
                        'id_contrato' => $idContrato,
                        'estatuscontrato' => $estadocontra,
                        'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agregó correctamente y se liquidó el costo del contrato.');
                }
                if ($abono == $totalcontrato && $pago == 0 && $es == 1 && $tienePromocion) {
                    if ($metodopago == 1) {
                        $banderacase = 4;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'tipoabono' => 6, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $costo, 'ultimoabono' => $actualizar, 'total' => 0, 'entregaproducto' => 1
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agrego correctamente y se liquido el costo del contrato.');
                }
                if ($pago != 0 && $estadocontrato < 1 && $enganche < 1 && $abono == ($totalcontrato - 100) && !$tienePromocion) {
                    if ($metodopago == 1) {
                        $banderacase = 5;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }

                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'tipoabono' => 1, 'poliza' => null, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$abono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $costo, 'ultimoabono' => $actualizar, 'total' => 0, 'entregaproducto' => 1, 'enganche' => 1, 'totalhistorial' => $totalengancheresta
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agrego correctamente y se liquido el costo del contrato.');
                }
                $totalenganche = 100;
                if ($totalproductos > 0 && $totalA < $totalproductos) {
                    $totalenganche = $totalproductos + 100;
                }
                switch ($pago) {
                    case 0:
                        if ($pago == 0 && $estadocontrato == 4) {
                            $minimo = $totalcontrato;
                        } else {
                            $totalcontrato = $totalcontrato - 100;
                        }
                        break;
                    case 1:
                        if ($abonosPeriodo[0]->total >= 150 && $estadocontrato != 4) {
                            $minimoadelanto = $adelanto * 150;
                        } else {
                            $minimoadelanto = ($adelanto * 150) + 150;
                        }
                        if ($estadocontrato == 4) {
                            if ($abonosPeriodo[0]->total >= 150) {
                                $minimoadelanto = ($adelanto * 150) + $costoatraso;
                            } else {
                                $minimoadelanto = ($adelanto * 150) + 150 + $costoatraso;
                            }
                        }
                        $minimo = 150;
                        break;
                    case 2:
                        if ($abonosPeriodo[0]->total >= 300 && $estadocontrato != 4) {
                            $minimoadelanto = $adelanto * 300;
                        } else {
                            $minimoadelanto = ($adelanto * 300) + 300;
                        }
                        if ($estadocontrato == 4) {
                            if ($abonosPeriodo[0]->total >= 300) {
                                $minimoadelanto = ($adelanto * 300) + $costoatraso;
                            } else {
                                $minimoadelanto = ($adelanto * 300) + 300 + $costoatraso;
                            }
                        }
                        $minimo = 300;
                        break;
                    case 4:
                        if ($abonosPeriodo[0]->total >= 450 && $estadocontrato != 4) {
                            $minimoadelanto = $adelanto * 450;
                        } else {
                            $minimoadelanto = ($adelanto * 450) + 450;
                        }
                        if ($estadocontrato == 4) {
                            if ($abonosPeriodo[0]->total >= 450) {
                                $minimoadelanto = ($adelanto * 450) + $costoatraso;
                            } else {
                                $minimoadelanto = ($adelanto * 450) + 450 + $costoatraso;
                            }
                        }
                        $minimo = 450;
                        break;
                }

                if ($estadocontrato >= 2 && $estadocontrato < 12) {
                    if ($pago == 1 && $adelanto > 0 && $abono < $minimoadelanto) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Respecto a los abonos que quieres adelantar, abonar minimo la cantida: $' . $minimoadelanto);
                    }
                    if ($pago == 1 && $abono < 150 && $abonoperiodo == null && $costoatraso == 0 && $fechaentrega != $nowparce) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 150 en pago semanal');
                    }
                    if ($pago == 2 && $adelanto > 0 && $abono < $minimoadelanto) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Respecto a los abonos que quieres adelantar, abonar minimo la cantida: $' . $minimoadelanto);
                    }
                    if ($pago == 2 && $abono < 300 && $abonoperiodo == null && $costoatraso == 0 && $fechaentrega != $nowparce) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 300 en pago Quincenal');
                    }
                    if ($pago == 4 && $adelanto > 0 && $abono < $minimoadelanto) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Respecto a los abonos que quieres adelantar, abonar minimo la cantida: $' . $minimoadelanto);
                    }
                    if ($pago == 4 && $abono < 450 && $abonoperiodo == null && $costoatraso == 0 && $fechaentrega != $nowparce) {
                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'No se puede abonar menos de 450 en pago Mensual');
                    }

                }
                if ($adelantar == 1 && $adelanto == null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Favor de elegir una cantidad de semanas a adelantar');
                }
                if ($adelantar == null && $adelanto != null) {
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Solo permitido si elige la opcion de adelantar abono');
                }

                if ($estadocontrato == 4) {
                    //CONTRATO CON ABONO ATRASADO
                    if ($metodopago == 1) {
                        $banderacase = 12;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }
                    $dentroRango = DB::select("SELECT id FROM contratos where id = '$idContrato' AND
              ((STR_TO_DATE('$now','%Y-%m-%d') = STR_TO_DATE(diaseleccionado,'%Y-%m-%d')) OR
                (STR_TO_DATE('$now','%Y-%m-%d') >= STR_TO_DATE(fechacobroini,'%Y-%m-%d')) AND STR_TO_DATE('$now','%Y-%m-%d') <= STR_TO_DATE(fechacobrofin,'%Y-%m-%d'))");

                    $totaladeudo = $minimo + $costoatraso;
                    $restoadeudo = $totaladeudo - $abono;
                    $atrasocorto = $costoatraso - $abono;
                    $diaseleccionado = false;
                    if ($contra[0]->diaseleccionado != null || strlen($contra[0]->diaseleccionado) > 0) { //VALIDAMOS SI TENEMOS UN DIA SELECCIONADO
                        if ($now == Carbon::parse($contra[0]->diaseleccionado)) { // VALIDAMOS SI EL DIA SELECCIONADO ES IGUAL AL DIA DE ACTUAL
                            $diaseleccionado = true;
                        }
                    }

                    //Tabla de abonos ->  periodo
                    $insertarAbono = 0;
                    $insertarTipoAbono = 0; // 0 -> Abono normal
                    $insertarAtraso = 0;
                    $adelantarpagos = 0;
                    $adelantarpagos2 = 0;
                    //Tabla de abonos -> atrasos
                    $insertarAbono2 = null;
                    $insertarTipoAbono2 = null; // 0 -> Abono normal
                    $insertarAtraso2 = null;
                    //Tabla de contrato
                    $atrasoMenosAbono = 0;
                    $atrasoMenosAbono2 = null;
                    $estadodelcontrato = 4;
                    $fechaatraso = null; //para saber los dias de atraso

                    if (($now >= Carbon::parse($contra[0]->fechacobroini) && $now <= Carbon::parse($contra[0]->fechacobrofin)) || $diaseleccionado) { //VALIDAMOS SI EL DIA ACTUAL SE ENCUENTRA ENTRE LA FECHAINI Y FECHA FIN / DIA ACTUAL IGUAL AL DIA SELECCIONADO EN CASO DE EXISTIR

                        if ($abonosPeriodo[0]->total >= $contratosGlobal::calculoCantidadFormaDePago($pago)) { //Validamos si se encuentra cubierto lo del periodo
                            if ($atrasocorto <= 0) { //Si el abono supero lo que ya se tiene de atraso.
                                $insertarAbono = $abono;
                                $insertarTipoAbono = 0; // 0 -> Abono normal
                                $insertarAtraso = $costoatraso; // Lo que se tiene de atraso
                                $atrasoMenosAbono = 0; //Como el abono supero lo que tenia de atraso entonces se deja en 0.
                                $estadodelcontrato = 2; //Se elimina el atraso del contrato y vuelve a un estado de entregado.
                                $fechaatraso = null; // se regresa al campo para el contado de dias atrasados en null
                                $adelantarpagos = $adelanto;

                            } else {
                                $insertarAbono = $abono;
                                $insertarTipoAbono = 0; // 0 -> Abono normal
                                $insertarAtraso = $abono;
                                $atrasoMenosAbono = $costoatraso - $abono;
                                //Lo que tenemos de atraso menos el abono.
                            }

                        } else if (($abonosPeriodo[0]->total + $abono) >= $contratosGlobal::calculoCantidadFormaDePago($pago)) { //Validamos si los abonos del periodo + el abono ya cubren lo del periodo
                            $restanPorPagarPeriodo = $contratosGlobal::calculoCantidadFormaDePago($pago) - $abonosPeriodo[0]->total; //abono del periodo menos el total de abonos del periodo
                            $faltaPorPagarMenosElAbonoPeriodo = $restanPorPagarPeriodo - $abono; // Lo que resta por pagar del periodo - el abono.
                            if ($faltaPorPagarMenosElAbonoPeriodo >= 0) { // Validamos si sigue quedANDo lo del periodo sin pagar
                                $insertarAbono = $abono;
                                $insertarTipoAbono = 3; // 0 -> Abono del periodo
                                $insertarAtraso = 0;
                                $atrasoMenosAbono = $costoatraso;
                            } else {
                                // Se dio dinero de mas de lo del periodo
                                $insertarAbono = $restanPorPagarPeriodo;
                                $insertarTipoAbono = 3; //  Abono del periodo
                                $insertarAtraso = 0;
                                // $atrasoMenosAbono = $atrasocorto;

                                if (($costoatraso - abs($faltaPorPagarMenosElAbonoPeriodo)) == 0) { //Validamos si el costo atraso menos el sobrante cubre todo lo atrasado
                                    $insertarAbono2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                    $insertarTipoAbono2 = 0; // 0 -> Abono normal
                                    $insertarAtraso2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                    $atrasoMenosAbono2 = 0;
                                    $estadodelcontrato = 2;
                                    $fechaatraso = null; // se regresa al campo para el contado de dias atrasados en null

                                } else if (($costoatraso - abs($faltaPorPagarMenosElAbonoPeriodo)) > 0) { //Valida si aun queda costo atraso
                                    $insertarAbono2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                    $insertarTipoAbono2 = 0; // Abono  normal
                                    $insertarAtraso2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                    $atrasoMenosAbono2 = $costoatraso - abs($faltaPorPagarMenosElAbonoPeriodo);
                                } else {//Si el costo atraso se supero y ademas sobro para abonar
                                    $insertarAbono2 = abs($faltaPorPagarMenosElAbonoPeriodo);
                                    $insertarTipoAbono2 = 0; //  Abono normal
                                    $insertarAtraso2 = $costoatraso;
                                    $atrasoMenosAbono2 = 0;
                                    $estadodelcontrato = 2;
                                    $adelantarpagos2 = $adelanto;
                                    $fechaatraso = null; // se regresa al campo para el contado de dias atrasados en null
                                }
                            }
                        } else if (($abonosPeriodo[0]->total + $abono) < $contratosGlobal::calculoCantidadFormaDePago($pago)) { // Validamos si aun no se cubre lo del periodo
                            $insertarAbono = $abono;
                            $insertarTipoAbono = 3; //Abono del periodo
                            $insertarAtraso = 0;
                            $atrasoMenosAbono = $costoatraso;
                        }


                    } else if ($now > Carbon::parse($contra[0]->fechacobrofin) || $now < Carbon::parse($contra[0]->fechacobroini)) {

                        if ($abono >= $costoatraso) {
                            $insertarAbono = $abono;
                            $insertarTipoAbono = 0; // Abono normal
                            $insertarAtraso = $costoatraso;
                            $atrasoMenosAbono = 0;
                            if ($totalcontrato - $abono == 0) {
                                $estadodelcontrato = 5;
                                $insertarTipoAbono = 6; // Abono liquidado
                            }

                        } else {
                            $insertarAbono = $abono;
                            $insertarTipoAbono = 0; // Abono normal
                            $insertarAtraso = $abono;
                            $atrasoMenosAbono = $costoatraso - $abono;
                        }
                    }

                    $insertarAbono = number_format($insertarAbono, 1, ".", "");
                    $insertarAtraso = number_format($insertarAtraso, 1, ".", "");
                    $insertarAbono2 = number_format($insertarAbono2, 1, ".", "");
                    $insertarAtraso2 = number_format($insertarAtraso2, 1, ".", "");
                    $ID2 = $contratosGlobal::getFolioId();
                    $ID3 = $contratosGlobal::getFolioId();


                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'adelantos' => $adelantarpagos, 'poliza' => null, 'metodopago' => $metodopago,
                        'tipoabono' => $insertarTipoAbono, 'abono' => $insertarAbono, 'atraso' => $insertarAtraso, 'created_at' => Carbon::now()
                    ]);


                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : '$insertarAbono'"
                    ]);

                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalabono' => $tot, 'pagosadelantar' => $adelantados, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'costoatraso' => $atrasoMenosAbono,
                        'estatus_estadocontrato' => $estadodelcontrato, 'fechaatraso' => $fechaatraso
                    ]);

                    //Insertar en tabla registroestadocontrato
                    DB::table('registroestadocontrato')->insert([
                        'id_contrato' => $idContrato,
                        'estatuscontrato' => $estadodelcontrato,
                        'created_at' => Carbon::now()
                    ]);

                    if ($insertarAbono2 != null && $insertarAbono2 > 0) {
                        DB::table('abonos')->insert([
                            'id' => $ID2, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'adelantos' => $adelantarpagos2, 'poliza' => null, 'metodopago' => $metodopago,
                            'tipoabono' => $insertarTipoAbono2, 'abono' => $insertarAbono2, 'atraso' => $insertarAtraso2, 'created_at' => Carbon::now()
                        ]);


                        DB::table('historialcontrato')->insert([
                            'id' => $ID3, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se agrego el abono : ' $insertarAbono2'"
                        ]);

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'costoatraso' => $atrasoMenosAbono2,
                            'estatus_estadocontrato' => $estadodelcontrato, 'fechaatraso' => $fechaatraso
                        ]);

                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => $estadodelcontrato,
                            'created_at' => Carbon::now()
                        ]);
                    }


                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'Se agrego el abono correctamente');


                }

                if ($enganche < 1 && $abono >= $totalenganche && $estadocontrato <= 1 && !$tienePromocion && $contaenganche2 == null) {
                    if ($estadocontrato == 1) {
                        $tipoabonocontado = 4;

                        if ($pago != 0) {
                            $tipoabonocontado = 1;
                        }

                        if ($metodopago == 1) {
                            $banderacase = 6;
                            return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                        }
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'tipoabono' => $tipoabonocontado, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'poliza' => null, 'created_at' => Carbon::now()
                        ]);

                        DB::table('historialcontrato')->insert([
                            'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad con enganche: '$abono'"
                        ]);

                        if ($tienePromocion && $es == 1 || $ec != null) {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                                'total' => $totalpromoresta,
                            ]);
                        } else {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                                'total' => $totalcontratoresta,
                            ]);
                        }

                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono y el enganche se agregaron correctamente');
                    } elseif ($estadocontrato == 0 && $enganche < 1) {
                        $tipoabonocontado = 1;

                        if ($pago == 0) {
                            $tipoabonocontado = 4;
                            $polizaabo = null;
                        }
                        if ($metodopago == 1) {
                            $banderacase = 7;
                            return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                        }
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'tipoabono' => $tipoabonocontado, 'id_usuario' => $usuarioId, 'abono' => $abono, 'metodopago' => $metodopago, 'poliza' => null, 'created_at' => Carbon::now()
                        ]);

                        DB::table('historialcontrato')->insert([
                            'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad con enganche: '$abono'"
                        ]);

                        if ($tienePromocion && $es == 1 || $ec != null) {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                                'total' => $totalpromoresta,
                            ]);
                        } else {
                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                'totalabono' => $tot, 'enganche' => 1, 'totalhistorial' => $totalengancheresta, 'totalpromocion' => $totalenganchepromo, 'ultimoabono' => $actualizar,
                                'total' => $totalcontratoresta,
                            ]);
                        }

                        return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono y el enganche se agregaron correctamente');
                    }
                }
                if ($abono >= 150 && $entregaproducto == 0 && $pago != 0 && $estadocontrato == 12 && ((Auth::user()->rol_id) != 12 || (Auth::user()->rol_id) == 13)) {
                    if ($metodopago == 1) {
                        $banderacase = 8;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }

                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 2, 'abono' => $abono, 'poliza' => null, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad para poder entregar el producto: '$abono'"
                    ]);

                    if ($tienePromocion && $es == 1 || $ec != null) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'entregaproducto' => 1, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                            'total' => $totalcontratoresta2, 'fechaentrega' => $nowparce
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'entregaproducto' => 1, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                            'total' => $totalcontratoresta2, 'fechaentrega' => $nowparce
                        ]);
                    }
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono para la entrega de producto se agrego correctamente');
                }
                if (((Auth::user()->rol_id) == 4) && $pago != 0 && $abono >= $minimo && $abonoperiodo == null && $dentroRango != null && $estadocontrato >= 2) {
                    if ($metodopago == 1) {
                        $banderacase = 9;
                        return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                    }

                    DB::table('abonos')->insert([
                        'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 3, 'abono' => $abono, 'poliza' => null, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                    ]);

                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad para poder entregar el producto: '$abono'"
                    ]);

                    if ($tienePromocion && $es == 1 || $ec != null) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                            'total' => $totalcontratoresta2,
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'ultimoabono' => $actualizar, 'pagosadelantar' => $adelantados,
                            'total' => $totalcontratoresta2,
                        ]);
                    }
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El abono del periodo se agrego correctamente');
                }

                try {

                    if ($abono == $totalproductos && $abonoprod[0]->suma != $totalproductos) {
                        if ($metodopago == 1) {
                            $banderacase = 10;
                            return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                        }
                        DB::table('abonos')->insert([
                            'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 7, 'abono' => $abono, 'adelantos' => $adelanto, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                        ]);
                    } else {
                        if ($metodopago == 1) {
                            $banderacase = 11;
                            return redirect()->route('payment', ["idFranquicia" => $idFranquicia, "idContrato" => $idContrato, "abono" => $abono, "banderacase" => $banderacase, "nuevoabono" => $nuevoabono, "cantidadsubscripcion" => $cantidadsubscripcion]);
                        }
                        if ($estadocontrato >= 2) {
                            DB::table('abonos')->insert([
                                'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 0, 'abono' => $abono, 'adelantos' => $adelanto, 'poliza' => null, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                            ]);
                        } else {
                            DB::table('abonos')->insert([
                                'id' => $randomId, 'folio' => $folio, 'id_franquicia' => $idFranquicia, 'id_contrato' => $idContrato, 'id_usuario' => $usuarioId, 'tipoabono' => 0, 'abono' => $abono, 'adelantos' => $adelanto, 'metodopago' => $metodopago, 'created_at' => Carbon::now()
                            ]);
                        }
                    }


                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => $actualizar, 'cambios' => " Se abono la cantidad: '$abono'"
                    ]);

                    if ($tienePromocion && $es == 1 || $ec != null) {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'pagosadelantar' => $adelantados,
                        ]);
                    } else {
                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'totalabono' => $tot, 'ultimoabono' => $actualizar, 'total' => $totalcontratoresta2, 'pagosadelantar' => $adelantados,
                        ]);
                    }


                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El Abono se agrego correctamente.');
                } catch (\Exception $e) {
                    \Log::info("Error: " . $e->getMessage());
                    return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                }

            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function obtenerEstadoPromocion($idContrato, $idFranquicia)
    {
        $respuesta = false;

        $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
        if ($contrato[0]->idcontratorelacion != null) {
            //Es un contrato hijo
            $idContrato = $contrato[0]->idcontratorelacion;
        }

        $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");

        if ($promocioncontrato != null) {
            if ($promocioncontrato[0]->estado == 1) {
                //Promocion esta activa
                $respuesta = true;
            }
        }
        return $respuesta;
    }

    public function agregarformapago($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 6)) {

            $rules = [
                'formapago' => 'required|string',
            ];
            if (request('formapago') != 0 && request('formapago') != 1 && request('formapago') != 2 && request('formapago') != 4) {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago correcta']);
            }
            if (request('formapago') == 'nada') {
                return back()->withErrors(['formapago' => 'Elegir una forma de pago']);
            }

            request()->validate($rules);

            $contrato = DB::select("SELECT c.estatus_estadocontrato, c.fechacobroini, c.fechacobrofin, c.pago, c.diapago,
                                            (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia
                                            FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

            if($contrato != null) {
                //Existe contrato

                if(($contrato[0]->estatus_estadocontrato == 0
                        || $contrato[0]->estatus_estadocontrato == 2
                        || $contrato[0]->estatus_estadocontrato == 4
                        || ($contrato[0]->estatus_estadocontrato == 12 && $contrato[0]->fechacobroini == null && $contrato[0]->fechacobrofin == null))
                    && ($contrato[0]->estadogarantia == null || ($contrato[0]->estadogarantia != 0 && $contrato[0]->estadogarantia != 1 && $contrato[0]->estadogarantia != 2))) {
                    //Cumplio con las validaciones

                    $formaPagoActualizar = request('formapago');

                    if($contrato[0]->pago != $formaPagoActualizar) {
                        //Se cambio la forma de pago

                        $fechaCobroIniActualizar = null;
                        $fechaCobroFinActualizar = null;
                        $fechaDiaSeleccionadoActualizar = null;

                        if($contrato[0]->estatus_estadocontrato != 0 && $contrato[0]->estatus_estadocontrato != 12) {
                            //ESTADO DIFERENTE A NO TERMINADO O ENVIADO

                            $ultimoAbono = DB::select("SELECT abono, folio, created_at, tipoabono FROM abonos
                                                                WHERE id_contrato = '$idContrato'
                                                                AND id_franquicia = '$idFranquicia'
                                                                AND tipoabono != '7' ORDER BY created_at DESC LIMIT 1");

                            if($ultimoAbono != null) {
                                //Se encontro por lo menos un abono

                                $contratosGlobal = new contratosGlobal;

                                $sumatotal = $ultimoAbono[0]->abono;
                                if($ultimoAbono[0]->folio != null) {
                                    //Tiene folio el ultimo abono
                                    $sumaAbonosFolio = DB::select("SELECT SUM(abono) as sumatotal FROM abonos
                                                                WHERE id_contrato = '$idContrato'
                                                                AND id_franquicia = '$idFranquicia'
                                                                AND folio = '" . $ultimoAbono[0]->folio . "'");
                                    $sumatotal = $sumaAbonosFolio[0]->sumatotal;
                                }

                                if($sumatotal >= $contratosGlobal::calculoCantidadFormaDePago($formaPagoActualizar)) {
                                    //Suma de abono es mayor o igual a la forma de pago a actualizar

                                    $fechaCreacionUltimoAbono = $ultimoAbono[0]->created_at;
                                    $tipoUltimoAbono = $ultimoAbono[0]->tipoabono;

                                    $fechaActual = Carbon::now();
                                    //$fechaActual = Carbon::parse('2022-12-02 00:00:00');
                                    $fechaActual = Carbon::parse($fechaActual)->format('Y-m-d');
                                    $diaActual = Carbon::parse($fechaActual)->format('d');
                                    $calculofechaspago = new calculofechaspago;
                                    $hoyNumero = Carbon::parse($fechaActual)->dayOfWeekIso;

                                    switch ($contrato[0]->pago) { //VALIDAMOS QUE FORMA DE PAGO TENIA ANTERIORMENTE
                                        case 1: //SEMANAL
                                            if ($formaPagoActualizar == 2) {
                                                //Semanal a Quincenal
                                                if ($diaActual > 15) {
                                                    //diaActual es del 15 en adelante

                                                    //Calculo fechaCobroIniActual y $fechaCobroFinActual
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth()->addDays(15); //Se pondra el primer dia del mes actual y se sumaran quince dias
                                                    $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                    $fechaCobroFinActual = Carbon::parse($fechaCobroFinActual); //Parsear fechaCobroFinActual para obtener Ejem. 2022-08-31 00:00:00

                                                    //Calculo fechaCobroIniSiguiente y $fechaCobroFinSiguiente
                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addMonth(); //Se pondra el primer dia del mes actual y se sumara un mes
                                                    $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->addDays(14); //Se le sumaran 14 dias a fechaCobroIniSiguiente
                                                } else {
                                                    //diaActual es menor o igual a 15

                                                    //Calculo fechaCobroIniActual y $fechaCobroFinActual
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth();
                                                    $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->addDays(14);

                                                    //Calculo fechaCobroIniSiguiente y $fechaCobroFinSiguiente
                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addDays(15);
                                                    $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                    $fechaCobroFinSiguiente = Carbon::parse($fechaCobroFinSiguiente); //Parsear fechaCobroFinSiguiente para obtener Ejem. 2022-08-31 00:00:00
                                                }

                                            } elseif ($formaPagoActualizar == 4) {
                                                //Semanal a Mensual

                                                //Calculo fechaCobroIniActual y $fechaCobroFinActual
                                                $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth(); //Se pondra el primer dia del mes actual
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroFinActual); //Parsear fechaCobroFinActual para obtener Ejem. 2022-08-31 00:00:00

                                                //Calculo fechaCobroIniSiguiente y $fechaCobroFinSiguiente
                                                $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addMonth(); //Se pondra el primer dia del mes actual y se sumara un mes
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroFinSiguiente); //Parsear fechaCobroFinSiguiente para obtener Ejem. 2022-08-31 00:00:00
                                            }
                                            break;
                                        case 2: //QUINCENAL
                                            if ($formaPagoActualizar == 1) {
                                                //Quincenal a Semanal

                                                //Calculo fechaCobroIniActual y fechaCobroIniSiguiente
                                                if ($hoyNumero != 6) {
                                                    //Lunes, Martes, Miercoles, Jueves, Viernes o Domingo
                                                    if($hoyNumero == 7) {
                                                        //Domingo
                                                        $fechaCobroIniActual = Carbon::parse($fechaActual)->subDays(1)->format('Y-m-d'); //Se obtiene el sabado anterior
                                                        $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Parsear fechaCobroIniActual para obtener Ejem. 2022-08-13 00:00:00

                                                        $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->addDays(6); //Se obtiene el sabado siguiente
                                                    }else {
                                                        //Lunes, Martes, Miercoles, Jueves, Viernes
                                                        $fechaCobroIniActual = $calculofechaspago::obtenerDia($fechaActual, $hoyNumero, 0); //Se obtiene el sabado anterior
                                                        $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Se da formato ejemplo: 2022-01-02 00:00:00

                                                        $fechaCobroIniSiguiente = $calculofechaspago::obtenerDia($fechaActual, $hoyNumero, 2); //Se obtiene el sabado siguiente
                                                        $fechaCobroIniSiguiente = Carbon::parse($fechaCobroIniSiguiente); //Se da formato ejemplo: 2022-01-02 00:00:00
                                                    }
                                                } else {
                                                    //Sabado
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->format('Y-m-d'); //Se obtiene el sabado actual
                                                    $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Parsear fechaCobroIniActual para obtener Ejem. 2022-08-13 00:00:00

                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->addWeek(); //Se obtiene el sabado siguiente
                                                }

                                                //Calculo fechaCobroFinActual y fechaCobroFinSiguiente
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->addDays(6); //Se obtiene el viernes siguiente de las fechas actuales
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->addDays(6); //Se obtiene el viernes siguiente de las fechas siguientes

                                            } elseif ($formaPagoActualizar == 4) {
                                                //Quincenal a Mensual

                                                //Calculo fechaCobroIniActual y $fechaCobroFinActual
                                                $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth(); //Se pondra el primer dia del mes actual
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroFinActual); //Parsear fechaCobroFinActual para obtener Ejem. 2022-08-31 00:00:00

                                                //Calculo fechaCobroIniSiguiente y $fechaCobroFinSiguiente
                                                $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addMonth(); //Se pondra el primer dia del mes actual y se sumara un mes
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroFinSiguiente); //Parsear fechaCobroFinSiguiente para obtener Ejem. 2022-08-31 00:00:00
                                            }
                                            break;
                                        case 4: //MENSUAL
                                            if ($formaPagoActualizar == 1) {
                                                //Mensual a Semanal

                                                //Calculo fechaCobroIniActual y fechaCobroIniSiguiente
                                                if ($hoyNumero != 6) {
                                                    //Lunes, Martes, Miercoles, Jueves, Viernes o Domingo
                                                    if($hoyNumero == 7) {
                                                        //Domingo
                                                        $fechaCobroIniActual = Carbon::parse($fechaActual)->subDays(1)->format('Y-m-d'); //Se obtiene el sabado anterior
                                                        $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Parsear fechaCobroIniActual para obtener Ejem. 2022-08-13 00:00:00

                                                        $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->addDays(6); //Se obtiene el sabado siguiente
                                                    }else {
                                                        //Lunes, Martes, Miercoles, Jueves, Viernes
                                                        $fechaCobroIniActual = $calculofechaspago::obtenerDia($fechaActual, $hoyNumero, 0); //Se obtiene el sabado anterior
                                                        $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Se da formato ejemplo: 2022-01-02 00:00:00

                                                        $fechaCobroIniSiguiente = $calculofechaspago::obtenerDia($fechaActual, $hoyNumero, 2); //Se obtiene el sabado siguiente
                                                        $fechaCobroIniSiguiente = Carbon::parse($fechaCobroIniSiguiente); //Se da formato ejemplo: 2022-01-02 00:00:00
                                                    }
                                                } else {
                                                    //Sabado
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->format('Y-m-d'); //Se obtiene el sabado actual
                                                    $fechaCobroIniActual = Carbon::parse($fechaCobroIniActual); //Parsear fechaCobroIniActual para obtener Ejem. 2022-08-13 00:00:00

                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->addWeek(); //Se obtiene el sabado siguiente
                                                }

                                                //Calculo fechaCobroFinActual y fechaCobroFinSiguiente
                                                $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->addDays(6); //Se obtiene el viernes siguiente de las fechas actuales
                                                $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->addDays(6); //Se obtiene el viernes siguiente de las fechas siguientes

                                            } elseif ($formaPagoActualizar == 2) {
                                                //Mensual a Quincenal
                                                if ($diaActual > 15) {
                                                    //diaActual es del 15 en adelante

                                                    //Calculo fechaCobroIniActual y fechaCobroFinActual
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth()->addDays(15); //Se pondra el primer dia del mes actual y se sumaran quince dias
                                                    $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                    $fechaCobroFinActual = Carbon::parse($fechaCobroFinActual); //Parsear fechaCobroFinActual para obtener Ejem. 2022-08-31 00:00:00

                                                    //Calculo fechaCobroIniSiguiente y fechaCobroFinSiguiente
                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addMonth(); //Se pondra el primer dia del mes actual y se sumara un mes
                                                    $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->addDays(14); //Se le sumaran 14 dias a fechaCobroIniSiguiente
                                                } else {
                                                    //diaActual es menor o igual a 15

                                                    //Calculo fechaCobroIniActual y fechaCobroFinActual
                                                    $fechaCobroIniActual = Carbon::parse($fechaActual)->firstOfMonth();
                                                    $fechaCobroFinActual = Carbon::parse($fechaCobroIniActual)->addDays(14);

                                                    //Calculo fechaCobroIniSiguiente y fechaCobroFinSiguiente
                                                    $fechaCobroIniSiguiente = Carbon::parse($fechaActual)->firstOfMonth()->addDays(15);
                                                    $fechaCobroFinSiguiente = Carbon::parse($fechaCobroIniSiguiente)->endOfMonth()->format('Y-m-d'); //Se obtendra el ultimo dia del mes
                                                    $fechaCobroFinSiguiente = Carbon::parse($fechaCobroFinSiguiente); //Parsear fechaCobroFinSiguiente para obtener Ejem. 2022-08-31 00:00:00
                                                }
                                            }
                                            break;
                                    }

                                    if($tipoUltimoAbono == 2 || (Carbon::parse($fechaCreacionUltimoAbono)->format('Y-m-d') >= Carbon::parse($fechaCobroIniActual)->format('Y-m-d')
                                        && Carbon::parse($fechaCreacionUltimoAbono)->format('Y-m-d') <= Carbon::parse($fechaCobroFinActual)->format('Y-m-d'))) {
                                        $fechaCobroIniActualizar = $fechaCobroIniSiguiente;
                                        $fechaCobroFinActualizar = $fechaCobroFinSiguiente;
                                    }else {
                                        $fechaCobroIniActualizar = $fechaCobroIniActual;
                                        $fechaCobroFinActualizar = $fechaCobroFinActual;
                                    }

                                    //OBTENER DIASELECCIONADO
                                    if(strlen($contrato[0]->diapago) > 0) {
                                        //Se tiene un dia de pago
                                        $fechaDiaSeleccionadoActualizar = $calculofechaspago::obtenerDiaSeleccionado($contrato[0]->diapago, $fechaCobroIniActualizar, $fechaCobroFinActualizar);
                                    }

                                }else {
                                    //Suma de abono es menor a la forma de pago a actualizar
                                    return back()->with('alerta', 'Para cambiar la forma de pago es necesario que el ultimo abono cubra el minimo a la forma de pago que se quiere cambiar.');
                                }

                            }else {
                                //No se encontro ningun abono
                                return back()->with('alerta', 'No se puede cambiar la forma de pago por que no se encontro ningun abono en el contrato.');
                            }

                        }

                        DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                            'pago' => $formaPagoActualizar,
                            'fechacobroini' => $fechaCobroIniActualizar,
                            'fechacobrofin' => $fechaCobroFinActualizar,
                            'diaseleccionado' => $fechaDiaSeleccionadoActualizar
                        ]);

                        //Guardar en tabla historialcontrato
                        $randomId2 = $this->getHistorialContratoId();
                        $usuarioId = Auth::user()->id;
                        $formaPagoTexto = null;
                        if ($formaPagoActualizar == 0) {
                            $formaPagoTexto = 'Contado';
                        } elseif ($formaPagoActualizar == 1) {
                            $formaPagoTexto = 'Semanal';
                        } elseif ($formaPagoActualizar == 2) {
                            $formaPagoTexto = 'Quicenal';
                        } elseif ($formaPagoActualizar == 4) {
                            $formaPagoTexto = 'Mensual';
                        }
                        DB::table('historialcontrato')->insert([
                            'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Se actualizo la forma de pago '$formaPagoTexto'"
                        ]);
                        return back()->with('bien', 'La forma de pago se actualizó correctamente.');

                    }
                    //Forma de pago sigue siendo la misma
                    return back()->with('alerta', 'Se esta cambiando a la misma forma de pago.');

                }
                //No cumplio con las validaciones
                return back()->with('alerta', 'No se puede cambiar la forma de pago al contrato.');

            }
            //No existe el contrato
            return back()->with('alerta', 'El contrato no existe.');

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function correo()
    {

        $datos = [
            "usuario" => "Christian",
            "Fecha" => Carbon::now(),
            "Saldo" => "1600"
        ];
        Mail::to("marcosyera10@gmail.com")->queue(new prueba($datos));
    }

    public function agregarArchivoExcel()
    {
        \Log::info("Entro");
        $jsonDatos = request("datos");
        //dd($jsonDatos); //Asi es como llegaria
        $todosLosDatos = base64_decode($jsonDatos);//Obtenemos todos los datos
        $jsonContratos = json_decode($todosLosDatos, true);
        //dd($jsonContratos);

        //RECORRIDO DE CONTRATOS PARA INSERTAR REGISTRO EN TABLA CONTRATOS Y HISTORIALCLINICO
        if (!empty($jsonContratos)) {
            //jsonContratos es diferente a vacio

            foreach ($jsonContratos as $contrato) {

                $fechaActual = Carbon::now()->format('Y-m-d H:i:s');

                $IDCONTRATO = $this->getContratoId();
                $IDFRANQUICIA = self::validacionDeNulo($contrato['IDFRANQUICIA']);
                $IDZONA = self::validacionDeNulo($contrato['IDZONA']);
                $NOMBRE = self::validacionDeNulo($contrato['NOMBRE']);
                $CALLE = self::validacionDeNulo($contrato['CALLE']);
                $NUMERO = self::validacionDeNulo($contrato['NUMERO']);
                $COLONIA = self::validacionDeNulo($contrato['COLONIA']);
                $LOCALIDAD = self::validacionDeNulo($contrato['LOCALIDAD']);
                $TELEFONO = self::validacionDeNulo($contrato['TELEFONO']);
                $TELEFONOREFERENCIA = self::validacionDeNulo($contrato['TELEFONOREFERENCIA']);
                $FORMADEPAGO = self::validacionDeNulo($contrato['FORMADEPAGO']);
                $TOTAL = self::validacionDeNulo($contrato['TOTAL']);
                $ESTATUS_ESTADOCONTRATO = 2;
                if ($TOTAL == null || $TOTAL == 0) {
                    $ESTATUS_ESTADOCONTRATO = 5;
                }
                \Log::info($IDCONTRATO);

                //Crear contrato
                DB::table("contratos")->insert([
                    "id" => $IDCONTRATO,
                    "datos" => '1',
                    "id_franquicia" => $IDFRANQUICIA,
                    "id_usuariocreacion" => '335', //Agregar el id_usuariocreacion
                    "nombre_usuariocreacion" => 'SISTEMAS TUXPAN', //Agregar el nombre_usuariocreacion
                    "id_zona" => $IDZONA,
                    "nombre" => $NOMBRE,
                    "calle" => $CALLE,
                    "numero" => $NUMERO,
                    "colonia" => $COLONIA,
                    "localidad" => $LOCALIDAD,
                    "telefono" => $TELEFONO,
                    "telefonoreferencia" => $TELEFONOREFERENCIA,
                    "id_optometrista" => '335', //Agregar el id_optometrista
                    "pago" => $FORMADEPAGO,
                    "total" => $TOTAL,
                    "contador" => '1',
                    "totalhistorial" => $TOTAL,
                    "estatus_estadocontrato" => $ESTATUS_ESTADOCONTRATO,
                    "fechaentrega" => $fechaActual,
                    "enganche" => 1,
                    "entregaproducto" => 1,
                    "poliza" => 1,
                    "created_at" => $fechaActual,
                    "updated_at" => $fechaActual,
                    'fechacobroini' => '2021-10-29',
                    'fechacobrofin' => '2021-11-07',
                ]);

                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $IDCONTRATO,
                    'estatuscontrato' => $ESTATUS_ESTADOCONTRATO,
                    'created_at' => Carbon::now()
                ]);

                //Crear historial clinico
                $IDHISTORIAL = $this->getHistorialContratoId();
                $FECHAENTREGA = Carbon::now()->format('Y-m-d');
                DB::table("historialclinico")->insert([
                    "id" => $IDHISTORIAL,
                    "id_contrato" => $IDCONTRATO,
                    "edad" => '0',
                    "fechaentrega" => $FECHAENTREGA,
                    "diagnostico" => '?????',
                    "hipertension" => '?????',
                    "id_producto" => '1', //Agregar el idproducto
                    "id_paquete" => '1', //Agregar el idpaquete
                    "created_at" => $fechaActual,
                    "updated_at" => $fechaActual
                ]);

            }

        }//CONTRATOS

    }

    public static function liquidarContratosArchivo()
    {
        \Log::info("Entro");
        $jsonDatos = request("datos");
        //dd($jsonDatos); //Asi es como llegaria
        $todosLosDatos = base64_decode($jsonDatos);//Obtenemos todos los datos
        $jsonContratos = json_decode($todosLosDatos, true);
        //dd($jsonContratos);
        $idUsuario = "416";
        $idFranquicia = "6E2AA";

        //RECORRIDO DE CONTRATOS PARA INSERTAR REGISTRO EN TABLA CONTRATOS Y HISTORIALCLINICO
        if (!empty($jsonContratos)) {
            //jsonContratos es diferente a vacio

            $ahora = Carbon::now();
            foreach ($jsonContratos as $contrato) {
                $idContrato = $contrato['IDCONTRATO'];
                \Log::info("CONTRATO: $idContrato");
                $existeContrato = DB::select("SELECT id,estatus_estadocontrato,total,totalabono,costoatraso FROM contratos WHERE id = '$idContrato'");
                if ($existeContrato != null) {
                    if ($existeContrato[0]->estatus_estadocontrato == 2 || $existeContrato[0]->estatus_estadocontrato == 4 || $existeContrato[0]->estatus_estadocontrato == 12) {
                        $totalabono = $existeContrato[0]->totalabono;
                        $total = $existeContrato[0]->total;
                        $idAbono = self::getAbonosContratoId();

                        $atraso = 0;
                        if ($existeContrato[0]->estatus_estadocontrato == 4) {
                            $atraso = $existeContrato[0]->costoatraso;
                        }
                        try {
                            DB::table("contratos")->where("id", "=", $idContrato)->update([
                                "estatus_estadocontrato" => 5,
                                "ultimoabono" => $ahora,
                                "totalabono" => $totalabono + $total,
                                "total" => 0,
                                "costoatraso" => 0,
                                "entregaproducto" => 1,
                                "estatusanteriorcontrato" => $existeContrato[0]->estatus_estadocontrato
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 5,
                                'created_at' => Carbon::now()
                            ]);

                            DB::table("abonos")->insert([
                                "id" => $idAbono,
                                "id_franquicia" => $idFranquicia,
                                "id_contrato" => $idContrato,
                                "id_usuario" => $idUsuario,
                                "abono" => $total,
                                "adelantos" => 0,
                                "tipoabono" => 6,
                                "atraso" => $atraso,
                                "poliza" => 0,
                                "metodopago" => 0,
                                "created_at" => $ahora
                            ]);
                        } catch (\Exception $e) {
                            \Log::info("Error: $e");
                        }
                    }

                } else {
                    \Log::info("No se encontro el contrato: $idContrato");
                }
            }
        }
    }


    private static function validacionDeNulo($valor)
    {
        $respuesta = null;
        if (strlen($valor) > 0) {
            $respuesta = $valor;
        }
        return $respuesta;
    }

    public function agregarnota($idFranquicia, $idContrato)
    {

        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || ((Auth::user()->rol_id) == 4) || ((Auth::user()->rol_id) == 6)) {

            request()->validate([
                'nota' => 'nullable|string|max:255'
            ]);

            $nota = request("nota");
            if ($nota == null || strlen($nota) == 0) {
                $nota = "";
            }

            DB::table("contratos")->where("id_franquicia", "=", $idFranquicia)->where("id", "=", $idContrato)->update([
                "nota" => $nota
            ]);
            return back()->with("bien", "La nota se actualizo correctamente.");

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function obtenerFechaUltimoAbonoDadoEnContrato($idFranquicia, $idContrato)
    {
        $respuesta = null;

        $abono = DB::select("SELECT a.created_at FROM abonos a INNER JOIN contratos c ON c.id = a.id_contrato WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato' ORDER BY a.created_at DESC limit 1");

        if ($abono != null) {
            //Se encontro abono anterior
            $respuesta = $abono[0]->created_at;
        }

        return $respuesta;
    }

    public function aumentardescontarsaldocontrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && (((Auth::user()->rol_id) == 7) || (Auth::user()->rol_id) == 6)) {
            //Rol Director, Administracion

            try {

                $contrato = DB::select("SELECT c.estatus_estadocontrato as estatus_estadocontrato,
                                                (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia,
                                                    c.total as total,
                                                        c.totalhistorial as totalhistorial,
                                                            c.totalpromocion as totalpromocion,
                                                                c.fechacobroini as fechacobroini,
                                                                    c.fechacobrofin as fechacobrofin,
                                                                        c.totalreal as totalreal
                                                                            FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                if ($contrato != null) {
                    //Existe el contrato

                    $estadocontrato = $contrato[0]->estatus_estadocontrato;

                    if ($estadocontrato == 2 || $estadocontrato == 4 || $estadocontrato == 5 || $estadocontrato == 12) {
                        //estadocontrato ENTREGADO, ABONOATRASADO, LIQUIDADO O ENVIADO

                        $estadogarantia = $contrato[0]->estadogarantia;

                        if ($estadogarantia != 2) {
                            //estadogarantia sea diferente a creada

                            $total = $contrato[0]->total;
                            $totalhistorial = $contrato[0]->totalhistorial;
                            $totalpromocion = $contrato[0]->totalpromocion;
                            $fechacobroini = $contrato[0]->fechacobroini;
                            $fechacobrofin = $contrato[0]->fechacobrofin;
                            $totalreal = $contrato[0]->totalreal;

                            $aumentardescontar = request('aumentardescontar');
                            $mensaje = "";

                            if ($aumentardescontar < 0) {
                                //Estan descontando

                                if (($total + $aumentardescontar) < 0) {
                                    return back()->with('alerta', 'No se puede descontar mas de lo que es el saldo actual.');
                                } else {

                                    $mensaje = "desconto";
                                    $estadoactualizar = $estadocontrato;
                                    if (($estadocontrato == 2 || $estadocontrato == 4) && ($total + $aumentardescontar) == 0) {
                                        //ENTREGADO O ABONOATRASADO && total == 0
                                        $estadoactualizar = 5; //LIQUIDADO
                                    }

                                    $totalhistorialactualizar = $totalhistorial + $aumentardescontar;
                                    $totalpromocionactualizar = $totalpromocion + $aumentardescontar;
                                    $totalrealactualizar = $totalreal + $aumentardescontar;

                                    if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                                        //Tiene promocion y esta activa
                                        $promocionterminada = DB::select("SELECT promocionterminada FROM contratos where id = '$idContrato'");
                                        if ($promocionterminada != null) {
                                            if ($promocionterminada[0]->promocionterminada == 1) {
                                                //Promocion ha sido terminada
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'totalhistorial' => $totalhistorialactualizar,
                                                    'totalpromocion' => $totalpromocionactualizar,
                                                    'totalreal' => $totalrealactualizar,
                                                    'estatus_estadocontrato' => $estadoactualizar
                                                ]);
                                            } else {
                                                //Promocion no ha sido terminada
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'totalhistorial' => $totalhistorialactualizar,
                                                    'totalreal' => $totalrealactualizar,
                                                    'estatus_estadocontrato' => $estadoactualizar
                                                ]);
                                            }

                                            //Insertar en tabla registroestadocontrato
                                            DB::table('registroestadocontrato')->insert([
                                                'id_contrato' => $idContrato,
                                                'estatuscontrato' => $estadoactualizar,
                                                'created_at' => Carbon::now()
                                            ]);
                                        }
                                    } else {
                                        //No tiene promocion o existe la promocion pero esta desactivada
                                        if ($totalpromocion > 0) {
                                            //Si se tiene una promocion pero esta desactivada
                                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                'totalhistorial' => $totalhistorialactualizar,
                                                'totalpromocion' => $totalpromocionactualizar,
                                                'totalreal' => $totalrealactualizar,
                                                'estatus_estadocontrato' => $estadoactualizar
                                            ]);
                                        } else {
                                            //No se tiene ninguna promocion
                                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                'totalhistorial' => $totalhistorialactualizar,
                                                'totalreal' => $totalrealactualizar,
                                                'estatus_estadocontrato' => $estadoactualizar
                                            ]);
                                        }

                                        //Insertar en tabla registroestadocontrato
                                        DB::table('registroestadocontrato')->insert([
                                            'id_contrato' => $idContrato,
                                            'estatuscontrato' => $estadoactualizar,
                                            'created_at' => Carbon::now()
                                        ]);

                                    }

                                }

                            } else {
                                //Estan aumentando

                                if ($aumentardescontar > 9999) {
                                    return back()->with('alerta', 'No se puede aumentar mas de $9999.');
                                } else {

                                    $mensaje = "aumento";
                                    $totalhistorialactualizar = $totalhistorial + $aumentardescontar;
                                    $totalpromocionactualizar = $totalpromocion + $aumentardescontar;
                                    $totalrealactualizar = $totalreal + $aumentardescontar;

                                    $estadoactualizar = $estadocontrato;
                                    $fechacobroiniactualizar = $fechacobroini;
                                    $fechacobrofinactualizar = $fechacobrofin;

                                    if ($estadocontrato == 5) {
                                        //LIQUIDADO
                                        $estadoactualizar = 2;
                                        $fechacobroiniactualizar = null;
                                        $fechacobrofinactualizar = null;
                                    }

                                    if ($this->obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                                        //Tiene promocion y esta activa
                                        $promocionterminada = DB::select("SELECT promocionterminada FROM contratos where id = '$idContrato'");
                                        if ($promocionterminada != null) {
                                            if ($promocionterminada[0]->promocionterminada == 1) {
                                                //Promocion ha sido terminada
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'totalhistorial' => $totalhistorialactualizar,
                                                    'totalpromocion' => $totalpromocionactualizar,
                                                    'totalreal' => $totalrealactualizar,
                                                    'estatus_estadocontrato' => $estadoactualizar,
                                                    'fechacobroini' => $fechacobroiniactualizar,
                                                    'fechacobrofin' => $fechacobrofinactualizar
                                                ]);
                                            } else {
                                                //Promocion no ha sido terminada
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'totalhistorial' => $totalhistorialactualizar,
                                                    'totalreal' => $totalrealactualizar,
                                                    'estatus_estadocontrato' => $estadoactualizar,
                                                    'fechacobroini' => $fechacobroiniactualizar,
                                                    'fechacobrofin' => $fechacobrofinactualizar
                                                ]);
                                            }

                                            //Insertar en tabla registroestadocontrato
                                            DB::table('registroestadocontrato')->insert([
                                                'id_contrato' => $idContrato,
                                                'estatuscontrato' => $estadoactualizar,
                                                'created_at' => Carbon::now()
                                            ]);
                                        }
                                    } else {
                                        //No tiene promocion o existe la promocion pero esta desactivada
                                        if ($totalpromocion > 0) {
                                            //Si se tiene una promocion pero esta desactivada
                                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                'totalhistorial' => $totalhistorialactualizar,
                                                'totalpromocion' => $totalpromocionactualizar,
                                                'totalreal' => $totalrealactualizar,
                                                'estatus_estadocontrato' => $estadoactualizar,
                                                'fechacobroini' => $fechacobroiniactualizar,
                                                'fechacobrofin' => $fechacobrofinactualizar
                                            ]);
                                        } else {
                                            //No se tiene ninguna promocion
                                            DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                'totalhistorial' => $totalhistorialactualizar,
                                                'totalreal' => $totalrealactualizar,
                                                'estatus_estadocontrato' => $estadoactualizar,
                                                'fechacobroini' => $fechacobroiniactualizar,
                                                'fechacobrofin' => $fechacobrofinactualizar
                                            ]);
                                        }

                                        //Insertar en tabla registroestadocontrato
                                        DB::table('registroestadocontrato')->insert([
                                            'id_contrato' => $idContrato,
                                            'estatuscontrato' => $estadoactualizar,
                                            'created_at' => Carbon::now()
                                        ]);

                                    }

                                }

                            }

                            //Guardar en tabla historialcontrato
                            $randomId2 = $this->getHistorialContratoId();
                            $usuarioId = Auth::user()->id;
                            DB::table('historialcontrato')->insert([
                                'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Se " . $mensaje . " " . $aumentardescontar . " al contrato, total anterior: " . $totalreal . ", saldo anterior: " . $total
                            ]);

                            //Actualizar en tabla autorizaciones a tipo 3
                            $solicitudaumentarDescontar = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato = '$idContrato' AND a.estatus = 1 AND a.tipo = 2 ORDER BY a.created_at DESC LIMIT 1");
                            $indiceSolicitud = $solicitudaumentarDescontar[0]->indice;
                            if($solicitudaumentarDescontar != null){
                                //Tiene solicitud aprobada para aumentar/descontar
                                DB::table('autorizaciones')->where([['indice', '=', $indiceSolicitud], ['id_contrato', '=', $idContrato]])->update([
                                    'tipo' => '3', 'updated_at' => Carbon::now()
                                ]);
                            }

                            return back()->with('bien', "Se " . $mensaje . " correctamente el saldo");

                        }
                        return back()->with('alerta', 'No se puede aumentar/descontar el saldo (Se tiene garantia).');

                    }
                    return back()->with('alerta', 'No se puede aumentar/descontar el saldo (Verificar el estado del contrato).');

                }
                return back()->with('alerta', 'No se encontro el contrato.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function agregarhistorialmovimientocontrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && (((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8))) {
            //Rol administrador, director o principal

            try {

                $contrato = DB::select("SELECT c.estatus_estadocontrato as estatus_estadocontrato
                                                FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                if ($contrato != null) {
                    //Existe el contrato

                    $movimiento = request('movimiento');

                    if (strlen($movimiento) == 0) {
                        return back()->with('alerta', "Favor de agregar el mensaje de movimiento");
                    }

                    //Guardar en tabla historialcontrato
                    $usuarioId = Auth::user()->id;
                    DB::table('historialcontrato')->insert([
                        'id' => $this->getHistorialContratoId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Agrego el movimiento: " . $movimiento
                    ]);

                    return back()->with('bien', "Se agrego correctamente el movimiento.");

                }
                return back()->with('alerta', 'No se encontro el contrato.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function supervisarcontrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && (((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8))) {
            //Rol administrador, director o principal

            try {

                $contrato = DB::select("SELECT c.estatus_estadocontrato as estatus_estadocontrato,
                                                (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia
                                                    FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                if ($contrato != null) {
                    //Existe el contrato

                    $estadocontrato = $contrato[0]->estatus_estadocontrato;

                    if ($estadocontrato == 2 || $estadocontrato == 4 || $estadocontrato == 12) {

                        $estadogarantia = $contrato[0]->estadogarantia;

                        if ($estadogarantia == null || $estadogarantia >= 2) {
                            //estadogarantia ya fue creada

                            //Actualizar estado SUPERVISION
                            DB::table("contratos")->where("id", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                                'estatus_estadocontrato' => 15
                            ]);

                            //Insertar en tabla registroestadocontrato
                            DB::table('registroestadocontrato')->insert([
                                'id_contrato' => $idContrato,
                                'estatuscontrato' => 15,
                                'created_at' => Carbon::now()
                            ]);

                            //Guardar en tabla historialcontrato
                            $usuarioId = Auth::user()->id;
                            DB::table('historialcontrato')->insert([
                                'id' => $this->getHistorialContratoId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Se cambio el estatus del contrato a 'supervision'"
                            ]);

                            //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                            DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                            return back()->with("bien", "El estatus del contrato se actualizo correctamente");
                        }

                        return back()->with('alerta', 'No se puede supervisar el contrato (Tiene una garantia pendiente/Tiene reportada una garantia)');
                    }

                    return back()->with('alerta', 'No se puede cambiar el estado a supervision necesita el contrato estar en estado ENTREGA/ABONO ATRASADO/ENVIADO.');

                }
                return back()->with('alerta', 'No se encontro el contrato.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function restablecercontrato($idFranquicia, $idContrato)
    {
        if (Auth::check() && (((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8))) {
            //Rol administrador, director o principal

            try {

                $contrato = DB::select("SELECT c.estatus_estadocontrato as estatus_estadocontrato, c.id_zona as id_zona
                                                    FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                if ($contrato != null) {
                    //Existe el contrato

                    $estadocontrato = $contrato[0]->estatus_estadocontrato;
                    $id_zona = $contrato[0]->id_zona;

                    if ($estadocontrato == 15) {

                        $registroestadocontrato = DB::select("SELECT estatuscontrato
                                                    FROM registroestadocontrato WHERE id_contrato = '$idContrato' AND estatuscontrato != '15' ORDER BY created_at DESC LIMIT 1");

                        $estadoactualizar = 2;
                        if ($registroestadocontrato != null) {
                            $estadoactualizar = $registroestadocontrato[0]->estatuscontrato;
                        }

                        //Actualizar estado
                        DB::table("contratos")->where("id", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                            'estatus_estadocontrato' => $estadoactualizar
                        ]);

                        //Insertar en tabla registroestadocontrato
                        DB::table('registroestadocontrato')->insert([
                            'id_contrato' => $idContrato,
                            'estatuscontrato' => $estadoactualizar,
                            'created_at' => Carbon::now()
                        ]);

                        //Guardar en tabla historialcontrato
                        $usuarioId = Auth::user()->id;
                        DB::table('historialcontrato')->insert([
                            'id' => $this->getHistorialContratoId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Se restauro el estatus del contrato de 'supervision'"
                        ]);

                        $contratosGlobal = new contratosGlobal;

                        $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $id_zona . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona

                        if ($cobradoresAsignadosAZona != null) {
                            //Existen cobradores
                            foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                //Recorrido cobradores
                                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                            }
                        }

                        return back()->with("bien", "El estatus del contrato se actualizo correctamente");

                    }

                    return back()->with('alerta', 'No se puede restablecer el contrato, debe estar en estado de SUPERVISION.');

                }
                return back()->with('alerta', 'No se encontro el contrato.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function migrarcuentas($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7)) {
            //Rol director

            return view('administracion.contrato.tablamigrarcuentas', [
                "idFranquicia" => $idFranquicia
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function migrarcuentasarchivo($idFranquicia, Request $request)
    {

        $archivoExcel = $request->file('archivo');
        if ($archivoExcel != null) {
            //Existe archivo

            if (request()->hasFile('archivo')) {

                $extension = $archivoExcel->getClientOriginalExtension();
                if ($extension == "xlsx" || $extension == "xls") { //Es un archivo de excel?

                    try {

                        $errores = array();
                        $filas = Excel::toArray(new CsvImport(), $archivoExcel);

                        $globalesServicioWeb = new globalesServicioWeb;

                        $anoActual = Carbon::now()->format('y'); //Obtener los ultimos 2 digitos del año 21, 22, 23, 24, etc

                        //Obtener indice de la franquicia
                        $franquicia = DB::select("SELECT indice FROM franquicias WHERE id = '$idFranquicia'");
                        $identificadorFranquicia = "";
                        if ($franquicia != null) {
                            //Existe franquicia
                            $identificadorFranquicia = $globalesServicioWeb::obtenerIdentificadorFranquicia($franquicia[0]->indice);
                        }
                        $identificadorFranquicia = $anoActual . $identificadorFranquicia; //Seria el identificadorFranquicia completo = 22001, 22002, 22003, etc

                        //Obtener el ultimo id generado en la tabla de contrato
                        $contratoSelect = DB::select("SELECT id FROM contratos WHERE id_franquicia = '$idFranquicia' AND id LIKE '%$identificadorFranquicia%' ORDER BY id DESC LIMIT 1");
                        if ($contratoSelect != null) {
                            //Existe registro (Significa que ya hay contratos personalizados creados)
                            $idContrato = substr($contratoSelect[0]->id, -5);
                            $ultimoIdContratoPerzonalizado = $idContrato;
                        } else {
                            //Sera el primer contrato perzonalizado a crear de la sucursal
                            $ultimoIdContratoPerzonalizado = 0;
                        }

                        foreach ($filas[0] as $key => $contrato) {

                            try {

                                $fechaActual = Carbon::now()->format('Y-m-d H:i:s');

                                $arrayRespuesta = $globalesServicioWeb::generarIdContratoPersonalizado($identificadorFranquicia, $ultimoIdContratoPerzonalizado);
                                $IDCONTRATO = $arrayRespuesta[0];
                                $IDZONA = $contrato[0];
                                if (strlen($IDZONA) == 0) {
                                    //IDZONA es igual a vacio
                                    $IDZONA = null;
                                }

                                $NOMBRE = $contrato[1];
                                if (strlen($NOMBRE) == 0) {
                                    //NOMBRE es igual a vacio
                                    $NOMBRE = null;
                                }

                                $CALLE = $contrato[2];
                                if (strlen($CALLE) == 0) {
                                    //CALLE es igual a vacio
                                    $CALLE = null;
                                }

                                $NUMERO = $contrato[3];
                                if (strlen($NUMERO) == 0) {
                                    //NUMERO es igual a vacio
                                    $NUMERO = null;
                                }

                                $COLONIA = $contrato[4];
                                if (strlen($COLONIA) == 0) {
                                    //COLONIA es igual a vacio
                                    $COLONIA = null;
                                }

                                $LOCALIDAD = $contrato[5];
                                if (strlen($LOCALIDAD) == 0) {
                                    //LOCALIDAD es igual a vacio
                                    $LOCALIDAD = null;
                                }

                                $TELEFONO = $contrato[6];
                                if (strlen($TELEFONO) == 0) {
                                    //TELEFONO es igual a vacio
                                    $TELEFONO = null;
                                }

                                $TELEFONOREFERENCIA = $contrato[7];
                                if (strlen($TELEFONOREFERENCIA) == 0) {
                                    //TELEFONOREFERENCIA es igual a vacio
                                    $TELEFONOREFERENCIA = null;
                                }

                                $FORMADEPAGO = $contrato[8];
                                if (strlen($FORMADEPAGO) == 0) {
                                    //FORMADEPAGO es igual a vacio
                                    $FORMADEPAGO = null;
                                }

                                $TOTAL = $contrato[9];
                                if (strlen($TOTAL) == 0) {
                                    //TOTAL es igual a vacio
                                    $TOTAL = null;
                                }

                                $IDENTIFICADORARCHIVO = $contrato[10];
                                if (strlen($IDENTIFICADORARCHIVO) > 0) {
                                    //Contiene algo el IDENTIFICADORARCHIVO
                                    $IDENTIFICADORARCHIVO = "CONTRATO FISICO: " . $IDENTIFICADORARCHIVO;
                                } else {
                                    //IDENTIFICADORARCHIVO esta vacio
                                    $IDENTIFICADORARCHIVO = null;
                                }

                                $ESTATUS_ESTADOCONTRATO = 2;
                                if ($TOTAL == null || $TOTAL == 0) {
                                    $ESTATUS_ESTADOCONTRATO = 5;
                                }

                                //\Log::info($IDCONTRATO);

                                //Crear contrato
                                DB::table("contratos")->insert([
                                    "id" => $IDCONTRATO,
                                    "datos" => '1',
                                    "id_franquicia" => $idFranquicia,
                                    "id_usuariocreacion" => '749', //Agregar el id_usuariocreacion
                                    "nombre_usuariocreacion" => 'SISTEMAS XONACATLAN', //Agregar el nombre_usuariocreacion
                                    "id_zona" => $IDZONA,
                                    "nombre" => $NOMBRE,
                                    "calle" => $CALLE,
                                    "numero" => $NUMERO,
                                    "colonia" => $COLONIA,
                                    "localidad" => $LOCALIDAD,
                                    "telefono" => $TELEFONO,
                                    "telefonoreferencia" => $TELEFONOREFERENCIA,
                                    "id_optometrista" => '749', //Agregar el id_optometrista
                                    "pago" => $FORMADEPAGO,
                                    "total" => $TOTAL,
                                    "totalreal" => $TOTAL,
                                    "contador" => '1',
                                    "totalhistorial" => $TOTAL,
                                    "estatus_estadocontrato" => $ESTATUS_ESTADOCONTRATO,
                                    "fechaentrega" => $fechaActual,
                                    "enganche" => 0,
                                    "entregaproducto" => 1,
                                    "poliza" => null,
                                    "created_at" => $fechaActual,
                                    "updated_at" => $fechaActual,
                                    'fechacobroini' => null,
                                    'fechacobrofin' => null
                                ]);

                                //Insertar en tabla registroestadocontrato
                                DB::table('registroestadocontrato')->insert([
                                    'id_contrato' => $IDCONTRATO,
                                    'estatuscontrato' => $ESTATUS_ESTADOCONTRATO,
                                    'created_at' => $fechaActual
                                ]);

                                //Crear historial clinico
                                $IDHISTORIAL = $this->getHistorialContratoId();
                                $FECHAENTREGA = Carbon::now()->format('Y-m-d');
                                DB::table("historialclinico")->insert([
                                    "id" => $IDHISTORIAL,
                                    "id_contrato" => $IDCONTRATO,
                                    "edad" => '0',
                                    "fechaentrega" => $FECHAENTREGA,
                                    "diagnostico" => '?????',
                                    "hipertension" => '?????',
                                    "esfericoder" => '0',
                                    "cilindroder" => '0',
                                    "ejeder" => '0',
                                    "addder" => '0',
                                    "altder" => '0',
                                    "esfericoizq" => '0',
                                    "cilindroizq" => '0',
                                    "ejeizq" => '0',
                                    "addizq" => '0',
                                    "altizq" => '0',
                                    "id_producto" => '00000', //idproducto PROPIO
                                    "id_paquete" => '1', //Agregar el idpaquete
                                    "material" => '1', //CR
                                    "bifocal" => '3', //NA
                                    "fotocromatico" => '0',
                                    "ar" => '1',
                                    "tinte" => '0',
                                    "blueray" => '0',
                                    "otroT" => '0',
                                    "observacionesinterno" => $IDENTIFICADORARCHIVO,
                                    "created_at" => $fechaActual,
                                    "updated_at" => $fechaActual
                                ]);

                                $ultimoIdContratoPerzonalizado = $arrayRespuesta[1] + 1;

                                $IDENTIFICADORARCHIVO = $IDENTIFICADORARCHIVO == null ? "NA" : $IDENTIFICADORARCHIVO;
                                \Log::info($IDENTIFICADORARCHIVO . ", CODIGO CONTRATO GENERADO: " . $IDCONTRATO);

                                if($IDZONA != null) {
                                    //idzona es diferente de null
                                    $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $IDZONA . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona

                                    $contratosGlobal = new contratosGlobal;
                                    if ($cobradoresAsignadosAZona != null) {
                                        //Existen cobradores
                                        foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                            //Recorrido cobradores
                                            $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($IDCONTRATO, $cobradorAsignadoAZona->id);
                                        }
                                    }
                                }

                            } catch (\Exception $e) {
                                \Log::info("Error al migrar cuenta: " . $contrato[1] . "\n" . $e);
                                continue;
                            }

                        }

                        return back()->with("bien", "Se migraron correctamente los contratos.");

                    } catch (\Exception $e) {
                        \Log::info("ERROR: " . $e);
                        return back()->with("error", "Tuvimos un problema, por favor contacta al administrador de la pagina.");
                    }

                }

                return back()->with("alerta", "Por favor, selecciona un archivo valido.");

            }

        }

        return back()->with("alerta", "Por favor, selecciona un archivo.");

    }

    public function traspasarcontrato($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //Rol administrador, director, principal, confirmaciones

            $contrato = null;
            $idContrato = "";
            $id_franquicia = $idFranquicia;


            return view('administracion.contrato.traspasarcontrato', [
                'idFranquicia' => $id_franquicia,
                'idContrato' => $idContrato,
                'contrato' => $contrato
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function buscarcontratotraspasar($idFranquicia)
    {

        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL

            //Valor de idContrato
            $idContrato = request('idContrato');

            //Validacion de campo
            request()->validate([
                'idContrato' => 'required|string'
            ]);

            return redirect()->route('obtenercontratotraspasar', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function cargarpromocionesfranquicia(Request $request)
    {

        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - ADMINISTRACION
            $id_franquicia = $request->input("sucursalSeleccionada");
            $zonas = DB::select("SELECT z.id, z.zona FROM zonas z WHERE z.id_franquicia = '$id_franquicia' ORDER BY z.zona ASC");
            //Promociones para la sucursal seleccionada
            $promociones = DB::select("SELECT p.id, p.titulo FROM promocion p WHERE p.id_franquicia = '$id_franquicia'");

            $response = ['promociones' => $promociones, 'zonas' => $zonas];

            return response()->json($response);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function obtenercontratotraspasar($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL

            $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato'");

            if ($existeContrato != null) {
                //Si existe contrato

                $franquiciaContratoExistente = $existeContrato[0]->id_franquicia;
                $rolUsuario = Auth::user()->rol_id;
                $idUsuario = Auth::user()->id;

                switch ($rolUsuario) {
                    case 7:
                        //Si es director puede acceder a todos los contratos
                        if ($existeContrato[0]->estatus_estadocontrato == '2' || $existeContrato[0]->estatus_estadocontrato == '4' || $existeContrato[0]->estatus_estadocontrato == '5' ||
                            $existeContrato[0]->estatus_estadocontrato == '7' || $existeContrato[0]->estatus_estadocontrato == '10' || $existeContrato[0]->estatus_estadocontrato == '11' ||
                            $existeContrato[0]->estatus_estadocontrato == '12') {
                            //El contrato tiene estatus 4, 7, 10, 11, 12

                            $contrato = DB::select("SELECT c.nombre AS nombreCliente, c.telefono AS telefono, c.telefonoreferencia AS telefonoReferencia,
                                                    c.localidad, c.colonia, c.calle, c.numero, c.id_zona, c.totalreal AS total, c.total AS saldo, c.ultimoabono,
                                                    (SELECT p.titulo FROM promocion p WHERE p.id = c.id_promocion) AS promociones,
                                                    (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) AS sucursalActual
                                                    FROM contratos c
                                                    WHERE c.id = '$idContrato' AND c.id_franquicia = '$franquiciaContratoExistente'");

                            $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f WHERE (f.id != '$franquiciaContratoExistente') ORDER BY ciudad ASC");

                            $idFranquicia = $franquiciaContratoExistente;
                        } else {
                            //El contrato no tiene estatus de atrasado, aprovado, manufactura, proceso de envio o enviado
                            return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'No puedes generar un traspaso de este contrato debido a su estatus actual.');
                        }
                        break;  // Fin de case

                    case 6:
                        //Rol de Administrador
                    case 8:
                        //Rol de Principal
                        if ($existeContrato[0]->id_franquicia == $idFranquicia) {
                            //La sucursal del usuario es igual a la del contrato

                            if ($existeContrato[0]->estatus_estadocontrato == '2' || $existeContrato[0]->estatus_estadocontrato == '4' || $existeContrato[0]->estatus_estadocontrato == '5' ||
                                $existeContrato[0]->estatus_estadocontrato == '7' || $existeContrato[0]->estatus_estadocontrato == '10' || $existeContrato[0]->estatus_estadocontrato == '11' ||
                                $existeContrato[0]->estatus_estadocontrato == '12') {
                                //El contrato tiene estatus 4, 7, 10, 11, 12

                                $contrato = DB::select("SELECT c.nombre AS nombreCliente, c.telefono AS telefono, c.telefonoreferencia AS telefonoReferencia,
                                                    c.localidad, c.colonia, c.calle, c.numero, c.id_zona, c.totalreal AS total, c.total AS saldo, c.ultimoabono,
                                                    (SELECT p.titulo FROM promocion p WHERE p.id = c.id_promocion) AS promociones,
                                                    (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) AS sucursalActual
                                                    FROM contratos c
                                                    WHERE c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'");

                                //Si el rol es Administrador, Principal o confirmaciones excluir franquicia de Pruebas
                                $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where (f.id != '00000' AND f.id != '$idFranquicia') ORDER BY ciudad ASC");

                            } else {
                                //El contrato no tiene estatus de atrasado, aprovado, manufactura, proceso de envio o enviado
                                return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'No puedes generar un traspaso de este contrato debido a su estatus actual.');
                            }
                        } else {
                            //El contrato encontrado pertenece a otra sucursal
                            return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'Contrato perteneciente a otra sucursal');
                        }
                        break;  //Fin de case

                    case 15:
                        //Rol de Confirmaciones

                        $existeGarantia = DB::select("SELECT * FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = '2' ORDER BY created_at ASC limit 1");

                        if ($existeGarantia == null) {
                            //No tiene garantia el contrato
                            $bandera = false;
                            //optenemos sucursales asignadas
                            $franquicias = DB::select("SELECT f.id FROM franquicias f
                                                INNER JOIN sucursalesconfirmaciones sf ON f.id = sf.id_franquicia
                                                WHERE f.id != '00000' AND sf.id_usuario = '$idUsuario' ORDER BY ciudad ASC");

                            foreach ($franquicias as $franquicia) {
                                if ($franquicia->id == $franquiciaContratoExistente) {
                                    //Si la sucursal del contrato pertenece a una asiganada a confirmaciones
                                    $bandera = true; // Bandera colcar en verdadero y salir del ciclo
                                    break;  //Fin de ciclo
                                }
                            }
                            if ($bandera == true) {
                                //El contrato pertenece a una sucursal asiganada a confirmaciones
                                if ($existeContrato[0]->estatus_estadocontrato == '1' || $existeContrato[0]->estatus_estadocontrato == '9' || $existeContrato[0]->estatus_estadocontrato == '7') {
                                    //El contrato tiene estatus de TERMINADO, PROCESO DE APROBACION O APROBADO

                                    $contrato = DB::select("SELECT c.nombre AS nombreCliente, c.telefono AS telefono, c.telefonoreferencia AS telefonoReferencia,
                                                    c.localidad, c.colonia, c.calle, c.numero, c.id_zona, c.totalreal AS total, c.total AS saldo, c.ultimoabono,
                                                    (SELECT p.titulo FROM promocion p WHERE p.id = c.id_promocion) AS promociones,
                                                    (SELECT f.ciudad FROM franquicias f WHERE f.id = c.id_franquicia) AS sucursalActual
                                                    FROM contratos c
                                                    WHERE c.id = '$idContrato' AND c.id_franquicia = '$franquiciaContratoExistente'");

                                    //Si el rol es Administrador, Principal o confirmaciones excluir franquicia de Pruebas
                                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f where (f.id != '00000' AND f.id != '$franquiciaContratoExistente') ORDER BY ciudad ASC");

                                } else {
                                    //El contrato no tiene estatus de atrasado, aprovado, manufactura, proceso de envio o enviado
                                    return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'No puedes generar un traspaso de este contrato debido a su estatus actual.');
                                }
                            } else {
                                //No pertenece a una sucursal asignada a confirmaciones
                                return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'Contrato perteneciente a otra sucursal');
                            }

                            break; // Fin de case

                        } else {
                            //Si tiene garantia el contrato
                            return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'No se puede hacer el traspaso de este contrato debido que presenta una garantia');
                        }
                }

                return view('administracion.contrato.traspasarcontrato', ['contrato' => $contrato, 'idContrato' => $idContrato, 'idFranquicia' => $idFranquicia, 'franquicias' => $franquicias]);

            } else {
                //No existe el contrato
                return redirect()->route('traspasarcontrato', [$idFranquicia])->with('alerta', 'Contrato no existente, verifica el ID CONTRATO');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function generartraspasocontrato($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - CONFIRMACIONES

            //Valor de sucursal traspaso
            $franquiciaTraspaso = $request->input('sucursalSeleccionada');
            $zonaTraspaso = $request->input('zonaSeleccionada');
            $promocionTraspaso = $request->input('promocionSeleccionada');
            $promocionContrato = $request->input('promocionContrato');
            $idFranquiciaContrato = "";
            $rolUsuario = Auth::user()->rol_id; // Rol de usuario
            $idUsuario = Auth::user()->id; // ID usuario
            $franquiciaUsuario = $idFranquicia;

            //Consultas verificar contrato
            if ((Auth::user()->rol_id) == 15) {
                //Para rol de Confirmaciones verificar sucursales
                $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato'");
                $idFranquiciaContrato = $existeContrato[0]->id_franquicia;
                $tieneAbonos = DB::select("SELECT * FROM abonos a WHERE a.id_contrato='$idContrato' AND a.id_franquicia = '$idFranquiciaContrato';");
            } else {
                $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'");
                $tieneAbonos = DB::select("SELECT * FROM abonos a WHERE a.id_contrato='$idContrato' AND a.id_franquicia = '$idFranquicia';");
            }


            if ($promocionContrato != null) {
                //Validar parametros sucursal a traspasar Sucursal seleccionada - Zona - Promocion
                request()->validate([
                    'sucursalSeleccionada' => 'required',
                    'zonaSeleccionada' => 'required',
                    'promocionSeleccionada' => 'required'
                ]);
            } else {
                //Si no tenia el contrato promocion
                //No requerir promocion en select
                request()->validate([
                    'sucursalSeleccionada' => 'required',
                    'zonaSeleccionada' => 'required'
                ]);
            }

            if ($existeContrato != null) {
                //Si existe contrato

                $banderaContrato = false; //Bandera para validacion de contrato

                switch ($rolUsuario) {
                    case 6:
                        //Rol Administracion
                    case 7:
                        //Rol director
                    case 8:
                        //Rol de principal
                        if ($existeContrato[0]->estatus_estadocontrato == '2' || $existeContrato[0]->estatus_estadocontrato == '4' || $existeContrato[0]->estatus_estadocontrato == '7' ||
                            $existeContrato[0]->estatus_estadocontrato == '10' || $existeContrato[0]->estatus_estadocontrato == '11' || $existeContrato[0]->estatus_estadocontrato == '12')  {
                            //Si el estatus del contrato pertenece a 4,7,10,11,12
                            $existeGarantia = DB::select("SELECT * FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia IN (0,1,2) ORDER BY created_at ASC limit 1");
                            if ($existeGarantia == null) {
                                //Si NO tiene garantia puedes hacer el traspaso
                                $banderaContrato = true; //El contrato existe, tiene el estatus correcto y no tiene garantia
                            } else {
                                //Si tiene garantia -> No se puede hacer el traspaso
                                return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'Contrato presenta garantia, es necesario cancelarla para el proceso.');
                            }

                        } else {
                            //El contrato no tiene estatus de atrasado, aprovado, manufactura, proceso de envio o enviado
                            return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'No puedes generar un traspaso de este contrato debido a su estatus actual.');
                        }
                        break;
                    case 15:
                        //Rol de Confirmaciones

                        $existeGarantia = DB::select("SELECT * FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = '2' ORDER BY created_at ASC limit 1");

                        if ($existeGarantia == null) {
                            //Si NO tiene garantia puedes hacer el traspaso

                            $banderaFranquicia = false;
                            //optenemos sucursales asignadas
                            $franquicias = DB::select("SELECT f.id FROM franquicias f
                                                INNER JOIN sucursalesconfirmaciones sf ON f.id = sf.id_franquicia
                                                WHERE f.id != '00000' AND sf.id_usuario = '$idUsuario' ORDER BY ciudad ASC");

                            foreach ($franquicias as $franquicia) {
                                if ($franquicia->id == $existeContrato[0]->id_franquicia) {
                                    //Si la sucursal del contrato pertenece a una asiganada a confirmaciones
                                    $banderaFranquicia = true; // Bandera colcar en verdadero y salir del ciclo
                                    break;
                                }
                            }
                            if ($banderaFranquicia == true) {
                                //El contrato pertenece a una sucursal asiganada a confirmaciones
                                if ($existeContrato[0]->estatus_estadocontrato == '1' || $existeContrato[0]->estatus_estadocontrato == '9' || $existeContrato[0]->estatus_estadocontrato == '7') {
                                    //El contrato tiene estatus de TERMINADO, PROCESO DE APROBACION O APROBADO

                                    $banderaContrato = true; //Contrato validado correctamente y perteneciente a sucursal asiganada
                                    $idFranquicia = $idFranquiciaContrato;
                                } else {
                                    return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'No puedes generar un traspaso de este contrato debido a su estatus actual.');
                                }
                            } else {
                                //No pertenece a una sucursal asignada a confirmaciones
                                return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'Contrato perteneciente a otra sucursal');
                            }
                        } else {
                            //Si tiene garantia -> No se puede hacer el traspaso
                            return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'Contrato presenta garantia, es necesario cancelarla para el proceso.');
                        }
                        break;
                }

                if ($banderaContrato == true) {
                    //Si el contrato es validado correctamente

                    try {
                        //Actualizamos el contrato con la nueva sucursal

                        //Actualizar tabla contratos
                        if ($existeContrato[0]->id_promocion == null || $promocionTraspaso == "Sin promocion") {
                            //No tiene promocion
                            DB::table('contratos')->where("id", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                                'id_franquicia' => $franquiciaTraspaso, 'id_zona' => $zonaTraspaso, 'id_promocion' => null, 'updated_at' => Carbon::now()
                            ]);
                        } else {
                            //Si tiene promocion
                            DB::table('contratos')->where("id", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                                'id_franquicia' => $franquiciaTraspaso, 'id_zona' => $zonaTraspaso, 'id_promocion' => $promocionTraspaso, 'updated_at' => Carbon::now()
                            ]);

                            //Actualizar tabla promocioncontrato
                            DB::table('promocioncontrato')->where("id_contrato", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                                'id_franquicia' => $franquiciaTraspaso, 'updated_at' => Carbon::now()
                            ]);
                        }

                        //Actualizar tabla Abonos
                        if ($tieneAbonos != null) {
                            //Tiene abonos el contrato
                            DB::table('abonos')->where("id_contrato", "=", $idContrato)->where("id_franquicia", "=", $idFranquicia)->update([
                                'id_franquicia' => $franquiciaTraspaso, 'updated_at' => Carbon::now()
                            ]);
                        }

                        //Registrar movimiento en historial
                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');
                        $usuarioId = Auth::user()->id;
                        $franquicia = DB::select("SELECT f.ciudad FROM franquicias f where f.id = '$franquiciaTraspaso'");
                        $nombreFranquicia = $franquicia[0]->ciudad;
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(),
                            'cambios' => "Se traspaso el contrato a sucursal: '$nombreFranquicia'"]);

                        //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                        DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                        if ($existeContrato[0]->estatus_estadocontrato == '4' || $existeContrato[0]->estatus_estadocontrato == '12') {
                            //ABONO ATRASADO O ENVIADO
                            $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $zonaTraspaso . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona de traspaso

                            $contratosGlobal = new contratosGlobal;
                            if ($cobradoresAsignadosAZona != null) {
                                //Existen cobradores
                                foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                    //Recorrido cobradores
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $cobradorAsignadoAZona->id);
                                }
                            }
                        }

                        return redirect()->route('traspasarcontrato', ['idFranquicia' => $franquiciaUsuario])->with('bien', "El contrato a sido transferido correctamente");

                    } catch (\Exception $e) {
                        \Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }
                }
                //Y si no es valido?
                return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'Contrato no valido.');
            } else {
                //No existe el contrato
                return redirect()->route('traspasarcontrato', [$franquiciaUsuario])->with('alerta', 'Contrato no existente, verifica el ID CONTRATO');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function reportecontratos($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //Rol administrador, director, principal, confirmaciones

            //Variables
            $franquicias = "";
            $ventasAsistentes = null;
            $ventasOptometristas = null;
            $totalVentasAsistentes = null;
            $totalVentasOptometristas = null;
            $ventasPorFranquiciaOptometrsitas = [];
            $ventasPorFranquiciaAsistentes = [];
            $bandera = false;

            switch (Auth::user()->rol_id) {
                case 7:
                    //Rol de director
                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f WHERE (f.id != '00000') ORDER BY ciudad ASC");
                    break;
                case 6:
                    //Rol de Administracion
                case 8:
                    //Rol de Principal
                    $franquicias = DB::select("SELECT f.id, f.ciudad FROM franquicias f WHERE f.id = '$idFranquicia'");
                    $bandera = true;
                    break;
                case 15:
                    //Rol de administracion
                    $idUsuario = Auth::user()->id;
                    //Obtener las sucursales asigandas
                    $franquicias = DB::select("SELECT f.id AS id, f.ciudad AS ciudad FROM franquicias f
                                                INNER JOIN sucursalesconfirmaciones sf ON f.id = sf.id_franquicia
                                                WHERE f.id != '00000' AND sf.id_usuario = '$idUsuario' ORDER BY ciudad ASC");
                    $bandera = true;
                    break;
            }

            if ($bandera == true) {
                //Se obtienen los datos sobre ventas para las sucursales (Sin importar si es 1 o mas sucursales)
                $ventasPorFranquicias = $franquicias;
                $indice = 0;

                foreach ($ventasPorFranquicias as $ventasPorFranquicia) {

                    $id_Franquicia = $ventasPorFranquicia->id;
                    //Optener datos de ventas en la semana para solo la sucursal asiganda
                    $asistentes = DB::select("SELECT u.name, u.id FROM users u inner join usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.rol_id = '13' AND uf.id_franquicia = '$id_Franquicia'");
                    $optometristas = DB::select("SELECT u.name, u.id  FROM users u inner join usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.rol_id = '12' AND uf.id_franquicia = '$id_Franquicia'");

                    //Obtener ventas de la semana Optometristas y Asistentes
                    $ventasOptometristas = contratosGlobal::obtenerVentasSemana($optometristas, $id_Franquicia, 0);
                    $ventasAsistentes = contratosGlobal::obtenerVentasSemana($asistentes, $id_Franquicia, 1);

                    //Suma de ventas por dia
                    $totalVentasAsistentes[$indice] = contratosGlobal::totalVentasPorDia($asistentes);
                    $totalVentasOptometristas[$indice] = contratosGlobal::totalVentasPorDia($optometristas);

                    //Se ingresan las ventas a un uevo arreglo pero en cada indice va una franquicia
                    $ventasPorFranquiciaAsistentes[$indice] = $ventasAsistentes;
                    $ventasPorFranquiciaOptometrsitas[$indice] = $ventasOptometristas;
                    $indice = $indice + 1;
                }
            }

            return view('administracion.contrato.reportecontratos', [
                'ventasAsistentes' => $ventasAsistentes,
                'ventasOptometristas' => $ventasOptometristas,
                'totalVentasAsistentes' => $totalVentasAsistentes,
                'totalVentasOptometristas' => $totalVentasOptometristas,
                'franquicias' => $franquicias,
                'ventasPorFranquiciaOptometrsitas' => $ventasPorFranquiciaOptometrsitas,
                'ventasPorFranquiciaAsistentes' => $ventasPorFranquiciaAsistentes
            ]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function obtenerreportecontratosdirector(Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7)) {
            //Rol administrador, director, principal, confirmaciones

            //Variables
            $totalVentasAsistentes = null;
            $totalVentasOptometristas = null;
            $ventasPorFranquiciaOptometrsitas = [];
            $ventasPorFranquiciaAsistentes = [];

            //Datos recibidos
            $franquiciaSeleccionada = $request->input("franquiciaSeleccionada");

            if ($franquiciaSeleccionada != null) {
                //se selecciono una franquicia
                //Obtenemos las franquicias - en este caso solo sera 1
                $franquicias = DB::select("SELECT f.id, f.ciudad FROM franquicias f WHERE f.id = '$franquiciaSeleccionada';");
            } else {
                //Selecciono - Todas las sucursales
                $franquicias = DB::select("SELECT f.id, f.ciudad FROM franquicias f WHERE f.id != '00000' ORDER BY f.ciudad ASC;");
            }

            //Obtener datos para sucursal seleccionada o todas las sucursales
            $ventasPorFranquicias = $franquicias;
            $indice = 0;

            foreach ($ventasPorFranquicias as $ventasPorFranquicia) {

                $id_Franquicia = $ventasPorFranquicia->id;
                //Optener datos de ventas en la semana para solo la sucursal asiganda
                $asistentes = DB::select("SELECT u.name, u.id FROM users u inner join usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.rol_id = '13' AND uf.id_franquicia = '$id_Franquicia'");
                $optometristas = DB::select("SELECT u.name, u.id  FROM users u inner join usuariosfranquicia uf ON uf.id_usuario = u.id WHERE u.rol_id = '12' AND uf.id_franquicia = '$id_Franquicia'");

                //Obtener ventas de la semana Asistente y Optometrista
                $ventasOptometristas = contratosGlobal::obtenerVentasSemana($optometristas, $id_Franquicia, 0);
                $ventasAsistentes = contratosGlobal::obtenerVentasSemana($asistentes, $id_Franquicia, 1);

                //Suma de ventas por dia
                $totalVentasAsistentes[$indice] = contratosGlobal::totalVentasPorDia($asistentes);
                $totalVentasOptometristas[$indice] = contratosGlobal::totalVentasPorDia($optometristas);

                //Se ingresan las ventas a un uevo arreglo pero en cada indice va una franquicia
                $ventasPorFranquiciaAsistentes[$indice] = $ventasAsistentes;
                $ventasPorFranquiciaOptometrsitas[$indice] = $ventasOptometristas;
                $indice = $indice + 1; //Incrementar indice para ingresar a otro espacio del arreglo
            }

            $view = view('administracion.contrato.listas.listareportecontratosdirector', [
                'totalVentasAsistentes' => $totalVentasAsistentes,
                'totalVentasOptometristas' => $totalVentasOptometristas,
                'franquicias' => $franquicias,
                'franquiciaSeleccionada' => $franquiciaSeleccionada,
                'ventasPorFranquiciaOptometrsitas' => $ventasPorFranquiciaOptometrsitas,
                'ventasPorFranquiciaAsistentes' => $ventasPorFranquiciaAsistentes
            ])->render();

            return \Response::json(array("valid" => "true", "view" => $view));


        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }

    }

    public function listasolicitudautorizacion($idFranquicia){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8  || (Auth::user()->rol_id) == 15)){
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - CONFIRMACIONES

            $rol_id = Auth::user()->rol_id;
            $idUsuario = Auth::user()->id;

            switch ($rol_id){
                case 6:
                    //Rol de Administracion
                    //Solo optener solicitudes de su franquiciaa
                    $solicitudesAutorizacion = DB::select("SELECT f.ciudad AS sucursal,a.id_contrato,c.created_at AS fecha_contrato, a.created_at AS fecha_solicitud, c.estatus_estadocontrato AS estado_contrato, u.name AS usuario_solicitud, a.indice,
                                                                (SELECT hc.cambios FROM historialcontrato hc WHERE hc.id_contrato = a.id_contrato AND a.id_mensaje = hc.id AND hc.tipomensaje = '3'
                                                                 ORDER BY hc.created_at DESC LIMIT 1) AS mensaje, a.tipo FROM autorizaciones a
                                                                INNER JOIN contratos c ON c.id = a.id_contrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                INNER JOIN users u ON u.id = a.id_usuarioC
                                                                WHERE a.estatus = 0 AND a.tipo = 0 AND c.id_franquicia = '$idFranquicia'
                                                                ORDER BY sucursal, a.tipo ASC, fecha_solicitud DESC");
                    break;
                case 8:
                    //Rol de Principal
                    //Solo optener solicitudes de su franquiciaa
                    $solicitudesAutorizacion = DB::select("SELECT f.ciudad AS sucursal,a.id_contrato,c.created_at AS fecha_contrato, a.created_at AS fecha_solicitud, c.estatus_estadocontrato AS estado_contrato, u.name AS usuario_solicitud, a.indice,
                                                                 (SELECT hc.cambios FROM historialcontrato hc WHERE hc.id_contrato = a.id_contrato AND a.id_mensaje = hc.id AND hc.tipomensaje = '3'
                                                                 ORDER BY hc.created_at DESC LIMIT 1) AS mensaje, a.tipo FROM autorizaciones a
                                                                INNER JOIN contratos c ON c.id = a.id_contrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                INNER JOIN users u ON u.id = a.id_usuarioC
                                                                WHERE a.estatus = 0 AND (a.tipo = 0 OR a.tipo = 1 OR a.tipo = 2 OR a.tipo = 4) AND c.id_franquicia = '$idFranquicia'
                                                                OORDER BY sucursal, a.tipo ASC, fecha_solicitud DESC");
                    break;

                case 7:
                    //Rol de director
                    //Obtener solicitudes de todas las franquicias
                    $solicitudesAutorizacion = DB::select("SELECT f.ciudad AS sucursal,a.id_contrato,c.created_at AS fecha_contrato, a.created_at AS fecha_solicitud, c.estatus_estadocontrato AS estado_contrato, u.name AS usuario_solicitud, a.indice,
                                                                 (SELECT hc.cambios FROM historialcontrato hc WHERE hc.id_contrato = a.id_contrato AND a.id_mensaje = hc.id AND hc.tipomensaje = '3'
                                                                 ORDER BY hc.created_at DESC LIMIT 1) AS mensaje, a.tipo FROM autorizaciones a
                                                                INNER JOIN contratos c ON c.id = a.id_contrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                INNER JOIN users u ON u.id = a.id_usuarioC
                                                                WHERE a.estatus = 0 AND (a.tipo = 0 OR a.tipo = 1 OR a.tipo = 2 OR a.tipo = 4) AND c.id_franquicia != '00000'
                                                                ORDER BY sucursal, a.tipo ASC, fecha_solicitud DESC");
                    break;

                case 15:
                    //Rol de Confirmaciones
                    //Obtener solicitudes de franquicias asignadas
                    $solicitudesAutorizacion = DB::select("SELECT f.ciudad AS sucursal,a.id_contrato,c.created_at AS fecha_contrato, a.created_at AS fecha_solicitud, c.estatus_estadocontrato AS estado_contrato, u.name AS usuario_solicitud, a.indice,
                                                                (SELECT hc.cambios FROM historialcontrato hc WHERE hc.id_contrato = a.id_contrato AND a.id_mensaje = hc.id AND hc.tipomensaje = '3'
                                                                 ORDER BY hc.created_at DESC LIMIT 1) AS mensaje, a.tipo FROM autorizaciones a
                                                                INNER JOIN contratos c ON c.id = a.id_contrato
                                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                                INNER JOIN users u ON u.id = a.id_usuarioC
                                                                WHERE sc.id_usuario = '$idUsuario' and a.estatus = 0 AND a.tipo = 0
                                                                ORDER BY ORDER BY sucursal, a.tipo ASC, fecha_solicitud DESC");
                    break;
            }

            return view('administracion.contrato.tablasolicitudesautorizacion', [
                'solicitudesAutorizacion' => $solicitudesAutorizacion
            ]);
        }else{
            if(Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function autorizarcontrato($idContrato, $indice){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8  || (Auth::user()->rol_id) == 15)){
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - CONFIRMACIONES

            $rol_id = Auth::user()->rol_id;
            $idUsuario = Auth::user()->id;

            //Comprobar que contrato pertenezca a sucursal asignada
            switch ($rol_id){
                case 6:
                    //Rol de ADMINISTRACION
                case 8:
                    //Rol de PRINCIPAL
                    $existeContrato = DB::select("SELECT * FROM contratos c
                                                inner join usuariosfranquicia uf ON uf.id_franquicia = c.id_franquicia
                                                INNER JOIN users u ON uf.id_usuario = u.id
                                                WHERE c.id = '$idContrato' AND u.id = '$idUsuario'");
                    break;

                case 7:
                    //Rol de DIRECTOR
                    $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato' and c.id_franquicia != '00000'");
                    break;
                case 15:
                    //Rol de CONFIRMACIONES
                    $existeContrato = DB::select("SELECT * FROM contratos c
                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON u.id = sc.id_usuario
                                                WHERE c.id = '$idContrato' AND  sc.id_usuario = '$idUsuario'");
                    break;
            }
            if($existeContrato != null){
                //Contrato existe y pertenece a sucursal
                $existeSolicitud = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato = '$idContrato' AND a.estatus = '0' AND a.indice = '$indice'");

                if($existeSolicitud != null){
                    //Si existe solicitud
                    switch ($existeSolicitud[0]->tipo){
                        case 0:
                            //Tipo Solicitud de garantia
                            $cambios = "Solicitud de garantia autorizada.";
                            $mensaje = " Solicitud de garantia autorizada correctamente.";
                            break;

                        case 1:
                            //Tipo cancelar contrato
                            $cambios = "Solicitud de cancelacion de contrato autorizada.";
                            $mensaje = " Solicitud de cancelacion de contrato autorizada correctamente.";
                            break;

                        case 2:
                            //Tipo aumentar/descontar
                            $cambios = "Solicitud cambio de total en contrato autorizada.";
                            $mensaje = " Solicitud cambio de total en contrato autorizada correctamente.";
                            break;

                        case 4:
                            //Tipo cambiar paquete
                            $cambios = "Solicitud cambio de paquete autorizada.";
                            $mensaje = " Solicitud cambio de paquete autorizada correctamente.";
                            break;

                    }
                    try {
                        //Actualizar a estatus AUTORIZADA
                        DB::table('autorizaciones')->where([['indice', '=', $indice], ['id_contrato', '=', $idContrato]])->update([
                            'estatus' => '1', 'updated_at' => Carbon::now()
                        ]);

                        $globalesServicioWeb = new globalesServicioWeb;

                        if($existeSolicitud[0]->tipo == 0){
                            //Si es una solicitud de garantia

                            //Generar una garantia con estatus 0
                            $idGarantiaAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('garantias', '5');
                            DB::table('garantias')->insert([
                                'id' => $idGarantiaAlfanumerico,
                                'id_contrato' => $idContrato,
                                'estadogarantia' => 0,
                                'created_at' => Carbon::now()
                            ]);
                        }

                        //Registrar movimiento
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico,
                            'id_usuarioC' => Auth::user()->id,
                            'id_contrato' => $idContrato,
                            'created_at' => Carbon::now(),
                            'cambios' => $cambios,
                            'tipomensaje' => '3'
                        ]);

                        return back()->with('bien', $mensaje);

                    } catch (Exception $e){
                        Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }

                }else{
                    //No existe ninguna solicitud para el contrato
                    return back()->with('alerta', 'No existe ninguna solicitud para el contrato');
                }

            }else {
                return back()->with('alerta', 'No existe el contrato o no pertenece a la sucursal.');
            }

        }else{
            if(Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function rechazarcontrato($idContrato, $indice){
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8  || (Auth::user()->rol_id) == 15)){
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - CONFIRMACIONES
            $rol_id = Auth::user()->rol_id;
            $idUsuario = Auth::user()->id;

            //Comprobar que contrato pertenezca a sucursal asignada
            switch ($rol_id){
                case 6:
                    //Rol de ADMINISTRACION
                case 8:
                    //Rol de PRINCIPAL
                    $existeContrato = DB::select("SELECT * FROM contratos c
                                                inner join usuariosfranquicia uf ON uf.id_franquicia = c.id_franquicia
                                                INNER JOIN users u ON uf.id_usuario = u.id
                                                WHERE c.id = '$idContrato' AND u.id = '$idUsuario'");
                    break;

                case 7:
                    //Rol de DIRECTOR
                    $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato' and c.id_franquicia != '00000'");
                    break;
                case 15:
                    //Rol de CONFIRMACIONES
                    $existeContrato = DB::select("SELECT * FROM contratos c
                                                INNER JOIN franquicias f ON f.id = c.id_franquicia
                                                INNER JOIN sucursalesconfirmaciones sc ON c.id_franquicia = sc.id_franquicia
                                                INNER JOIN users u ON u.id = sc.id_usuario
                                                WHERE c.id = '$idContrato' AND  sc.id_usuario = '$idUsuario'");
                    break;
            }

            $existeSolicitud = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato = '$idContrato' AND a.estatus = '0' AND a.indice = '$indice'");
            if($existeContrato != null){
                //Existe el contrato y pertenece a la sucursal
                if($existeSolicitud != null){
                    //Si existe solicitud
                    switch ($existeSolicitud[0]->tipo){
                        case 0:
                            //Tipo Solicitud de garantia
                            $cambios = "Solicitud de garantia rechazada.";
                            $mensaje = " Solicitud de garantia rechazada correctamente.";
                            break;

                        case 1:
                            //Tipo cancelar contrato
                            $cambios = "Solicitud de cancelacion de contrato rechazada.";
                            $mensaje = " Solicitud de cancelacion de contrato rechazada correctamente.";
                            break;

                        case 2:
                            //Tipo aumentar/descontar
                            $cambios = "Solicitud cambio de total en contrato rechazada.";
                            $mensaje = " Solicitud cambio de total en contrato rechazada correctamente.";
                            break;

                        case 4:
                            //Tipo cambiar paquete
                            $cambios = "Solicitud cambio de paquete rechazada.";
                            $mensaje = " Solicitud cambio de paquete rechazada correctamente.";
                            break;

                    }
                    try {
                        //Actualizar a estatus AUTORIZADA
                        DB::table('autorizaciones')->where([['indice', '=', $indice], ['id_contrato', '=', $idContrato]])->update([
                            'estatus' => '2', 'updated_at' => Carbon::now()
                        ]);

                        $globalesServicioWeb = new globalesServicioWeb;

                        //Registrar movimiento
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico,
                            'id_usuarioC' => Auth::user()->id,
                            'id_contrato' => $idContrato,
                            'created_at' => Carbon::now(),
                            'cambios' => $cambios,
                            'tipomensaje' => '3'
                        ]);

                        return back()->with('bien', $mensaje);

                    } catch (Exception $e){
                        Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }

                }else{
                    //No existe ninguna solicitud para el contrato
                    return back()->with('alerta', 'No existe ninguna solicitud para el contrato.');
                }
            } else {
                return back()->with('alerta', 'No existe el contrato o no pertenece a sucursal.');
            }

        }else{
            if(Auth::check()) {
                return redirect()->route('redireccionar');
            }else{
                return redirect()->route('login');
            }
        }
    }

    public function solicitarautorizaciongarantia($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - CONFIRMACIONES

            $rol_id = Auth::user()->rol_id;
            $idUsuario = Auth::user()->id;

            $mensaje = $request->input("mensaje");

            //Validaciones de campo mensaje
            request()->validate([
                'mensaje' => 'required|string|min:1'
            ]);

            if ($rol_id == 15) {
                //Si es rol CONFIRMACIONES
                $validacionContrato = "c.id = '$idContrato'";
            } else {
                //Si es rol DIRECTOR, ADMINISTRACION, PRINCIPAL
                $validacionContrato = "c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'";

            }
            $existeContrato = DB::select("SELECT * FROM contratos c WHERE $validacionContrato");

            if ($existeContrato != null) {
                //Si existe el contrato
                if ($rol_id == 15) {
                    //Si es CONFIRMACIONES valida que el contrato pertenezca a una franquicia asiganada

                    $banderaFranquicia = false;
                    //optenemos sucursales asignadas
                    $franquicias = DB::select("SELECT f.id FROM franquicias f
                                                INNER JOIN sucursalesconfirmaciones sf ON f.id = sf.id_franquicia
                                                WHERE f.id != '00000' AND sf.id_usuario = '$idUsuario' ORDER BY ciudad ASC");

                    foreach ($franquicias as $franquicia) {
                        if ($franquicia->id == $existeContrato[0]->id_franquicia) {
                            //Si la sucursal del contrato pertenece a una asiganada a confirmaciones
                            $banderaFranquicia = true; // Bandera = verdadero y salir del ciclo
                            break;
                        }
                    }
                    if ($banderaFranquicia == false) {
                        //No pertenece a ningua fraqnuicia asiganada
                        return back()->with('alerta', 'No puedes accesar al contrato debido a la sucursal que pertenece.');
                    }
                }

                if ($existeContrato[0]->estatus_estadocontrato == 2 || $existeContrato[0]->estatus_estadocontrato == 4 || $existeContrato[0]->estatus_estadocontrato == 5) {
                    //El contrato tiene estatus ENTREGADO, ATRASADO, PAGADO

                    try {
                        //Insertamos valores de peticion y movimiento

                        //Generamos ID alfanumero de identificacion de mensaje y movimiento
                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');

                        //Insertar solicitud de autorizacion
                        DB::table('autorizaciones')->insert([
                            'id_contrato' => $idContrato, 'id_usuarioC' => $idUsuario, 'id_mensaje' => $idHistorialContratoAlfanumerico,
                            'estatus' => '0', 'tipo' => '0', 'created_at' => Carbon::now()
                        ]);

                        //Insertamos el movimiento con su respectivo mensaje de solicitud
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $idUsuario, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(),
                            'cambios' => "Solicitó autorizacion con el siguiente mensaje: '$mensaje'", 'tipomensaje' => '3']);

                        return back()->with('bien', 'Solicitud de garantia generada correctamente');

                    } catch (Exception $e) {
                        Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }
                } else {
                    return back()->with('alerta', 'No puedes acceder al contrato debido a su estatus actual.');
                }
            } else {
                return back()->with('alerta', 'Contrato no existente, verifica el ID CONTRATO.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    //Funcion: solicitarautorizacioncancelarcontrato
    //Descripcion: Genera la solicitud para cancelar un contrato, almacena en tabla autorizaciones, movimeintos con un tipo 1 (cancelar contrato)
    public function solicitarautorizacioncancelarcontrato($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 8 || (Auth::user()->rol_id) == 15)) {
            //ROL DE DIRECTOR - ADMINISTRADOR - GENERAL - CONFIRMACIONES

            $rol_id = Auth::user()->rol_id;
            $idUsuario = Auth::user()->id;

            $mensaje = $request->input("mensaje");

            //Validaciones de campo mensaje
            request()->validate([
                'mensaje' => 'required|string|min:1'
            ]);

            if ($rol_id == 15) {
                //Si es rol CONFIRMACIONES
                $validacionContrato = "c.id = '$idContrato'";
            } else {
                //Si es rol DIRECTOR, ADMINISTRACION, PRINCIPAL
                $validacionContrato = "c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'";

            }
            $existeContrato = DB::select("SELECT * FROM contratos c WHERE $validacionContrato");

            if ($existeContrato != null) {
                //Si existe el contrato
                if ($rol_id == 15) {
                    //Si es CONFIRMACIONES valida que el contrato pertenezca a una franquicia asiganada

                    $banderaFranquicia = false;
                    //optenemos sucursales asignadas
                    $franquicias = DB::select("SELECT f.id FROM franquicias f
                                                INNER JOIN sucursalesconfirmaciones sf ON f.id = sf.id_franquicia
                                                WHERE f.id != '00000' AND sf.id_usuario = '$idUsuario' ORDER BY ciudad ASC");

                    foreach ($franquicias as $franquicia) {
                        if ($franquicia->id == $existeContrato[0]->id_franquicia) {
                            //Si la sucursal del contrato pertenece a una asiganada a confirmaciones
                            $banderaFranquicia = true; // Bandera = verdadero y salir del ciclo
                            break;
                        }
                    }
                    if ($banderaFranquicia == false) {
                        //No pertenece a ningua fraqnuicia asiganada
                        return back()->with('alerta', 'No puedes accesar al contrato debido a la sucursal que pertenece.');
                    }
                }

                if ($existeContrato[0]->estatus_estadocontrato == 0 || $existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 2
                    || $existeContrato[0]->estatus_estadocontrato == 3 || $existeContrato[0]->estatus_estadocontrato == 4 || $existeContrato[0]->estatus_estadocontrato == 5
                    || $existeContrato[0]->estatus_estadocontrato == 12 || $existeContrato[0]->estatus_estadocontrato == 14 || $existeContrato[0]->estatus_estadocontrato == 15) {
                    //El contrato tiene estatus NO TERMINADO, TERMINADO, ENTREGADO, PRE-CANCELADO, ATRASADO, PAGADO, ENVIADO, LIO/FUGA, SUPERVISION

                    try {
                        //Insertamos valores de peticion y movimiento

                        //Generamos ID alfanumero de identificacion de mensaje y movimiento
                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');

                        //Insertar solicitud de autorizacion
                        DB::table('autorizaciones')->insert([
                            'id_contrato' => $idContrato, 'id_usuarioC' => $idUsuario, 'id_mensaje' => $idHistorialContratoAlfanumerico,
                            'estatus' => '0', 'tipo' => '1', 'created_at' => Carbon::now()
                        ]);

                        //Insertamos el movimiento con su respectivo mensaje de solicitud
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $idUsuario, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(),
                            'cambios' => "Solicitó autorizacion con el siguiente mensaje: '$mensaje'", 'tipomensaje' => '3']);

                        return back()->with('bien', 'Solicitud de cancelar contrato generada correctamente');

                    } catch (Exception $e) {
                        Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }
                } else {
                    return back()->with('alerta', 'No puedes acceder al contrato debido a su estatus actual.');
                }
            } else {
                return back()->with('alerta', 'Contrato no existente, verifica el ID CONTRATO.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    //Funcion: solicitarautorizacionaumentardisminuir
    //Descripcion: Genera la solicitud para aumentra o diminuir el total del contrato, almacena en tabla autorizaciones, movimientos con un tipo 2 (aumentar/disminuir)
    public function solicitarautorizacionaumentardisminuir($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7)) {
            //ROL DE DIRECTOR - ADMINISTRADOR

            $idUsuario = Auth::user()->id;

            $mensaje = $request->input("mensaje");

            //Validaciones de campo mensaje
            request()->validate([
                'mensaje' => 'required|string|min:1'
            ]);

            $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'");

            if ($existeContrato != null) {
                //Si existe el contrato

                if ( $existeContrato[0]->estatus_estadocontrato == 2 || $existeContrato[0]->estatus_estadocontrato == 4 || $existeContrato[0]->estatus_estadocontrato == 5
                    || $existeContrato[0]->estatus_estadocontrato == 12) {
                    //El contrato tiene estatus  ENTREGADO, ATRASADO, PAGADO, ENVIADO

                    try {
                        //Insertamos valores de peticion y movimiento

                        //Generamos ID alfanumero de identificacion de mensaje y movimiento
                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');

                        //Insertar solicitud de autorizacion
                        DB::table('autorizaciones')->insert([
                            'id_contrato' => $idContrato, 'id_usuarioC' => $idUsuario, 'id_mensaje' => $idHistorialContratoAlfanumerico,
                            'estatus' => '0', 'tipo' => '2', 'created_at' => Carbon::now()
                        ]);

                        //Insertamos el movimiento con su respectivo mensaje de solicitud
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $idUsuario, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(),
                            'cambios' => "Solicitó autorizacion con el siguiente mensaje: '$mensaje'", 'tipomensaje' => '3']);

                        return back()->with('bien', 'Solicitud de Aumentar/Disminuir saldo generada correctamente');

                    } catch (Exception $e) {
                        Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }
                } else {
                    return back()->with('alerta', 'No puedes acceder al contrato debido a su estatus actual.');
                }
            } else {
                return back()->with('alerta', 'Contrato no existente, verifica el ID CONTRATO.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    //Funcion: solicitarautorizacioncambiopaquete
    //Descripcion: Genera la solicitud para actualizar el paquete seleccionado del contrato, almacena en tabla autorizaciones, movimientos con un tipo 2 (aumentar/disminuir)
    public function solicitarautorizacioncambiopaquete($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6 || (Auth::user()->rol_id) == 7)) {
            //ROL DE DIRECTOR - ADMINISTRADOR

            $idUsuario = Auth::user()->id;

            $mensaje = $request->input("mensaje");

            //Validaciones de campo mensaje
            request()->validate([
                'mensaje' => 'required|string|min:1'
            ]);

            $existeContrato = DB::select("SELECT * FROM contratos c WHERE c.id = '$idContrato' AND c.id_franquicia = '$idFranquicia'");

            if ($existeContrato != null) {
                //Si existe el contrato

                if ($existeContrato[0]->estatus_estadocontrato == 0 || $existeContrato[0]->estatus_estadocontrato == 1 || $existeContrato[0]->estatus_estadocontrato == 2
                    || $existeContrato[0]->estatus_estadocontrato == 3 || $existeContrato[0]->estatus_estadocontrato == 4 || $existeContrato[0]->estatus_estadocontrato == 5
                    || $existeContrato[0]->estatus_estadocontrato == 12 ||  $existeContrato[0]->estatus_estadocontrato == 15) {
                    //El contrato tiene estatus NO TERMINADO, TERMINADO, ENTREGADO, PRE-CANCELADO, ATRASADO, PAGADO, ENVIADO, SUPERVISION

                    try {
                        //Insertamos valores de peticion y movimiento

                        //Generamos ID alfanumero de identificacion de mensaje y movimiento
                        $globalesServicioWeb = new globalesServicioWeb;
                        $idHistorialContratoAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('historialcontrato', '5');

                        //Insertar solicitud de autorizacion
                        DB::table('autorizaciones')->insert([
                            'id_contrato' => $idContrato, 'id_usuarioC' => $idUsuario, 'id_mensaje' => $idHistorialContratoAlfanumerico,
                            'estatus' => '0', 'tipo' => '4', 'created_at' => Carbon::now()
                        ]);

                        //Insertamos el movimiento con su respectivo mensaje de solicitud
                        DB::table('historialcontrato')->insert([
                            'id' => $idHistorialContratoAlfanumerico, 'id_usuarioC' => $idUsuario, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(),
                            'cambios' => "Solicitó autorizacion con el siguiente mensaje: '$mensaje'", 'tipomensaje' => '3']);

                        return back()->with('bien', 'Solicitud de cambio de paquete generada correctamente');

                    } catch (Exception $e) {
                        Log::info("Error: " . $e->getMessage());
                        return back()->with('error', 'Tuvimos un error, por favor contacta al administrador de la pagina   Error:' . $e->getMessage());
                    }
                } else {
                    return back()->with('alerta', 'No puedes acceder al contrato debido a su estatus actual.');
                }
            } else {
                return back()->with('alerta', 'Contrato no existente, verifica el ID CONTRATO.');
            }
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

}
