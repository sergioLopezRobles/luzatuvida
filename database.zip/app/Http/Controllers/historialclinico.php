<?php

namespace App\Http\Controllers;

use App\Clases\contratosGlobal;
use App\Clases\globalesServicioWeb;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Image;
use Illuminate\Support\Facades\Validator;

class historialclinico extends Controller
{
    public function nuevohistorialclinico($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || Auth::check() && ((Auth::user()->rol_id) == 6)) {
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $armazones = DB::select("SELECT * FROM producto WHERE  id_tipoproducto = '1' order by nombre");
            //contrato
            $idUsuario = Auth::user()->id;
            $ultimoOptometrista = DB::select("SELECT
                                id_optometrista as ID,  u.name as NAME
                                from contratos c
                                inner join users u on c.id_optometrista = u.id
                                AND c.id_usuariocreacion = '$idUsuario'
                                order by c.created_at desc
                                limit 1");
            $ultimaZona = DB::select("SELECT
            id_zona as ID,  z.zona as zona
            from contratos c
            inner join zonas z on c.id_zona = z.id
            AND c.id_usuariocreacion = '$idUsuario'
            order by c.created_at desc
            limit 1");
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                                FROM users u
                                INNER JOIN usuariosfranquicia uf
                                ON uf.id_usuario = u.id
                                WHERE uf.id_franquicia = '$idFranquicia'
                                AND u.rol_id = 12");
            $usuaricontrato = DB::select("SELECT COUNT(id) as prueba FROM contratos WHERE id_usuariocreacion = '$idUsuario' AND estatus_estadocontrato = 0");
            $contratohoypromo = DB::select("SELECT id FROM contratos WHERE id_usuariocreacion = '$idUsuario' AND id_promocion >= 1 AND ifnull(promocionterminada,0) < 1");
            if ($contratohoypromo != null) {
                $contratohoypromoid = $contratohoypromo[0]->id;
            }
            if (Auth::user()->rol_id == 13 && $usuaricontrato[0]->prueba > 0 || Auth::user()->rol_id == 12 && $usuaricontrato[0]->prueba > 0) {
                return redirect()->route('listacontrato', $idFranquicia)->with('alerta', 'Necesitas terminar/cancelar los contratos pendientes para continuar.');
            }
            if ((((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12)) && $contratohoypromo != null) {
                return redirect()->route('listacontrato', $idFranquicia)->with('alerta', 'Revisar el contrato con promoción aun no esta completado ' . $contratohoypromoid);
            }

            return view('administracion.historialclinico.nuevo', ['idFranquicia' => $idFranquicia, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'armazones' => $armazones,
                'ultimoOptometrista' => $ultimoOptometrista, 'ultimaZona' => $ultimaZona, 'zonas' => $zonas]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function nuevohijo($idFranquicia)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || Auth::check() && ((Auth::user()->rol_id) == 6)) {
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $armazones = DB::select("SELECT * FROM producto WHERE  id_tipoproducto = '1' order by nombre");
            //contrato
            $idUsuario = Auth::user()->id;
            $ultimoOptometrista = DB::select("SELECT
                            id_optometrista as ID,  u.name as NAME
                            from contratos c
                            inner join users u on c.id_optometrista = u.id
                            AND c.id_usuariocreacion = '$idUsuario'
                            order by c.created_at desc
                            limit 1");
            $ultimaZona = DB::select("SELECT
        id_zona as ID,  z.zona as zona
        from contratos c
        inner join zonas z on c.id_zona = z.id
        AND c.id_usuariocreacion = '$idUsuario'
        order by c.created_at desc
        limit 1");
            $zonas = DB::select("SELECT id as ID, zona as zona FROM zonas where id_franquicia = '$idFranquicia'");
            $optometristas = DB::select("SELECT u.ID,u.NAME
                            FROM users u
                            INNER JOIN usuariosfranquicia uf
                            ON uf.id_usuario = u.id
                            WHERE uf.id_franquicia = '$idFranquicia'
                            AND u.rol_id = 12");

            return view('administracion.historialclinico.nuevo', ['idFranquicia' => $idFranquicia, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'armazones' => $armazones,
                'ultimoOptometrista' => $ultimoOptometrista, 'ultimaZona' => $ultimaZona, 'zonas' => $zonas]);
        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }


    public function nuevohistorialclinico2($idFranquicia, $idContrato)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || Auth::check() && ((Auth::user()->rol_id) == 6)) {
            $optometristas = DB::select("SELECT u.id,u.name
                                    FROM users u
                                    INNER JOIN usuariosfranquicia uf
                                    ON u.id = uf.id_usuario
                                    WHERE u.rol_id = 12
                                    AND uf.id_franquicia = '$idFranquicia' ");
            $datosContrato = DB::select("SELECT * FROM contratos WHERE id = '$idContrato'");
            $hc2 = DB::select("SELECT COUNT(id) as canti FROM historialclinico WHERE id_contrato = '$idContrato'");
            $historialC = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.otroM, h.molestiaotro, h.ultimoexamen, p.nombre
        FROM historialclinico h
        INNER JOIN paquetes p
        ON p.id = h.id_paquete
        WHERE id_contrato = '$idContrato'");
            $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
            $armazones = DB::select("SELECT * FROM producto WHERE id_tipoproducto = '1' order by nombre");
            $cont = $hc2[0]->canti;

            if ($cont == 2) {
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('alerta', 'Llenar los historiales clinicos correctamente.');
            }

            return view('administracion.historialclinico.nuevo2', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato, 'optometristas' => $optometristas, 'paquetes' => $paquetes, 'fotocromatico' => $fotocromatico,
                'AR' => $AR, 'tinte' => $tinte, 'blueray' => $blueray, 'datosContrato' => $datosContrato, 'armazones' => $armazones, 'historialC' => $historialC]);

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarhistorial($idFranquicia, $idContrato, $idHistorial)
    {

        $datosHistorial = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.otroM, h.molestiaotro, h.ultimoexamen, p.nombre, pr.nombre as nombre2, h.id_contrato, h.fechaentrega,
        h.esfericoder, h.cilindroder, h.ejeder, h.addder, h.altder, h.esfericoizq, h.cilindroizq, h.ejeizq, h.addizq, h.altizq, h.material, h.materialotro, h.costomaterial,
        h.bifocal, h.fotocromatico, h.ar, h.tinte, h.blueray, h.otroT, h.tratamientootro, h.costotratamiento, h.observaciones,h.observacionesinterno
        FROM historialclinico h
        INNER JOIN paquetes p
        ON p.id = h.id_paquete
        INNER JOIN producto pr
        ON pr.id = h.id_producto
        WHERE h.id = '$idHistorial' AND h.id_contrato = '$idContrato'");
        $fotocromatico = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
        $AR = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
        $tinte = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
        $blueray = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");

        return view('administracion.historialclinico.actualizarhistorial', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato,
            'idHistorial' => $idHistorial, 'datosHistorial' => $datosHistorial, 'fotocromatico' => $fotocromatico,
            'ar' => $AR, 'tinte' => $tinte, 'blueray' => $blueray]);
    }

    private function getContratoId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom();
            $existente = DB::select("select id from contratos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }


    private function generadorRandom($length = 10)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    private function getHistorialId5()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom5();
            $existente = DB::select("select id from contratos where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    private function getHistorialId2()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom5();
            $existente = DB::select("select id from historialclinico where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    private function getContratoHistorialId()
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = $this->generadorRandom5();
            $existente = DB::select("select id from historialcontrato where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }

    private function generadorRandom5($length = 5)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    // Generador random

    public function crearhistorialclinico($idFranquicia, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || Auth::check() && ((Auth::user()->rol_id) == 6)) {
            $idContrato = request('idcontrato');
            $idcontratopadre = request('idcontratopadre');
            if ($idcontratopadre != null) {
                $contratovalido = DB::select(" SELECT co.id,pro.armazones,(select count(id) from contratos where idcontratorelacion = '$idcontratopadre') as totalhijos
            from contratos co
            inner join promocion pro
            on pro.id = co.id_promocion
            where co.id = '$idcontratopadre';");
                if ($contratovalido != null) {
                    if (($contratovalido[0]->totalhijos + 1) < $contratovalido[0]->armazones) {
                        $rules2 = [

                            'nombre' => 'required|string|max:255',
                            'telefono' => 'required|string|size:10|regex:/[0-9]/',
                            // 'fotoine'=>'required|image|mimes:jpg',
                            // 'fotoineatras'=>'required|image|mimes:jpg',
                            // 'fotocasa'=>'required|image|mimes:jpg',
                            // 'comprobantedomicilio'=>'required|image|mimes:jpg',
                            'edad' => 'required|string|max:255',
                            'diagnostico' => 'required|string|max:255',
                            'ocupacion' => 'required|string|max:255',
                            'diabetes' => 'required|string|max:255',
                            'hipertension' => 'required|string|max:255',
                            'paquete' => 'required|integer',
                            'producto' => 'required|string|max:255',
                            'ultimoexamen' => 'nullable|date',
                            'correo' => 'nullable|email',
                            'fechaentrega' => 'required|date'

                        ];
                        if (request('material') != '3' && request('motro') != null && request('costomaterial') != null) {
                            return back()->withErrors(['motro' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                        }
                        if (request('material') == '3' && request('motro') == null && request('costomaterial') == null) {
                            return back()->withErrors(['motro' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                        }
                        if (request('material') == '3' && request('motro') == null && request('costomaterial') != null) {
                            return back()->withErrors(['motro' => 'Llenar ambos campos para otro'])->withInput($request->all());
                        }
                        if (request('material') == '3' && request('motro') != null && request('costomaterial') == null) {
                            return back()->withErrors(['motro' => 'Llenar ambos campos para otro'])->withInput($request->all());
                        }
                        if (request('molestia') != null && request('otroM') == null) {
                            return back()->withErrors(['molestia' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                        }
                        if (request('otroTra') != null && request('otroT') == null && request('costoT') == null) {
                            return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                        }
                        if (request('otroTra') != null && request('otroT') != null && request('costoT') == null) {
                            return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                        }
                        if (request('otroTra') != null && request('otroT') == null && request('costoT') != null) {
                            return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
                        }
                        if (request('otroTra') == null && request('otroT') != null && request('costoT') != null) {
                            return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
                        }
                        if (request('otroTra') == null && request('otroT') != null && request('costoT') == null) {
                            return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                        }
                        if (request('otroTra') == null && request('otroT') == null && request('costoT') != null) {
                            return back()->withErrors(['costoT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
                        }
                        if (request('dolor') == null && request('ardor') == null && request('golpe') == null && request('molestia') == null && request('otroM') == null) {
                            return back()->withErrors(['molestia' => 'Elegir al menos una molestia'])->withInput($request->all());
                        }
                        if (request('fotocromatico') == null && request('ar') == null && request('tinte') == null && request('blueray') == null && request('otroTra') == null) {
                            return back()->withErrors(['fotocromatico' => 'Elegir al menos una molestia'])->withInput($request->all());
                        }
                        if (request('paquete') == 0) {
                            return back()->withErrors(['paquete' => 'Campo obligatorio'])->withInput($request->all());
                        }
                        if (request('producto') == 'nada') {
                            return back()->withErrors(['producto' => 'Campo obligatorio'])->withInput($request->all());
                        }
                        if (request('tinte') == 1 && request('paquete') == 1) {
                            return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete'])->withInput($request->all());
                        }
                        if (request('tinte') == 1 && request('paquete') == 2) {
                            return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete'])->withInput($request->all());
                        }
                        if (request('zona') == 'Seleccionar') {
                            return back()->withErrors(['zona' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
                        }
                        if (request('optometrista') == 'Seleccionar') {
                            return back()->withErrors(['optometrista' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
                        }
                        if (request('telefono') == null && request('correo') == null) {
                            return back()->withErrors(['correo' => 'Ingresar algun correo o el telefono del cliente'])->withInput($request->all());
                        }
                        if (request('ar') != null && request('blueray') != null) {
                            return back()->withErrors(['ar' => 'Solo se puede elegir uno entre AR y BlueRay'])->withInput($request->all());
                        }
                        if (request('paquete') == 1) {
                            if (request('fotocromatico') != null && request('ar') != null || request('blueray') != null || request('otroTra') != null) {
                                $n = 0;
                                if (request('fotocromatico') == 1) {

                                    $n = $n + 1;
                                }
                                if (request('ar') == 1) {

                                    $n = $n + 1;
                                }
                                if (request('blueray') == 1) {

                                    $n = $n + 1;
                                }
                                if (request('otroTra') == 1) {
                                    $n = $n + 1;
                                }

                                if ($n > 1) {

                                    return back()->withErrors(['fotocromatico' => 'Solo se permite un tratamiento con el paquete de lectura'])->withInput($request->all());
                                }
                            }
                        }
                        request()->validate($rules2);
                        if (request('principal') == null) {
                            $validacion = Validator::make($request->all(), [
                                'fotoine' => 'required|image',
                                'fotoineatras' => 'required|image',
                                'fotocasa' => 'required|image',
                                'comprobantedomicilio' => 'required|image'
                            ]);


                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'fotoine' => 'Campo requerido',
                                    'fotoineatras' => 'Campo requerido',
                                    'fotocasa' => 'Campo requerido',
                                    'comprobantedomicilio' => 'Campo requerido'
                                ])->withInput($request->all());
                            }
                        }


                        if (request('paquete') == 1) {
                            $validacion = Validator::make($request->all(), [
                                'esfericod' => 'required|string',
                                'cilindrod' => 'required|string',
                                'ejed' => 'required|string',
                                'altd' => 'required|string',
                                'esfericod2' => 'required|string',
                                'cilindrod2' => 'required|string',
                                'ejed2' => 'required|string',
                                'altd2' => 'required|string',

                            ]);
                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'esfericod' => 'Campo requerido para LECTURA',
                                    'cilindrod' => 'Campo requerido para LECTURA',
                                    'ejed' => 'Campo requerido para LECTURA',
                                    'altd' => 'Campo requerido para LECTURA',
                                    'esfericod2' => 'Campo requerido para LECTURA',
                                    'cilindrod2' => 'Campo requerido para LECTURA',
                                    'ejed2' => 'Campo requerido para LECTURA',
                                    'altd2' => 'Campo requerido para LECTURA',
                                ])->withInput($request->all());
                            }


                        }
                        if (request('paquete') == 3) {
                            $validacion = Validator::make($request->all(), [
                                'esfericod' => 'required|string',
                                'cilindrod' => 'required|string',
                                'ejed' => 'required|string',
                                'esfericod2' => 'required|string',
                                'cilindrod2' => 'required|string',
                                'ejed2' => 'required|string',

                            ]);
                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'esfericod' => 'Campo requerido para ECO JR',
                                    'cilindrod' => 'Campo requerido para ECO JR',
                                    'ejed' => 'Campo requerido para ECO JR',
                                    'esfericod2' => 'Campo requerido para ECO JR',
                                    'cilindrod2' => 'Campo requerido para ECO JR',
                                    'ejed2' => 'Campo requerido para ECO JR',
                                ])->withInput($request->all());
                            }
                        }

                        if (request('paquete') == 4) {
                            $validacion = Validator::make($request->all(), [
                                'esfericod' => 'required|string',
                                'cilindrod' => 'required|string',
                                'ejed' => 'required|string',
                                'esfericod2' => 'required|string',
                                'cilindrod2' => 'required|string',
                                'ejed2' => 'required|string',


                            ]);
                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'esfericod' => 'Campo requerido para JR',
                                    'cilindrod' => 'Campo requerido para JR',
                                    'ejed' => 'Campo requerido para JR',
                                    'esfericod2' => 'Campo requerido para JR',
                                    'cilindrod2' => 'Campo requerido para JR',
                                    'ejed2' => 'Campo requerido para JR',
                                ])->withInput($request->all());
                            }
                        }
                        if (request('paquete') == 5) {
                            $validacion = Validator::make($request->all(), [
                                'esfericod' => 'required|string',
                                'cilindrod' => 'required|string',
                                'ejed' => 'required|string',
                                'addd' => 'required|string',
                                'altd' => 'required|string',
                                'esfericod2' => 'required|string',
                                'cilindrod2' => 'required|string',
                                'ejed2' => 'required|string',
                                'addd2' => 'required|string',
                                'altd2' => 'required|string',

                            ]);
                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'esfericod' => 'Campo requerido para DORADO 1',
                                    'cilindrod' => 'Campo requerido para DORADO 1',
                                    'ejed' => 'Campo requerido para DORADO 1',
                                    'addd' => 'required|string',
                                    'altd' => 'Campo requerido para DORADO 1',
                                    'esfericod2' => 'Campo requerido para DORADO 1',
                                    'cilindrod2' => 'Campo requerido para DORADO 1',
                                    'ejed2' => 'Campo requerido para DORADO 1',
                                    'addd2' => 'required|string',
                                    'altd2' => 'Campo requerido para DORADO 1',
                                ])->withInput($request->all());
                            }
                        }
                        if (request('paquete') == 6) {
                            $validacion = Validator::make($request->all(), [
                                'esfericod' => 'required|string',
                                'cilindrod' => 'required|string',
                                'ejed' => 'required|string',
                                'esfericod2' => 'required|string',
                                'cilindrod2' => 'required|string',
                                'ejed2' => 'required|string',

                            ]);
                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'esfericod' => 'Campo requerido para DORADO2',
                                    'cilindrod' => 'Campo requerido para DORADO2',
                                    'ejed' => 'Campo requerido para DORADO2',
                                    'esfericod2' => 'Campo requerido para DORADO2',
                                    'cilindrod2' => 'Campo requerido para DORADO2',
                                    'ejed2' => 'Campo requerido para DORADO2',

                                ])->withInput($request->all());
                            }
                        }
                        if (request('paquete') == 7) {
                            $validacion = Validator::make($request->all(), [
                                'esfericod' => 'required|string',
                                'cilindrod' => 'required|string',
                                'ejed' => 'required|string',
                                'addd' => 'required|string',
                                'altd' => 'required|string',
                                'esfericod2' => 'required|string',
                                'cilindrod2' => 'required|string',
                                'ejed2' => 'required|string',
                                'addd2' => 'required|string',
                                'altd2' => 'required|string',

                            ]);
                            if ($validacion->fails()) {
                                return back()->withErrors([
                                    'esfericod' => 'Campo requerido para PLATINO',
                                    'cilindrod' => 'Campo requerido para PLATINO',
                                    'ejed' => 'Campo requerido para PLATINO',
                                    'addd' => 'Campo requerido para PLATINO',
                                    'altd' => 'Campo requerido para PLATINO',
                                    'esfericod2' => 'Campo requerido para PLATINO',
                                    'cilindrod2' => 'Campo requerido para PLATINO',
                                    'ejed2' => 'Campo requerido para PLATINO',
                                    'addd2' => 'Campo requerido para PLATINO',
                                    'altd2' => 'Campo requerido para PLATINO',
                                ])->withInput($request->all());
                            }


                        }

                        try {
                            // contrato 2
                            $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                            $randomId = $this->getContratoId();
                            $randomIdH = $this->getHistorialId5();

                            $fotoine = "";


                            if (request('principal') == null) {

                                $fotoBruta = 'Foto-Ine-Frente-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                                $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');

                                $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->height();
                                $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->width();
                                if ($alto > $ancho) {
                                    $imagenfotoine = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->resize(600, 800);
                                } else {
                                    $imagenfotoine = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->resize(800, 600);
                                }
                                $imagenfotoine->save();


                                $fotoBruta2 = 'Foto-Ine-Atras-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                                $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta2, 'disco');
                                $alto2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->height();
                                $ancho2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->width();
                                if ($alto2 > $ancho2) {
                                    $imagenfotoineatras = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->resize(600, 800);
                                } else {
                                    $imagenfotoineatras = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->resize(800, 600);
                                }
                                $imagenfotoineatras->save();

                                $fotoBruta3 = 'Foto-Casa-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                                $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta3, 'disco');
                                $alto3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->height();
                                $ancho3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->width();
                                if ($alto3 > $ancho3) {
                                    $imagenfotocasa = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->resize(600, 800);
                                } else {
                                    $imagenfotocasa = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->resize(800, 600);
                                }
                                $imagenfotocasa->save();

                                $fotoBruta5 = 'Foto-Pagare-Contrato-' . $randomId . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                                $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta5, 'disco');
                                $alto5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->height();
                                $ancho5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->width();
                                if ($alto5 > $ancho5) {
                                    $imagenfotopagare = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->resize(600, 800);
                                } else {
                                    $imagenfotopagare = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->resize(800, 600);
                                }
                                $imagenfotopagare->save();

                                $fotoBruta4 = 'Foto-comprobantedomicilio-Contrato-' . $randomId . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                                $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedomicilio', $fotoBruta4, 'disco');
                                $alto4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->height();
                                $ancho4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->width();
                                if ($alto4 > $ancho4) {
                                    $imagencomprobantedomicilio = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->resize(600, 800);
                                } else {
                                    $imagencomprobantedomicilio = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->resize(800, 600);
                                }
                                $imagencomprobantedomicilio->save();
                            }


                            $datos = 1;
                            $creacion = Carbon::now();
                            $usuarioId = Auth::user()->id;
                            $usuarioNombre = Auth::user()->name;


                            $contra = DB::select("SELECT c.id,c.datos,c.id_franquicia,c.id_usuariocreacion,c.nombre_usuariocreacion,z.zona,c.nombre,c.calle,c.numero, c.pago, u.name, pr.titulo, c.telefonoreferencia, c.nombrereferencia, c.correo,
                    c.depto,c.alladode,c.frentea,c.entrecalles,c.colonia,c.localidad,c.telefono,c.casatipo,c.casacolor,c.created_at,c.updated_at,c.id_optometrista, c.id_promocion, c.contador, c.fotoine, c.fotoineatras, c.fotocasa, c.pagare, c.comprobantedomicilio,
                    (SELECT COUNT(id) from promocioncontrato pc where pc.id_contrato = c.id) as promo
                    FROM contratos c
                    INNER JOIN zonas z
                    ON z.id = c.id_zona
                    INNER JOIN users u
                    ON u.id = c.id_optometrista
                    INNER JOIN promocion pr
                    ON pr.id = c.id_promocion
                    WHERE c.datos = 1
                    AND c.id = '$idcontratopadre'
                    AND c.id_franquicia = '$idFranquicia'");
                            $zona = $contra[0]->zona;
                            $optometrista = $contra[0]->id_optometrista;
                            $calle = $contra[0]->calle;
                            $pago = $contra[0]->pago;
                            $numero = $contra[0]->numero;
                            $depto = $contra[0]->depto;
                            $alladode = $contra[0]->alladode;
                            $frentea = $contra[0]->frentea;
                            $entrecalles = $contra[0]->entrecalles;
                            $colonia = $contra[0]->colonia;
                            $localidad = $contra[0]->localidad;
                            $casatipo = $contra[0]->casatipo;
                            $casacolor = $contra[0]->casacolor;
                            $contador = $contra[0]->contador;
                            $telefonoR = $contra[0]->telefonoreferencia;
                            $nombreR = $contra[0]->nombrereferencia;
                            $correo = $contra[0]->correo;
                            $suma = $contador + 1;

                            if (request('principal') == 1) {
                                $fotoine = $contra[0]->fotoine;
                                $fotoineatras = $contra[0]->fotoineatras;
                                $fotocasa = $contra[0]->fotocasa;
                                $comprobantedomicilio = $contra[0]->comprobantedomicilio;
                                $fotopagare = $contra[0]->pagare;
                            }

                            $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                            $randomId = $this->getContratoId();
                            $datos = 1;
                            $creacion = Carbon::now();
                            $usuarioId = Auth::user()->id;
                            $usuarioNombre = Auth::user()->name;

                            DB::table('contratos')->insert([
                                'id' => $randomId, 'datos' => $datos, 'id_franquicia' => $idFranquicia, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => $zona, 'id_optometrista' => $optometrista,
                                'nombre' => request('nombre'), 'pago' => $pago, 'calle' => $calle, 'numero' => $numero, 'depto' => $depto, 'alladode' => $alladode, 'frentea' => $frentea,
                                'entrecalles' => $entrecalles, 'colonia' => $colonia, 'localidad' => $localidad, 'telefono' => request('telefono'), 'casatipo' => $casatipo, 'casacolor' => $casacolor, 'created_at' => $creacion,
                                'idcontratorelacion' => $idcontratopadre, 'nombrereferencia' => $nombreR, 'telefonoreferencia' => $telefonoR, 'correo' => $correo, 'estatus_estadocontrato' => 0,
                                'fotoine' => $fotoine, 'fotocasa' => $fotocasa, 'comprobantedomicilio' => $comprobantedomicilio, 'fotoineatras' => $fotoineatras, 'pagare' => $fotopagare, 'poliza' => null, 'totalpromocion' => 0
                            ]);

                            DB::table('contratos')->where([['id', '=', $idcontratopadre], ['id_franquicia', '=', $idFranquicia]])->update([
                                'contador' => $suma
                            ]);

                            //historial clinico
                            $fotocromatico2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
                            $AR2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
                            $tinte2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
                            $blueray2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
                            $dolor = request('dolor') != Null;
                            $ardor = request('ardor') != Null;
                            $golpe = request('golpe') != Null;
                            $otroM = request('otroM') != Null;
                            $otroTra = request('otroTra') != Null;
                            $fotocromatico = request('fotocromatico');
                            $ar = request('ar');
                            $tinte = request('tinte');
                            $blueray = request('blueray');
                            $otromaterial = request('costomaterial');
                            $otrotratamiento = request('costoT');
                            if ($tinte != null) {
                                $tinte = 1;
                                $tinte5 = $tinte2[0]->precio;
                                $fotocromatico = null;
                                $ar = null;
                                $blueray = null;
                            } else {
                                $tinte = null;
                                $tinte5 = 0;
                            }
                            if ($fotocromatico != null) {
                                $fotocromatico5 = $fotocromatico2[0]->precio;
                                $fotocromatico = 1;
                            } else {
                                $fotocromatico = null;
                                $fotocromatico5 = 0;
                            }
                            if ($ar != null) {
                                $ar5 = $AR2[0]->precio;
                                $ar = 1;
                            } else {
                                $ar = null;
                                $ar5 = 0;
                            }
                            if ($blueray != null) {
                                $blueray5 = $blueray2[0]->precio;
                                $blueray = 1;
                            } else {
                                $blueray = null;
                                $blueray5 = 0;
                            }
                            $totalidad = "";
                            if ($tinte != null && request('paquete') > 2) {
                                $totalidad = $tinte5 + $otromaterial + $otrotratamiento;
                            } else {
                                if (request('paquete') == 2) {
                                    $totalidad = $ar5 + $blueray5 + $otromaterial + $otrotratamiento;
                                } else {
                                    $totalidad = $fotocromatico5 + $ar5 + $blueray5 + $otromaterial + $otrotratamiento;
                                }
                            }


                            $historial = DB::select("SHOW TABLE STATUS LIKE 'historialclinico'");
                            $siguienteId = $historial[0]->Auto_increment;
                            $idContrato = $randomId;
                            $value = request('paquete');
                            $value2 = request('producto');
                            $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia' and id = '$value'");
                            $con = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' and id = '$idContrato'");
                            $armazon = DB::select("SELECT * FROM producto WHERE  id = '$value2' AND id_tipoproducto = '1'");
                            $arma = $armazon[0]->id;
                            $armapz = $armazon[0]->piezas - 1;
                            $hijo = $con[0]->idcontratorelacion;
                            $val = $con[0]->totalhistorial;
                            $valor = $paquetes[0]->precio;
                            $total = $valor + $val + $totalidad;

                            if ($value == 1) {
                                if (request('cilindrod') != 0 || request('cilindrod2') != 0) {
                                    $total = $total + 590;
                                }
                            }

                            if ($hijo == null) {
                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'totalhistorial' => $total, 'total' => $total, 'totalreal' => $total
                                ]);
                            } else {
                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                    'totalhistorial' => $total, 'estatus' => 0, 'estatus_estadocontrato' => 0, 'total' => $total, 'totalreal' => $total
                                ]);
                                //Insertar en tabla registroestadocontrato
                                DB::table('registroestadocontrato')->insert([
                                    'id_contrato' => $idContrato,
                                    'estatuscontrato' => 0,
                                    'created_at' => Carbon::now()
                                ]);
                            }
                            DB::table('producto')->where([['id', '=', $arma], ['id_franquicia', '=', $idFranquicia]])->update([
                                'piezas' => $armapz
                            ]);

                            if (request('paquete') == 6) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'addder' => request('addd'), 'altder' => request('altd'),
                                    'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'), 'addizq' => request('addd2'), 'altizq' => request('altd2'), 'altizq' => request('altd2'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);
                                return redirect()->route('nuevohistorialclinico2', ['id' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');
                            } elseif (request('paquete') == 1) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);
                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                            } elseif (request('paquete') == 2) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => 0, 'ar' => $ar, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);
                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                            } elseif (request('paquete') == 3) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);
                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                            } elseif (request('paquete') == 4) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);
                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                            } elseif (request('paquete') == 5) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'addder' => request('addd'), 'altder' => request('altd'),
                                    'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'), 'addizq' => request('addd2'), 'altizq' => request('altd2'), 'altizq' => request('altd2'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);
                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                            } elseif (request('paquete') == 7) {
                                DB::table('historialclinico')->insert([
                                    'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                                    'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                                ]);

                                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato, 'idcontratopadre' => $idContratoPadre])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');
                            }
                        } catch (\Exception $e) {
                            \Log::info("Error: " . $e);
                            return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
                        }

                    } else {
                        if (Auth::check()) {
                            return redirect()->route('redireccionar');
                        } else {
                            return redirect()->route('login');
                        }

                    }
                }
            }
// Sino detecta un contrato padre entonces sera un contrato nuevo sin dependencias
            //PRIMER CONTRATO
            //  return;
            try{
                $rules = [
                    'zona' => 'required',
                    'nombre' => 'required|string|max:255',
                    'optometrista' => 'required|integer',
                    'calle' => 'required|string|max:255',
                    'numero' => 'required|string|min:1|max:255',
                    'departamento' => 'required|string|max:255',
                    'alladode' => 'required|string|max:255',
                    'frentea' => 'required|string|max:255',
                    'entrecalles' => 'required|string|max:255',
                    'colonia' => 'required|string|max:255',
                    'localidad' => 'required|string|max:255',
                    'telefono' => 'required|string|size:10|regex:/[0-9]/',
                    'tr' => 'required|string|size:10|regex:/[0-9]/',
                    'casatipo' => 'required|string|max:255',
                    'nr' => 'required|string|max:255',
                    'casacolor' => 'required|string|max:255',
                    'fotoine' => 'required|image',
                    'fotoineatras' => 'required|image',
                    'fotocasa' => 'required|image',
                    'pagare' => 'required|image',
                    'comprobantedomicilio' => 'required|image',
                    'edad' => 'required|string|max:255',
                    'diagnostico' => 'required|string|max:255',
                    'ocupacion' => 'required|string|max:255',
                    'diabetes' => 'required|string|max:255',
                    'hipertension' => 'required|string|max:255',
                    'paquete' => 'required|integer',
                    'producto' => 'required|string|max:255',
                    'ultimoexamen' => 'nullable|date',
                    'correo' => 'nullable|email',
                    'fechaentrega' => 'required|date'
                ];

                if (request('zona') == 'Seleccionar') {
                    return back()->withErrors(['zona' => 'Elige una zona, campo obligatorio'])->withInput($request->all());
                }
                if (request('optometrista') == 'Seleccionar') {
                    return back()->withErrors(['optometrista' => 'Elige un optometrista, campo obligatorio'])->withInput($request->all());
                }
                if (request('material') != '3' && request('motro') != null && request('costomaterial') != null) {
                    return back()->withErrors(['motro' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                }
                if (request('material') == '3' && request('motro') == null && request('costomaterial') == null) {
                    return back()->withErrors(['motro' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                }
                if (request('material') == '3' && request('motro') == null && request('costomaterial') != null) {
                    return back()->withErrors(['motro' => 'Llenar ambos campos para otro'])->withInput($request->all());
                }
                if (request('material') == '3' && request('motro') != null && request('costomaterial') == null) {
                    return back()->withErrors(['motro' => 'Llenar ambos campos para otro'])->withInput($request->all());
                }
                if (request('molestia') != null && request('otroM') == null) {
                    return back()->withErrors(['molestia' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                }
                if (request('otroTra') != null && request('otroT') == null && request('costoT') == null) {
                    return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                }
                if (request('otroTra') != null && request('otroT') != null && request('costoT') == null) {
                    return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                }
                if (request('otroTra') != null && request('otroT') == null && request('costoT') != null) {
                    return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
                }
                if (request('otroTra') == null && request('otroT') != null && request('costoT') != null) {
                    return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
                }
                if (request('otroTra') == null && request('otroT') != null && request('costoT') == null) {
                    return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
                }
                if (request('otroTra') == null && request('otroT') == null && request('costoT') != null) {
                    return back()->withErrors(['costoT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
                }
                if (request('dolor') == null && request('ardor') == null && request('golpe') == null && request('molestia') == null && request('otroM') == null) {
                    return back()->withErrors(['dolor' => 'Elegir al menos una molestia'])->withInput($request->all());
                }
                if (request('fotocromatico') == null && request('ar') == null && request('tinte') == null && request('blueray') == null && request('otroTra') == null) {
                    return back()->withErrors(['fotocromatico' => 'Elegir al menos una molestia'])->withInput($request->all());
                }
                if (request('paquete') == 0) {
                    return back()->withErrors(['paquete' => 'Campo obligatorio'])->withInput($request->all());
                }
                if (request('producto') == 'nada') {
                    return back()->withErrors(['producto' => 'Campo obligatorio'])->withInput($request->all());
                }
                if (request('tinte') == 1 && request('paquete') == 1) {
                    return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete'])->withInput($request->all());
                }
                if (request('tinte') == 1 && request('paquete') == 2) {
                    return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete'])->withInput($request->all());
                }
                if (request('telefono') == null && request('correo') == null) {
                    return back()->withErrors(['correo' => 'Ingresar algun correo o el telefono del cliente'])->withInput($request->all());
                }
                if (request('ar') != null && request('blueray') != null) {
                    return back()->withErrors(['ar' => 'Solo se puede elegir uno entre AR y BlueRay'])->withInput($request->all());
                }
                if (request('paquete') == 1) {
                    if (request('fotocromatico') != null && request('ar') != null || request('blueray') != null || request('otroTra') != null) {
                        $n = 0;
                        if (request('fotocromatico') == 1) {

                            $n = $n + 1;
                        }
                        if (request('ar') == 1) {

                            $n = $n + 1;
                        }
                        if (request('blueray') == 1) {

                            $n = $n + 1;
                        }
                        if (request('otroTra') == 1) {
                            $n = $n + 1;
                        }

                        if ($n > 1) {

                            return back()->withErrors(['fotocromatico' => 'Solo se permite uno con el paquete de lectura'])->withInput($request->all());
                        }
                    }
                }
                request()->validate($rules);


                if (request('paquete') == 1) {
                    $validacion = Validator::make($request->all(), [
                        'esfericod' => 'required|string',
                        'cilindrod' => 'required|string',
                        'ejed' => 'required|string',
                        'altd' => 'required|string',
                        'esfericod2' => 'required|string',
                        'cilindrod2' => 'required|string',
                        'ejed2' => 'required|string',
                        'altd2' => 'required|string',

                    ]);
                    if ($validacion->fails()) {
                        return back()->withErrors([
                            'esfericod' => 'Campo requerido para LECTURA',
                            'cilindrod' => 'Campo requerido para LECTURA',
                            'ejed' => 'Campo requerido para LECTURA',
                            'altd' => 'Campo requerido para LECTURA',
                            'esfericod2' => 'Campo requerido para LECTURA',
                            'cilindrod2' => 'Campo requerido para LECTURA',
                            'ejed2' => 'Campo requerido para LECTURA',
                            'altd2' => 'Campo requerido para LECTURA',
                        ])->withInput($request->all());
                    }


                }
                if (request('paquete') == 3) {
                    $validacion = Validator::make($request->all(), [
                        'esfericod' => 'required|string',
                        'cilindrod' => 'required|string',
                        'ejed' => 'required|string',
                        'esfericod2' => 'required|string',
                        'cilindrod2' => 'required|string',
                        'ejed2' => 'required|string',

                    ]);
                    if ($validacion->fails()) {
                        return back()->withErrors([
                            'esfericod' => 'Campo requerido para ECO JR',
                            'cilindrod' => 'Campo requerido para ECO JR',
                            'ejed' => 'Campo requerido para ECO JR',
                            'esfericod2' => 'Campo requerido para ECO JR',
                            'cilindrod2' => 'Campo requerido para ECO JR',
                            'ejed2' => 'Campo requerido para ECO JR',
                        ])->withInput($request->all());
                    }
                }

                if (request('paquete') == 4) {
                    $validacion = Validator::make($request->all(), [
                        'esfericod' => 'required|string',
                        'cilindrod' => 'required|string',
                        'ejed' => 'required|string',
                        'esfericod2' => 'required|string',
                        'cilindrod2' => 'required|string',
                        'ejed2' => 'required|string',


                    ]);
                    if ($validacion->fails()) {
                        return back()->withErrors([
                            'esfericod' => 'Campo requerido para JR',
                            'cilindrod' => 'Campo requerido para JR',
                            'ejed' => 'Campo requerido para JR',
                            'esfericod2' => 'Campo requerido para JR',
                            'cilindrod2' => 'Campo requerido para JR',
                            'ejed2' => 'Campo requerido para JR',
                        ])->withInput($request->all());
                    }
                }
                if (request('paquete') == 5) {
                    $validacion = Validator::make($request->all(), [
                        'esfericod' => 'required|string',
                        'cilindrod' => 'required|string',
                        'ejed' => 'required|string',
                        'addd' => 'required|string',
                        'altd' => 'required|string',
                        'esfericod2' => 'required|string',
                        'cilindrod2' => 'required|string',
                        'ejed2' => 'required|string',
                        'addd2' => 'required|string',
                        'altd2' => 'required|string',

                    ]);
                    if ($validacion->fails()) {
                        return back()->withErrors([
                            'esfericod' => 'Campo requerido para DORADO 1',
                            'cilindrod' => 'Campo requerido para DORADO 1',
                            'ejed' => 'Campo requerido para DORADO 1',
                            'addd' => 'required|string',
                            'altd' => 'Campo requerido para DORADO 1',
                            'esfericod2' => 'Campo requerido para DORADO 1',
                            'cilindrod2' => 'Campo requerido para DORADO 1',
                            'ejed2' => 'Campo requerido para DORADO 1',
                            'addd2' => 'required|string',
                            'altd2' => 'Campo requerido para DORADO 1',
                        ])->withInput($request->all());
                    }
                }
                if (request('paquete') == 6) {
                    $validacion = Validator::make($request->all(), [
                        'esfericod' => 'required|string',
                        'cilindrod' => 'required|string',
                        'ejed' => 'required|string',
                        'esfericod2' => 'required|string',
                        'cilindrod2' => 'required|string',
                        'ejed2' => 'required|string',

                    ]);
                    if ($validacion->fails()) {
                        return back()->withErrors([
                            'esfericod' => 'Campo requerido para DORADO2',
                            'cilindrod' => 'Campo requerido para DORADO2',
                            'ejed' => 'Campo requerido para DORADO2',
                            'esfericod2' => 'Campo requerido para DORADO2',
                            'cilindrod2' => 'Campo requerido para DORADO2',
                            'ejed2' => 'Campo requerido para DORADO2',

                        ])->withInput($request->all());
                    }
                }
                if (request('paquete') == 7) {
                    $validacion = Validator::make($request->all(), [
                        'esfericod' => 'required|string',
                        'cilindrod' => 'required|string',
                        'ejed' => 'required|string',
                        'addd' => 'required|string',
                        'altd' => 'required|string',
                        'esfericod2' => 'required|string',
                        'cilindrod2' => 'required|string',
                        'ejed2' => 'required|string',
                        'addd2' => 'required|string',
                        'altd2' => 'required|string',

                    ]);
                    if ($validacion->fails()) {
                        return back()->withErrors([
                            'esfericod' => 'Campo requerido para PLATINO',
                            'cilindrod' => 'Campo requerido para PLATINO',
                            'ejed' => 'Campo requerido para PLATINO',
                            'addd' => 'Campo requerido para PLATINO',
                            'altd' => 'Campo requerido para PLATINO',
                            'esfericod2' => 'Campo requerido para PLATINO',
                            'cilindrod2' => 'Campo requerido para PLATINO',
                            'ejed2' => 'Campo requerido para PLATINO',
                            'addd2' => 'Campo requerido para PLATINO',
                            'altd2' => 'Campo requerido para PLATINO',
                        ])->withInput($request->all());
                    }


                }

                // contrato
                $contratos = DB::select("SHOW TABLE STATUS LIKE 'contratos'");
                $randomId = $this->getContratoId();
                $randomIdH = $this->getHistorialId5();

                $fotoBruta = 'Foto-Ine-Frente-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoine')->getClientOriginalExtension();
                $fotoine = request()->file('fotoine')->storeAs('uploads/imagenes/contratos/fotoine', $fotoBruta, 'disco');
                $alto = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->height();
                $ancho = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->width();

                if ($alto > $ancho) {
                    $imagenfotoine = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->resize(600, 800);
                } else {
                    $imagenfotoine = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoine/' . $fotoBruta)->resize(800, 600);
                }
                $imagenfotoine->save();

                $fotoBruta2 = 'Foto-Ine-Atras-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotoineatras')->getClientOriginalExtension();
                $fotoineatras = request()->file('fotoineatras')->storeAs('uploads/imagenes/contratos/fotoineatras', $fotoBruta2, 'disco');
                $alto2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->height();
                $ancho2 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->width();
                if ($alto2 > $ancho2) {
                    $imagenfotoineatras = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->resize(600, 800);
                } else {
                    $imagenfotoineatras = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotoineatras/' . $fotoBruta2)->resize(800, 600);
                }
                $imagenfotoineatras->save();

                $fotoBruta5 = 'Foto-Pagare-Contrato-' . $randomId . '-' . time() . '.' . request()->file('pagare')->getClientOriginalExtension();
                $fotopagare = request()->file('pagare')->storeAs('uploads/imagenes/contratos/pagare', $fotoBruta5, 'disco');
                $alto5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->height();
                $ancho5 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->width();
                if ($alto5 > $ancho5) {
                    $imagenfotopagare = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->resize(600, 800);
                } else {
                    $imagenfotopagare = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/pagare/' . $fotoBruta5)->resize(800, 600);
                }
                $imagenfotopagare->save();

                $fotoBruta3 = 'Foto-Casa-Contrato-' . $randomId . '-' . time() . '.' . request()->file('fotocasa')->getClientOriginalExtension();
                $fotocasa = request()->file('fotocasa')->storeAs('uploads/imagenes/contratos/fotocasa', $fotoBruta3, 'disco');
                $alto3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->height();
                $ancho3 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->width();
                if ($alto3 > $ancho3) {
                    $imagenfotocasa = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->resize(600, 800);
                } else {
                    $imagenfotocasa = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/fotocasa/' . $fotoBruta3)->resize(800, 600);
                }
                $imagenfotocasa->save();

                $fotoBruta4 = 'Foto-comprobantedomicilio-Contrato-' . $randomId . '-' . time() . '.' . request()->file('comprobantedomicilio')->getClientOriginalExtension();
                $comprobantedomicilio = request()->file('comprobantedomicilio')->storeAs('uploads/imagenes/contratos/comprobantedomicilio', $fotoBruta4, 'disco');
                $alto4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->height();
                $ancho4 = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->width();
                if ($alto4 > $ancho4) {
                    $imagencomprobantedomicilio = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->resize(600, 800);
                } else {
                    $imagencomprobantedomicilio = Image::make(config('filesystems.disks.disco.root') . '/uploads/imagenes/contratos/comprobantedomicilio/' . $fotoBruta4)->resize(800, 600);
                }
                $imagencomprobantedomicilio->save();

                $datos = 1;
                $creacion = Carbon::now();
                $usuarioId = Auth::user()->id;
                $usuarioNombre = Auth::user()->name;

                DB::table('contratos')->insert([
                    'id' => $randomId, 'datos' => $datos, 'id_franquicia' => $idFranquicia, 'id_usuariocreacion' => $usuarioId, 'nombre_usuariocreacion' => $usuarioNombre, 'id_zona' => request('zona'), 'id_promocion' => request('promocion'), 'id_optometrista' => request('optometrista'),
                    'nombre' => request('nombre'), 'pago' => request('formapago'), 'calle' => request('calle'), 'numero' => request('numero'), 'depto' => request('departamento'), 'alladode' => request('alladode'), 'frentea' => request('frentea'),
                    'entrecalles' => request('entrecalles'), 'colonia' => request('colonia'), 'localidad' => request('localidad'), 'telefono' => request('telefono'), 'casatipo' => request('casatipo'), 'casacolor' => request('casacolor'), 'created_at' => $creacion, 'correo' => request('correo'),
                    'nombrereferencia' => request('nr'), 'telefonoreferencia' => request('tr'), 'fotoine' => $fotoine, 'fotocasa' => $fotocasa, 'comprobantedomicilio' => $comprobantedomicilio, 'fotoineatras' => $fotoineatras, 'pagare' => $fotopagare, 'contador' => 1, 'poliza' => null
                ]);

                //historial clinico
                $dolor = request('dolor') != Null;
                $ardor = request('ardor') != Null;
                $golpe = request('golpe') != Null;
                $otroM = request('otroM') != Null;
                $otroTra = request('otroTra') != Null;
                $fotocromatico2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
                $AR2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
                $tinte2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
                $blueray2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
                $fotocromatico = request('fotocromatico');
                $ar = request('ar');
                $tinte = request('tinte');
                $blueray = request('blueray');
                $otromaterial = request('costomaterial');
                $otrotratamiento = request('costoT');
                if ($tinte != null) {
                    $tinte = 1;
                    $tinte6 = $tinte2[0]->precio;
                    $fotocromatico = null;
                    $ar = null;
                    $blueray = null;
                } else {
                    $tinte6 = null;
                    $tinte = 0;
                }
                $fotocromaticoActivo = false;
                if ($fotocromatico != null) {
                    $fotocromatico = 1;
                    $fotocromatico6 = $fotocromatico2[0]->precio;
                    $fotocromaticoActivo = true;
                } else {
                    $fotocromatico = null;
                    $fotocromatico6 = 0;
                }
                if ($ar != null) {
                    $ar = 1;
                    $ar6 = $AR2[0]->precio;
                } else {
                    $ar = null;
                    $ar6 = 0;
                }
                if ($blueray != null) {
                    $blueray = 1;
                    $blueray6 = $blueray2[0]->precio;
                    if (request('paquete') == 2) {
                        if (!$fotocromaticoActivo) {
                            $blueray6 = 0;
                        }
                    }
                } else {
                    $blueray = null;
                    $blueray6 = 0;
                }

                $totalidad = "";
                if ($tinte != null && request('paquete') > 2) {
                    $totalidad = $tinte6 + $otromaterial + $otrotratamiento;
                } else {
                    if (request('paquete') == 2) {
                        $totalidad = $ar6 + $blueray6 + $otromaterial + $otrotratamiento;
                    } else {
                        $totalidad = $fotocromatico6 + $ar6 + $blueray6 + $otromaterial + $otrotratamiento;
                    }
                }

                $historial = DB::select("SHOW TABLE STATUS LIKE 'historialclinico'");
                $siguienteId = $historial[0]->Auto_increment;
                $idContrato = $randomId;
                $value = request('paquete');
                $value2 = request('producto');
                $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia' and id = '$value'");
                $con = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' and id = '$idContrato'");
                $armazon = DB::select("SELECT * FROM producto WHERE id = '$value2' AND id_tipoproducto = '1'");
                $arma = $armazon[0]->id;
                $armapz = $armazon[0]->piezas - 1;
                $hijo = $con[0]->idcontratorelacion;
                $val = $con[0]->totalhistorial;
                $valor = $paquetes[0]->precio;
                $total = $valor + $val + $totalidad;
                if ($value == 1) {
                    if (request('cilindrod') != 0 || request('cilindrod2') != 0) {
                        $total = $total + 590;
                    }
                }
                if ($hijo == null) {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalhistorial' => $total, 'total' => $total, 'estatus_estadocontrato' => 0, 'totalreal' => $total
                    ]);
                } else {
                    DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                        'totalhistorial' => $total, 'total' => $total, 'estatus' => 0, 'estatus_estadocontrato' => 0, 'totalreal' => $total
                    ]);
                }

                //Insertar en tabla registroestadocontrato
                DB::table('registroestadocontrato')->insert([
                    'id_contrato' => $idContrato,
                    'estatuscontrato' => 0,
                    'created_at' => Carbon::now()
                ]);

                DB::table('producto')->where([['id', '=', $arma], ['id_franquicia', '=', $idFranquicia]])->update([
                    'piezas' => $armapz
                ]);

                if (request('paquete') == 6) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                        'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'addder' => request('addd'), 'altder' => request('altd'),
                        'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'), 'addizq' => request('addd2'), 'altizq' => request('altd2'), 'altizq' => request('altd2'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('nuevohistorialclinico2', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');
                } elseif (request('paquete') == 1) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                        'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                } elseif (request('paquete') == 2) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                } elseif (request('paquete') == 3) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                        'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                } elseif (request('paquete') == 4) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                        'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                } elseif (request('paquete') == 5) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                        'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'addder' => request('addd'), 'altder' => request('altd'),
                        'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'), 'addizq' => request('addd2'), 'altizq' => request('altd2'), 'altizq' => request('altd2'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');

                } elseif (request('paquete') == 7) {
                    DB::table('historialclinico')->insert([
                        'id' => $randomIdH, 'id_contrato' => $idContrato, 'edad' => request('edad'), 'diagnostico' => request('diagnostico'), 'ocupacion' => request('ocupacion'), 'diabetes' => request('diabetes'), 'hipertension' => request('hipertension'),
                        'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpe, 'otroM' => $otroM, 'ultimoexamen' => request('ultimoexamen'), 'molestiaotro' => request('molestia'), 'esfericoder' => request('esfericod'),
                        'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                        'id_producto' => request('producto'), 'id_paquete' => request('paquete'), 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                        'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                    ]);
                    return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico y el contrato se crearon correctamente.');
                }
            } catch (\Exception $e) {
                \Log::info("Error: " . $e);
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function crearhistorialclinico2($idFranquicia, $idContrato, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || Auth::check() && ((Auth::user()->rol_id) == 6)) {
            $rules = [
                'edad' => 'required|string|max:255',
                'diagnostico' => 'required|string|max:255',
                'ocupacion' => 'required|string|max:255',
                'diabetes' => 'required|string|max:255',
                'hipertension' => 'required|string|max:255',
                'producto' => 'required|string',
                'ultimoexamen' => 'nullable|date',
                'fechaentrega' => 'required|date'

            ];
            if (request('material') != '3' && request('motro') != null && request('costomaterial') != null) {
                return back()->withErrors(['motro' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('material') == '3' && request('motro') == null && request('costomaterial') == null) {
                return back()->withErrors(['motro' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('material') == '3' && request('motro') == null && request('costomaterial') != null) {
                return back()->withErrors(['motro' => 'Llenar ambos campos para otro'])->withInput($request->all());
            }
            if (request('material') == '3' && request('motro') != null && request('costomaterial') == null) {
                return back()->withErrors(['motro' => 'Llenar ambos campos para otro'])->withInput($request->all());
            }
            if (request('producto') == 'nada') {
                return back()->withErrors(['producto' => 'Campo obligatorio'])->withInput($request->all());
            }
            if (request('otroTra') != null && request('otroT') == null && request('costoT') == null) {
                return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('otroTra') != null && request('otroT') != null && request('costoT') == null) {
                return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('otroTra') != null && request('otroT') == null && request('costoT') != null) {
                return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
            }
            if (request('otroTra') == null && request('otroT') != null && request('costoT') != null) {
                return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
            }
            if (request('paquete') == 1) {
                if (request('fotocromatico') != null && request('ar') != null || request('blueray') != null || request('otroTra') != null) {
                    $n = 0;
                    if (request('fotocromatico') == 1) {

                        $n = $n + 1;
                    }
                    if (request('ar') == 1) {

                        $n = $n + 1;
                    }
                    if (request('blueray') == 1) {

                        $n = $n + 1;
                    }
                    if (request('otroTra') == 1) {
                        $n = $n + 1;
                    }

                    if ($n > 1) {

                        return back()->withErrors(['fotocromatico' => 'Solo se permite uno con el paquete de lectura'])->withInput($request->all());
                    }
                }
            }
            if (request('tinte') == 1 && request('paquete') == 1) {
                return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete'])->withInput($request->all());
            }
            if (request('tinte') == 1 && request('paquete') == 2) {
                return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete'])->withInput($request->all());
            }
            request()->validate($rules);

            if (request('paquete') == 'DORADO 2') {
                $validacion = Validator::make($request->all(), [
                    'esfericod' => 'required|string',
                    'cilindrod' => 'required|string',
                    'ejed' => 'required|string',
                    'esfericod2' => 'required|string',
                    'cilindrod2' => 'required|string',
                    'ejed2' => 'required|string',

                ]);
                if ($validacion->fails()) {
                    return back()->withErrors([
                        'esfericod' => 'Campo requerido para DORADO2',
                        'cilindrod' => 'Campo requerido para DORADO2',
                        'ejed' => 'Campo requerido para DORADO2',
                        'esfericod2' => 'Campo requerido para DORADO2',
                        'cilindrod2' => 'Campo requerido para DORADO2',
                        'ejed2' => 'Campo requerido para DORADO2',
                    ])->withInput($request->all());
                }
            }
            try {
                $randomIdH2 = $this->getHistorialId2();
                $historialC = DB::select("SELECT h.edad, h.diagnostico, h.hipertension, h.id_paquete, h.diabetes, h.ocupacion, h.dolor, h.ardor, h.golpeojos, h.molestiaotro, h.ultimoexamen, p.nombre
                FROM historialclinico h
                INNER JOIN paquetes p
                ON p.id = h.id_paquete
                WHERE id_contrato = '$idContrato'");
                $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia'");
                $edad = $historialC[0]->edad;
                $diagnostico = $historialC[0]->diagnostico;
                $ocupacion = $historialC[0]->ocupacion;
                $diabetes = $historialC[0]->diabetes;
                $hipertension = $historialC[0]->hipertension;
                $dolor = $historialC[0]->dolor;
                $ardor = $historialC[0]->ardor;
                $golpeojos = $historialC[0]->golpeojos;
                $ultimoexamen = $historialC[0]->ultimoexamen;
                $molestiaotro = $historialC[0]->molestiaotro;
                $idpaquete = $historialC[0]->id_paquete;
                $paquete = $paquetes[0]->id;
                $otroM = request('otroM') != Null;
                $otroTra = request('otroTra') != Null;
                $value2 = request('producto');
                $armazon = DB::select("SELECT * FROM producto WHERE id = '$value2' AND id_tipoproducto = '1'");
                $arma = $armazon[0]->id;
                $armapz = $armazon[0]->piezas - 1;

                $fotocromatico2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
                $AR2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
                $tinte2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
                $blueray2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");

                $fotocromatico = request('fotocromatico');
                $ar = request('ar');
                $tinte = request('tinte');
                $blueray = request('blueray');
                $otromaterial = request('costomaterial');
                $otrotratamiento = request('costoT');
                if ($tinte != null) {
                    $tinte = $tinte2[0]->precio;
                    $tinte6 = 1;
                    $fotocromatico = null;
                    $ar = null;
                    $blueray = null;
                } else {
                    $tinte = null;
                    $tinte6 = 0;
                }
                if ($fotocromatico != null && $idpaquete != 2) {
                    $fotocromatico = $fotocromatico2[0]->precio;
                    $fotocromatico6 = 1;
                } else {
                    $fotocromatico = null;
                    $fotocromatico6 = 0;
                }
                if ($ar != null) {
                    $ar = $AR2[0]->precio;
                    $ar6 = 1;
                } else {
                    $ar = null;
                    $ar6 = 0;
                }
                if ($blueray != null) {
                    $blueray = $blueray2[0]->precio;
                    $blueray6 = 1;
                } else {
                    $blueray6 = 0;
                }
                $totalidad = "";
                if ($tinte != null && $idpaquete > 2) {
                    $totalidad = $tinte + $otromaterial + $otrotratamiento;
                } else {
                    $totalidad = $fotocromatico + $ar + $blueray + $otromaterial + $otrotratamiento;
                }

                $paquetes = DB::select("SELECT * FROM paquetes WHERE id_franquicia = '$idFranquicia' and id = '6'");
                $con = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' and id = '$idContrato'");
                $val = $con[0]->totalhistorial;
                $total = $val + $totalidad;
                $historial = DB::select("SHOW TABLE STATUS LIKE 'historialclinico'");
                $siguienteId = $historial[0]->Auto_increment;


                DB::table('historialclinico')->insert([
                    'id' => $randomIdH2, 'id_contrato' => $idContrato, 'edad' => $edad, 'diagnostico' => $diagnostico, 'ocupacion' => $ocupacion, 'diabetes' => $diabetes, 'hipertension' => $hipertension,
                    'dolor' => $dolor, 'ardor' => $ardor, 'golpeojos' => $golpeojos, 'otroM' => $otroM, 'ultimoexamen' => $ultimoexamen, 'molestiaotro' => $molestiaotro, 'esfericoder' => request('esfericod'),
                    'cilindroder' => request('cilindrod'), 'ejeder' => request('ejed'), 'esfericoizq' => request('esfericod2'), 'cilindroizq' => request('cilindrod2'), 'ejeizq' => request('ejed2'),
                    'id_producto' => request('producto'), 'id_paquete' => $idpaquete, 'fechaentrega' => request('fechaentrega'), 'material' => request('material'), 'materialotro' => request('motro'), 'bifocal' => request('bifocal'),
                    'fotocromatico' => $fotocromatico6, 'ar' => $ar6, 'tinte' => $tinte6, 'blueray' => $blueray6, 'otroT' => $otroTra, 'tratamientootro' => request('otroT'), 'costomaterial' => request('costomaterial'), 'costotratamiento' => request('costoT'), 'observaciones' => request('observaciones'), 'observacionesinterno' => request('observacionesinterno'), 'created_at' => Carbon::now()
                ]);

                DB::table('producto')->where([['id', '=', $arma], ['id_franquicia', '=', $idFranquicia]])->update([
                    'piezas' => $armapz
                ]);

                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalhistorial' => $total, 'total' => $total, 'estatus' => 0, 'totalreal' => $total
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $idContrato])->with('bien', 'El historial clinico se creo correctamente.');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function editarHistorial($idFranquicia, $idContrato, $idHistorial, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8) || ((Auth::user()->rol_id) == 13) || ((Auth::user()->rol_id) == 12) || Auth::check() && ((Auth::user()->rol_id) == 6)) {

            if (request('tinte') == 1 && request('paquete') == 'PROTECCION') {
                return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete']);
            }
            if (request('tinte') == 1 && request('paquete') == 'LECTURA') {
                return back()->withErrors(['tinte' => 'No se permite agregar tinte con este paquete']);
            }
            if (request('otroTra') != null && request('otroT') == null && request('costoT') == null) {
                return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('otroTra') != null && request('otroT') != null && request('costoT') == null) {
                return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('otroTra') != null && request('otroT') == null && request('costoT') != null) {
                return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
            }
            if (request('otroTra') == null && request('otroT') != null && request('costoT') != null) {
                return back()->withErrors(['otroT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
            }
            if (request('otroTra') == null && request('otroT') != null && request('costoT') == null) {
                return back()->withErrors(['otroT' => 'Solo se permite con la opción de "otro"'])->withInput($request->all());
            }
            if (request('otroTra') == null && request('otroT') == null && request('costoT') != null) {
                return back()->withErrors(['costoT' => 'Llenar ambos campos para otro tratamiento'])->withInput($request->all());
            }
            if (request('ar') != null && request('blueray') != null) {
                return back()->withErrors(['ar' => 'Solo se puede elegir uno entre AR y BlueRay'])->withInput($request->all());
            }

            $datosHistorial = DB::select("SELECT id_contrato ,id, tinte, ar, fotocromatico, blueray, otroT, id_paquete
                                                    FROM historialclinico WHERE id = '$idHistorial' AND id_contrato = '$idContrato'");
            $contrato = $datosHistorial[0]->id_contrato;
            $tinte3 = $datosHistorial[0]->tinte;
            $ar3 = $datosHistorial[0]->ar;
            $fotocromatico3 = $datosHistorial[0]->fotocromatico;
            $blueray3 = $datosHistorial[0]->blueray;
            $otroT3 = $datosHistorial[0]->otroT;
            $paquetedatos = $datosHistorial[0]->id_paquete;

            $fotocromatico2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'fotocromático'");
            $AR2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'A/R'");
            $tinte2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'tinte'");
            $blueray2 = DB::select("SELECT * FROM tratamientos WHERE id_franquicia = '$idFranquicia' AND nombre = 'BlueRay'");
            $randomId2 = $this->getContratoHistorialId();
            $fotocromatico = request('fotocromatico');
            $ar = request('ar');
            $tinte = request('tinte');
            $blueray = request('blueray');
            $otrotra = request('otroTra');
            $otroT = request('otroT');
            $costotra = request('costoT');
            $movimientos = "";
            if ($paquetedatos == 1) {
                if (request('fotocromatico') != null && request('ar') != null || request('blueray') != null || request('otroTra') != null) {
                    $n = 0;
                    if (request('fotocromatico') == 1) {

                        $n = $n + 1;
                    }
                    if (request('ar') == 1) {

                        $n = $n + 1;
                    }
                    if (request('blueray') == 1) {
                        $n = $n + 1;
                    }
                    if (request('otroTra') == 1) {
                        $n = $n + 1;
                    }
                    if ($n > 1) {

                        return back()->withErrors(['fotocromatico' => 'Solo se permite un tratamiento con el paquete de lectura'])->withInput($request->all());
                    }
                }
            }
            if ($tinte != null && $tinte3 == null) {
                $tinte = 1;
                $tinte7 = $tinte2[0]->precio;
                $movimientos = 'tinte';
            } else {
                if ($tinte === null && $tinte3 != null) {
                    $tinte = null;
                    $tinte7 = 0;
                    $movimientos = strlen($movimientos) == 0 ? 'tinte' : $movimientos . '/tinte';
                } else {
                    $tinte = $tinte3;
                }
                $tinte7 = 0;
            }
            if ($fotocromatico != null && $fotocromatico3 == null) { //FOto request && foto BD
                $fotocromatico = 1;
                $fotocromatico7 = $fotocromatico2[0]->precio;
                $movimientos = strlen($movimientos) == 0 ? 'fotocromatico' : $movimientos . '/fotocromatico';
            } else {
                if ($fotocromatico === null && $fotocromatico3 != null) {
                    $fotocromatico = null;
                    $fotocromatico7 = 0;
                    $movimientos = strlen($movimientos) == 0 ? 'fotocromatico' : $movimientos . '/fotocromatico';
                } else {
                    $fotocromatico = $fotocromatico3;
                }
                $fotocromatico7 = 0;
            }
            if ($blueray != null && $blueray3 == null) { // BLueray request y blueray de BD.
                $blueray = 1;
                $blueray7 = $blueray2[0]->precio;
                $movimientos = strlen($movimientos) == 0 ? 'blueray' : $movimientos . '/blueray';
            } else {
                if ($blueray === null && $blueray3 != null) {
                    $blueray = null;
                    $movimientos = strlen($movimientos) == 0 ? 'fotocromatico' : $movimientos . '/fotocromatico';
                } else {
                    $blueray = $blueray3;
                }
                $blueray7 = 0;
            }
            if ($ar != null && $ar3 === null) {
                $ar = 1;
                $ar7 = $AR2[0]->precio;
                $movimientos = strlen($movimientos) == 0 ? 'AR' : $movimientos . '/AR';
            } else {
                if ($ar === null && $ar3 != 0) {
                    $ar = null;
                    $movimientos = strlen($movimientos) == 0 ? 'AR' : $movimientos . '/AR';
                } else {
                    $ar = $ar3;
                }
                $ar7 = 0;
            }
            $trataientoextra = 0;
            if ($otrotra != null && $otroT3 == 0) {
                $trataientoextra = $costotra;
                $movimientos = strlen($movimientos) == 0 ? 'Tratamiento extra' : $movimientos . '/Tratamiento extra';
            } else {
                if ($otrotra === null && $otroT3 == 0) {
                    $otrotra = null;
                    $movimientos = strlen($movimientos) == 0 ? 'AR' : $movimientos . '/AR';
                } else {
                    $otrotra = $otroT3;
                    $trataientoextra = 0;
                }
            }
            $totalidad = "";
            if ($tinte != null) {
                $totalidad = $tinte7 + $trataientoextra;
            } else {
                if (request('paquete') == 'PROTECCION') {
                    $totalidad = $ar7 + $blueray7 + $trataientoextra;
                } else {
                    $totalidad = $fotocromatico7 + $ar7 + $blueray7 + $trataientoextra;
                }
            }


            $contratos = DB::select("SELECT * FROM contratos  WHERE  id = '$contrato'");
            $TH = $contratos[0]->totalhistorial + $totalidad;
            $TH2 = $contratos[0]->total + $totalidad;
            $TH3 = $contratos[0]->totalpromocion + $totalidad;
            $totalreal = $contratos[0]->totalreal + $totalidad;
            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $esIgual = 0;

            if ($ar == $ar3 && $fotocromatico == $fotocromatico3 && $blueray == $blueray3 && $tinte == $tinte3 && $otroT3 == $otrotra) {
                $esIgual = 1;
            }
            try {

                DB::table('contratos')->where([['id', '=', $contrato], ['id_franquicia', '=', $idFranquicia]])->update([
                    'totalhistorial' => $TH, 'total' => $TH2, 'totalreal' => $totalreal
                ]);
                if ($esIgual == 0) {
                    DB::table('historialcontrato')->insert([
                        'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $contrato, 'created_at' => $actualizar, 'cambios' => " Se modifico el historial clinico: '$idHistorial', Se agrego el cambio en tratamientos: '$movimientos'"
                    ]);
                }


                DB::table('historialclinico')->where([['id', '=', $idHistorial], ['id_contrato', '=', $contrato]])->update([
                    'fotocromatico' => $fotocromatico, 'ar' => $ar, 'tinte' => $tinte, 'blueray' => $blueray, 'otroT' => $otrotra, 'tratamientootro' => $otroT, 'costotratamiento' => $costotra
                ]);
                return redirect()->route('vercontrato', ['idFranquicia' => $idFranquicia, 'idContrato' => $contrato])->with('bien', 'El historial clinico se actualizo correctamente.');


            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al dministrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function editarHistorialArmazon($idFranquicia, $idContrato, $idHistorial, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            if (request('producto') == 'nada') {
                return back()->withErrors(['producto' => 'Campo obligatorio'])->withInput($request->all());
            }

            $datosHistorial = DB::select("SELECT id_contrato, id, id_producto FROM historialclinico WHERE id = '$idHistorial' AND id_contrato = '$idContrato'");
            $idcontrato = $datosHistorial[0]->id_contrato;

            $contrato = DB::select("SELECT estatus_estadocontrato FROM contratos WHERE id = '$idcontrato'");

            if ($contrato != null) {
                if ($contrato[0]->estatus_estadocontrato > 1 && $contrato[0]->estatus_estadocontrato != 9) {
                    return back()->with('alerta', 'No puedes cambiar el modelo del armazon en este momento.');
                }
            }

            $usuarioId = Auth::user()->id;
            $actualizar = Carbon::now();
            $randomId2 = $this->getContratoHistorialId();

            try {

                //Obtener producto actual del historial
                $idProductoActual = $datosHistorial[0]->id_producto;
                $armazonActual = DB::select("SELECT * FROM producto WHERE id = '$idProductoActual' AND id_tipoproducto = '1'");
                $idArmazonActual = $armazonActual[0]->id;
                $piezasArmazonActualAumentado = $armazonActual[0]->piezas + 1;

                //Sumarle una pieza al producto que se quito
                DB::table('producto')->where('id', '=', $idArmazonActual)->update([
                    'piezas' => $piezasArmazonActualAumentado
                ]);

                //Obtener producto a actualizar
                $idArmazonActualizar = request('producto');
                $armazonActualizar = DB::select("SELECT * FROM producto WHERE id = '$idArmazonActualizar' AND id_tipoproducto = '1'");
                $piezasArmazonActualizarDecrementado = $armazonActualizar[0]->piezas - 1;

                //Restarle una pieza al producto que se actualizo
                DB::table('producto')->where('id', '=', $idArmazonActualizar)->update([
                    'piezas' => $piezasArmazonActualizarDecrementado
                ]);

                //Guardar movimiento
                DB::table('historialcontrato')->insert([
                    'id' => $randomId2, 'id_usuarioC' => $usuarioId, 'id_contrato' => $idcontrato, 'created_at' => $actualizar, 'cambios' => " Se modifico el historial clinico: '$idHistorial', Se cambio el armazon"
                ]);

                //Guardar id_producto en historialclinico
                DB::table('historialclinico')->where([['id', '=', $idHistorial], ['id_contrato', '=', $idcontrato]])->update([
                    'id_producto' => $idArmazonActualizar
                ]);
                return redirect()->route('contratoactualizar', [$idFranquicia, $idcontrato])->with("bien", "El historial clinico se actualizo correctamente.");

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function agregarGarantiaHistorial($idFranquicia, $idContrato, $idHistorial, Request $request)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            if (request('optometristagarantia') == 'nada') {
                return back()->withErrors(['optometristagarantia' => 'Campo obligatorio'])->withInput($request->all());
            }

            try {

                $datosHistorial = DB::select("SELECT id_contrato, tipo FROM historialclinico WHERE id = '$idHistorial' AND id_contrato = '$idContrato'");

                if ($datosHistorial != null) {
                    //Existe historial

                    $tipoHistorial = $datosHistorial[0]->tipo;

                    if($tipoHistorial == 0) {
                        //Tipo historial es igual a 0

                        $idContrato = $datosHistorial[0]->id_contrato;
                        $id_optometrista = request('optometristagarantia');

                        $optometrista = DB::select("SELECT name FROM users WHERE id = '$id_optometrista'");

                        if ($optometrista != null) {
                            //Existe optometrista

                            $nombreOptometrista = $optometrista[0]->name;
                            $globalesServicioWeb = new globalesServicioWeb;

                            $contrato = DB::select("SELECT estatus_estadocontrato, totalhistorial, totalpromocion, totalreal FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");

                            if ($contrato != null) {
                                //Existe contrato

                                $estatus_estadocontrato = $contrato[0]->estatus_estadocontrato;

                                if($estatus_estadocontrato == 2 || $estatus_estadocontrato == 5 || $estatus_estadocontrato == 4 || $estatus_estadocontrato == 12) {
                                    //ENTREGADO, LIQUIDADO, ABONO ATRASADO, ENVIADO

                                    $totalhistorialcontratogarantia = $contrato[0]->totalhistorial;
                                    $totalpromocioncontratogarantia = $contrato[0]->totalpromocion;
                                    $totalrealcontratogarantia = $contrato[0]->totalreal;
                                    $tieneGarantiaReportada = DB::select("SELECT id FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia = 0");

                                    if ($tieneGarantiaReportada != null) {
                                        //Tiene garantia reportada

                                        $idGarantia = $tieneGarantiaReportada[0]->id;
                                        DB::table('garantias')->where([['id', '=', $idGarantia], ['id_contrato', '=', $idContrato]])->update([
                                            'id_historial' => $idHistorial,
                                            'id_optometrista' => $id_optometrista,
                                            'estadogarantia' => 1,
                                            'estadocontratogarantia' => $estatus_estadocontrato,
                                            'totalhistorialcontratogarantia' => $totalhistorialcontratogarantia,
                                            'totalpromocioncontratogarantia' => $totalpromocioncontratogarantia,
                                            'totalrealcontratogarantia' => $totalrealcontratogarantia
                                        ]);

                                    } else {
                                        //No tiene garantia reportada

                                        $tieneHistorialGarantiaSinCrear = DB::select("SELECT id FROM garantias WHERE id_contrato = '$idContrato' AND id_historial = '$idHistorial' AND estadogarantia = 1");

                                        if ($tieneHistorialGarantiaSinCrear != null) {
                                            //Ya tiene asignada una garantia el historial
                                            return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'Ya existe una garantia en el historial la cual no ha sido creada.');
                                        } else {
                                            //No tiene asignada una garantia el historial
                                            $idGarantiaAlfanumerico = $globalesServicioWeb::generarIdAlfanumerico('garantias', '5');
                                            DB::table('garantias')->insert([
                                                'id' => $idGarantiaAlfanumerico,
                                                'id_contrato' => $idContrato,
                                                'id_historial' => $idHistorial,
                                                'id_optometrista' => $id_optometrista,
                                                'estadogarantia' => 1,
                                                'estadocontratogarantia' => $estatus_estadocontrato,
                                                'totalhistorialcontratogarantia' => $totalhistorialcontratogarantia,
                                                'totalpromocioncontratogarantia' => $totalpromocioncontratogarantia,
                                                'totalrealcontratogarantia' => $totalrealcontratogarantia,
                                                'created_at' => Carbon::now()
                                            ]);
                                        }

                                    }

                                    $usuarioId = Auth::user()->id;
                                    //Guardar movimiento
                                    DB::table('historialcontrato')->insert([
                                        'id' => $this->getContratoHistorialId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se asigno a '$nombreOptometrista' la garantia para el historial '$idHistorial'"
                                    ]);

                                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                                    $contratosGlobal = new contratosGlobal;
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $id_optometrista);

                                    return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('bien', 'Se agrego correctamente la garantia al historial.');

                                }
                                //ESTATUS DEL CONTRATO DIFERENTE A ENTREGADO, LIQUIDADO, ABONO ATRASADO, ENVIADO
                                return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'El estatus del contrato no es autorizado para realizar garatías');

                            }
                            //No existe el contrato
                            return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'No existe el contrato');

                        }
                        //No existe el optometrista
                        return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'No existe el optometrista que se quiere asignar');

                    }
                    //Tipo historial es diferente de 0
                    return back()->with('alerta', 'Ha este tipo de historial no se puede asignar garantía');

                }
                //No existe el historial
                return back()->with('alerta', 'No existe el historial');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function cancelarGarantiaHistorial($idFranquicia, $idContrato, $idHistorial)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 6) || ((Auth::user()->rol_id) == 7) || ((Auth::user()->rol_id) == 8)) {

            try {

                $datosHistorial = DB::select("SELECT id_contrato FROM historialclinico WHERE id = '$idHistorial' AND id_contrato = '$idContrato'");

                if ($datosHistorial != null) {
                    $idContrato = $datosHistorial[0]->id_contrato;

                    $garantiasCancelar = DB::select("SELECT id, id_historial, estadogarantia, estadocontratogarantia, totalhistorialcontratogarantia, totalpromocioncontratogarantia,
                                                            totalrealcontratogarantia, id_optometrista FROM garantias WHERE id_contrato = '$idContrato' AND estadogarantia IN (0,1,2)");

                    if($garantiasCancelar != null) {//Tiene garantias para cancelar?
                        //Tiene garantias para cancelar

                        foreach ($garantiasCancelar as $garantiaCancelar) {

                            $idGarantia = $garantiaCancelar->id;
                            $idhistorial = $garantiaCancelar->id_historial;
                            $estadogarantia = $garantiaCancelar->estadogarantia;
                            $estadocontratogarantia = $garantiaCancelar->estadocontratogarantia;
                            $totalhistorialcontratogarantia = $garantiaCancelar->totalhistorialcontratogarantia;
                            $totalpromocioncontratogarantia = $garantiaCancelar->totalpromocioncontratogarantia;
                            $totalrealcontratogarantia = $garantiaCancelar->totalrealcontratogarantia;
                            $idoptometristagarantia = $garantiaCancelar->id_optometrista;

                            $usuarioId = Auth::user()->id;

                            switch ($estadogarantia) {
                                case 0:
                                    //No se han creado las garantia 0
                                    DB::table('garantias')->where([['id', '=', $idGarantia], ['id_contrato', '=', $idContrato]])->update([
                                        'estadogarantia' => 4,
                                        'updated_at' => Carbon::now()
                                    ]);
                                    //Guardar movimiento
                                    DB::table('historialcontrato')->insert([
                                        'id' => $this->getContratoHistorialId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se cancelo la garantia reportada"
                                    ]);
                                    break;
                                case 1:
                                    //No se han creado las garantia 1
                                    DB::table('garantias')->where([['id', '=', $idGarantia], ['id_contrato', '=', $idContrato], ['id_historial', '=', $idHistorial]])->update([
                                        'estadogarantia' => 4,
                                        'updated_at' => Carbon::now()
                                    ]);
                                    //Guardar movimiento
                                    DB::table('historialcontrato')->insert([
                                        'id' => $this->getContratoHistorialId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se cancelo la garantia al historial '$idHistorial'"
                                    ]);
                                    //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato y el idoptometristagarantia
                                    DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato' AND id_usuario = '$idoptometristagarantia'");
                                    break;
                                case 2:
                                    //Ya se habian creado las garantias
                                    $globalesServicioWeb = new globalesServicioWeb;
                                    $contrato = DB::select("SELECT totalhistorial, totalpromocion, totalabono, totalproducto FROM contratos WHERE id = '$idContrato' AND id_franquicia = '$idFranquicia'");

                                    if($contrato != null) {
                                        //Se encontro el contrato
                                        $totalhistorial = $contrato[0]->totalhistorial;
                                        $totalpromocion = $contrato[0]->totalpromocion;
                                        $totalabono = $contrato[0]->totalabono;
                                        $totalproducto = $contrato[0]->totalproducto;

                                        if($globalesServicioWeb::obtenerEstadoPromocion($idContrato, $idFranquicia)) {
                                            //Tiene promocion
                                            if($totalpromocion > $totalpromocioncontratogarantia) {
                                                //Devolver el estado del contrato, el total, y el totalpromocion a como estaban
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia,
                                                    'total' => $totalpromocioncontratogarantia + $totalproducto - $totalabono,
                                                    'totalpromocion' => $totalpromocioncontratogarantia,
                                                    'totalhistorial' => $totalhistorialcontratogarantia,
                                                    'totalreal' => $totalrealcontratogarantia
                                                ]);
                                            }else {
                                                //Devolver el estado del contrato
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia
                                                ]);
                                            }

                                        }else {
                                            //No tiene promocion
                                            if($totalhistorial > $totalhistorialcontratogarantia) {
                                                //Devolver el estado del contrato, el total, y el totalhistorial a como estaban
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia,
                                                    'total' => $totalhistorialcontratogarantia + $totalproducto - $totalabono,
                                                    'totalhistorial' => $totalhistorialcontratogarantia,
                                                    'totalpromocion' => $totalpromocioncontratogarantia,
                                                    'totalreal' => $totalrealcontratogarantia
                                                ]);
                                            }else {
                                                //Devolver el estado del contrato
                                                DB::table('contratos')->where([['id', '=', $idContrato], ['id_franquicia', '=', $idFranquicia]])->update([
                                                    'estatus_estadocontrato' => $estadocontratogarantia
                                                ]);
                                            }

                                        }

                                        //Insertar en tabla registroestadocontrato
                                        DB::table('registroestadocontrato')->insert([
                                            'id_contrato' => $idContrato,
                                            'estatuscontrato' => $estadocontratogarantia,
                                            'created_at' => Carbon::now()
                                        ]);

                                    }else {
                                        return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'No se encontro el contrato.');
                                    }

                                    //Actualizar estadogarantia a 4
                                    DB::table('garantias')->where([['id', '=', $idGarantia], ['id_contrato', '=', $idContrato], ['id_historial', '=', $idhistorial]])->update([
                                        'estadogarantia' => 4,
                                        'updated_at' => Carbon::now()
                                    ]);
                                    //Guardar movimiento
                                    DB::table('historialcontrato')->insert([
                                        'id' => $this->getContratoHistorialId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => " Se cancelo la garantia al historial '$idhistorial'"
                                    ]);

                                    //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                                    DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '$idContrato'");

                                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                                    $contratosGlobal = new contratosGlobal;
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, Auth::id());
                                    break;
                            }

                        }

                        return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('bien', 'Se cancelo correctamente la garantia del historial.');
                    }

                    //No tiene garantias para cancelar
                    return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'No se puede cancelar la garantia por que no hay un optometrista asignado.');

                }
                //No existe el historial
                return redirect()->route('contratoactualizar', [$idFranquicia, $idContrato])->with('alerta', 'No existe el historial');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    public function actualizarpaquetehistorial($idFranquicia, $idContrato, $idHistorial)
    {
        if (Auth::check() && ((Auth::user()->rol_id) == 7 || (Auth::user()->rol_id) == 6)) {

            $paquetehistorialeditar = request('paquetehistorialeditar'.$idHistorial);

            if ($paquetehistorialeditar == '') {
                return back()->with('alerta', 'No se selecciono ningun paquete a actualizar');
            }

            try {

                $datosHistorial = DB::select("SELECT id_contrato, tipo, id_paquete FROM historialclinico WHERE id = '$idHistorial' AND id_contrato = '$idContrato'");

                if ($datosHistorial != null) {
                    //Existe historial

                    $tipoHistorial = $datosHistorial[0]->tipo;
                    $idpaquetehistorial = $datosHistorial[0]->id_paquete;

                    if($idpaquetehistorial == $paquetehistorialeditar) {
                        //Se quiere actualizar al mismo paquete
                        return back()->with('alerta', 'No se puede actualizar al mismo paquete');
                    }

                    if($tipoHistorial == 0) {
                        //Es tipo 0 (Historial no garantia)

                        $idContrato = $datosHistorial[0]->id_contrato;

                        $contrato = DB::select("SELECT c.estatus_estadocontrato as estatus_estadocontrato,
                                                        (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id ORDER BY g.created_at DESC LIMIT 1) AS estadogarantia
                                                            FROM contratos c WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                        if($contrato != null) {
                            //Existe contrato

                            $estadocontrato = $contrato[0]->estatus_estadocontrato;

                            if($estadocontrato == 2 || $estadocontrato == 4 || $estadocontrato == 5 || $estadocontrato == 12) {
                                //estadocontrato ENTREGADO, ABONOATRASADO, LIQUIDADO O ENVIADO

                                $estadogarantia = $contrato[0]->estadogarantia;

                                if($estadogarantia != 2) {
                                    //estadogarantia sea diferente a creada

                                    $historiales = DB::select("SELECT * FROM historialclinico WHERE id_contrato = '$idContrato' AND tipo = '0' ORDER BY created_at DESC");

                                    if($historiales != null) {

                                        $contador = 0;
                                        $idpaquetehistorialentrante = null;

                                        foreach ($historiales as $historial) {

                                            $idhistorialentrante = $historial->id;
                                            $idpaquetehistorialentrante = $historial->id_paquete;
                                            $esfericoderhistorialentrante = $historial->esfericoder;
                                            $cilindroderhistorialentrante = $historial->cilindroder;
                                            $ejederhistorialentrante = $historial->ejeder;
                                            $addderhistorialentrante = $historial->addder;
                                            $altderhistorialentrante = $historial->altder;
                                            $esfericoizqhistorialentrante = $historial->esfericoizq;
                                            $cilindroizqhistorialentrante = $historial->cilindroizq;
                                            $ejeizqhistorialentrante = $historial->ejeizq;
                                            $addizqhistorialentrante = $historial->addizq;
                                            $altizqhistorialentrante = $historial->altizq;

                                            $esfericoderactualizar = null;
                                            $cilindroderactualizar = null;
                                            $ejederactualizar = null;
                                            $addderactualizar = null;
                                            $altderactualizar = null;
                                            $esfericoizqactualizar = null;
                                            $cilindroizqactualizar = null;
                                            $ejeizqactualizar = null;
                                            $addizqactualizar = null;
                                            $altizqactualizar = null;
                                            $tipohistorialactualizar = 0;
                                            $crearsegundohistorial = false;
                                            $crearsegundohistorialsinconversion = false;

                                            if($contador == 0 && $idpaquetehistorialentrante == 6) {
                                                $tipohistorialactualizar = 2;
                                                DB::update("UPDATE garantias SET estadogarantia = '4' WHERE id_contrato = '$idContrato' AND id_historial = '$idhistorialentrante' AND estadogarantia IN (0,1)");
                                            }

                                            if($paquetehistorialeditar == 6) {
                                                //Se va a editar a DORADO2
                                                $crearsegundohistorial = true;
                                                if($idpaquetehistorialentrante == 1) {
                                                    //Paquete entrante es LECTURA
                                                    $crearsegundohistorialsinconversion = true;
                                                }
                                            }

                                            if($paquetehistorialeditar != 2) {
                                                //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)

                                                if(strlen($esfericoderhistorialentrante) > 0) {
                                                    //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if($paquetehistorialeditar == 1 || $paquetehistorialeditar == 3 || $paquetehistorialeditar == 4 || $paquetehistorialeditar == 6) {
                                                        //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $esfericoderactualizar = $esfericoderhistorialentrante;
                                                    }elseif ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        // (PAQUETE ACTUALIZAR)
                                                        $esfericoderactualizar = $esfericoderhistorialentrante;
                                                    }
                                                }else {
                                                    //PROTECCION (PAQUETE ACTUAL)
                                                    $esfericoderactualizar = 0;
                                                }

                                                if(strlen($cilindroderhistorialentrante) > 0) {
                                                    //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if($paquetehistorialeditar == 1 || $paquetehistorialeditar == 3 || $paquetehistorialeditar == 4 || $paquetehistorialeditar == 6) {
                                                        //LECTURA, ECO JR, JR, DORADO 2 (PAQUETE ACTUALIZAR)
                                                        $cilindroderactualizar = $cilindroderhistorialentrante;
                                                    }elseif ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $cilindroderactualizar = $cilindroderhistorialentrante;
                                                    }
                                                }else {
                                                    //PROTECCION (PAQUETE ACTUAL)
                                                    $cilindroderactualizar = 0;
                                                }

                                                if(strlen($ejederhistorialentrante) > 0) {
                                                    //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if($paquetehistorialeditar == 1 || $paquetehistorialeditar == 3 || $paquetehistorialeditar == 4 || $paquetehistorialeditar == 6) {
                                                        //LECTURA, ECO JR, JR, DORADO 2 (PAQUETE ACTUALIZAR)
                                                        $ejederactualizar = $ejederhistorialentrante;
                                                    }elseif ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $ejederactualizar = $ejederhistorialentrante;
                                                    }
                                                }else {
                                                    //PROTECCION (PAQUETE ACTUAL)
                                                    $ejederactualizar = 0;
                                                }

                                                if(strlen($addderhistorialentrante) > 0) {
                                                    //DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $addderactualizar = $addderhistorialentrante;
                                                    }
                                                }else {
                                                    //LECTURA, ECO JR, JR, DORADO 2 o PROTECCION (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $addderactualizar = 0;
                                                    }
                                                }

                                                if(strlen($altderhistorialentrante) > 0) {
                                                    //DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $altderactualizar = $altderhistorialentrante;
                                                    }
                                                }else {
                                                    //LECTURA, ECO JR, JR, DORADO 2 o PROTECCION (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $altderactualizar = 0;
                                                    }
                                                }

                                                if(strlen($esfericoizqhistorialentrante) > 0) {
                                                    //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if($paquetehistorialeditar == 1 || $paquetehistorialeditar == 3 || $paquetehistorialeditar == 4 || $paquetehistorialeditar == 6) {
                                                        //LECTURA, ECO JR, JR, DORADO 2 (PAQUETE ACTUALIZAR)
                                                        $esfericoizqactualizar = $esfericoizqhistorialentrante;
                                                    }elseif ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $esfericoizqactualizar = $esfericoizqhistorialentrante;
                                                    }
                                                }else {
                                                    //PROTECCION (PAQUETE ACTUAL)
                                                    $esfericoizqactualizar = 0;
                                                }

                                                if(strlen($cilindroizqhistorialentrante) > 0) {
                                                    //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if($paquetehistorialeditar == 1 || $paquetehistorialeditar == 3 || $paquetehistorialeditar == 4 || $paquetehistorialeditar == 6) {
                                                        //LECTURA, ECO JR, JR, DORADO 2 (PAQUETE ACTUALIZAR)
                                                        $cilindroizqactualizar = $cilindroizqhistorialentrante;
                                                    }elseif ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $cilindroizqactualizar = $cilindroizqhistorialentrante;
                                                    }
                                                }else {
                                                    //PROTECCION (PAQUETE ACTUAL)
                                                    $cilindroizqactualizar = 0;
                                                }

                                                if(strlen($ejeizqhistorialentrante) > 0) {
                                                    //LECTURA, ECO JR, JR, DORADO 2, DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if($paquetehistorialeditar == 1 || $paquetehistorialeditar == 3 || $paquetehistorialeditar == 4 || $paquetehistorialeditar == 6) {
                                                        //LECTURA, ECO JR, JR, DORADO 2 (PAQUETE ACTUALIZAR)
                                                        $ejeizqactualizar = $ejeizqhistorialentrante;
                                                    }elseif ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $ejeizqactualizar = $ejeizqhistorialentrante;
                                                    }
                                                }else {
                                                    //PROTECCION (PAQUETE ACTUAL)
                                                    $ejeizqactualizar = 0;
                                                }

                                                if(strlen($addizqhistorialentrante) > 0) {
                                                    //DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $addizqactualizar = $addizqhistorialentrante;
                                                    }
                                                }else {
                                                    //LECTURA, ECO JR, JR, DORADO 2 o PROTECCION (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $addizqactualizar = 0;
                                                    }
                                                }

                                                if(strlen($altizqhistorialentrante) > 0) {
                                                    //DORADO 1 o PLATINO (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $altizqactualizar = $altizqhistorialentrante;
                                                    }
                                                }else {
                                                    //LECTURA, ECO JR, JR, DORADO 2 o PROTECCION (PAQUETE ACTUAL)
                                                    if ($paquetehistorialeditar == 5 || $paquetehistorialeditar == 7) {
                                                        //DORADO 1 o PLATINO (PAQUETE ACTUALIZAR)
                                                        $altizqactualizar = 0;
                                                    }
                                                }

                                            }

                                            if($crearsegundohistorial) {

                                                $idhistorialnuevo = $this->getHistorialId2();

                                                DB::table('historialclinico')->insert([
                                                    'id' => $idhistorialnuevo,
                                                    'id_contrato' => $idContrato,
                                                    'edad' => $historial->edad,
                                                    'fechaentrega' => $historial->fechaentrega,
                                                    'diagnostico' => $historial->diagnostico,
                                                    'ocupacion' => $historial->ocupacion,
                                                    'diabetes' => $historial->diabetes,
                                                    'hipertension' => $historial->hipertension,
                                                    'dolor' => $historial->dolor,
                                                    'ardor' => $historial->ardor,
                                                    'golpeojos' => $historial->golpeojos,
                                                    'otroM' => $historial->otroM,
                                                    'molestiaotro' => $historial->molestiaotro,
                                                    'ultimoexamen' => $historial->ultimoexamen,
                                                    'esfericoder' => $esfericoderactualizar,
                                                    'cilindroder' => $cilindroderactualizar,
                                                    'ejeder' => $ejederactualizar,
                                                    'addder' => $addderactualizar,
                                                    'altder' => $altderactualizar,
                                                    'esfericoizq' => $esfericoizqactualizar,
                                                    'cilindroizq' => $cilindroizqactualizar,
                                                    'ejeizq' => $ejeizqactualizar,
                                                    'addizq' => $addizqactualizar,
                                                    'altizq' => $altizqactualizar,
                                                    'id_producto' => '00000',
                                                    'id_paquete' => $paquetehistorialeditar,
                                                    'material' => $historial->material,
                                                    'materialotro' => $historial->materialotro,
                                                    'costomaterial' => $historial->costomaterial,
                                                    'bifocal' => $historial->bifocal,
                                                    'fotocromatico' => $historial->fotocromatico,
                                                    'ar' => $historial->ar,
                                                    'tinte' => $historial->tinte,
                                                    'blueray' => $historial->blueray,
                                                    'otroT' => $historial->otroT,
                                                    'tratamientootro' => $historial->tratamientootro,
                                                    'costotratamiento' => $historial->costotratamiento,
                                                    'observaciones' => $historial->observaciones,
                                                    'observacionesinterno' => $historial->observacionesinterno,
                                                    'tipo' => $tipohistorialactualizar,
                                                    'created_at' => Carbon::now()
                                                ]);

                                                if($crearsegundohistorialsinconversion) {

                                                    $historialsinconversionentrante = DB::select("SELECT * FROM historialsinconversion WHERE id_contrato = '$idContrato' AND id_historial = '$idhistorialentrante' ORDER BY created_at DESC LIMIT 1");

                                                    if ($historialsinconversionentrante != null) {

                                                        DB::table('historialsinconversion')->insert([
                                                            'id_contrato' => $idContrato,
                                                            'id_historial' => $idhistorialnuevo,
                                                            'esfericoder' => $historialsinconversionentrante[0]->esfericoder,
                                                            'cilindroder' => $historialsinconversionentrante[0]->cilindroder,
                                                            'ejeder' => $historialsinconversionentrante[0]->ejeder,
                                                            'addder' => $historialsinconversionentrante[0]->addder,
                                                            'esfericoizq' => $historialsinconversionentrante[0]->esfericoizq,
                                                            'cilindroizq' => $historialsinconversionentrante[0]->cilindroizq,
                                                            'ejeizq' => $historialsinconversionentrante[0]->ejeizq,
                                                            'addizq' => $historialsinconversionentrante[0]->addizq,
                                                            'created_at' => Carbon::now()
                                                        ]);

                                                    }

                                                }

                                            }

                                            DB::table('historialclinico')->where([['id', '=', $idhistorialentrante], ['id_contrato', '=', $idContrato]])->update([
                                                'id_paquete' => $paquetehistorialeditar,
                                                'esfericoder' => $esfericoderactualizar,
                                                'cilindroder' => $cilindroderactualizar,
                                                'ejeder' => $ejederactualizar,
                                                'addder' => $addderactualizar,
                                                'altder' => $altderactualizar,
                                                'esfericoizq' => $esfericoizqactualizar,
                                                'cilindroizq' => $cilindroizqactualizar,
                                                'ejeizq' => $ejeizqactualizar,
                                                'addizq' => $addizqactualizar,
                                                'altizq' => $altizqactualizar,
                                                'tipo' => $tipohistorialactualizar
                                            ]);

                                            $contador++;

                                        }

                                        $nombrePaqueteEntrante = $this->obtenerNombrePaquete($idpaquetehistorialentrante);
                                        $nombrePaqueteActualizar = $this->obtenerNombrePaquete($paquetehistorialeditar);

                                        //Guardar en tabla historialcontrato
                                        $usuarioId = Auth::user()->id;
                                        DB::table('historialcontrato')->insert([
                                            'id' => $this->getContratoHistorialId(), 'id_usuarioC' => $usuarioId, 'id_contrato' => $idContrato, 'created_at' => Carbon::now(), 'cambios' => "Se actualizo correctamente el paquete de " ."'". $nombrePaqueteEntrante ."'". " a " . "'" .$nombrePaqueteActualizar. "'"
                                        ]);

                                        //Actualizar en tabla autorizaciones a tipo 5 (Paquete actualizado)
                                        $solicitudcambiopaquete = DB::select("SELECT * FROM autorizaciones a WHERE a.id_contrato = '$idContrato' AND a.estatus = 1 AND a.tipo = 4 ORDER BY a.created_at DESC LIMIT 1");
                                        $indiceSolicitud = $solicitudcambiopaquete[0]->indice;
                                        if($solicitudcambiopaquete != null){
                                            //Tiene solicitud aprobada para cambio de paquete
                                            DB::table('autorizaciones')->where([['indice', '=', $indiceSolicitud], ['id_contrato', '=', $idContrato]])->update([
                                                'tipo' => '5', 'updated_at' => Carbon::now()
                                            ]);
                                        }

                                        return back()->with('bien', 'Se actualizo correctamente el paquete.');

                                    }

                                }
                                return back()->with('alerta', 'No se puede cambiar el paquete (Se tiene garantia).');
                            }
                            return back()->with('alerta', 'No se puede cambiar el paquete (Verificar el estado del contrato).');
                        }
                        //No existe contrato
                        return back()->with('alerta', 'No se encontro el contrato.');
                    }
                    //Es tipo 1 (Historial de garantia)
                    return back()->with('alerta', 'El historial es de garantia');

                }
                //No existe el historial
                return back()->with('alerta', 'No existe el historial');

            } catch (\Exception $e) {
                \Log::info("Error: " . $e->getMessage());
                return back()->with('error', 'Tuvimos un problema, por favor contacta al administrador de la pagina.');
            }

        } else {
            if (Auth::check()) {
                return redirect()->route('redireccionar');
            } else {
                return redirect()->route('login');
            }
        }
    }

    private function obtenerNombrePaquete($idPaquete)
    {
        $nombrePaquete = "";

        switch ($idPaquete) {
            case 1:
                $nombrePaquete = 'LECTURA';
                break;
            case 2:
                $nombrePaquete = 'PROTECCION';
                break;
            case 3:
                $nombrePaquete = 'ECO JR';
                break;
            case 4:
                $nombrePaquete = 'JR';
                break;
            case 5:
                $nombrePaquete = 'DORADO 1';
                break;
            case 6:
                $nombrePaquete = 'DORADO 2';
                break;
            case 7:
                $nombrePaquete = 'PLATINO';
                break;
        }

        return $nombrePaquete;
    }

}
