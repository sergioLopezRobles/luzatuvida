<?php
namespace App\Clases;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class contratosGlobal{

    public static function calculoCantidadFormaDePago($formaDePago){
        switch($formaDePago){
            case 1: //SEMANAL
                return 150;
            case 2://QUINCENAL
                return 300;
            case 4://MENSUAL
                return 400;
        }
    }

    public static function getFolioId() {
        $unico = "";
        $esUnico = false;
        while(!$esUnico){
            $randomFolio2 = self::generadorRandom2();
            $existente = DB::select("select id from abonos where id = '$randomFolio2'");
            if (sizeof ($existente) == 0){
                $unico = $randomFolio2;
                $esUnico = true;
            }
        }
           return $unico;
    }
    public static function generadorRandom2($length = 5){
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomFolio2 = '';
        for ($i = 0; $i < $length; $i++) {
            $randomFolio2 .= $caracteres[rand(0, $charactersLength - 1)];
        }
        return $randomFolio2;
    }

    public static function validarSiExisteFolioAlfanumericoEnAbonosContrato($idContrato) {
        $unico = "";
        $esUnico = false;
        while(!$esUnico){
            $randomFolio2 = self::generadorRandom2();
            $existente = DB::select("select folio from abonos where folio = '$randomFolio2' AND id_contrato = '$idContrato'");
            if (sizeof ($existente) == 0){
                $unico = $randomFolio2;
                $esUnico = true;
            }
        }
        return $unico;
    }

    public static function calculoTotal($idContrato)
    {

        self::actualizarTotalProductoContrato($idContrato);
        self::actualizarTotalAbonoContrato($idContrato);

        if (self::obtenerEstadoPromocion($idContrato)) {
            //Tiene promocion y esta activa
            $promocionterminada = DB::select("SELECT promocionterminada FROM contratos where id = '$idContrato'");
            if ($promocionterminada != null) {
                if ($promocionterminada[0]->promocionterminada == 1) {
                    //Promocion ha sido terminada
                    DB::update("UPDATE contratos
                        SET total = coalesce(totalpromocion,0)  + coalesce(totalproducto,0) - coalesce(totalabono,0)
                        WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                } else {
                    //Promocion no ha sido terminada
                    DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
                }
            }
        } else {
            //No tiene promocion o existe la promocion pero esta desactivada
            DB::update("UPDATE contratos
                    SET total = coalesce(totalhistorial,0) + coalesce(totalproducto,0) - coalesce(totalabono,0)
                    WHERE idcontratorelacion = '$idContrato' OR id ='$idContrato'");
        }
    }

    private static function obtenerEstadoPromocion($idContrato)
    {
        $respuesta = false;

        $contrato = DB::select("SELECT idcontratorelacion FROM contratos WHERE id = '$idContrato'");
        if ($contrato[0]->idcontratorelacion != null) {
            //Es un contrato hijo
            $idContrato = $contrato[0]->idcontratorelacion;
        }

        $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_contrato = '$idContrato'");

        if ($promocioncontrato != null) {
            if ($promocioncontrato[0]->estado == 1) {
                //Promocion esta activa
                $respuesta = true;
            }
        }
        return $respuesta;
    }

    private static function actualizarTotalProductoContrato($idContrato)
    {
        DB::update("UPDATE contratos c
                    SET c.totalproducto = coalesce((SELECT SUM(cp.total) FROM contratoproducto cp WHERE cp.id_contrato = c.id), 0)
                    WHERE c.id = '$idContrato'");
    }

    private static function actualizarTotalAbonoContrato($idContrato)
    {
        DB::update("UPDATE contratos c
                    SET c.totalabono = coalesce((SELECT SUM(a.abono) FROM abonos a WHERE a.id_contrato = c.id), 0)
                    WHERE c.id = '$idContrato'");
    }

    public static function obtenerVentasSemana($usuarios, $idFranquicia, $opcion){

        //Obtener perido de fechas a consultar
        $now = Carbon::now();
        $nowParse = Carbon::parse($now)->format('Y-m-d');
        $polizaGlobales = new polizaGlobales();
        $numeroDia = $now->dayOfWeekIso;    //Obtenemos el dia de la semana actual
        $fechaLunes = $nowParse;    //Obtener fecha con formato

        if($numeroDia != 1 && $numeroDia != 7){
            //Si no es lunes y domingo
            $fechaLunes = $polizaGlobales::obtenerDia($numeroDia, 1);   //se obtenie la fecha del lunes anterior a la fecha actaul
        }
        if($numeroDia == 7){
            //Si es domigo obtenemos la fecha del lunes pasado
            $fechaLunes = date("Y-m-d",strtotime($nowParse."- 6 days"));
            $numeroDia = 6; //Dia semana lo tomaremos como sabado por ser ultimo dia de trabajo
        }

        $fechaMartes = date("Y-m-d",strtotime($fechaLunes."+ 1 days"));
        $fechaMiercoles = date("Y-m-d",strtotime($fechaLunes."+ 2 days"));
        $fechaJueves = date("Y-m-d",strtotime($fechaLunes."+ 3 days"));
        $fechaViernes = date("Y-m-d",strtotime($fechaLunes."+ 4 days"));
        $fechaSabado = date("Y-m-d",strtotime($fechaLunes."+ 5 days"));

        //Opciones - $opcion
        // 0 -> Ventas para Optometristas
        //1 -> Ventas para Asistentes

        foreach ($usuarios as $usuario) {

            switch ($opcion){
                case 0:
                    //Condicion para ventas de Optometristas
                    $condicionVenta = "(c.id_usuariocreacion = '" . $usuario->id . "' OR c.id_optometrista = '" . $usuario->id . "')";
                    break;

                case 1:
                    //Condicion para ventas de Asistentes
                    $condicionVenta = "c.id_usuariocreacion = '" . $usuario->id . "'";
                    break;
            }

            //Consulta ventas
            $consultaVentas = DB::select("SELECT distinct (r.id_contrato), STR_TO_DATE(r.created_at,'%Y-%m-%d') as fechaAprobado FROM registroestadocontrato r
                                               INNER JOIN contratos c ON c.id = r.id_contrato
                                                WHERE $condicionVenta
                                                AND r.estatuscontrato IN (7)
                                                AND c.id_franquicia = '$idFranquicia'
                                                AND NOT EXISTS (SELECT * FROM garantias g WHERE g.id_contrato = c.id)
                                                AND STR_TO_DATE(r.created_at,'%Y-%m-%d') BETWEEN STR_TO_DATE('$fechaLunes','%Y-%m-%d') AND STR_TO_DATE('$fechaSabado','%Y-%m-%d')
                                                ORDER BY STR_TO_DATE(r.created_at,'%Y-%m-%d') DESC");

            //Contratos Rechazados - Cancelados - Lio/Fuga
            $consultaRechazados = DB::select("SELECT COUNT(c.id) as totalRechazados FROM contratos c
                                               INNER JOIN franquicias f ON f.id = c.id_franquicia
                                               WHERE  $condicionVenta
                                               AND (c.estatus_estadocontrato = 6 OR c.estatus_estadocontrato = 8 OR c.estatus_estadocontrato = 14)
                                               AND f.id = '$idFranquicia'
                                               AND STR_TO_DATE(c.created_at,'%Y-%m-%d') BETWEEN STR_TO_DATE('$fechaLunes','%Y-%m-%d') AND STR_TO_DATE('$nowParse','%Y-%m-%d')");

            //Variables de conteo
            $totalLunes = 0;
            $totalMartes = 0;
            $totalMiercoles = 0;
            $totalMiercoles = 0;
            $totalJueves = 0;
            $totalViernes = 0;
            $totalSabado = 0;

            foreach ($consultaVentas as $datos){

                if($datos-> fechaAprobado == $fechaLunes){
                    //Suma contrato aprobados en Lunes
                    $totalLunes = $totalLunes + 1;
                }if($datos-> fechaAprobado == $fechaMartes){
                    //Suma contrato aprobados en Martes
                    $totalMartes = $totalMartes + 1;
                }if($datos-> fechaAprobado == $fechaMiercoles){
                    //Suma contrato aprobados en Miercoles
                    $totalMiercoles = $totalMiercoles + 1;
                }if($datos-> fechaAprobado == $fechaJueves){
                    //Suma contrato aprobados en Jueves
                    $totalJueves = $totalJueves + 1;
                }if($datos-> fechaAprobado == $fechaViernes){
                    //Suma contrato aprobados en Viernes
                    $totalViernes = $totalViernes + 1;
                }if($datos-> fechaAprobado == $fechaSabado){
                    //Suma contrato aprobados en Sabado
                    $totalSabado = $totalSabado + 1;
                }

            }

            switch ($numeroDia){

                case 1:
                    //Lunes
                    $usuario->ventasLunes = $totalLunes;
                    $usuario->ventasMartes= null;
                    $usuario->ventasMiercoles= null;
                    $usuario->ventasJueves= null;
                    $usuario->ventasViernes= null;
                    $usuario->ventasSabado= null;
                    $usuario->ventasRechazadas= $consultaRechazados[0]->totalRechazados;
                    $usuario->totalVentas= $totalLunes;
                    break;

                case 2:
                    //Martes
                    $usuario->ventasLunes = $totalLunes;
                    $usuario->ventasMartes= $totalMartes;
                    $usuario->ventasMiercoles= null;
                    $usuario->ventasJueves= null;
                    $usuario->ventasViernes= null;
                    $usuario->ventasSabado= null;
                    $usuario->ventasRechazadas= $consultaRechazados[0]->totalRechazados;
                    $usuario->totalVentas= $totalLunes + $totalMartes;
                    break;

                case 3:
                    //Miercoles
                    $usuario->ventasLunes = $totalLunes;
                    $usuario->ventasMartes= $totalMartes;
                    $usuario->ventasMiercoles= $totalMiercoles;
                    $usuario->ventasJueves= null;
                    $usuario->ventasViernes= null;
                    $usuario->ventasSabado= null;
                    $usuario->ventasRechazadas= $consultaRechazados[0]->totalRechazados;
                    $usuario->totalVentas= $totalLunes + $totalMartes + $totalMiercoles;
                    break;

                case 4:
                    //Jueves
                    $usuario->ventasLunes = $totalLunes;
                    $usuario->ventasMartes= $totalMartes;
                    $usuario->ventasMiercoles= $totalMiercoles;
                    $usuario->ventasJueves= $totalJueves;
                    $usuario->ventasViernes= null;
                    $usuario->ventasSabado= null;
                    $usuario->ventasRechazadas= $consultaRechazados[0]->totalRechazados;
                    $usuario->totalVentas= $totalLunes + $totalMartes + $totalMiercoles + $totalJueves;
                    break;

                case 5:
                    //Viernes
                    $usuario->ventasLunes = $totalLunes;
                    $usuario->ventasMartes= $totalMartes;
                    $usuario->ventasMiercoles= $totalMiercoles;
                    $usuario->ventasJueves= $totalJueves;
                    $usuario->ventasViernes= $totalViernes;
                    $usuario->ventasSabado= null;
                    $usuario->ventasRechazadas= $consultaRechazados[0]->totalRechazados;
                    $usuario->totalVentas= $totalLunes + $totalMartes + $totalMiercoles + $totalJueves + $totalViernes;
                    break;

                case 6:
                    //Sabado
                    $usuario->ventasLunes = $totalLunes;
                    $usuario->ventasMartes= $totalMartes;
                    $usuario->ventasMiercoles= $totalMiercoles;
                    $usuario->ventasJueves= $totalJueves;
                    $usuario->ventasViernes= $totalViernes;
                    $usuario->ventasSabado= $totalSabado;
                    $usuario->ventasRechazadas= $consultaRechazados[0]->totalRechazados;
                    $usuario->totalVentas= $totalLunes + $totalMartes + $totalMiercoles + $totalJueves + $totalViernes + $totalSabado;
                    break;

            }

        }

        return $usuarios;
    }

    public  static function totalVentasPorDia($usuarios){

        $totalVentasPorDia = [0,0,0,0,0,0,0];
        foreach ($usuarios as $usuario) {

            if($usuario->ventasLunes != null){
                $totalVentasPorDia[0]= $totalVentasPorDia[0] + $usuario->ventasLunes;
            }if($usuario->ventasMartes != null){
                $totalVentasPorDia[1]= $totalVentasPorDia[1] + $usuario->ventasMartes;
            }if($usuario->ventasMiercoles != null){
                $totalVentasPorDia[2]= $totalVentasPorDia[2] + $usuario->ventasMiercoles;
            }if($usuario->ventasJueves != null){
                $totalVentasPorDia[3]= $totalVentasPorDia[3] + $usuario->ventasJueves;
            }if($usuario->ventasViernes != null){
                $totalVentasPorDia[4]= $totalVentasPorDia[4] + $usuario->ventasViernes;
            }if($usuario->ventasSabado != null){
                $totalVentasPorDia[5]= $totalVentasPorDia[5] + $usuario->ventasSabado;
            }
            $totalVentasPorDia[6]= $totalVentasPorDia[6] + $usuario->ventasRechazadas;

        }

        return $totalVentasPorDia;

    }

    public static function insertarDatosTablaContratosTemporalesSincronizacion($idFranquicia, $idUsuario, $idZona, $rol){

        if($rol == 4) {
            //Cobranza
            $contratos = DB::select(
                "SELECT IFNULL(c.id, '') as id,
                            IFNULL(c.datos, '') as datos,
                            IFNULL(c.id_usuariocreacion, '') as id_usuariocreacion,
                            IFNULL(c.nombre_usuariocreacion, '') as nombre_usuariocreacion,
                            IFNULL(c.id_zona, '') as id_zona,
                            IFNULL(c.estatus, '0') as estatus,
                            IFNULL(c.nombre, '') as nombre,
                            IFNULL(c.calle, '') as calle,
                            IFNULL(c.numero, '') as numero,
                            IFNULL(c.depto, '') as depto,
                            IFNULL(c.alladode, '') as alladode,
                            IFNULL(c.frentea, '') as frentea,
                            IFNULL(c.entrecalles, '') as entrecalles,
                            IFNULL(c.colonia, '') as colonia,
                            IFNULL(c.localidad, '') as localidad,
                            IFNULL(c.telefono, '') as telefono,
                            IFNULL(c.telefonoreferencia, '') as telefonoreferencia,
                            IFNULL(c.correo, '') as correo,
                            IFNULL(c.nombrereferencia, '') as nombrereferencia,
                            IFNULL(c.casatipo, '') as casatipo,
                            IFNULL(c.casacolor, '') as casacolor,
                            SUBSTRING_INDEX(IFNULL(c.fotoine, ''), '/', -1) AS fotoine,
                            SUBSTRING_INDEX(IFNULL(c.fotocasa, ''), '/', -1) as fotocasa,
                            SUBSTRING_INDEX(IFNULL(c.comprobantedomicilio, ''), '/', -1) as comprobantedomicilio,
                            SUBSTRING_INDEX(IFNULL(c.pagare, ''), '/', -1) as pagare,
                            SUBSTRING_INDEX(IFNULL(c.fotootros, ''), '/', -1) as fotootros,
                            IFNULL(c.pagosadelantar, '0') as pagosadelantar,
                            IFNULL(c.created_at, '') as created_at,
                            IFNULL(c.updated_at, '') as updated_at,
                            IFNULL(c.id_optometrista, '') as id_optometrista,
                            SUBSTRING_INDEX(IFNULL(c.tarjeta, ''), '/', -1) as tarjeta,
                            IFNULL(c.pago, '') as pago,
                            IFNULL(c.id_promocion, '') as id_promocion,
                            SUBSTRING_INDEX(IFNULL(c.fotoineatras, ''), '/', -1) as fotoineatras,
                            SUBSTRING_INDEX(IFNULL(c.tarjetapensionatras, ''), '/', -1) as tarjetapensionatras,
                            IFNULL(c.total, '') as total,
                            IFNULL(c.idcontratorelacion, '') as idcontratorelacion,
                            IFNULL(c.contador, '') as contador,
                            IFNULL(c.totalhistorial, '0') as totalhistorial,
                            IFNULL(c.totalpromocion, '0') as totalpromocion,
                            IFNULL(c.totalproducto, '0') as totalproducto,
                            IFNULL(c.totalabono, '0') as totalabono,
                            IFNULL(c.fechaatraso, '') as fechaatraso,
                            IFNULL(c.costoatraso, '0') as costoatraso,
                            IFNULL(c.ultimoabono, '') as ultimoabono,
                            IFNULL(c.estatus_estadocontrato, '') as estatus_estadocontrato,
                            IFNULL(c.diapago, '') as diapago,
                            IFNULL(c.fechacobroini, '') as fechacobroini,
                            IFNULL(c.fechacobrofin, '') as fechacobrofin,
                            IFNULL(c.enganche, '0') as enganche,
                            IFNULL(c.entregaproducto, '0') as entregaproducto,
                            IFNULL(c.diaseleccionado, '') as diaseleccionado,
                            IFNULL(c.fechaentrega, '') as fechaentrega,
                            IFNULL(c.promocionterminada, '0') as promocionterminada,
                            IFNULL(c.subscripcion, '') as subscripcion,
                            IFNULL(c.fechasubscripcion, '') as fechasubscripcion,
                            IFNULL(c.nota, '') as nota,
                            IFNULL(c.totalreal, '') as totalreal,
                            IFNULL(c.diatemporal, '') as diatemporal,
                            IFNULL(c.coordenadas, '') as coordenadas,
                            IFNULL((SELECT p.nombre
                                    FROM paquetes p
                                    WHERE p.id = (SELECT hc.id_paquete
                                                  FROM historialclinico hc
                                                  WHERE hc.id_contrato = c.id
                                                  ORDER BY hc.created_at
                                                  DESC LIMIT 1) LIMIT 1), '') as nombrepaquete,
                            (SELECT a.created_at
                                FROM abonos a
                                WHERE a.id_contrato = c.id
                                AND a.tipoabono != '7'
                                ORDER BY a.created_at
                                DESC LIMIT 1) as ultimoabonoreal,
                            IFNULL((SELECT pr.titulo
                                    FROM promocion pr
                                    WHERE (pr.id = c.id_promocion OR pr.id = (SELECT pc.id_promocion FROM promocioncontrato pc WHERE pc.id_contrato = c.idcontratorelacion))), '') as titulopromocion
                            FROM contratos c
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND c.id_zona = '" . $idZona . "'
                            AND (c.estatus_estadocontrato IN (2,4,12)
                                    OR c.id IN (SELECT g.id_contrato
                                                    FROM garantias g
                                                    INNER JOIN contratos con ON con.id = g.id_contrato
                                                    WHERE con.estatus_estadocontrato IN (1,7,9,10,11)
                                                    AND con.id_franquicia = '$idFranquicia'
                                                    AND con.id_zona = '" . $idZona . "'
                                                    AND g.estadogarantia IN (1,2)))");

        }else {
            //Asistente o Optometrista
            $nowParse = Carbon::now()->format('Y-m-d');
            $contratos = DB::select(
                "SELECT IFNULL(c.id, '') as id,
                            IFNULL(c.datos, '') as datos,
                            IFNULL(c.id_usuariocreacion, '') as id_usuariocreacion,
                            IFNULL(c.nombre_usuariocreacion, '') as nombre_usuariocreacion,
                            IFNULL(c.id_zona, '') as id_zona,
                            IFNULL(c.estatus, '0') as estatus,
                            IFNULL(c.nombre, '') as nombre,
                            IFNULL(c.calle, '') as calle,
                            IFNULL(c.numero, '') as numero,
                            IFNULL(c.depto, '') as depto,
                            IFNULL(c.alladode, '') as alladode,
                            IFNULL(c.frentea, '') as frentea,
                            IFNULL(c.entrecalles, '') as entrecalles,
                            IFNULL(c.colonia, '') as colonia,
                            IFNULL(c.localidad, '') as localidad,
                            IFNULL(c.telefono, '') as telefono,
                            IFNULL(c.telefonoreferencia, '') as telefonoreferencia,
                            IFNULL(c.correo, '') as correo,
                            IFNULL(c.nombrereferencia, '') as nombrereferencia,
                            IFNULL(c.casatipo, '') as casatipo,
                            IFNULL(c.casacolor, '') as casacolor,
                            SUBSTRING_INDEX(IFNULL(c.fotoine, ''), '/', -1) AS fotoine,
                            SUBSTRING_INDEX(IFNULL(c.fotocasa, ''), '/', -1) as fotocasa,
                            SUBSTRING_INDEX(IFNULL(c.comprobantedomicilio, ''), '/', -1) as comprobantedomicilio,
                            SUBSTRING_INDEX(IFNULL(c.pagare, ''), '/', -1) as pagare,
                            SUBSTRING_INDEX(IFNULL(c.fotootros, ''), '/', -1) as fotootros,
                            IFNULL(c.pagosadelantar, '0') as pagosadelantar,
                            IFNULL(c.created_at, '') as created_at,
                            IFNULL(c.updated_at, '') as updated_at,
                            IFNULL(c.id_optometrista, '') as id_optometrista,
                            SUBSTRING_INDEX(IFNULL(c.tarjeta, ''), '/', -1) as tarjeta,
                            IFNULL(c.pago, '') as pago,
                            IFNULL(c.id_promocion, '') as id_promocion,
                            SUBSTRING_INDEX(IFNULL(c.fotoineatras, ''), '/', -1) as fotoineatras,
                            SUBSTRING_INDEX(IFNULL(c.tarjetapensionatras, ''), '/', -1) as tarjetapensionatras,
                            IFNULL(c.total, '') as total,
                            IFNULL(c.idcontratorelacion, '') as idcontratorelacion,
                            IFNULL(c.contador, '') as contador,
                            IFNULL(c.totalhistorial, '0') as totalhistorial,
                            IFNULL(c.totalpromocion, '0') as totalpromocion,
                            IFNULL(c.totalproducto, '0') as totalproducto,
                            IFNULL(c.totalabono, '0') as totalabono,
                            IFNULL(c.fechaatraso, '') as fechaatraso,
                            IFNULL(c.costoatraso, '0') as costoatraso,
                            IFNULL(c.ultimoabono, '') as ultimoabono,
                            IFNULL(c.estatus_estadocontrato, '') as estatus_estadocontrato,
                            IFNULL(c.diapago, '') as diapago,
                            IFNULL(c.fechacobroini, '') as fechacobroini,
                            IFNULL(c.fechacobrofin, '') as fechacobrofin,
                            IFNULL(c.enganche, '0') as enganche,
                            IFNULL(c.entregaproducto, '0') as entregaproducto,
                            IFNULL(c.diaseleccionado, '') as diaseleccionado,
                            IFNULL(c.fechaentrega, '') as fechaentrega,
                            IFNULL(c.promocionterminada, '0') as promocionterminada,
                            IFNULL(c.subscripcion, '') as subscripcion,
                            IFNULL(c.fechasubscripcion, '') as fechasubscripcion,
                            IFNULL(c.nota, '') as nota,
                            IFNULL(c.totalreal, '') as totalreal,
                            IFNULL(c.diatemporal, '') as diatemporal,
                            IFNULL(c.coordenadas, '') as coordenadas
                            FROM contratos c
                            WHERE c.id_franquicia = '$idFranquicia'
                            AND (c.id_usuariocreacion = '" . $idUsuario . "' AND c.estatus_estadocontrato IN (0,1,9))
                            OR c.id IN (SELECT g.id_contrato
                                        FROM garantias g
                                        INNER JOIN contratos con ON con.id = g.id_contrato
                                        WHERE g.id_optometrista = '" . $idUsuario . "'
                                        AND con.id_franquicia = '$idFranquicia'
                                        AND (g.estadogarantia = 1 OR (g.estadogarantia = 2 AND STR_TO_DATE(g.updated_at,'%Y-%m-%d') = STR_TO_DATE('$nowParse','%Y-%m-%d')))
                                            AND con.estatus_estadocontrato IN (1,2,5,12,4,9))");

        }

        if($contratos != null) {
            //Existen contratos

            foreach ($contratos as $contrato) {

                try {

                    $nombrepaquete = "";
                    $ultimoabonoreal = "";
                    $titulopromocion = "";

                    if ($rol == 4) {
                        //Rol cobranza
                        $nombrepaquete = $contrato->nombrepaquete;
                        $ultimoabonoreal = $contrato->ultimoabonoreal;
                        $titulopromocion = $contrato->titulopromocion;
                    }

                    //Insertar en tabla contratostemporalessincronizacion
                    DB::table('contratostemporalessincronizacion')->insert([
                        'id_usuario' => $idUsuario,
                        'id' => $contrato->id,
                        'datos' => $contrato->datos,
                        'id_usuariocreacion' => $contrato->id_usuariocreacion,
                        'nombre_usuariocreacion' => $contrato->nombre_usuariocreacion,
                        'id_zona' => $contrato->id_zona,
                        'estatus' => $contrato->estatus,
                        'nombre' => $contrato->nombre,
                        'calle' => $contrato->calle,
                        'numero' => $contrato->numero,
                        'depto' => $contrato->depto,
                        'alladode' => $contrato->depto,
                        'frentea' => $contrato->frentea,
                        'entrecalles' => $contrato->entrecalles,
                        'colonia' => $contrato->colonia,
                        'localidad' => $contrato->localidad,
                        'telefono' => $contrato->telefono,
                        'telefonoreferencia' => $contrato->telefonoreferencia,
                        'correo' => $contrato->correo,
                        'nombrereferencia' => $contrato->nombrereferencia,
                        'casatipo' => $contrato->casatipo,
                        'casacolor' => $contrato->casacolor,
                        'fotoine' => $contrato->fotoine,
                        'fotocasa' => $contrato->fotocasa,
                        'comprobantedomicilio' => $contrato->comprobantedomicilio,
                        'pagare' => $contrato->pagare,
                        'fotootros' => $contrato->fotootros,
                        'pagosadelantar' => $contrato->pagosadelantar,
                        'id_optometrista' => $contrato->id_optometrista,
                        'tarjeta' => $contrato->tarjeta,
                        'pago' => $contrato->pago,
                        'id_promocion' => $contrato->id_promocion,
                        'fotoineatras' => $contrato->fotoineatras,
                        'tarjetapensionatras' => $contrato->tarjetapensionatras,
                        'total' => $contrato->total,
                        'idcontratorelacion' => $contrato->idcontratorelacion,
                        'contador' => $contrato->contador,
                        'totalhistorial' => $contrato->totalhistorial,
                        'totalpromocion' => $contrato->totalpromocion,
                        'totalproducto' => $contrato->totalproducto,
                        'totalabono' => $contrato->totalabono,
                        'fechaatraso' => $contrato->fechaatraso,
                        'costoatraso' => $contrato->costoatraso,
                        'ultimoabono' => $contrato->ultimoabono,
                        'estatus_estadocontrato' => $contrato->estatus_estadocontrato,
                        'diapago' => $contrato->diapago,
                        'fechacobroini' => $contrato->fechacobroini,
                        'fechacobrofin' => $contrato->fechacobrofin,
                        'enganche' => $contrato->enganche,
                        'entregaproducto' => $contrato->entregaproducto,
                        'diaseleccionado' => $contrato->diaseleccionado,
                        'fechaentrega' => $contrato->fechaentrega,
                        'promocionterminada' => $contrato->promocionterminada,
                        'subscripcion' => $contrato->subscripcion,
                        'fechasubscripcion' => $contrato->fechasubscripcion,
                        'nota' => $contrato->nota,
                        'totalreal' => $contrato->totalreal,
                        'diatemporal' => $contrato->diatemporal,
                        'coordenadas' => $contrato->coordenadas,
                        'nombrepaquete' => $nombrepaquete,
                        'ultimoabonoreal' => $ultimoabonoreal,
                        'titulopromocion' => $titulopromocion,
                        'created_at' => $contrato->created_at,
                        'updated_at' => ($contrato->updated_at == null ? $contrato->created_at : $contrato->updated_at)
                    ]);

                } catch (\Exception $e) {
                    \Log::info("Error: Funcion : insertarDatosTablaContratosTemporalesSincronizacion: " . $contrato->id . " '$idFranquicia'" . "\n" . $e);
                    continue;
                }

            }

        }

    }

    public static function insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato, $idUsuario){

        try {

            $usuario = DB::select("SELECT rol_id FROM users WHERE id = '$idUsuario'");

            $arregloIdsUsuarios = array();
            array_push($arregloIdsUsuarios, $idUsuario);

            if($usuario != null) {
                //Existe el usuario
                $rol = $usuario[0]->rol_id;

                $contrato = DB::select(
                    "SELECT IFNULL(c.id, '') as id,
                                IFNULL(c.datos, '') as datos,
                                IFNULL(c.id_usuariocreacion, '') as id_usuariocreacion,
                                IFNULL(c.nombre_usuariocreacion, '') as nombre_usuariocreacion,
                                IFNULL(c.id_zona, '') as id_zona,
                                IFNULL(c.estatus, '0') as estatus,
                                IFNULL(c.nombre, '') as nombre,
                                IFNULL(c.calle, '') as calle,
                                IFNULL(c.numero, '') as numero,
                                IFNULL(c.depto, '') as depto,
                                IFNULL(c.alladode, '') as alladode,
                                IFNULL(c.frentea, '') as frentea,
                                IFNULL(c.entrecalles, '') as entrecalles,
                                IFNULL(c.colonia, '') as colonia,
                                IFNULL(c.localidad, '') as localidad,
                                IFNULL(c.telefono, '') as telefono,
                                IFNULL(c.telefonoreferencia, '') as telefonoreferencia,
                                IFNULL(c.correo, '') as correo,
                                IFNULL(c.nombrereferencia, '') as nombrereferencia,
                                IFNULL(c.casatipo, '') as casatipo,
                                IFNULL(c.casacolor, '') as casacolor,
                                SUBSTRING_INDEX(IFNULL(c.fotoine, ''), '/', -1) AS fotoine,
                                SUBSTRING_INDEX(IFNULL(c.fotocasa, ''), '/', -1) as fotocasa,
                                SUBSTRING_INDEX(IFNULL(c.comprobantedomicilio, ''), '/', -1) as comprobantedomicilio,
                                SUBSTRING_INDEX(IFNULL(c.pagare, ''), '/', -1) as pagare,
                                SUBSTRING_INDEX(IFNULL(c.fotootros, ''), '/', -1) as fotootros,
                                IFNULL(c.pagosadelantar, '0') as pagosadelantar,
                                IFNULL(c.created_at, '') as created_at,
                                IFNULL(c.updated_at, '') as updated_at,
                                IFNULL(c.id_optometrista, '') as id_optometrista,
                                SUBSTRING_INDEX(IFNULL(c.tarjeta, ''), '/', -1) as tarjeta,
                                IFNULL(c.pago, '') as pago,
                                IFNULL(c.id_promocion, '') as id_promocion,
                                SUBSTRING_INDEX(IFNULL(c.fotoineatras, ''), '/', -1) as fotoineatras,
                                SUBSTRING_INDEX(IFNULL(c.tarjetapensionatras, ''), '/', -1) as tarjetapensionatras,
                                IFNULL(c.total, '') as total,
                                IFNULL(c.idcontratorelacion, '') as idcontratorelacion,
                                IFNULL(c.contador, '') as contador,
                                IFNULL(c.totalhistorial, '0') as totalhistorial,
                                IFNULL(c.totalpromocion, '0') as totalpromocion,
                                IFNULL(c.totalproducto, '0') as totalproducto,
                                IFNULL(c.totalabono, '0') as totalabono,
                                IFNULL(c.fechaatraso, '') as fechaatraso,
                                IFNULL(c.costoatraso, '0') as costoatraso,
                                IFNULL(c.ultimoabono, '') as ultimoabono,
                                IFNULL(c.estatus_estadocontrato, '') as estatus_estadocontrato,
                                IFNULL(c.diapago, '') as diapago,
                                IFNULL(c.fechacobroini, '') as fechacobroini,
                                IFNULL(c.fechacobrofin, '') as fechacobrofin,
                                IFNULL(c.enganche, '0') as enganche,
                                IFNULL(c.entregaproducto, '0') as entregaproducto,
                                IFNULL(c.diaseleccionado, '') as diaseleccionado,
                                IFNULL(c.fechaentrega, '') as fechaentrega,
                                IFNULL(c.promocionterminada, '0') as promocionterminada,
                                IFNULL(c.subscripcion, '') as subscripcion,
                                IFNULL(c.fechasubscripcion, '') as fechasubscripcion,
                                IFNULL(c.nota, '') as nota,
                                IFNULL(c.totalreal, '') as totalreal,
                                IFNULL(c.diatemporal, '') as diatemporal,
                                IFNULL(c.coordenadas, '') as coordenadas,
                                IFNULL((SELECT p.nombre
                                        FROM paquetes p
                                        WHERE p.id = (SELECT hc.id_paquete
                                                      FROM historialclinico hc
                                                      WHERE hc.id_contrato = c.id
                                                      ORDER BY hc.created_at
                                                      DESC LIMIT 1) LIMIT 1), '') as nombrepaquete,
                                (SELECT a.created_at
                                    FROM abonos a
                                    WHERE a.id_contrato = c.id
                                    AND a.tipoabono != '7'
                                    ORDER BY a.created_at
                                    DESC LIMIT 1) as ultimoabonoreal,
                                IFNULL((SELECT pr.titulo
                                        FROM promocion pr
                                        WHERE (pr.id = c.id_promocion OR pr.id = (SELECT pc.id_promocion FROM promocioncontrato pc WHERE pc.id_contrato = c.idcontratorelacion))), '') as titulopromocion
                                FROM contratos c
                                WHERE c.id = '$idContrato'");

                if($contrato != null) {
                    //Existe el contrato

                    if ($rol == 16 || $rol == 6 || $rol == 7 || $rol == 8) {
                        //Laboratorio, Administrativo, Director o Principal

                        if($contrato[0]->estatus_estadocontrato == 10 || $contrato[0]->estatus_estadocontrato == 11 || $contrato[0]->estatus_estadocontrato == 12
                            || $contrato[0]->estatus_estadocontrato == 2 || $contrato[0]->estatus_estadocontrato == 4 || $contrato[0]->estatus_estadocontrato == 5) {
                            //MANOFACTURA, EN PROCESO DE ENVIO, ENVIADO, ENTREGADO, ABONO ATRASADO O LIQUIDADO

                            $cobradoresAsignadosAZona = DB::select("SELECT u.id
                                              FROM users u
                                              INNER JOIN usuariosfranquicia uf
                                              ON u.id = uf.id_usuario
                                              WHERE u.rol_id = 4 AND u.id_zona = '" . $contrato[0]->id_zona . "'"); //Obtener idsUsuarios con rol cobranza y que este asignado a la zona

                            if ($cobradoresAsignadosAZona != null) {
                                //Existen cobradores
                                $arregloIdsUsuarios = array();
                                foreach ($cobradoresAsignadosAZona as $cobradorAsignadoAZona) {
                                    //Recorrido cobradores
                                    array_push($arregloIdsUsuarios, $cobradorAsignadoAZona->id);
                                }
                            }

                        }
                    }

                    if ($rol == 15 || $rol == 7 || $rol == 8) {
                        //Confirmaciones, Director o Principal

                        if($contrato[0]->estatus_estadocontrato == 0 || $contrato[0]->estatus_estadocontrato == 1 || $contrato[0]->estatus_estadocontrato == 9
                            || $contrato[0]->estatus_estadocontrato == 7) {
                            //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION, APROBADO
                            $arregloIdsUsuarios = array();
                            array_push($arregloIdsUsuarios, $contrato[0]->id_usuariocreacion);
                        }

                    }

                    foreach ($arregloIdsUsuarios as $arregloIdUsuario) {
                        //Recorrido de arregloIdsUsuarios

                        try{

                            $existeRegistro = DB::select("SELECT indice FROM contratostemporalessincronizacion WHERE id = '$idContrato' AND id_usuario = '$arregloIdUsuario'");

                            if ($existeRegistro != null) {
                                //Existe el registro en la tabla (Actualizar)

                                DB::table("contratostemporalessincronizacion")->where("id", "=", $idContrato)->update([
                                    'datos' => $contrato[0]->datos,
                                    'id_usuariocreacion' => $contrato[0]->id_usuariocreacion,
                                    'nombre_usuariocreacion' => $contrato[0]->nombre_usuariocreacion,
                                    'id_zona' => $contrato[0]->id_zona,
                                    'estatus' => $contrato[0]->estatus,
                                    'nombre' => $contrato[0]->nombre,
                                    'calle' => $contrato[0]->calle,
                                    'numero' => $contrato[0]->numero,
                                    'depto' => $contrato[0]->depto,
                                    'alladode' => $contrato[0]->depto,
                                    'frentea' => $contrato[0]->frentea,
                                    'entrecalles' => $contrato[0]->entrecalles,
                                    'colonia' => $contrato[0]->colonia,
                                    'localidad' => $contrato[0]->localidad,
                                    'telefono' => $contrato[0]->telefono,
                                    'telefonoreferencia' => $contrato[0]->telefonoreferencia,
                                    'correo' => $contrato[0]->correo,
                                    'nombrereferencia' => $contrato[0]->nombrereferencia,
                                    'casatipo' => $contrato[0]->casatipo,
                                    'casacolor' => $contrato[0]->casacolor,
                                    'fotoine' => $contrato[0]->fotoine,
                                    'fotocasa' => $contrato[0]->fotocasa,
                                    'comprobantedomicilio' => $contrato[0]->comprobantedomicilio,
                                    'pagare' => $contrato[0]->pagare,
                                    'fotootros' => $contrato[0]->fotootros,
                                    'pagosadelantar' => $contrato[0]->pagosadelantar,
                                    'id_optometrista' => $contrato[0]->id_optometrista,
                                    'tarjeta' => $contrato[0]->tarjeta,
                                    'pago' => $contrato[0]->pago,
                                    'id_promocion' => $contrato[0]->id_promocion,
                                    'fotoineatras' => $contrato[0]->fotoineatras,
                                    'tarjetapensionatras' => $contrato[0]->tarjetapensionatras,
                                    'total' => $contrato[0]->total,
                                    'idcontratorelacion' => $contrato[0]->idcontratorelacion,
                                    'contador' => $contrato[0]->contador,
                                    'totalhistorial' => $contrato[0]->totalhistorial,
                                    'totalpromocion' => $contrato[0]->totalpromocion,
                                    'totalproducto' => $contrato[0]->totalproducto,
                                    'totalabono' => $contrato[0]->totalabono,
                                    'fechaatraso' => $contrato[0]->fechaatraso,
                                    'costoatraso' => $contrato[0]->costoatraso,
                                    'ultimoabono' => $contrato[0]->ultimoabono,
                                    'estatus_estadocontrato' => $contrato[0]->estatus_estadocontrato,
                                    'diapago' => $contrato[0]->diapago,
                                    'fechacobroini' => $contrato[0]->fechacobroini,
                                    'fechacobrofin' => $contrato[0]->fechacobrofin,
                                    'enganche' => $contrato[0]->enganche,
                                    'entregaproducto' => $contrato[0]->entregaproducto,
                                    'diaseleccionado' => $contrato[0]->diaseleccionado,
                                    'fechaentrega' => $contrato[0]->fechaentrega,
                                    'promocionterminada' => $contrato[0]->promocionterminada,
                                    'subscripcion' => $contrato[0]->subscripcion,
                                    'fechasubscripcion' => $contrato[0]->fechasubscripcion,
                                    'nota' => $contrato[0]->nota,
                                    'totalreal' => $contrato[0]->totalreal,
                                    'diatemporal' => $contrato[0]->diatemporal,
                                    'coordenadas' => $contrato[0]->coordenadas,
                                    'nombrepaquete' => $contrato[0]->nombrepaquete,
                                    'ultimoabonoreal' => $contrato[0]->ultimoabonoreal,
                                    'titulopromocion' => $contrato[0]->titulopromocion,
                                    'created_at' => $contrato[0]->created_at,
                                    'updated_at' => ($contrato[0]->updated_at == null ? $contrato[0]->created_at : $contrato[0]->updated_at)
                                ]);

                            } else {
                                //No existe el registro en la tabla (Insertar)

                                DB::table('contratostemporalessincronizacion')->insert([
                                    'id_usuario' => $arregloIdUsuario,
                                    'id' => $contrato[0]->id,
                                    'datos' => $contrato[0]->datos,
                                    'id_usuariocreacion' => $contrato[0]->id_usuariocreacion,
                                    'nombre_usuariocreacion' => $contrato[0]->nombre_usuariocreacion,
                                    'id_zona' => $contrato[0]->id_zona,
                                    'estatus' => $contrato[0]->estatus,
                                    'nombre' => $contrato[0]->nombre,
                                    'calle' => $contrato[0]->calle,
                                    'numero' => $contrato[0]->numero,
                                    'depto' => $contrato[0]->depto,
                                    'alladode' => $contrato[0]->depto,
                                    'frentea' => $contrato[0]->frentea,
                                    'entrecalles' => $contrato[0]->entrecalles,
                                    'colonia' => $contrato[0]->colonia,
                                    'localidad' => $contrato[0]->localidad,
                                    'telefono' => $contrato[0]->telefono,
                                    'telefonoreferencia' => $contrato[0]->telefonoreferencia,
                                    'correo' => $contrato[0]->correo,
                                    'nombrereferencia' => $contrato[0]->nombrereferencia,
                                    'casatipo' => $contrato[0]->casatipo,
                                    'casacolor' => $contrato[0]->casacolor,
                                    'fotoine' => $contrato[0]->fotoine,
                                    'fotocasa' => $contrato[0]->fotocasa,
                                    'comprobantedomicilio' => $contrato[0]->comprobantedomicilio,
                                    'pagare' => $contrato[0]->pagare,
                                    'fotootros' => $contrato[0]->fotootros,
                                    'pagosadelantar' => $contrato[0]->pagosadelantar,
                                    'id_optometrista' => $contrato[0]->id_optometrista,
                                    'tarjeta' => $contrato[0]->tarjeta,
                                    'pago' => $contrato[0]->pago,
                                    'id_promocion' => $contrato[0]->id_promocion,
                                    'fotoineatras' => $contrato[0]->fotoineatras,
                                    'tarjetapensionatras' => $contrato[0]->tarjetapensionatras,
                                    'total' => $contrato[0]->total,
                                    'idcontratorelacion' => $contrato[0]->idcontratorelacion,
                                    'contador' => $contrato[0]->contador,
                                    'totalhistorial' => $contrato[0]->totalhistorial,
                                    'totalpromocion' => $contrato[0]->totalpromocion,
                                    'totalproducto' => $contrato[0]->totalproducto,
                                    'totalabono' => $contrato[0]->totalabono,
                                    'fechaatraso' => $contrato[0]->fechaatraso,
                                    'costoatraso' => $contrato[0]->costoatraso,
                                    'ultimoabono' => $contrato[0]->ultimoabono,
                                    'estatus_estadocontrato' => $contrato[0]->estatus_estadocontrato,
                                    'diapago' => $contrato[0]->diapago,
                                    'fechacobroini' => $contrato[0]->fechacobroini,
                                    'fechacobrofin' => $contrato[0]->fechacobrofin,
                                    'enganche' => $contrato[0]->enganche,
                                    'entregaproducto' => $contrato[0]->entregaproducto,
                                    'diaseleccionado' => $contrato[0]->diaseleccionado,
                                    'fechaentrega' => $contrato[0]->fechaentrega,
                                    'promocionterminada' => $contrato[0]->promocionterminada,
                                    'subscripcion' => $contrato[0]->subscripcion,
                                    'fechasubscripcion' => $contrato[0]->fechasubscripcion,
                                    'nota' => $contrato[0]->nota,
                                    'totalreal' => $contrato[0]->totalreal,
                                    'diatemporal' => $contrato[0]->diatemporal,
                                    'coordenadas' => $contrato[0]->coordenadas,
                                    'nombrepaquete' => $contrato[0]->nombrepaquete,
                                    'ultimoabonoreal' => $contrato[0]->ultimoabonoreal,
                                    'titulopromocion' => $contrato[0]->titulopromocion,
                                    'created_at' => $contrato[0]->created_at,
                                    'updated_at' => ($contrato[0]->updated_at == null ? $contrato[0]->created_at : $contrato[0]->updated_at)
                                ]);

                            }

                        } catch (\Exception $e) {
                            \Log::info("Error: Funcion : insertarOActualizarDatosTablaContratosTemporalesSincronizacionPorContrato al insertar contrato: " . $idContrato . " con el id_usuario: " . $arregloIdUsuario . "\n" . $e);
                        }

                    }

                }

            }

        } catch (\Exception $e) {
            \Log::info("Error: Funcion : insertarOActualizarDatosTablaContratosTemporalesSincronizacionPorContrato al insertar contrato: " . $idContrato . "\n" . $e);
        }

    }

    public static function actualizarDatosPorContratoTablaContratosTemporalesSincronizacion($idContrato){

        try {

            $contrato = DB::select(
                "SELECT IFNULL(c.id, '') as id,
                                IFNULL(c.datos, '') as datos,
                                IFNULL(c.id_usuariocreacion, '') as id_usuariocreacion,
                                IFNULL(c.nombre_usuariocreacion, '') as nombre_usuariocreacion,
                                IFNULL(c.id_zona, '') as id_zona,
                                IFNULL(c.estatus, '0') as estatus,
                                IFNULL(c.nombre, '') as nombre,
                                IFNULL(c.calle, '') as calle,
                                IFNULL(c.numero, '') as numero,
                                IFNULL(c.depto, '') as depto,
                                IFNULL(c.alladode, '') as alladode,
                                IFNULL(c.frentea, '') as frentea,
                                IFNULL(c.entrecalles, '') as entrecalles,
                                IFNULL(c.colonia, '') as colonia,
                                IFNULL(c.localidad, '') as localidad,
                                IFNULL(c.telefono, '') as telefono,
                                IFNULL(c.telefonoreferencia, '') as telefonoreferencia,
                                IFNULL(c.correo, '') as correo,
                                IFNULL(c.nombrereferencia, '') as nombrereferencia,
                                IFNULL(c.casatipo, '') as casatipo,
                                IFNULL(c.casacolor, '') as casacolor,
                                SUBSTRING_INDEX(IFNULL(c.fotoine, ''), '/', -1) AS fotoine,
                                SUBSTRING_INDEX(IFNULL(c.fotocasa, ''), '/', -1) as fotocasa,
                                SUBSTRING_INDEX(IFNULL(c.comprobantedomicilio, ''), '/', -1) as comprobantedomicilio,
                                SUBSTRING_INDEX(IFNULL(c.pagare, ''), '/', -1) as pagare,
                                SUBSTRING_INDEX(IFNULL(c.fotootros, ''), '/', -1) as fotootros,
                                IFNULL(c.pagosadelantar, '0') as pagosadelantar,
                                IFNULL(c.created_at, '') as created_at,
                                IFNULL(c.updated_at, '') as updated_at,
                                IFNULL(c.id_optometrista, '') as id_optometrista,
                                SUBSTRING_INDEX(IFNULL(c.tarjeta, ''), '/', -1) as tarjeta,
                                IFNULL(c.pago, '') as pago,
                                IFNULL(c.id_promocion, '') as id_promocion,
                                SUBSTRING_INDEX(IFNULL(c.fotoineatras, ''), '/', -1) as fotoineatras,
                                SUBSTRING_INDEX(IFNULL(c.tarjetapensionatras, ''), '/', -1) as tarjetapensionatras,
                                IFNULL(c.total, '') as total,
                                IFNULL(c.idcontratorelacion, '') as idcontratorelacion,
                                IFNULL(c.contador, '') as contador,
                                IFNULL(c.totalhistorial, '0') as totalhistorial,
                                IFNULL(c.totalpromocion, '0') as totalpromocion,
                                IFNULL(c.totalproducto, '0') as totalproducto,
                                IFNULL(c.totalabono, '0') as totalabono,
                                IFNULL(c.fechaatraso, '') as fechaatraso,
                                IFNULL(c.costoatraso, '0') as costoatraso,
                                IFNULL(c.ultimoabono, '') as ultimoabono,
                                IFNULL(c.estatus_estadocontrato, '') as estatus_estadocontrato,
                                IFNULL(c.diapago, '') as diapago,
                                IFNULL(c.fechacobroini, '') as fechacobroini,
                                IFNULL(c.fechacobrofin, '') as fechacobrofin,
                                IFNULL(c.enganche, '0') as enganche,
                                IFNULL(c.entregaproducto, '0') as entregaproducto,
                                IFNULL(c.diaseleccionado, '') as diaseleccionado,
                                IFNULL(c.fechaentrega, '') as fechaentrega,
                                IFNULL(c.promocionterminada, '0') as promocionterminada,
                                IFNULL(c.subscripcion, '') as subscripcion,
                                IFNULL(c.fechasubscripcion, '') as fechasubscripcion,
                                IFNULL(c.nota, '') as nota,
                                IFNULL(c.totalreal, '') as totalreal,
                                IFNULL(c.diatemporal, '') as diatemporal,
                                IFNULL(c.coordenadas, '') as coordenadas,
                                IFNULL((SELECT p.nombre
                                        FROM paquetes p
                                        WHERE p.id = (SELECT hc.id_paquete
                                                      FROM historialclinico hc
                                                      WHERE hc.id_contrato = c.id
                                                      ORDER BY hc.created_at
                                                      DESC LIMIT 1) LIMIT 1), '') as nombrepaquete,
                                (SELECT a.created_at
                                    FROM abonos a
                                    WHERE a.id_contrato = c.id
                                    AND a.tipoabono != '7'
                                    ORDER BY a.created_at
                                    DESC LIMIT 1) as ultimoabonoreal,
                                IFNULL((SELECT pr.titulo
                                        FROM promocion pr
                                        WHERE (pr.id = c.id_promocion OR pr.id = (SELECT pc.id_promocion FROM promocioncontrato pc WHERE pc.id_contrato = c.idcontratorelacion))), '') as titulopromocion
                                FROM contratos c
                                WHERE c.id = '$idContrato'");

            if($contrato != null) {
                //Existe el contrato

                DB::table("contratostemporalessincronizacion")->where("id", "=", $idContrato)->update([
                    'datos' => $contrato[0]->datos,
                    'id_usuariocreacion' => $contrato[0]->id_usuariocreacion,
                    'nombre_usuariocreacion' => $contrato[0]->nombre_usuariocreacion,
                    'id_zona' => $contrato[0]->id_zona,
                    'estatus' => $contrato[0]->estatus,
                    'nombre' => $contrato[0]->nombre,
                    'calle' => $contrato[0]->calle,
                    'numero' => $contrato[0]->numero,
                    'depto' => $contrato[0]->depto,
                    'alladode' => $contrato[0]->depto,
                    'frentea' => $contrato[0]->frentea,
                    'entrecalles' => $contrato[0]->entrecalles,
                    'colonia' => $contrato[0]->colonia,
                    'localidad' => $contrato[0]->localidad,
                    'telefono' => $contrato[0]->telefono,
                    'telefonoreferencia' => $contrato[0]->telefonoreferencia,
                    'correo' => $contrato[0]->correo,
                    'nombrereferencia' => $contrato[0]->nombrereferencia,
                    'casatipo' => $contrato[0]->casatipo,
                    'casacolor' => $contrato[0]->casacolor,
                    'fotoine' => $contrato[0]->fotoine,
                    'fotocasa' => $contrato[0]->fotocasa,
                    'comprobantedomicilio' => $contrato[0]->comprobantedomicilio,
                    'pagare' => $contrato[0]->pagare,
                    'fotootros' => $contrato[0]->fotootros,
                    'pagosadelantar' => $contrato[0]->pagosadelantar,
                    'id_optometrista' => $contrato[0]->id_optometrista,
                    'tarjeta' => $contrato[0]->tarjeta,
                    'pago' => $contrato[0]->pago,
                    'id_promocion' => $contrato[0]->id_promocion,
                    'fotoineatras' => $contrato[0]->fotoineatras,
                    'tarjetapensionatras' => $contrato[0]->tarjetapensionatras,
                    'total' => $contrato[0]->total,
                    'idcontratorelacion' => $contrato[0]->idcontratorelacion,
                    'contador' => $contrato[0]->contador,
                    'totalhistorial' => $contrato[0]->totalhistorial,
                    'totalpromocion' => $contrato[0]->totalpromocion,
                    'totalproducto' => $contrato[0]->totalproducto,
                    'totalabono' => $contrato[0]->totalabono,
                    'fechaatraso' => $contrato[0]->fechaatraso,
                    'costoatraso' => $contrato[0]->costoatraso,
                    'ultimoabono' => $contrato[0]->ultimoabono,
                    'estatus_estadocontrato' => $contrato[0]->estatus_estadocontrato,
                    'diapago' => $contrato[0]->diapago,
                    'fechacobroini' => $contrato[0]->fechacobroini,
                    'fechacobrofin' => $contrato[0]->fechacobrofin,
                    'enganche' => $contrato[0]->enganche,
                    'entregaproducto' => $contrato[0]->entregaproducto,
                    'diaseleccionado' => $contrato[0]->diaseleccionado,
                    'fechaentrega' => $contrato[0]->fechaentrega,
                    'promocionterminada' => $contrato[0]->promocionterminada,
                    'subscripcion' => $contrato[0]->subscripcion,
                    'fechasubscripcion' => $contrato[0]->fechasubscripcion,
                    'nota' => $contrato[0]->nota,
                    'totalreal' => $contrato[0]->totalreal,
                    'diatemporal' => $contrato[0]->diatemporal,
                    'coordenadas' => $contrato[0]->coordenadas,
                    'nombrepaquete' => $contrato[0]->nombrepaquete,
                    'ultimoabonoreal' => $contrato[0]->ultimoabonoreal,
                    'titulopromocion' => $contrato[0]->titulopromocion,
                    'created_at' => $contrato[0]->created_at,
                    'updated_at' => ($contrato[0]->updated_at == null ? $contrato[0]->created_at : $contrato[0]->updated_at)
                ]);

            }

        } catch (\Exception $e) {
            \Log::info("Error: Funcion : actualizarDatosPorContratoTablaContratosTemporalesSincronizacion al actualizar contrato: " . $idContrato . "\n" . $e);
        }

    }

}//clase
