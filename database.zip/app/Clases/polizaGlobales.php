<?php

namespace App\Clases;

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class polizaGlobales
{

    public static function calcularTotales($idFranquicia, $idPoliza){

        $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza' AND id_franquicia = '$idFranquicia'");
        $ultimaPoliza = DB::select("SELECT * FROM poliza WHERE  id_franquicia = '$idFranquicia' AND id != '$idPoliza' ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza sin importar si es de la semana actual o no.

        $totalAnterior = $ultimaPoliza[0]->total == null ? 0 : $ultimaPoliza[0]->total;
        $ingresosVentas = $poliza[0]->ingresosventas == null ? 0 : $poliza[0]->ingresosventas;
        $ingresosCobranza = $poliza[0]->ingresoscobranza == null ? 0: $poliza[0]->ingresoscobranza;
        $ingresosAdmin = DB::select("SELECT COALESCE(SUM(monto),0) as monto FROM ingresosoficina WHERE id_poliza = '$idPoliza'");
        $ingresoAdmin =  $ingresosAdmin[0]->monto == null ? 0 : $ingresosAdmin[0]->monto;

        $gastosadmon = DB::select("SELECT COALESCE(SUM(monto),0) as monto FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 0");
        $gastosventas = DB::select("SELECT COALESCE(SUM(monto),0) as monto FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 1");
        $gastoscobranza = DB::select("SELECT COALESCE(SUM(monto),0) as monto FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 2");
        $otrosgastos = DB::select("SELECT COALESCE(SUM(monto),0) as monto FROM gastos WHERE id_poliza = '$idPoliza' and tipogasto = 3");

        $gastosAdmin = $gastosadmon[0]->monto == null ? 0 : $gastosadmon[0]->monto;
        $gastoVentas = $gastosventas[0]->monto == null ? 0 : $gastosventas[0]->monto;
        $gastoCobranza = $gastoscobranza[0]->monto == null ? 0 : $gastoscobranza[0]->monto;
        $otrosGastos = $otrosgastos[0]->monto == null ? 0 : $otrosgastos[0]->monto;

        $total = ((float)$totalAnterior+(float)$ingresoAdmin+(float)$ingresosVentas+(float)$ingresosCobranza)-((float)$gastosAdmin+(float)$gastoVentas+(float)$gastoCobranza+(float)$otrosGastos);

        DB::table("poliza")->where("id","=",$idPoliza)->where("id_franquicia","=",$idFranquicia)->update([
            "gastosadmin" => $gastosAdmin,
            "gastosventas" =>$gastoVentas,
            "gastoscobranza" => $gastoCobranza,
            "otrosgastos" => $otrosGastos,
            "ingresosadmin" => $ingresoAdmin,
            "total" => $total
        ]);

    }

    public static function calculosVentasOptos($idFranquicia, $idPoliza, $ultimaPolizaId, $idUsuario)
    {

        if(strlen($idUsuario) > 0) {
            //idUsuario es diferente de vacio

            $query = "SELECT u.id,u.name,
                                            COALESCE((SELECT acumuladas FROM polizaventasdias pvd  WHERE pvd.id_usuario = u.id AND pvd.id_poliza = '$ultimaPolizaId'),0) as acumuladas,
                                            (SELECT count(c.id) FROM contratos c WHERE c.id_optometrista = u.id AND c.poliza = '$idPoliza') as diaActual,
                                            (SELECT id_tipoasistencia FROM asistencia a WHERE a.id_usuario = u.id AND a.id_poliza = '$idPoliza') as asistencia,
                                            COALESCE((SELECT SUM(cp.total)
                                                            FROM contratos c INNER JOIN contratoproducto cp ON c.id = cp.id_contrato
                                                            INNER JOIN producto p ON cp.id_producto = p.id  WHERE c.id_optometrista = u.id AND p.id_tipoproducto = 3
                                                            AND c.poliza = '$idPoliza' AND c.estatus_estadocontrato IN (2,4,5,7,10,11,12) ),0) as gotas,
                                            COALESCE((SELECT SUM(a.abono)
                                                            FROM abonos a INNER JOIN contratos c ON c.id = a.id_contrato WHERE a.tipoabono IN (0,1,4)
                                            AND c.id_optometrista = u.id AND a.id_usuario = c.id_usuariocreacion AND c.poliza = '$idPoliza' AND c.estatus_estadocontrato IN (2,4,5,7,10,11,12)),0) as enganche,
                                           COALESCE((SELECT SUM(cp.total)
                                                            FROM contratos c INNER JOIN contratoproducto cp ON c.id = cp.id_contrato
                                                            INNER JOIN producto p ON cp.id_producto = p.id  WHERE c.id_optometrista = u.id AND p.id_tipoproducto = 2
                                            AND c.poliza = '$idPoliza' AND c.estatus_estadocontrato IN (2,4,5,7,10,11,12) ),0) as polizas,
                                            COALESCE((SELECT ingresosventasacumulado FROM polizaventasdias pvd  WHERE pvd.id_usuario = u.id AND pvd.id_poliza = '$ultimaPolizaId'),0) as ingresosventasacumulado
                                            FROM users u
                                            INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                            WHERE uf.id_franquicia = '$idFranquicia' AND u.id = '$idUsuario'";

        }else {
            //idUsuario es vacio

            $query = "SELECT u.id,u.name,
                                            COALESCE((SELECT acumuladas FROM polizaventasdias pvd  WHERE pvd.id_usuario = u.id AND pvd.id_poliza = '$ultimaPolizaId'),0) as acumuladas,
                                            (SELECT count(c.id) FROM contratos c WHERE c.id_optometrista = u.id AND c.poliza = '$idPoliza') as diaActual,
                                            (SELECT id_tipoasistencia FROM asistencia a WHERE a.id_usuario = u.id AND a.id_poliza = '$idPoliza') as asistencia,
                                            COALESCE((SELECT SUM(cp.total)
                                                            FROM contratos c INNER JOIN contratoproducto cp ON c.id = cp.id_contrato
                                                            INNER JOIN producto p ON cp.id_producto = p.id  WHERE c.id_optometrista = u.id AND p.id_tipoproducto = 3
                                                            AND c.poliza = '$idPoliza' AND c.estatus_estadocontrato IN (2,4,5,7,10,11,12) ),0) as gotas,
                                            COALESCE((SELECT SUM(a.abono)
                                                            FROM abonos a INNER JOIN contratos c ON c.id = a.id_contrato WHERE a.tipoabono IN (0,1,4)
                                            AND c.id_optometrista = u.id AND a.id_usuario = c.id_usuariocreacion AND c.poliza = '$idPoliza' AND c.estatus_estadocontrato IN (2,4,5,7,10,11,12)),0) as enganche,
                                           COALESCE((SELECT SUM(cp.total)
                                                            FROM contratos c INNER JOIN contratoproducto cp ON c.id = cp.id_contrato
                                                            INNER JOIN producto p ON cp.id_producto = p.id  WHERE c.id_optometrista = u.id AND p.id_tipoproducto = 2
                                            AND c.poliza = '$idPoliza' AND c.estatus_estadocontrato IN (2,4,5,7,10,11,12) ),0) as polizas,
                                            COALESCE((SELECT ingresosventasacumulado FROM polizaventasdias pvd  WHERE pvd.id_usuario = u.id AND pvd.id_poliza = '$ultimaPolizaId'),0) as ingresosventasacumulado
                                            FROM users u
                                            INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                            WHERE uf.id_franquicia = '$idFranquicia' AND u.rol_id = '12'";
        }

        return DB::select($query);

    }

    public static function calculosVentasAsis($idFranquicia, $idPoliza, $ultimaPolizaId, $idUsuario)
    {

        if(strlen($idUsuario) > 0) {
            //idUsuario es diferente de vacio

            $query = "SELECT u.id,u.name,
                                        COALESCE((SELECT acumuladas FROM polizaventasdias pvd  WHERE pvd.id_usuario = u.id AND pvd.id_poliza = '$ultimaPolizaId'),0) as acumuladas,
                                        (SELECT count(c.id) FROM contratos c WHERE c.id_usuariocreacion = u.id AND c.poliza = '$idPoliza') as diaActual,
                                        (SELECT id_tipoasistencia FROM asistencia a WHERE a.id_usuario = u.id AND a.id_poliza = '$idPoliza') as asistencia
                                        FROM users u
                                        INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        WHERE uf.id_franquicia = '$idFranquicia' AND u.id = '$idUsuario'";

        }else {
            //idUsuario es vacio

            $query = "SELECT u.id,u.name,
                                        COALESCE((SELECT acumuladas FROM polizaventasdias pvd  WHERE pvd.id_usuario = u.id AND pvd.id_poliza = '$ultimaPolizaId'),0) as acumuladas,
                                        (SELECT count(c.id) FROM contratos c WHERE c.id_usuariocreacion = u.id AND c.poliza = '$idPoliza') as diaActual,
                                        (SELECT id_tipoasistencia FROM asistencia a WHERE a.id_usuario = u.id AND a.id_poliza = '$idPoliza') as asistencia
                                        FROM users u
                                        INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        WHERE uf.id_franquicia = '$idFranquicia' AND u.rol_id = '13'";

        }

        return DB::select($query);

    }

    public static function calculoProductividadOptos($idFranquicia, $idPoliza, $ultimaPolizaId, $idUsuario)
    {

        if(strlen($idUsuario) > 0) {
            //idUsuario es diferente de vacio

            $query = "SELECT
                                        u.id as ID,
                                        r.rol as ROL,
                                        u.sueldo as SUELDO,
                                        COALESCE((SELECT pp.totaleco FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as ECOJRANT,
                                        COALESCE((SELECT pp.totaljr FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as JUNIORANT,
                                        COALESCE((SELECT pp.totaldoradouno FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADOUNOANT,
                                        COALESCE((SELECT pp.totaldoradodos FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADODOSANT,
                                        COALESCE((SELECT pp.totalplatino FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as PLATINOANT,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete IN (1,2,3) AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as ECOJR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 4 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as JUNIOR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 5 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as DORADOUNO,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 6 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as DORADODOS,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 7 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as PLATINO,
                                        (SELECT preciom+precioa+preciob+preciot+precioe FROM insumos) as INSUMOS
                                        FROM users u
                                        INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        INNER JOIN roles r ON r.id = u.rol_id
                                    WHERE uf.id_franquicia = '$idFranquicia' AND u.id = '$idUsuario'";

        }else {
            //idUsuario es vacio

            $query = "SELECT
                                        u.id as ID,
                                        r.rol as ROL,
                                        u.sueldo as SUELDO,
                                        COALESCE((SELECT pp.totaleco FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as ECOJRANT,
                                        COALESCE((SELECT pp.totaljr FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as JUNIORANT,
                                        COALESCE((SELECT pp.totaldoradouno FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADOUNOANT,
                                        COALESCE((SELECT pp.totaldoradodos FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADODOSANT,
                                        COALESCE((SELECT pp.totalplatino FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as PLATINOANT,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete IN (1,2,3) AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as ECOJR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 4 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as JUNIOR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 5 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as DORADOUNO,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 6 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as DORADODOS,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 7 AND c.poliza = '$idPoliza' AND c.id_optometrista = u.id) as PLATINO,
                                        (SELECT preciom+precioa+preciob+preciot+precioe FROM insumos) as INSUMOS
                                        FROM users u
                                        INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        INNER JOIN roles r ON r.id = u.rol_id
                                    WHERE uf.id_franquicia = '$idFranquicia' AND u.rol_id = '12'";

        }

        return DB::select($query);

    }

    public static function calculoProductividadAsis($idFranquicia, $idPoliza, $ultimaPolizaId, $idUsuario)
    {

        if(strlen($idUsuario) > 0) {
            //idUsuario es diferente de vacio

            $query = "SELECT
                                        u.id as ID,
                                        r.rol as ROL,
                                        u.sueldo as SUELDO,
                                         COALESCE((SELECT pp.totaleco FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as ECOJRANT,
                                         COALESCE((SELECT pp.totaljr FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as JUNIORANT,
                                         COALESCE((SELECT pp.totaldoradouno FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADOUNOANT,
                                         COALESCE((SELECT pp.totaldoradodos FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADODOSANT,
                                         COALESCE((SELECT pp.totalplatino FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as PLATINOANT,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete IN (1,2,3) AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as ECOJR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 4 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as JUNIOR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 5 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as DORADOUNO,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 6 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as DORADODOS,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 7 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as PLATINO,
                                        (SELECT preciom+precioa+preciob+preciot+precioe FROM insumos) as INSUMOS
                                        FROM users u
                                        INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        INNER JOIN roles r ON r.id = u.rol_id
                                    WHERE uf.id_franquicia = '$idFranquicia' AND u.id = '$idUsuario'";

        }else {
            //idUsuario es vacio

            $query = "SELECT
                                        u.id as ID,
                                        r.rol as ROL,
                                        u.sueldo as SUELDO,
                                         COALESCE((SELECT pp.totaleco FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as ECOJRANT,
                                         COALESCE((SELECT pp.totaljr FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as JUNIORANT,
                                         COALESCE((SELECT pp.totaldoradouno FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADOUNOANT,
                                         COALESCE((SELECT pp.totaldoradodos FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as DORADODOSANT,
                                         COALESCE((SELECT pp.totalplatino FROM polizaproductividad pp  WHERE  pp.id_poliza = '$ultimaPolizaId' AND pp.id_usuario = u.id),0) as PLATINOANT,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete IN (1,2,3) AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as ECOJR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 4 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as JUNIOR,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 5 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as DORADOUNO,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 6 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as DORADODOS,
                                        (SELECT COUNT(hc.id) FROM historialclinico hc INNER JOIN contratos c  ON c.id = hc.id_contrato WHERE hc.id_paquete  = 7 AND c.poliza = '$idPoliza' AND c.id_usuariocreacion = u.id) as PLATINO,
                                        (SELECT preciom+precioa+preciob+preciot+precioe FROM insumos) as INSUMOS
                                        FROM users u
                                        INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        INNER JOIN roles r ON r.id = u.rol_id
                                    WHERE uf.id_franquicia = '$idFranquicia' AND u.rol_id = '13'";

        }

        return DB::select($query);

    }

    public static function calculoDeCobranza($idFranquicia, $idPoliza, $ultimaPolizaId, $idUsuario)
    {

        if(strlen($idUsuario) > 0) {
            //idUsuario es diferente de vacio
            $cobradores = DB::select("SELECT u.id as ID,u.name as NOMBRE,z.zona as ZONA,u.id_zona as idZona,u.sueldo FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        INNER JOIN zonas z ON z.id = u.id_zona WHERE u.id = '$idUsuario' AND uf.id_franquicia = '$idFranquicia'");
        }else {
            //Obtenemos todos los cobradores
            $cobradores = DB::select("SELECT u.id as ID,u.name as NOMBRE,z.zona as ZONA,u.id_zona as idZona,u.sueldo FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id
                                        INNER JOIN zonas z ON z.id = u.id_zona WHERE u.rol_id = '4' AND uf.id_franquicia = '$idFranquicia'");
        }

        $hoy = Carbon::now();
        //$hoy = Carbon::parse("2022-06-23");
        $hoyDiaDelMes = $hoy->format("d");
        $hoyNumero = $hoy->dayOfWeekIso; // Comienza en lunes -> 1 y obtenemos el dia actual de la semana
        $fechaSabadoAntes = self::obtenerDia($hoyNumero, 0); //Obtenemos la fecha del dia sabado anterior
        $fechaSabadoSiguiente = self::obtenerDia($hoyNumero, 2); //Obtenemos la fecha del dia sabado siguiente


        $primerpoliza = true; //Bandera para saber si sera la primerapoliza para hacer el calculo de tabular si no para tomar los datos de la tabla de polizacontratoscobranza
        $idPrimerPoliza = null;

        if(strlen($idUsuario) > 0 && $hoyNumero == 1) {
            //idUsuario es diferente de vacio && es lunes
            $primerpoliza = false;
            $idPrimerPoliza = $idPoliza;
        }

        if(($hoyNumero - 1) > 0) {
            //martes, miercoles, jueves, viernes o sabado

            $fecha = Carbon::parse($hoy)->format('Y-m-d');

            for ($i = ($hoyNumero - 1); $i > 0; $i--) {

                //Obtener fechas de dias anteriores
                $fecha = Carbon::create($fecha)->subDays(1)->format('Y-m-d'); //Descontando dias
                $poliza = DB::select("SELECT id FROM poliza WHERE id_franquicia = '$idFranquicia' AND STR_TO_DATE(created_at,'%Y-%m-%d') = STR_TO_DATE('$fecha','%Y-%m-%d')");

                if($poliza != null) {
                    //Existe poliza
                    $idPrimerPoliza = $poliza[0]->id;
                    $primerpoliza = false;
                }

            }

        }

        foreach ($cobradores as $cobrador) {

            $idCobrador = $cobrador->ID;
            $nombreCobrador = $cobrador->NOMBRE;
            $zonaCobrador = $cobrador->ZONA;
            $idZonaCobrador = $cobrador->idZona;
            $sueldoCobrador = $cobrador->sueldo;
            $tabular = 0;
            $tarjetasPagadas = 0;
            $tarjetaCobrada = 0;
            $cumplioSetentaYCinco = 0;
            $cumplioOchenta = 0;

            if($primerpoliza) {

                $query = "SELECT c.id as ID,
                                    c.estatus_estadocontrato as ESTATUS,
                                        c.ultimoabono as ULTIMOABONO,
                                            c.pago as PAGO,
                                                c.fechaentrega as FECHAENTREGACONTRATO,
							                        (SELECT h.fechaentrega FROM historialclinico h WHERE h.id_contrato = c.id ORDER BY h.created_at DESC LIMIT 1) as FECHAENTREGAHISTORIAL,
								                        c.fechacobroini as INICIAL,
                                                            c.fechacobrofin as FINAL,
                                                                (SELECT g.estadogarantia FROM garantias g WHERE g.id_contrato = c.id AND g.estadogarantia IN (1,2) ORDER BY g.created_at DESC LIMIT 1) as ESTADOGARANTIA
                                                    FROM contratos c
                                                    WHERE c.id_franquicia = '$idFranquicia' AND c.id_zona = '$idZonaCobrador'
                                                    AND (c.estatus_estadocontrato IN (1,2,4,7,10,11,12)
                                                        OR (c.estatus_estadocontrato = 5 AND c.ultimoabono >= '$fechaSabadoAntes'))";

                $contratos = DB::select($query); //Obtenemos todos los contratos
                foreach ($contratos as $contrato) {
                    $tabular = self::validarContratoTabular($tabular, $idPoliza, $contrato->ID, $contrato->ESTATUS, $contrato->ULTIMOABONO,
                        $contrato->PAGO, $contrato->FECHAENTREGACONTRATO, $contrato->FECHAENTREGAHISTORIAL,
                        $contrato->INICIAL, $contrato->FINAL, $contrato->ESTADOGARANTIA, $fechaSabadoAntes, $fechaSabadoSiguiente, $hoy); //Validar para incrementar tabular

                    $tarjetasPagadas = self::validarContratosLiquidados($tarjetasPagadas, $contrato->ESTATUS, $contrato->ULTIMOABONO, $fechaSabadoAntes); //Validar tarjetas pagadas esta semana

                    $tarjetaCobrada = self::validarUltimasTarjetasCobradas($tarjetaCobrada, $idPoliza, $idCobrador, $contrato->ID);
                }

            }else {

                $query = "SELECT c.id as ID,
                                    c.estatus_estadocontrato as ESTATUS,
                                        c.ultimoabono as ULTIMOABONO
                            FROM polizacontratoscobranza pcc INNER JOIN contratos c ON pcc.id_contrato = c.id
                            WHERE pcc.id_poliza = '$idPrimerPoliza' AND c.id_zona = '$idZonaCobrador'";

                $contratos = DB::select($query); //Obtenemos todos los contratos de la tabla de polizacontratoscobranza
                $contratoscancelados = DB::select("SELECT COUNT(c.id) AS contratoscancelados
                                                            FROM polizacontratoscobranza pcc INNER JOIN contratos c ON pcc.id_contrato = c.id
                                                            WHERE pcc.id_poliza = '$idPrimerPoliza' AND c.id_zona = '$idZonaCobrador' AND c.estatus_estadocontrato IN (3,6,8,14)"); //Obtenemos todos los contratos cancelados de la tabla polizacontratoscobranza
                $tabular = count($contratos) - $contratoscancelados[0]->contratoscancelados;

                if($tabular < 0) {
                    $tabular = 0;
                }

                foreach ($contratos as $contrato) {
                    $tarjetasPagadas = self::validarContratosLiquidados($tarjetasPagadas, $contrato->ESTATUS, $contrato->ULTIMOABONO, $fechaSabadoAntes); //Validar tarjetas pagadas esta semana

                    $tarjetaCobrada = self::validarUltimasTarjetasCobradas($tarjetaCobrada, $idPoliza, $idCobrador, $contrato->ID);
                }

            }

            //SECCION PARA OBTENER ARCHIVO
            $archivoQuery = DB::select("SELECT archivo FROM polizacobranza WHERE id_poliza = '$idPoliza' AND id_franquicia = '$idFranquicia' AND id_usuario = '$idCobrador'"); //Tomamos el campo de archivo de la tabla de polizas de cobranza
            $archivo = $archivoQuery == null ? 0 : $archivoQuery[0]->archivo;

            //ESTA SECCION ES PARA CALCULAR LAS TARJETAS ACUMULADAS Y PROMEDIO DE ABONOS
            $tarjetaAcumuladaSemana = $tarjetaCobrada;
            $abonos = DB::select("SELECT SUM(abono) as abono FROM abonos WHERE poliza = '$idPoliza' AND id_usuario = '$idCobrador' GROUP BY folio");
            $abonoPromedioAcumulado = 0;
            if($abonos != null) {
                //Se encontraron abonos
                $sumaabonos = 0;
                foreach ($abonos as $abono) {
                    $sumaabonos += $abono->abono;
                }
                $abonoPromedioAcumulado = $sumaabonos / count($abonos);
            }
            //SECCION PARA CALCULAR LO QUE SE COBRO EN EL DIA
            $ingresoCobranzaQuery = DB::select("SELECT COALESCE(SUM(a.abono),0) as ABONO FROM abonos a WHERE a.id_usuario = '$idCobrador' AND a.poliza = '$idPoliza'");
            $ingresoOficinaQuery = DB::select("SELECT COALESCE(SUM(a.abono),0) as ABONO FROM abonos a INNER JOIN users u INNER JOIN contratos c ON a.id_contrato = c.id
                                                        WHERE u.rol_id IN (6,7,8) AND a.id_usuario = u.id AND a.poliza = '$idPoliza' AND c.id_zona = '$idZonaCobrador'");
            $ingresoCobranza = $ingresoCobranzaQuery == null ? 0 : $ingresoCobranzaQuery[0]->ABONO;
            $ingresoOficina = $ingresoOficinaQuery == null ? 0 : $ingresoOficinaQuery[0]->ABONO;
            $ingresoAcumulado = $ingresoCobranza + $ingresoOficina; //Lo igualamos al ingreso cobranza mas el ingreso oficina
            if ($hoyNumero > 1) {
                //Otro dia que no es lunes
                if ($ultimaPolizaId != null) {
                    $polizaCobranza = DB::select("SELECT acumuladasemana as ACUMULADA,promedioacumulado as PROMEDIOANTERIOR,ingresoacumulado as INGRESOACUMULADO FROM polizacobranza WHERE id_poliza = '$ultimaPolizaId' AND id_usuario = '$idCobrador'");
                    $acumulada = $polizaCobranza == null ? 0 :  $polizaCobranza[0]->ACUMULADA ;
                    $tarjetaAcumuladaSemana = $tarjetaAcumuladaSemana + $acumulada;
                    //SECCION PARA PROMEDIO DE ABONOS
                    $promedioAnterior = $polizaCobranza == null ? 0 : $polizaCobranza[0]->PROMEDIOANTERIOR;
                    $abonoPromedioAcumulado = ($abonoPromedioAcumulado + $promedioAnterior) / 2;
                    //SECCION PARA CALCULAR EL ACUMULADO DE ABONO EN $$
                    $ingresoAcumuladoAnterior = $polizaCobranza == null ? 0 : $polizaCobranza[0]->INGRESOACUMULADO;
                    $ingresoAcumulado = $ingresoAcumulado + $ingresoAcumuladoAnterior;
                }
            }

            //SECCION PARA CALCULAR EL DIARIO ACUMULADO
            if($tabular > 0){
                $diarioAcumulado = ($tarjetaAcumuladaSemana * 100) / $tabular;
            }else{
                $diarioAcumulado = 0;
            }

            //SECCION PARA SABER SI EL COBRADOR RECIBIO PARA LA GAS
            $existeGastoGasCobrador = DB::select("SELECT gas FROM polizacobranza WHERE id_poliza = '$idPoliza' AND id_usuario = '$idCobrador'");
            $gas = $existeGastoGasCobrador == null ? 0 : $existeGastoGasCobrador[0]->gas;

            $tarjetasAlSetentaYCinco = $tabular * 0.75;
            $tarjetasPorCobrarAlSetentaYCinco = $tarjetasAlSetentaYCinco - $tarjetaAcumuladaSemana;
            $dineroPorCobrarAlSetentaYCinco = $tarjetasPorCobrarAlSetentaYCinco * 150;
            $tarjetasAlOchenta = $tabular * 0.80;
            $tarjetasPorCobrarAlOchenta = $tarjetasAlOchenta - $tarjetaAcumuladaSemana;
            $dineroPorCobrarAlOchenta = $tarjetasPorCobrarAlOchenta * 150;


            $total = $sueldoCobrador;
            if ($tarjetasPorCobrarAlSetentaYCinco <= 0) {
                $cumplioSetentaYCinco = $ingresoAcumulado * 0.06;
                $total += $cumplioSetentaYCinco;
            } elseif ($tarjetasPorCobrarAlOchenta <= 0) {
                $cumplioSetentaYCinco = 0;
                $cumplioOchenta = $ingresoAcumulado * 0.08;
                $total += $cumplioOchenta;
            }

            if(strlen($idUsuario) > 0) {
                //idUsuario es diferente de vacio

                DB::table("polizacobranza")
                    ->where("id_usuario", "=", $idCobrador)
                    ->where("id_franquicia", "=", $idFranquicia)
                    ->where("id_poliza", "=", $idPoliza)
                    ->update([
                        "fechapoliza" => $hoy,
                        "nombre" => $nombreCobrador,
                        "zona" => $zonaCobrador,
                        "tabular" => $tabular,
                        "archivo" => $archivo,
                        "pagadas" => $tarjetasPagadas,
                        "cobradas" => $tarjetaCobrada,
                        "acumuladasemana" => $tarjetaAcumuladaSemana,
                        "diarioacumulado" => $diarioAcumulado,
                        "promedioacumulado" => $abonoPromedioAcumulado,
                        "gas" => $gas,
                        "ingresocobranza" => $ingresoCobranza,
                        "ingresooficina" => $ingresoOficina,
                        "ingresoacumulado" => $ingresoAcumulado,
                        "sueldo" => $sueldoCobrador,
                        "totalpagar" => $total
                ]);

            }else {
                //idUsuario es vacio

                DB::table("polizacobranza")->insert([
                    "id_usuario" => $idCobrador,
                    "id_franquicia" => $idFranquicia,
                    "id_poliza" => $idPoliza,
                    "fechapoliza" => $hoy,
                    "nombre" => $nombreCobrador,
                    "zona" => $zonaCobrador,
                    "tabular" => $tabular,
                    "archivo" => $archivo,
                    "pagadas" => $tarjetasPagadas,
                    "cobradas" => $tarjetaCobrada,
                    "acumuladasemana" => $tarjetaAcumuladaSemana,
                    "diarioacumulado" => $diarioAcumulado,
                    "promedioacumulado" => $abonoPromedioAcumulado,
                    "gas" => $gas,
                    "ingresocobranza" => $ingresoCobranza,
                    "ingresooficina" => $ingresoOficina,
                    "ingresoacumulado" => $ingresoAcumulado,
                    //"tarjetassietecinco" =>$tarjetasAlSetentaYCinco,
                    //"tarjetascobrarsietecinco" => $tarjetasPorCobrarAlSetentaYCinco,
                    //"cobrarsietecinco" => $dineroPorCobrarAlSetentaYCinco,
                    //"tarjetasochenta" =>$tarjetasAlOchenta,
                    //"tarjetascobrarochenta"=>$tarjetasPorCobrarAlOchenta,
                    //"cobrarochenta"=>$dineroPorCobrarAlOchenta,
                    "sueldo" => $sueldoCobrador,
                    //"seissietecinco" => $cumplioSetentaYCinco,
                    //"ochosietecinco" => $cumplioOchenta,
                    "totalpagar" => $total
                ]);

            }

        }

    }

    private static function validarUltimasTarjetasCobradas($tarjetaCobrada, $idPoliza, $idCobrador, $idContrato)
    {

        $contrado = DB::select("SELECT id FROM abonos WHERE id_contrato = '$idContrato' AND poliza = '$idPoliza' AND id_usuario = '$idCobrador'"); //Obtenemos los abonos del contrato
        if ($contrado != null) { //Hay abonos??
            //Si hay abonos
            return $tarjetaCobrada + 1;
        }
        //No hay abonos
        return $tarjetaCobrada;
    }

    private static function validarContratosLiquidados($tarjetasPagadas, $estatus, $ultimoAbono, $fechaSabado)
    {
        if ($estatus == 5) { //Es un contrato pagado?
            //Si esta pagado
            $ultimoAbono = Carbon::parse($ultimoAbono);
            if ($ultimoAbono->gte($fechaSabado)) { //La fecha del abono es mayor o igual al dia sabado?
                return $tarjetasPagadas + 1;
            }
        }
        return $tarjetasPagadas;
    }

    private static function validarContratoTabular($tabular, $idPoliza, $idContrato, $estadoContrato, $ultimoAbono, $pago, $fechaEntregaContrato, $fechaEntregaHistorial, $fechaCobroInicial, $fechaCobroFinal, $estadoGarantia, $fechaSabadoAnterior, $fechaSabadoSiguiente, $hoy)
    {

        if($estadoGarantia != null) { //Tiene garantia?
            //Tiene garantia
            if($estadoGarantia == 2) { //Estado garantia es CREADA?
                //Estado garantia es CREADA
                if($estadoContrato == 1 || $estadoContrato == 7 || $estadoContrato == 9 || $estadoContrato == 10 || $estadoContrato == 11) {
                    //estadoContrato TERMINADO, APROBADO, EN PROCESO DE APROBACION, MANUFACTURA, EN PROCESO DE ENVIO
                    DB::table('polizacontratoscobranza')->insert([
                        'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                    ]);
                    return $tabular + 1;
                }
            }elseif($estadoGarantia == 3) { //Estado garantia es ENVIADO (LO REALIZA LABORATORIO)?
                //Estado garantia es ENVIADO
                if($estadoContrato == 2) { //estadoContrato ENTREGADO?
                    //estadoContrato ENTREGADO
                    if($fechaCobroInicial == null) { //fechacobroini es null?
                        //fechacobroini es null
                        DB::table('polizacontratoscobranza')->insert([
                            'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                        ]);
                        return $tabular + 1;
                    }
                }
                if($estadoContrato == 12) { //estadoContrato ENVIADO?
                    //estadoContrato ENVIADO
                    DB::table('polizacontratoscobranza')->insert([
                        'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                    ]);
                    return $tabular + 1;
                }
            }

        }else {
            //No tiene garantia

            if(($estadoContrato == 7 || $estadoContrato == 10 || $estadoContrato == 11 || $estadoContrato == 12)
                && (Carbon::parse($fechaEntregaHistorial)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                    && Carbon::parse($fechaEntregaHistorial)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d'))) {
                //estadoContrato APROBADO, EN PROCESO DE APROBACION, MANUFACTURA, EN PROCESO DE ENVIO, ENVIADO && fechadeentregahistorialcaeensabadoanterioraviernessiguiente
                DB::table('polizacontratoscobranza')->insert([
                    'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                ]);
                return $tabular + 1;
            }elseif($estadoContrato == 5) { //estadoContrato LIQUIDADO?
                //estadoContrato LIQUIDADO
                if((Carbon::parse($ultimoAbono)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                    && Carbon::parse($ultimoAbono)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d'))) {
                    //tieneabonoensabadoanterioraviernessiguiente
                    DB::table('polizacontratoscobranza')->insert([
                        'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                    ]);
                    return $tabular + 1;
                }
            }elseif($estadoContrato == 2 || $estadoContrato == 4) {
                //estadoContrato ENTREGADO o ABONO ATRASADO

                if($estadoContrato == 2 &&
                    (Carbon::parse($fechaEntregaContrato)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                        && Carbon::parse($fechaEntregaContrato)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d'))) {
                    //estadoContrato ENTREGADO && fechaentregacontratocaeensabadoanterioraviernessiguiente
                    DB::table('polizacontratoscobranza')->insert([
                        'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                    ]);
                    return $tabular + 1;
                }else {

                    if($pago == 1) {
                        //SEMANAL
                        if(((Carbon::parse($fechaCobroInicial)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                                    && Carbon::parse($fechaCobroInicial)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d'))
                                || (Carbon::parse($fechaCobroFinal)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                                    && Carbon::parse($fechaCobroFinal)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d')))
                            && Carbon::parse($ultimoAbono)->format('Y-m-d') < Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')) {
                            //fechaini y fechafin caen en la semana actual (sabadoanterioraviernessiguiente) && notenganabonoensabadoanterioraviernessiguiente
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        }
                    }else {
                        //QUINCENAL O MENSUAL
                        if(((Carbon::parse($fechaCobroInicial)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                                    && Carbon::parse($fechaCobroInicial)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d'))
                                || (Carbon::parse($fechaCobroFinal)->format('Y-m-d') >= Carbon::parse($fechaSabadoAnterior)->format('Y-m-d')
                                    && Carbon::parse($fechaCobroFinal)->format('Y-m-d') < Carbon::parse($fechaSabadoSiguiente)->format('Y-m-d')))
                            && Carbon::parse($ultimoAbono)->format('Y-m-d') < Carbon::parse($fechaCobroInicial)->format('Y-m-d')) {
                            //fechaini y fechafin caen en la semana actual (sabadoanterioraviernessiguiente) && notenganabonoenperiodofechainiyfechafin
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        }
                    }

                }
            }
        }

        /*if ($estatus == 5) { //Es un contrato pagado?
            //Si esta pagado
            $ultimoAbono = Carbon::parse($ultimoAbono);
            $tienePolizaElAbono = self::validarPolizaAbono($idContrato, $idPoliza);
            if ($ultimoAbono->gte($fechaSabadoAnterior) && !$tienePolizaElAbono) { //La fecha del abono es mayor o igual al dia sabado? y el abono no tiene ya una poliza?
                DB::table('polizacontratoscobranza')->insert([
                    'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                ]);
                return $tabular + 1;
            }
        } else {
            //No no esta pagado
            if (($hoyDiaDelMes >= 8 && $hoyDiaDelMes <= 15) || ($hoyDiaDelMes >= 22 && $hoyDiaDelMes <= 28)) { //Deberian ser solo semanales
                if ($pago == 2) { //Si la forma de pago es quincenal
                    //Es un quincenal
                    $fechaEntrega = Carbon::parse($fechaEntrega);
                    $tienePolizaElAbono = self::validarPolizaAbono($idContrato, $idPoliza);
                    if ($fechaEntrega >= $fechaSabadoAnterior) { //Contrato nuevo y tiene fecha de entrega
                        DB::table('polizacontratoscobranza')->insert([
                            'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                        ]);
                        return $tabular + 1;
                    } elseif ($diaSeleccionado != null && Carbon::parse($diaSeleccionado) <= $fechaSabadoSiguiente) { // Si el dia seleccionado es menor o igual al sabado siguiente como un dia 15
                        DB::table('polizacontratoscobranza')->insert([
                            'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                        ]);
                        return $tabular + 1;
                    } elseif (($fechaCobroInicial >= $fechaSabadoAnterior || $fechaCobroFinal <= $fechaSabadoSiguiente) && !$tienePolizaElAbono) { //Como es quincenal, validamos si su fecha inicial es mayor al sabado anterior o su fecha final menor al sabado siguiente y no tenga poliza el abono
                        DB::table('polizacontratoscobranza')->insert([
                            'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                        ]);
                        return $tabular + 1;
                    }
                } elseif ($pago == 4) { //Si la forma de pago es mensual
                    $fechaEntrega = Carbon::parse($fechaEntrega);
                    if ($fechaEntrega >= $fechaSabadoAnterior) { //Contrato nuevo y tiene fecha de entrega
                        DB::table('polizacontratoscobranza')->insert([
                            'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                        ]);
                        return $tabular + 1;
                    }
                } else {
                    //Es semanal
                    DB::table('polizacontratoscobranza')->insert([
                        'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                    ]);
                    return $tabular + 1;
                }
            } elseif ($hoyDiaDelMes >= 16 && $hoyDiaDelMes <= 21) { //Deberian ser solo semanales y quincenales
                if ($pago == 0 || $pago == 4) { //Si es un de contado o mensual
                    $fechaEntrega = Carbon::parse($fechaEntrega);
                    if ($fechaEntrega >= $fechaSabadoAnterior) { //Como son de contado o mensuales validamos si tienen una fecha de entrega en esta semana
                        DB::table('polizacontratoscobranza')->insert([
                            'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                        ]);
                        return $tabular + 1;
                    }
                } else { //Semanales y quincenales
                    $tienePolizaElAbono = self::validarPolizaAbono($idContrato, $idPoliza);
                    if ($pago == 1) { //  Semanal
                        if (($fechaCobroInicial >= $fechaSabadoAnterior || $fechaCobroFinal <= $fechaSabadoSiguiente) && $diaSeleccionado != null && Carbon::parse($diaSeleccionado) <= $fechaSabadoAnterior && !$tienePolizaElAbono) { //Semanal con dia seleccionado un 15
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        } elseif (($fechaCobroInicial >= $fechaSabadoAnterior || $fechaCobroFinal <= $fechaSabadoSiguiente) && $ultimoAbono < $fechaSabadoAnterior && !$tienePolizaElAbono) { //En caso de que tenga un abono ya en el periodo pero fue en la semana pasada
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        }
                        if ($fechaCobroInicial >= $fechaSabadoAnterior || $fechaCobroFinal <= $fechaSabadoSiguiente) { //Abono en el periodo
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        }
                    } else { //Quincenal
                        if (($fechaCobroInicial >= $fechaSabadoAnterior || $fechaCobroFinal <= $fechaSabadoSiguiente) && $ultimoAbono < $fechaSabadoAnterior && !$tienePolizaElAbono) { //En caso de que tenga un abono ya en el periodo pero fue en la semana pasada
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        } elseif ($fechaCobroInicial >= $fechaSabadoAnterior || $fechaCobroFinal <= $fechaSabadoSiguiente) {//Abono en el periodo
                            DB::table('polizacontratoscobranza')->insert([
                                'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                            ]);
                            return $tabular + 1;
                        }
                    }
                }

            } else { // del 29 al 7 entran todos
                DB::table('polizacontratoscobranza')->insert([
                    'id_poliza' => $idPoliza, 'id_contrato' => $idContrato, 'created_at' => $hoy
                ]);
                $tabular = $tabular + 1;
            }
        }*/

        return $tabular;
    }

    private static function validarPolizaAbono($idContrato, $idPoliza)
    {
        $tienePolizaElAbono = DB::select("SELECT poliza FROM abonos WHERE id_contrato = '$idContrato' ORDER BY created_at DESC LIMIT 1");
        if ($tienePolizaElAbono != null) { //Ya tiene una poliza?
            if ($tienePolizaElAbono[0]->poliza == $idPoliza) {//Si tiene una poliza igual a la actual es porque aun no se contabilizaba
                return false;
            }
            //Quiere decir que ya tenia una poliza diferente a la actual
            return true;
        }
        return false;
    }

    public static function obtenerDia($diaActualNumero, $diaSeleccionado)
    {
        //Dia seleccionado
        // 0-> SabadoAnterior
        // 1-> Lunes
        // 2-> SabadoSiguiente

        switch ($diaActualNumero) {
            case 1://Es Lunes
                if ($diaSeleccionado == 0) {
                    return Carbon::now()->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                }
                return Carbon::now()->addDays(5)->format('Y-m-d'); //Obtengo la fecha del dia sabado siguiente
            case 2://Es Martes
                if ($diaSeleccionado == 0) {
                    return Carbon::now()->subDays(3)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return Carbon::now()->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                }
                return Carbon::now()->addDays(4)->format('Y-m-d'); //Obtengo la fecha del dia sabado siguiente
            case 3://Es Miercoles
                if ($diaSeleccionado == 0) {
                    return Carbon::now()->subDays(4)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return Carbon::now()->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                }
                return Carbon::now()->addDays(3)->format('Y-m-d'); //Obtengo la fecha del dia sabado siguiente
            case 4://Es Jueves
                if ($diaSeleccionado == 0) {
                    return Carbon::now()->subDays(5)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return Carbon::now()->subDays(3)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                }
                return Carbon::now()->addDays(2)->format('Y-m-d'); //Obtengo la fecha del dia sabado siguiente
            case 5://Es Viernes
                if ($diaSeleccionado == 0) {
                    return Carbon::now()->subDays(6)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return Carbon::now()->subDays(4)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                }
                return Carbon::now()->addDays(1)->format('Y-m-d'); //Obtengo la fecha del dia sabado siguiente
            case 6://Es Sabado
                if ($diaSeleccionado == 0) {
                    return Carbon::now()->subDays(7)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return Carbon::now()->subDays(5)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                }
                return Carbon::now()->addDays(0)->format('Y-m-d'); //Obtengo la fecha del dia sabado siguiente
        }
        return Carbon::now();
    }

    public static function entregarPoliza($idFranquicia,$idPoliza){

        $idUsuario = Auth::id();
        $usuario = Auth::user()->name;
        $hoy = Carbon::now();
        DB::table("poliza")->where("id","=",$idPoliza)->where("id_franquicia","=",$idFranquicia)->update([
            "estatus" => 2,
            "updated_at" => $hoy,
            "realizo" => $usuario
        ]);

        DB::table('historialpoliza')->insert([
            'id_usuarioC' =>  $idUsuario, 'id_poliza' => $idPoliza, 'created_at' => $hoy,
            'cambios' => "El usuario '$usuario' entrego la poliza."
        ]);
    }

    public static function entregarORegresarPoliza($idPoliza,$entregarORegresar){
        $idUsuario = Auth::id();
        $usuario = Auth::user()->name;
        $hoy = Carbon::now();
        if($entregarORegresar == 1){
            DB::table("poliza")->where("id","=",$idPoliza)->update([
                "estatus" => 1,
                "updated_at" => $hoy,
                "autorizo" => $usuario
            ]);

            DB::table('historialpoliza')->insert([
                'id_usuarioC' =>  $idUsuario, 'id_poliza' => $idPoliza, 'created_at' => $hoy,
                'cambios' => "El usuario '$usuario' autorizo la poliza."
            ]);
        }else{
            DB::table("poliza")->where("id","=",$idPoliza)->update([
                "estatus" => 0,
                "updated_at" => $hoy,
                "autorizo" => $usuario
            ]);

            DB::table('historialpoliza')->insert([
                'id_usuarioC' =>  $idUsuario, 'id_poliza' => $idPoliza, 'created_at' => $hoy,
                'cambios' => "El usuario '$usuario' regreso la poliza a su estado anterior."
            ]);
        }

    }

    public static function obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $fechaCreacionPolizaEntrante, $id_usuario, $opcion)
    {
        //opcion
        //0 - Contratos por entregar
        //1 - Contratos monto total real

        $sumaContratos = 0;
        $query = self::obtenerQueryProductividadPoliza($idPoliza, $id_usuario, $opcion);

        //Se obtienen los contratos de idpoliza entrante
        $contratosPolizaEntrante = DB::select($query);

        if($contratosPolizaEntrante != null) {
            //Existen contratos por entregar
            $sumaContratos += $contratosPolizaEntrante[0]->suma;
        }

        $fechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->format('Y-m-d'); //Se obtiene fechaCreacionPolizaEntrante con formato Ejem. 2022-04-01
        $diaEnNumeroFechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->dayOfWeekIso - 1; //Se obtiene el numero de la semana de la fechaCreacionPolizaEntrante se le resta un dia para no volver a contar la entrante si no solamente las anteriores

        if($diaEnNumeroFechaCreacionPolizaEntrante > 0) {
            //$diaEnNumeroFechaCreacionPolizaEntrante es martes, miercoles, jueves, viernes o sabado

            $fecha = $fechaCreacionPolizaEntrante;

            for ($i = $diaEnNumeroFechaCreacionPolizaEntrante; $i > 0; $i--) {

                //Obtener fechas de dias anteriores
                $fecha = Carbon::create($fecha)->subDays(1)->format('Y-m-d'); //Descontando dias
                $poliza = DB::select("SELECT id FROM poliza WHERE id_franquicia = '$idFranquicia' AND STR_TO_DATE(created_at,'%Y-%m-%d') = STR_TO_DATE('$fecha','%Y-%m-%d')");

                if($poliza != null) {
                    //Existe poliza

                    $idPolizaExistente = $poliza[0]->id;

                    $query = self::obtenerQueryProductividadPoliza($idPolizaExistente, $id_usuario, $opcion);

                    $contratos = DB::select($query);

                    if($contratos != null) {
                        //Existen contratos por entregar
                        $sumaContratos += $contratos[0]->suma;
                    }

                }
            }

        }

        return $sumaContratos;

    }

    private static function obtenerQueryProductividadPoliza($idPoliza, $id_usuario, $opcion) {

        $query = "";

        switch ($opcion) {
            case 0:
                //Suma contratos por entregar OPTOMETRISTA
                $query = "SELECT COUNT(c.id) as suma FROM contratos c WHERE c.poliza = '$idPoliza' AND c.id_optometrista = '$id_usuario' AND c.estatus_estadocontrato IN (1,7,9,10,11,12)";
                break;
            case 1:
                //Suma monto total real OPTOMETRISTA
                $query = "SELECT COALESCE(SUM(c.totalreal),0) as suma FROM contratos c WHERE c.poliza = '$idPoliza' AND c.id_optometrista = '$id_usuario'";
                break;
            case 2:
                //Contratos entregados OPTOMETRISTA
                $query = "SELECT c.id, h.id_paquete, c.totalreal FROM contratos c INNER JOIN historialclinico h ON c.id = h.id_contrato WHERE c.poliza = '$idPoliza' AND c.id_optometrista = '$id_usuario' AND (c.estatus_estadocontrato IN (2,4,5) OR c.id IN (SELECT g.id_contrato FROM garantias g WHERE g.estadocontratogarantia IN (2,4,5) AND g.estadogarantia IN (1,2)))";
                break;
            case 3:
                //Suma contratos objetivo semana anterior ASISTENTE
                $query = "SELECT COUNT(c.id) as suma FROM contratos c WHERE c.poliza = '$idPoliza' AND c.id_usuariocreacion = '$id_usuario' AND (c.estatus_estadocontrato IN (2,4,5,7,10,11,12) OR c.id IN (SELECT g.id_contrato FROM garantias g WHERE g.estadogarantia IN (1,2)))";
                break;
            case 4:
                //Suma contratos no.ventas o ventas acumuladas semana actual ASISTENTE
                $query = "SELECT COUNT(c.id) as suma FROM contratos c WHERE c.poliza = '$idPoliza' AND c.id_usuariocreacion = '$id_usuario' AND (c.estatus_estadocontrato IN (1,2,4,5,7,9,10,11,12) OR c.id IN (SELECT g.id_contrato FROM garantias g WHERE g.estadogarantia IN (1,2)))";
                break;
            case 5:
                //Suma contratos entregados o ventas acumuladas entregadas semana actual ASISTENTE
                $query = "SELECT COUNT(c.id) as suma FROM contratos c WHERE c.poliza = '$idPoliza' AND c.id_usuariocreacion = '$id_usuario' AND (c.estatus_estadocontrato IN (2,4,5,7,10,11,12) OR c.id IN (SELECT g.id_contrato FROM garantias g WHERE g.estadogarantia IN (1,2)))";
                break;
        }

        return $query;
    }

    public static function obtenerNumeroContratosEntregadosAbonoAtrasadoLiquidadosConGarantiaPorPaqueteYContratosYSumaTotalRealContratosEntregadosPorUsuario($idFranquicia, $idPoliza, $fechaCreacionPolizaEntrante, $id_usuario) {

        $arrayRespuesta = array();
        $arrayNumContratosPorPaquetes = array();

        $query = self::obtenerQueryProductividadPoliza($idPoliza, $id_usuario, 2);

        //Se obtienen los contratos entregados del idpoliza entrante
        $contratosEntregadosAbonoAtrasadoLiquidadosConGarantia = DB::select($query);

        $array = array();
        $contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto = array();

        if($contratosEntregadosAbonoAtrasadoLiquidadosConGarantia != null) {
            //Existen contratos entregados

            foreach ($contratosEntregadosAbonoAtrasadoLiquidadosConGarantia as $contrato) {
                $idContrato = $contrato->id;
                if(!in_array($idContrato, $array)) {
                    //No existe contrato en el arreglo $contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto
                    array_push($contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto, $contrato); //Agregacion a $contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto
                    array_push($array, $idContrato); //Se agrega el id del contrato al array para que este no vuelva a insertarse de nuevo
                }
            }

        }

        $fechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->format('Y-m-d'); //Se obtiene fechaCreacionPolizaEntrante con formato Ejem. 2022-04-01
        $diaEnNumeroFechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->dayOfWeekIso - 1; //Se obtiene el numero de la semana de la fechaCreacionPolizaEntrante se le resta un dia para no volver a contar la entrante si no solamente las anteriores

        if($diaEnNumeroFechaCreacionPolizaEntrante > 0) {
            //$diaEnNumeroFechaCreacionPolizaEntrante es martes, miercoles, jueves, viernes o sabado

            $fecha = $fechaCreacionPolizaEntrante;

            for ($i = $diaEnNumeroFechaCreacionPolizaEntrante; $i > 0; $i--) {

                //Obtener fechas de dias anteriores
                $fecha = Carbon::create($fecha)->subDays(1)->format('Y-m-d'); //Descontando dias
                $poliza = DB::select("SELECT id FROM poliza WHERE id_franquicia = '$idFranquicia' AND STR_TO_DATE(created_at,'%Y-%m-%d') = STR_TO_DATE('$fecha','%Y-%m-%d')");

                if($poliza != null) {
                    //Existe poliza

                    $idPolizaExistente = $poliza[0]->id;

                    $query = self::obtenerQueryProductividadPoliza($idPolizaExistente, $id_usuario, 2);
                    $contratos = DB::select($query);

                    if($contratos != null) {
                        //Existen contratos entregados
                        foreach ($contratos as $contrato) {
                            $idContrato = $contrato->id;
                            if(!in_array($idContrato, $array)) {
                                //No existe contrato en el arreglo $contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto
                                array_push($contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto, $contrato); //Agregacion a $contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto
                                array_push($array, $idContrato); //Se agrega el id del contrato al array para que este no vuelva a insertarse de nuevo
                            }
                        }
                    }

                }
            }

        }

        $sumaTotalRealContratosEntregados = 0; //Para guardar la suma de los totalReal de los contratos entregados
        foreach ($contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto as $contratoCorrecto) {
            //Recorrido para obtener el numero de contratos entregados por paquetes
            $id_paquete = $contratoCorrecto->id_paquete;
            $totalReal = $contratoCorrecto->totalreal;
            $sumaTotalRealContratosEntregados += $totalReal;
            if(array_key_exists($id_paquete, $arrayNumContratosPorPaquetes)) {
                //Existe la llave del id_paquete
                $arrayNumContratosPorPaquetes[$id_paquete] = $arrayNumContratosPorPaquetes[$id_paquete] + 1;
            }else {
                //No se encontro la llave del id_paquete
                $arrayNumContratosPorPaquetes[$id_paquete] = 1;
            }
        }

        array_push($arrayRespuesta, $arrayNumContratosPorPaquetes);
        array_push($arrayRespuesta, $contratosEntregadosAbonoAtrasadoLiquidadosConGarantiaCorrecto);
        array_push($arrayRespuesta, $sumaTotalRealContratosEntregados);

        return $arrayRespuesta;

    }

    public static function obtenerDineroObjetivoEnVentas($contratos, $numeroventas, $totaleco, $totaljr, $totaldoradounoydoradodos, $totalplatino) {

        $arrayRespuesta = array();

        $dinerotreinta = 0;
        $dinerocuarenta = 0;

        $numeroventastreintaboolean = $numeroventas >= 30 ? true : false;

        if($numeroventastreintaboolean) {
            //No.ventas es mayor o igual a 30

            $sumaTotalRealEcoJr = 0;
            $sumaTotalRealJr = 0;
            $sumaTotalRealDorado1YDorado2 = 0;
            $sumaTotalRealPlatino = 0;

            foreach ($contratos as $contrato) {
                $idPaquete = $contrato->id_paquete;
                $totalRealContrato = $contrato->totalreal;
                switch ($idPaquete) {
                    case 1:
                    case 2:
                    case 3://Lectura, Proteccion y Eco Jr
                        $sumaTotalRealEcoJr += $totalRealContrato;
                        break;
                    case 4://Jr
                        $sumaTotalRealJr += $totalRealContrato;
                        break;
                    case 5:
                    case 6://Dorado 1 y Dorado 2
                        $sumaTotalRealDorado1YDorado2 += $totalRealContrato;
                        break;
                    case 7://Platino
                        $sumaTotalRealPlatino += $totalRealContrato;
                        break;
                }
            }

            $numeroventascuarentaboolean = $numeroventas >= 40 ? true : false;
            if($numeroventascuarentaboolean) {
                //No.ventas es mayor o igual a 40
                $dinerocuarenta = ($sumaTotalRealEcoJr + $sumaTotalRealJr + $sumaTotalRealDorado1YDorado2 + $sumaTotalRealPlatino) * 0.03;
            }else {
                //No.ventas es menor a 40

                $validacionEcoJr = $totaleco >= 24 ? true : false;
                $validacionJr = $totaljr >= 4 ? true : false;
                $validacionDorado1YDorado2 = $totaldoradounoydoradodos >= 10 ? true : false;
                $validacionPlatino = $totalplatino >= 2 ? true : false;

                if (!$validacionEcoJr) {
                    $sumaTotalRealEcoJr = 0;
                }

                if (!$validacionJr) {
                    $sumaTotalRealJr = 0;
                }

                if (!$validacionDorado1YDorado2) {
                    $sumaTotalRealDorado1YDorado2 = 0;
                }

                if (!$validacionPlatino) {
                    $sumaTotalRealPlatino = 0;
                }

                if ($validacionEcoJr || $validacionJr || $validacionDorado1YDorado2 || $validacionPlatino) {
                    $dinerotreinta = ($sumaTotalRealEcoJr + $sumaTotalRealJr + $sumaTotalRealDorado1YDorado2 + $sumaTotalRealPlatino) * 0.03;
                } else {
                    $dinerotreinta = 500;
                }

            }

        }

        array_push($arrayRespuesta, $dinerotreinta);
        array_push($arrayRespuesta, $dinerocuarenta);

        return $arrayRespuesta;

    }

    public static function obtenerNumeroObjetivoSemanaAnteriorAsistente($idFranquicia, $fechaCreacionPolizaEntrante, $id_usuario)
    {

        $numObjetivoSemanaAnterior = 0;

        $fechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->format('Y-m-d'); //Se obtiene fechaCreacionPolizaEntrante con formato Ejem. 2022-04-01
        $diaEnNumeroFechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->dayOfWeekIso; //Se obtiene el numero de la semana de la fechaCreacionPolizaEntrante

        if($diaEnNumeroFechaCreacionPolizaEntrante > 0) {
            //diaEnNumeroFechaCreacionPolizaEntrante es lunes, martes, miercoles, jueves, viernes o sabado

            $fecha = $fechaCreacionPolizaEntrante;
            $bandera = 0;

            for ($i = $diaEnNumeroFechaCreacionPolizaEntrante; $i >= 0; $i--) {

                if($bandera == 0) {
                    if ($i == 0) {
                        $i = 6; //Empezar desde el sabado
                        $bandera = 1;
                    }
                }

                //Obtener fechas de dias anteriores
                $fecha = Carbon::create($fecha)->subDays(1)->format('Y-m-d'); //Descontando dias

                if($bandera == 1) {

                    $poliza = DB::select("SELECT id FROM poliza WHERE id_franquicia = '$idFranquicia' AND STR_TO_DATE(created_at,'%Y-%m-%d') = STR_TO_DATE('$fecha','%Y-%m-%d')");

                    if ($poliza != null) {
                        //Existe poliza

                        $idPolizaExistente = $poliza[0]->id;

                        $query = self::obtenerQueryProductividadPoliza($idPolizaExistente, $id_usuario, 3);

                        $contratos = DB::select($query);

                        if ($contratos != null) {
                            //Existen contratos por entregar
                            $numObjetivoSemanaAnterior += $contratos[0]->suma;
                        }

                    }
                }

            }

        }

        return $numObjetivoSemanaAnterior;

    }

    public static function obtenerNoVentasAprobadasVentasAcumuladasYVentasAcumuladasAprobadasAsistente($idFranquicia, $idPoliza, $fechaCreacionPolizaEntrante, $id_usuario)
    {

        $arrayResultados = array();

        $sumaContratosNumVentas = 0;
        $sumaContratosAprobadas = 0;
        $sumaContratosVentasAcumuladas = 0;
        $sumaContratosVentasAcumuladasAprobadas = 0;

        //Se obtienen los contratos de idpoliza entrante
        $query1 = self::obtenerQueryProductividadPoliza($idPoliza, $id_usuario, 4);
        $contratosPolizaEntrante1 = DB::select($query1);
        if($contratosPolizaEntrante1 != null) {
            //Existen contratos
            $sumaContratosNumVentas += $contratosPolizaEntrante1[0]->suma; //Suma numero ventas
        }

        $query2 = self::obtenerQueryProductividadPoliza($idPoliza, $id_usuario, 5);
        $contratosPolizaEntrante2 = DB::select($query2);
        if($contratosPolizaEntrante2 != null) {
            //Existen contratos
            $sumaContratosAprobadas += $contratosPolizaEntrante2[0]->suma; //Suma numero entregados
        }

        $fechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->format('Y-m-d'); //Se obtiene fechaCreacionPolizaEntrante con formato Ejem. 2022-04-01
        $diaEnNumeroFechaCreacionPolizaEntrante = Carbon::parse($fechaCreacionPolizaEntrante)->dayOfWeekIso - 1; //Se obtiene el numero de la semana de la fechaCreacionPolizaEntrante se le resta un dia para no volver a contar la entrante si no solamente las anteriores

        if($diaEnNumeroFechaCreacionPolizaEntrante > 0) {
            //diaEnNumeroFechaCreacionPolizaEntrante es martes, miercoles, jueves, viernes o sabado

            $fecha = $fechaCreacionPolizaEntrante;

            for ($i = $diaEnNumeroFechaCreacionPolizaEntrante; $i > 0; $i--) {

                //Obtener fechas de dias anteriores
                $fecha = Carbon::create($fecha)->subDays(1)->format('Y-m-d'); //Descontando dias
                $poliza = DB::select("SELECT id FROM poliza WHERE id_franquicia = '$idFranquicia' AND STR_TO_DATE(created_at,'%Y-%m-%d') = STR_TO_DATE('$fecha','%Y-%m-%d')");

                if($poliza != null) {
                    //Existe poliza

                    $idPolizaExistente = $poliza[0]->id;

                    $query1 = self::obtenerQueryProductividadPoliza($idPolizaExistente, $id_usuario, 4);
                    $contratos1 = DB::select($query1);
                    if($contratos1 != null) {
                        //Existen contratos
                        $sumaContratosVentasAcumuladas += $contratos1[0]->suma; //Suma ventas acumuladas
                    }

                    $query2 = self::obtenerQueryProductividadPoliza($idPolizaExistente, $id_usuario, 5);
                    $contratos2 = DB::select($query2);
                    if($contratos2 != null) {
                        //Existen contratos
                        $sumaContratosVentasAcumuladasAprobadas += $contratos2[0]->suma; //Suma ventas acumuladas entregadas
                    }

                }
            }

        }

        array_push($arrayResultados, $sumaContratosNumVentas);
        array_push($arrayResultados, $sumaContratosAprobadas);
        array_push($arrayResultados, $sumaContratosNumVentas + $sumaContratosVentasAcumuladas);
        array_push($arrayResultados, $sumaContratosAprobadas + $sumaContratosVentasAcumuladasAprobadas);

        return $arrayResultados;

    }

    public static function obtenerQueryVentasOptos($hoyNumero,$diaactual,$idFranquicia,$idUsuario){

        switch ($hoyNumero){
            case 1: //LUNES
                return "$diaactual,0,0,0,0,0";
            case 2://MARTES
                $lunesFecha =  Carbon::now()->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                $ventaLunesOpto = DB::select("SELECT pvd.lunes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$lunesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaLunes = $ventaLunesOpto == null ? 0 : $ventaLunesOpto[0]->lunes;
                return "$ventaLunes,$diaactual,0,0,0,0";
            case 3://MIERCOLES
                $lunesFecha =  Carbon::now()->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                $ventaLunesOpto = DB::select("SELECT pvd.lunes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$lunesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaLunes = $ventaLunesOpto == null ? 0 : $ventaLunesOpto[0]->lunes;

                $martesFecha =  Carbon::now()->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia martes
                $ventaMartesOpto = DB::select("SELECT pvd.martes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$martesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMartes = $ventaMartesOpto == null ? 0 : $ventaMartesOpto[0]->martes;

                return "$ventaLunes,$ventaMartes,$diaactual,0,0,0";
            case 4://JUEVES
                $lunesFecha =  Carbon::now()->subDays(3)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                $ventaLunesOpto = DB::select("SELECT pvd.lunes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$lunesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaLunes = $ventaLunesOpto == null ? 0 : $ventaLunesOpto[0]->lunes;

                $martesFecha =  Carbon::now()->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia martes
                $ventaMartesOpto = DB::select("SELECT pvd.martes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$martesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMartes = $ventaMartesOpto == null ? 0 : $ventaMartesOpto[0]->martes;

                $miercolesFecha =  Carbon::now()->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia miercoles
                $ventaMiercolesOpto = DB::select("SELECT pvd.miercoles FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$miercolesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMiercoles = $ventaMiercolesOpto == null ? 0 : $ventaMiercolesOpto[0]->miercoles;

                return "$ventaLunes,$ventaMartes,$ventaMiercoles,$diaactual,0,0";
            case 5://VIERNES
                $lunesFecha =  Carbon::now()->subDays(4)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                $ventaLunesOpto = DB::select("SELECT pvd.lunes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$lunesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaLunes = $ventaLunesOpto == null ? 0 : $ventaLunesOpto[0]->lunes;

                $martesFecha =  Carbon::now()->subDays(3)->format('Y-m-d'); //Obtengo la fecha del dia martes
                $ventaMartesOpto = DB::select("SELECT pvd.martes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$martesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMartes = $ventaMartesOpto == null ? 0 : $ventaMartesOpto[0]->martes;

                $miercolesFecha =  Carbon::now()->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia miercoles
                $ventaMiercolesOpto = DB::select("SELECT pvd.miercoles FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$miercolesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMiercoles = $ventaMiercolesOpto == null ? 0 : $ventaMiercolesOpto[0]->miercoles;

                $juevesFecha =  Carbon::now()->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia jueves
                $ventaJuevesOpto = DB::select("SELECT pvd.jueves FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$juevesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaJueves = $ventaJuevesOpto == null ? 0 : $ventaJuevesOpto[0]->jueves;


                return "$ventaLunes,$ventaMartes,$ventaMiercoles,$ventaJueves,$diaactual,0";
            case 6://SABADO
                $lunesFecha =  Carbon::now()->subDays(5)->format('Y-m-d'); //Obtengo la fecha del dia lunes
                $ventaLunesOpto = DB::select("SELECT pvd.lunes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$lunesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaLunes = $ventaLunesOpto == null ? 0 : $ventaLunesOpto[0]->lunes;

                $martesFecha =  Carbon::now()->subDays(4)->format('Y-m-d'); //Obtengo la fecha del dia martes
                $ventaMartesOpto = DB::select("SELECT pvd.martes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$martesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMartes = $ventaMartesOpto == null ? 0 : $ventaMartesOpto[0]->martes;

                $miercolesFecha =  Carbon::now()->subDays(3)->format('Y-m-d'); //Obtengo la fecha del dia miercoles
                $ventaMiercolesOpto = DB::select("SELECT pvd.miercoles FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$miercolesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaMiercoles = $ventaMiercolesOpto == null ? 0 : $ventaMiercolesOpto[0]->miercoles;

                $juevesFecha =  Carbon::now()->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia jueves
                $ventaJuevesOpto = DB::select("SELECT pvd.jueves FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$juevesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaJueves = $ventaJuevesOpto == null ? 0 : $ventaJuevesOpto[0]->jueves;

                $viernesFecha =  Carbon::now()->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                $ventaViernesOpto = DB::select("SELECT pvd.viernes FROM polizaventasdias pvd INNER JOIN poliza p ON p.id = pvd.id_poliza WHERE p.created_at like '%$viernesFecha%' AND p.id_franquicia = '$idFranquicia' AND pvd.id_usuario = '$idUsuario'");
                $ventaViernes = $ventaViernesOpto == null ? 0 : $ventaViernesOpto[0]->viernes;

                return "$ventaLunes,$ventaMartes,$ventaMiercoles,$ventaJueves,$ventaViernes,$diaactual";
        }
        return "";
    }

}//clase
