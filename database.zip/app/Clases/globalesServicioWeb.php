<?php

namespace App\Clases;

use App\Clases\polizaGlobales;
use App\Http\Controllers\cobranza;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Clases\contratosGlobal;

class globalesServicioWeb
{

    public static function insertarOModificarRegistrosTablas($jsonDatos, $idFranquicia, $id_usuario)
    {

        $contratosGlobal = new contratosGlobal;

        $usuario = DB::select("SELECT rol_id FROM users WHERE id = '$id_usuario'");

        $rol_id = null;
        if ($usuario != null) {
            $rol_id = $usuario[0]->rol_id;
        }

        $fechaActual = Carbon::now()->format('Y-m-d H:i:s');

        $todosLosDatos = json_decode($jsonDatos, true);//Obtenemos todos los datos

        if (!empty($todosLosDatos[0]['contratos'])) {
            //Json contratos es diferente a vacio
            $jsonContratos = self::obtenerJsonDecodificado($todosLosDatos[0]['contratos']);//Obtenemos solo los contratos
        }
        $jsonAbonos = null;
        if (!empty($todosLosDatos[0]['abonos'])) {
            //Json abonos es diferente a vacio
            $jsonAbonos = self::obtenerJsonDecodificado($todosLosDatos[0]['abonos']);//Obtenemos los abonos
        }
        if (!empty($todosLosDatos[0]['historialesclinicos'])) {
            //Json historialesclinicos es diferente a vacio
            $jsonHistorialesClinicos = self::obtenerJsonDecodificado($todosLosDatos[0]['historialesclinicos']);//Obtenemos los historiales clinicos
        }
        if (!empty($todosLosDatos[0]['contratosproductos'])) {
            //Json contratosproductos es diferente a vacio
            $jsonContratosProductos = self::obtenerJsonDecodificado($todosLosDatos[0]['contratosproductos']);;//Obtenemos los productos del contrato
        }
        if (!empty($todosLosDatos[0]['productoseliminados'])) {
            //Json productoseliminados es diferente a vacio
            $jsonProductosEliminados = self::obtenerJsonDecodificado($todosLosDatos[0]['productoseliminados']);//Obtenemos los productos eliminados
        }
        $jsonAbonosEliminados = null;
        if (!empty($todosLosDatos[0]['abonoseliminados'])) {
            //Json abonoseliminados es diferente a vacio
            $jsonAbonosEliminados = self::obtenerJsonDecodificado($todosLosDatos[0]['abonoseliminados']);//Obtenemos los abonos eliminados
        }
        if (!empty($todosLosDatos[0]['historialcontratos'])) {
            //Json historialcontratos es diferente a vacio
            $jsonHistorialContratos = self::obtenerJsonDecodificado($todosLosDatos[0]['historialcontratos']);//Obtenemos los historiales de movimientos de los contratos
        }
        if (!empty($todosLosDatos[0]['promocioncontratos'])) {
            //Json promocioncontratos es diferente a vacio
            $jsonPromocionContratos = self::obtenerJsonDecodificado($todosLosDatos[0]['promocioncontratos']);//Obtenemos las promociones de los contratos
        }
        if (!empty($todosLosDatos[0]['payments'])) {
            //Json payments es diferente a vacio
            $jsonPayments = self::obtenerJsonDecodificado($todosLosDatos[0]['payments']);//Obtenemos los payments
        }
        if (!empty($todosLosDatos[0]['promocioneseliminadas'])) {
            //Json promocioneseliminadas es diferente a vacio
            $jsonPromocionesEliminadas = self::obtenerJsonDecodificado($todosLosDatos[0]['promocioneseliminadas']);//Obtenemos las promociones eliminadas
        }
        if (!empty($todosLosDatos[0]['datosstripe'])) {
            //Json datosstripe es diferente a vacio
            $jsonDatosStripe = self::obtenerJsonDecodificado($todosLosDatos[0]['datosstripe']);//Obtenemos los datos stripe
        }
        if (!empty($todosLosDatos[0]['garantias'])) {
            //Json garantias es diferente a vacio
            $jsonGarantias = self::obtenerJsonDecodificado($todosLosDatos[0]['garantias']);//Obtenemos las garantias
        }
        if (!empty($todosLosDatos[0]['ruta'])) {
            //Json ruta es diferente a vacio
            $jsonRuta = self::obtenerJsonDecodificado($todosLosDatos[0]['ruta']);//Obtenemos las rutas

        }
        if (!empty($todosLosDatos[0]['historialessinconversion'])) {
            //Json historialessinconversion es diferente a vacio
            $jsonHistorialesSinConversion = self::obtenerJsonDecodificado($todosLosDatos[0]['historialessinconversion']);//Obtenemos los historialessinconversion
        }

        //RECORRIDO DE JSONS PARA INSERTAR O ACTUALIZAR REGISTROS EN TABLAS
        if($rol_id == 4) {
            self::insertarActualizarAbonosYAbonosEliminados($idFranquicia, $id_usuario, $rol_id, $jsonAbonos, $jsonAbonosEliminados);
        }//ABONOS Y ABONOS ELIMINADOS (COBRANZA)

        if (!empty($jsonContratos)) {
            //jsonContratos es diferente a vacio

            foreach ($jsonContratos as $contrato) {
                //Recorrido de jsonContratos

                try {

                    $PAGO = self::validacionDeNulo($contrato['PAGO']);
                    $TARJETAFRENTE = self::validacionDeNulo($contrato['TARJETAFRENTE']);
                    if ($TARJETAFRENTE != null) {
                        $TARJETAFRENTE = 'uploads/imagenes/contratos/tarjetapension/' . $TARJETAFRENTE;
                    }
                    $TARJETAATRAS = self::validacionDeNulo($contrato['TARJETAATRAS']);
                    if ($TARJETAATRAS != null) {
                        $TARJETAATRAS = 'uploads/imagenes/contratos/tarjetapensionatras/' . $TARJETAATRAS;
                    }
                    $FOTOOTROS = self::validacionDeNulo($contrato['FOTOOTROS']);
                    if ($FOTOOTROS != null) {
                        $FOTOOTROS = 'uploads/imagenes/contratos/fotootros/' . $FOTOOTROS;
                    }
                    $ID_PROMOCION = self::validacionDeNulo($contrato['ID_PROMOCION']);
                    $IDCONTRATORELACION = self::validacionDeNulo($contrato['IDCONTRATORELACION']);
                    $ULTIMOABONO = self::validacionDeNulo($contrato['ULTIMOABONO']);
                    $DIAPAGO = self::validacionDeNulo($contrato['DIAPAGO']);
                    $FECHACOBROINI = self::validacionDeNulo($contrato['FECHACOBROINI']);
                    $FECHACOBROFIN = self::validacionDeNulo($contrato['FECHACOBROFIN']);
                    $FECHAATRASO = self::validacionDeNulo($contrato['FECHAATRASO']);
                    $DIASELECCIONADO = self::validacionDeNulo($contrato['DIASELECCIONADO']);
                    $ENTREGAPRODUCTO = self::validacionDeNulo($contrato['ENTREGAPRODUCTO']);
                    $FECHAENTREGA = self::validacionDeNulo($contrato['FECHAENTREGA']);
                    $CORREO = self::validacionDeNulo($contrato['CORREO']);
                    $SUBSCRIPCION = self::validacionDeNulo($contrato['SUBSCRIPCION']);
                    $FECHASUBSCRIPCION = self::validacionDeNulo($contrato['FECHASUBSCRIPCION']);
                    $NOTA = self::validacionDeNulo($contrato['NOTA']);
                    $TOTALREAL = self::validacionDeNulo($contrato['TOTALREAL']);
                    $DIATEMPORAL = self::validacionDeNulo($contrato['DIATEMPORAL']);
                    $COORDENADAS = self::validacionDeNulo($contrato['COORDENADAS']);
                    $UPDATED_AT = self::validacionDeNulo($contrato['UPDATED_AT']);

                    $existeContrato = DB::select("SELECT id, estatus_estadocontrato, fechacobroini, fechacobrofin, pago FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '" . $contrato['ID_CONTRATO'] . "'");

                    if ($existeContrato != null) {
                        //Existe el contrato
                        $estadoContratoActual = $existeContrato[0]->estatus_estadocontrato;
                        $pagoContratoActualizar = $existeContrato[0]->pago;

                        if ($estadoContratoActual == 0 || $estadoContratoActual == 1 || $estadoContratoActual == 9
                            || $estadoContratoActual == 12 || $estadoContratoActual == 2 || $estadoContratoActual == 4
                            || $estadoContratoActual == 5 || $estadoContratoActual == 7 || $estadoContratoActual == 10 || $estadoContratoActual == 11) {
                            //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION, ENVIADO, ENTREGADO, ABONOATRASADO, LIQUIDADO, APROBADO, MANUFACTURA, EN PROCESO DE ENVIO

                            if ($rol_id == 4) {
                                //Cobranza

                                $contratosGlobal::calculoTotal($contrato['ID_CONTRATO']);

                                $totalesContrato = DB::select("SELECT total, totalhistorial, totalreal FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '" . $contrato['ID_CONTRATO'] . "'");
                                $totalHistorialActualizar = null;
                                $totalActualizar = null;
                                if($totalesContrato != null) {
                                    //Existen totales
                                    $totalHistorialActualizar = $totalesContrato[0]->totalhistorial;
                                    $totalActualizar = $totalesContrato[0]->total;
                                }

                                if($estadoContratoActual == 2 || $estadoContratoActual == 4 || $estadoContratoActual == 5 || $estadoContratoActual == 12) {
                                    //Estado actual en la pagina es ENTREGADO, ABONO ATRASADO, LIQUIDADO O ENVIADO

                                    $validarGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND estadogarantia = '2' ORDER BY created_at DESC LIMIT 1");

                                    if($validarGarantia != null) {
                                        //Estado garantia es igual a 2
                                        $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                        if ($totalesContrato != null) {
                                            //Existen totales
                                            $diferenciaTotalReal = $totalesContrato[0]->totalreal - $TOTALREAL; //El restante que se sumo de lo que se haya agregado
                                            $totalHistorialActualizar = $contrato['TOTALHISTORIAL'] + $diferenciaTotalReal;
                                            $totalActualizar = $contrato['TOTAL'] + $diferenciaTotalReal;
                                        }
                                    }else {
                                        //Estado garantia es diferente de 2

                                        switch ($estadoContratoActual) {
                                            case 12: //Estado actual en la pagina es ENVIADO
                                                $pagoContratoActualizar = $contrato['PAGO'];
                                                if($contrato['ESTATUS_ESTADOCONTRATO'] != 2 && $contrato['ESTATUS_ESTADOCONTRATO'] != 4 && $contrato['ESTATUS_ESTADOCONTRATO'] != 5) {
                                                    //Estado que viene del movil es diferenete a ENTREGADO, ABONO ATRASADO Y LIQUIDADO
                                                    $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                }else {
                                                    //Estado que viene del movil es igual a ENTREGADO, ABONO ATRASADO O LIQUIDADO
                                                    if($pagoContratoActualizar == 0) {
                                                        //Pago de contado
                                                        $abonoContadoSinEnganche = DB::select("SELECT * FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND tipoabono = 5");

                                                        if($contrato['ESTATUS_ESTADOCONTRATO'] == 5 && $abonoContadoSinEnganche == null) {
                                                            //LIQUIDADO y no tiene contadosinenganche

                                                            $ultimoAbono = DB::select("SELECT abono, folio FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND tipoabono != '7' ORDER BY created_at DESC LIMIT 1");
                                                            if($ultimoAbono != null) {
                                                                //Se encontro ultimo abono
                                                                $sumatotal = $ultimoAbono[0]->abono;
                                                                if($ultimoAbono[0]->folio != null) {
                                                                    //Tiene folio el ultimo abono
                                                                    $sumaAbonosFolio = DB::select("SELECT SUM(abono) as sumatotal FROM abonos
                                                                                                            WHERE id_contrato = '" . $contrato['ID_CONTRATO'] . "'
                                                                                                            AND id_franquicia = '$idFranquicia'
                                                                                                            AND folio = '" . $ultimoAbono[0]->folio . "'");
                                                                    $sumatotal = $sumaAbonosFolio[0]->sumatotal;
                                                                }

                                                                if($totalActualizar == $sumatotal || $totalActualizar == 0) {
                                                                    //Total es igual a la sumaabono o Total es igual a 0
                                                                    $totalHistorialActualizar = $contrato['TOTALHISTORIAL']; //Obtenemos el totalhistorial del cobrador
                                                                    $totalActualizar = $contrato['TOTAL']; //Obtenemos el total del cobrador
                                                                    $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                                }else {
                                                                    //Total no es igual a la sumaabono
                                                                    $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                                    $FECHAENTREGA = null; //fechaentrega igualarla a nulo
                                                                    $ENTREGAPRODUCTO = 0; //entregaproducto igualarlo a nulo
                                                                }

                                                            }else {
                                                                //No se encontro ultimo abono
                                                                $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                                $FECHAENTREGA = null; //fechaentrega igualarla a nulo
                                                                $ENTREGAPRODUCTO = 0; //entregaproducto igualarlo a nulo
                                                            }

                                                        }else {
                                                            //LIQUIDADO y tiene contadosinenganche
                                                            $totalHistorialActualizar = $contrato['TOTALHISTORIAL']; //Obtenemos el totalhistorial del cobrador
                                                            $totalActualizar = $contrato['TOTAL']; //Obtenemos el total del cobrador
                                                            $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                        }

                                                    }else {
                                                        //Semanal, quincenal o mensual
                                                        $abonoEntrega = DB::select("SELECT id FROM abonos WHERE id_franquicia = '$idFranquicia'
                                                                            AND id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND tipoabono = '2'");
                                                        if($abonoEntrega != null) {
                                                            //Tiene abono entrega producto
                                                            $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                        }else {
                                                            //No tiene abono entrega producto
                                                            $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                            $FECHAENTREGA = null; //fechaentrega igualarla a nulo
                                                            $ENTREGAPRODUCTO = 0; //entregaproducto igualarlo a nulo
                                                        }
                                                    }
                                                }
                                                break;
                                            case 2: //Estado actual en la pagina es ENTREGADO
                                                $ultimoAbono = DB::select("SELECT created_at FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND tipoabono != '7' ORDER BY created_at DESC LIMIT 1");
                                                if($ultimoAbono != null) {
                                                    //Existe un abono
                                                    if($existeContrato[0]->fechacobroini != null && $existeContrato[0]->fechacobrofin != null) {
                                                        //fechacobroini y fechacobrofin son diferentes de nulo
                                                        if ((Carbon::parse($ultimoAbono[0]->created_at)->format('Y-m-d') >= Carbon::parse($existeContrato[0]->fechacobroini)->format('Y-m-d')
                                                            && Carbon::parse($ultimoAbono[0]->created_at)->format('Y-m-d') <= Carbon::parse($existeContrato[0]->fechacobrofin)->format('Y-m-d'))) {
                                                            //Hay un abono dentro del periodo
                                                            $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                        } else {
                                                            //No hay abono dentro del periodo
                                                            $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                        }
                                                    }else {
                                                        //fechacobroini y fechacobrofin son nulo
                                                        $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                    }
                                                }else {
                                                    //No existe abono
                                                    $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                }
                                                break;
                                            case 4: //Estado actual en la pagina es ABONO ATRASADO
                                                $ultimoAbono = DB::select("SELECT created_at FROM abonos WHERE id_franquicia = '$idFranquicia' AND id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND tipoabono != '7' ORDER BY created_at DESC LIMIT 1");
                                                if($ultimoAbono != null) {
                                                    //Existe un abono
                                                    if($existeContrato[0]->fechacobroini != null && $existeContrato[0]->fechacobrofin != null) {
                                                        //fechacobroini y fechacobrofin son diferentes de nulo
                                                        if ((Carbon::parse($ultimoAbono[0]->created_at)->format('Y-m-d') >= Carbon::parse($existeContrato[0]->fechacobroini)->format('Y-m-d')
                                                            && Carbon::parse($ultimoAbono[0]->created_at)->format('Y-m-d') <= Carbon::parse($existeContrato[0]->fechacobrofin)->format('Y-m-d'))) {
                                                            //Hay un abono dentro del periodo
                                                            $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                        } else {
                                                            //No hay abono dentro del periodo
                                                            $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                        }
                                                    }else {
                                                        //fechacobroini y fechacobrofin son nulo
                                                        $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                    }
                                                }else {
                                                    //No existe abono
                                                    $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                }
                                                break;
                                            case 5: //Estado actual en la pagina es LIQUIDADO
                                                $totalcontratoactualizado = DB::select("SELECT total FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '" . $contrato['ID_CONTRATO'] . "'");
                                                if($totalcontratoactualizado != null) {
                                                    //Existe el contrato
                                                    if($totalcontratoactualizado[0]->total <= 0) {
                                                        //Total es menor o igual a 0
                                                        $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                                    }else {
                                                        //Total es mayor a 0
                                                        if($pagoContratoActualizar == 0) {
                                                            //Pago de contado
                                                            $totalHistorialActualizar = $contrato['TOTALHISTORIAL']; //Obtenemos el totalhistorial del cobrador
                                                            $totalActualizar = $contrato['TOTAL']; //Obtenemos el total del cobrador
                                                        }
                                                        $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO']; //Obtenemos el estatus del cobrador
                                                    }
                                                }
                                                break;
                                        }

                                    }

                                }else {
                                    //Para todos los demas estatus, obtenemos el estatus de la pagina
                                    $estadoActualizar = $estadoContratoActual; //Obtenemos el estatus de la pagina
                                    if($estadoContratoActual == 1 || $estadoContratoActual == 9) {
                                        $validarGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND estadogarantia = '2' ORDER BY created_at DESC limit 1");
                                        if ($validarGarantia != null) {
                                            //Existe garantia creada
                                            if ($totalesContrato != null) {
                                                //Existen totales
                                                $diferenciaTotalReal = $totalesContrato[0]->totalreal - $TOTALREAL; //El restante que se sumo de lo que se haya agregado
                                                $totalHistorialActualizar = $contrato['TOTALHISTORIAL'] + $diferenciaTotalReal;
                                                $totalActualizar = $contrato['TOTAL'] + $diferenciaTotalReal;
                                            }
                                        }else {
                                            //No existe garantia creada
                                            if($pagoContratoActualizar == 0) {
                                                //Pago de contado
                                                $totalHistorialActualizar = $contrato['TOTALHISTORIAL']; //Obtenemos el totalhistorial del cobrador
                                                $totalActualizar = $contrato['TOTAL']; //Obtenemos el total del cobrador
                                            }
                                        }
                                    }else {
                                        if($pagoContratoActualizar == 0) {
                                            //Pago de contado
                                            $totalHistorialActualizar = $contrato['TOTALHISTORIAL']; //Obtenemos el totalhistorial del cobrador
                                            $totalActualizar = $contrato['TOTAL']; //Obtenemos el total del cobrador
                                        }
                                    }
                                }

                                DB::table("contratos")->where("id", "=", $contrato['ID_CONTRATO'])->where("id_franquicia", "=", $idFranquicia)->update([
                                    "pago" => $pagoContratoActualizar,
                                    "totalhistorial" => $totalHistorialActualizar,
                                    "total" => $totalActualizar,
                                    "ultimoabono" => $ULTIMOABONO,
                                    "estatus_estadocontrato" => $estadoActualizar,
                                    "diapago" => $DIAPAGO,
                                    "costoatraso" => $contrato['COSTOATRASO'],
                                    "fechaentrega" => $FECHAENTREGA,
                                    "pagosadelantar" => $contrato['PAGOSADELANTAR'], // Este campo se utilizara para validar si quiere adelantar abonos y hacer el calculo
                                    "enganche" => $contrato['ENGANCHE'],
                                    "entregaproducto" => $ENTREGAPRODUCTO,
                                    "promocionterminada" => $contrato['PROMOCIONTERMINADA'],
                                    "subscripcion" => $SUBSCRIPCION,
                                    "fechasubscripcion" => $FECHASUBSCRIPCION,
                                    "nota" => $NOTA,
                                    "diatemporal" => $DIATEMPORAL,
                                    "coordenadas" => $COORDENADAS,
                                    "created_at" => $contrato['CREATED_AT'],
                                    "updated_at" => $UPDATED_AT
                                ]);

                                //Insertar en tabla registroestadocontrato
                                DB::table('registroestadocontrato')->insert([
                                    'id_contrato' => $contrato['ID_CONTRATO'],
                                    'estatuscontrato' => $estadoActualizar,
                                    'created_at' => Carbon::now()
                                ]);

                                //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                                $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($contrato['ID_CONTRATO'], $id_usuario);

                            } else {
                                //Asistente/Opto

                                $totalHistorialActualizar = $contrato['TOTALHISTORIAL'];
                                $totalActualizar = $contrato['TOTAL'];
                                $totalRealActualizar = $TOTALREAL;
                                $totalPromocionActualizar = $contrato['TOTALPROMOCION'];
                                $totalAbonoActualizar = $contrato['TOTALABONO'];

                                $estadoActualizar = $contrato['ESTATUS_ESTADOCONTRATO'];
                                $garantiaTotales = false;

                                switch ($estadoContratoActual) {
                                    case 0: //No terminado
                                    case 1: //Terminado
                                    case null: // Contrato por crear
                                        $bandera = true;
                                        if($estadoContratoActual == 1) {
                                            //TERMINADO
                                            $validarGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND estadogarantia = '2' ORDER BY created_at DESC limit 1");
                                            if ($validarGarantia != null) {
                                                //Existe garantia creada
                                                $garantiaTotales = true;
                                            }
                                        }
                                        break;
                                    case 9: // En proceso de aprobacion
                                        $estadoActualizar = $estadoContratoActual; //Dejamos el estatus actual de la pagina
                                        $bandera = true;
                                        $validarGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '" . $contrato['ID_CONTRATO'] . "' AND estadogarantia = '2' ORDER BY created_at DESC limit 1");
                                        if ($validarGarantia != null) {
                                            //Existe garantia creada
                                            $garantiaTotales = true;
                                        }
                                        break;
                                    case 2: //Entregado
                                    case 4: //Abono atrasado
                                    case 12: //Enviado
                                    case 5: //Liquidado
                                        $validarGarantia = DB::select("SELECT id FROM garantias WHERE id_contrato = '" . $contrato['ID_CONTRATO'] . "' ORDER BY created_at DESC limit 1");
                                        $bandera = false;
                                        if($validarGarantia != null) {
                                            $bandera = true;
                                            $garantiaTotales = true;
                                        }
                                        break;
                                    default:
                                        $bandera = false;
                                        break;
                                }//switch

                                if($garantiaTotales) {
                                    //Sacar diferencia entre totales

                                    $totalesContrato = DB::select("SELECT total, totalhistorial, totalreal, totalpromocion, totalabono
                                                                        FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '" . $contrato['ID_CONTRATO'] . "'");

                                    if ($totalesContrato != null) {
                                        //Existen totales
                                        $diferenciaTotalReal = $totalRealActualizar - $totalesContrato[0]->totalreal; //El restante que se sumo de lo que se haya agregado
                                        $totalRealActualizar = $totalesContrato[0]->totalreal + $diferenciaTotalReal;
                                        $totalHistorialActualizar = $totalesContrato[0]->totalhistorial + $diferenciaTotalReal;
                                        $totalActualizar = $totalesContrato[0]->total + $diferenciaTotalReal;
                                        $totalAbonoActualizar = $totalesContrato[0]->totalabono;
                                        if(self::obtenerEstadoPromocion($contrato['ID_CONTRATO'], $idFranquicia)) {
                                            //Tiene promocion
                                            $totalPromocionActualizar = $totalesContrato[0]->totalpromocion + $diferenciaTotalReal;
                                        }
                                    }
                                }

                                if ($bandera) {

                                    DB::table("contratos")->where("id", "=", $contrato['ID_CONTRATO'])->where("id_franquicia", "=", $idFranquicia)->update([
                                        "datos" => $contrato['DATOS'],
                                        "id_usuariocreacion" => $contrato['ID_USUARIOCREACION'],
                                        "nombre_usuariocreacion" => $contrato['NOMBRE_USUARIOCREACION'],
                                        "id_zona" => $contrato['ID_ZONA'],
                                        "nombre" => $contrato['NOMBRE'],
                                        "calle" => $contrato['CALLE'],
                                        "numero" => $contrato['NUMERO'],
                                        "depto" => $contrato['DEPTO'],
                                        "alladode" => $contrato['ALLADODE'],
                                        "frentea" => $contrato['FRENTEA'],
                                        "entrecalles" => $contrato['ENTRECALLES'],
                                        "colonia" => $contrato['COLONIA'],
                                        "localidad" => $contrato['LOCALIDAD'],
                                        "telefono" => $contrato['TELEFONO'],
                                        "telefonoreferencia" => $contrato['TELEFONOREFERENCIA'],
                                        "nombrereferencia" => $contrato['NOMBREREFERENCIA'],
                                        "casatipo" => $contrato['CASATIPO'],
                                        "casacolor" => $contrato['CASACOLOR'],
                                        "fotoine" => 'uploads/imagenes/contratos/fotoine/' . $contrato['FOTOINEFRENTE'],//CONCATENAR LA RUTA CON EL NOMBRE
                                        "fotoineatras" => 'uploads/imagenes/contratos/fotoineatras/' . $contrato['FOTOINEATRAS'],//CONCATENAR LA RUTA CON EL NOMBRE
                                        "fotocasa" => 'uploads/imagenes/contratos/fotocasa/' . $contrato['FOTOCASA'],//CONCATENAR LA RUTA CON EL NOMBRE
                                        "comprobantedomicilio" => 'uploads/imagenes/contratos/comprobantedomicilio/' . $contrato['COMPROBANTEDOMICILIO'],//CONCATENAR LA RUTA CON EL NOMBRE
                                        "id_optometrista" => $contrato['ID_OPTOMETRISTA'],
                                        "tarjeta" => $TARJETAFRENTE, //CONCATENAR LA RUTA CON EL NOMBRE
                                        "tarjetapensionatras" => $TARJETAATRAS,//CONCATENAR LA RUTA CON EL NOMBRE
                                        "pago" => $PAGO,
                                        "id_promocion" => $ID_PROMOCION,
                                        "total" => $totalActualizar,
                                        "idcontratorelacion" => $IDCONTRATORELACION,
                                        "contador" => $contrato['CONTADOR'],
                                        "totalhistorial" => $totalHistorialActualizar,
                                        "totalpromocion" => $totalPromocionActualizar,
                                        "totalproducto" => $contrato['TOTALPRODUCTO'],
                                        "totalabono" => $totalAbonoActualizar,
                                        "ultimoabono" => $ULTIMOABONO,
                                        "estatus_estadocontrato" => $estadoActualizar,
                                        "diapago" => $DIAPAGO,
                                        "costoatraso" => $contrato['COSTOATRASO'],
                                        "pagosadelantar" => $contrato['PAGOSADELANTAR'], // Este campo se utilizara para validar si quiere adelantar abonos y hacer el calculo
                                        "enganche" => $contrato['ENGANCHE'],
                                        "entregaproducto" => $contrato['ENTREGAPRODUCTO'],
                                        "correo" => $CORREO,
                                        "estatus" => $contrato['ESTATUS'],
                                        "pagare" => 'uploads/imagenes/contratos/pagare/' . $contrato['PAGARE'],
                                        "fotootros" => $FOTOOTROS,
                                        "promocionterminada" => $contrato['PROMOCIONTERMINADA'],
                                        "subscripcion" => $SUBSCRIPCION,
                                        "fechasubscripcion" => $FECHASUBSCRIPCION,
                                        "totalreal" => $totalRealActualizar,
                                        "coordenadas" => $COORDENADAS,
                                        "created_at" => $contrato['CREATED_AT'],
                                        "updated_at" => $UPDATED_AT

                                    ]);

                                    //Insertar en tabla registroestadocontrato
                                    DB::table('registroestadocontrato')->insert([
                                        'id_contrato' => $contrato['ID_CONTRATO'],
                                        'estatuscontrato' => $estadoActualizar,
                                        'created_at' => Carbon::now()
                                    ]);

                                    //Insertar o actualizar contrato en tabla contratostemporalessincronizacion
                                    $contratosGlobal::insertarOActualizarDatosPorContratoTablaContratosTemporalesSincronizacion($contrato['ID_CONTRATO'], $id_usuario);

                                    if($estadoActualizar == 3) {
                                        //Estado del contrato se cambio a PRE-CANCELADO
                                        //Eliminar registros de la tabla contratostemporalessincronizacion que contengan ese idContrato
                                        DB::delete("DELETE FROM contratostemporalessincronizacion WHERE id = '" . $contrato['ID_CONTRATO'] . "'");
                                    }

                                }

                            }

                        }

                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonContratos: " . $contrato['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//CONTRATOS

        if($rol_id == 12) {
            self::insertarActualizarAbonosYAbonosEliminados($idFranquicia, $id_usuario, $rol_id, $jsonAbonos, $jsonAbonosEliminados);
        }//ABONOS Y ABONOS ELIMINADOS (ASISTENTE/OPTOMETRISTA)

        if (!empty($jsonHistorialesClinicos)) {
            //jsonHistorialesClinicos es diferente a vacio

            foreach ($jsonHistorialesClinicos as $historial) {
                //Recorrido de jsonHistorialesClinicos

                try {

                    //Validacion estado contrato
                    $contrato = DB::select("SELECT id, estatus_estadocontrato FROM contratos WHERE id = '" . $historial['ID_CONTRATO'] . "'");

                    if ($contrato != null) {

                        $estadoContratoActual = $contrato[0]->estatus_estadocontrato;

                        if ($estadoContratoActual == 0 || $estadoContratoActual == 1 || $estadoContratoActual == 9
                            || $estadoContratoActual == 12 || $estadoContratoActual == 2 || $estadoContratoActual == 4
                            || $estadoContratoActual == 5 || $estadoContratoActual == 7 || $estadoContratoActual == 10 || $estadoContratoActual == 11) {
                            //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION, ENVIADO, ENTREGADO, ABONOATRASADO, LIQUIDADO, APROBADO, MANUFACTURA, EN PROCESO DE ENVIO

                            $MOLESTIAOTRO = self::validacionDeNulo($historial['MOLESTIAOTRO']);
                            $ULTIMOEXAMEN = self::validacionDeNulo($historial['ULTIMOEXAMEN']);
                            $ESFERICODER = self::validacionDeNulo($historial['ESFERICODER']);
                            $CILINDRODER = self::validacionDeNulo($historial['CILINDRODER']);
                            $EJEDER = self::validacionDeNulo($historial['EJEDER']);
                            $ADDDER = self::validacionDeNulo($historial['ADDDER']);
                            $ALTDER = self::validacionDeNulo($historial['ALTDER']);
                            $ESFERICOIZQ = self::validacionDeNulo($historial['ESFERICOIZQ']);
                            $CILINDROIZQ = self::validacionDeNulo($historial['CILINDROIZQ']);
                            $EJEIZQ = self::validacionDeNulo($historial['EJEIZQ']);
                            $ADDIZQ = self::validacionDeNulo($historial['ADDIZQ']);
                            $ALTIZQ = self::validacionDeNulo($historial['ALTIZQ']);
                            $MATERIALOTRO = self::validacionDeNulo($historial['MATERIALOTRO']);
                            $COSTOMATERIAL = self::validacionDeNulo($historial['COSTOMATERIAL']);
                            $TRATAMIENTOOTRO = self::validacionDeNulo($historial['TRATAMIENTOOTRO']);
                            $COSTOTRATAMIENTO = self::validacionDeNulo($historial['COSTOTRATAMIENTO']);
                            $OBSERVACIONES = self::validacionDeNulo($historial['OBSERVACIONES']);
                            $OBSERVACIONESINTERNO = self::validacionDeNulo($historial['OBSERVACIONESINTERNO']);
                            $BIFOCALOTRO = self::validacionDeNulo($historial['BIFOCALOTRO']);
                            $COSTOBIFOCAL = self::validacionDeNulo($historial['COSTOBIFOCAL']);
                            $EMBARAZADA = self::validacionDeNulo($historial['EMBARAZADA']);
                            $DURMIOSEISOCHOHORAS = self::validacionDeNulo($historial['DURMIOSEISOCHOHORAS']);
                            $ACTIVIDADDIA = self::validacionDeNulo($historial['ACTIVIDADDIA']);
                            $PROBLEMASOJOS = self::validacionDeNulo($historial['PROBLEMASOJOS']);

                            $existeHistorial = DB::select("SELECT hc.id,c.estatus_estadocontrato FROM historialclinico hc INNER JOIN contratos c ON c.id = hc.id_contrato WHERE hc.id = '" . $historial['ID'] . "' AND hc.id_contrato = '" . $historial['ID_CONTRATO'] . "'");

                            //Asistente/Opto
                            switch ($estadoContratoActual) {
                                case 0: //No terminado
                                case 1: //Terminado
                                case null: // Contrato por crear
                                    $bandera = true;
                                    break;
                                case 9: // En proceso de aprobacion
                                    $bandera = true;
                                    break;
                                default:
                                    $bandera = false;
                                    break;
                            }//switch


                            if ($existeHistorial != null) { //Existe el historial?
                                if ($bandera) {
                                    //Existe el historial
                                    DB::table("historialclinico")->where("id", "=", $historial['ID'])->where("id_contrato", "=", $historial['ID_CONTRATO'])->update([
                                        "edad" => $historial['EDAD'],
                                        "fechaentrega" => $historial['FECHAENTREGA'],
                                        "diagnostico" => $historial['DIAGNOSTICO'],
                                        "ocupacion" => $historial['OCUPACION'],
                                        "diabetes" => $historial['DIABETES'],
                                        "hipertension" => $historial['HIPERTENSION'],
                                        "dolor" => $historial['DOLOR'],
                                        "ardor" => $historial['ARDOR'],
                                        "golpeojos" => $historial['GOLPEOJOS'],
                                        "otroM" => $historial['OTROM'],
                                        "molestiaotro" => $MOLESTIAOTRO,
                                        "ultimoexamen" => $ULTIMOEXAMEN,
                                        "esfericoder" => $ESFERICODER,
                                        "cilindroder" => $CILINDRODER,
                                        "ejeder" => $EJEDER,
                                        "addder" => $ADDDER,
                                        "altder" => $ALTDER,
                                        "esfericoizq" => $ESFERICOIZQ,
                                        "cilindroizq" => $CILINDROIZQ,
                                        "ejeizq" => $EJEIZQ,
                                        "addizq" => $ADDIZQ,
                                        "altizq" => $ALTIZQ,
                                        "id_producto" => $historial['ID_PRODUCTO'],
                                        "id_paquete" => $historial['ID_PAQUETE'],
                                        "material" => $historial['MATERIAL'],
                                        "materialotro" => $MATERIALOTRO,
                                        "costomaterial" => $COSTOMATERIAL,
                                        "bifocal" => $historial['BIFOCAL'],
                                        "fotocromatico" => $historial['FOTOCROMATICO'],
                                        "ar" => $historial['AR'],
                                        "tinte" => $historial['TINTE'],
                                        "blueray" => $historial['BLUERAY'],
                                        "otroT" => $historial['OTROT'],
                                        "tratamientootro" => $TRATAMIENTOOTRO,
                                        "costotratamiento" => $COSTOTRATAMIENTO,
                                        "observaciones" => $OBSERVACIONES,
                                        "observacionesinterno" => $OBSERVACIONESINTERNO,
                                        "tipo" => $historial['TIPO'],
                                        "bifocalotro" => $BIFOCALOTRO,
                                        "costobifocal" => $COSTOBIFOCAL,
                                        "embarazada" => $EMBARAZADA,
                                        "durmioseisochohoras" => $DURMIOSEISOCHOHORAS,
                                        "actividaddia" => $ACTIVIDADDIA,
                                        "problemasojos" => $PROBLEMASOJOS,
                                        "created_at" => $historial['CREATED_AT'],
                                        "updated_at" => $historial['UPDATED_AT']
                                    ]);
                                }
                            } else {
                                //No existe el historial
                                DB::table("historialclinico")->insert([
                                    "id" => $historial['ID'],
                                    "id_contrato" => $historial['ID_CONTRATO'],
                                    "edad" => $historial['EDAD'],
                                    "fechaentrega" => $historial['FECHAENTREGA'],
                                    "diagnostico" => $historial['DIAGNOSTICO'],
                                    "ocupacion" => $historial['OCUPACION'],
                                    "diabetes" => $historial['DIABETES'],
                                    "hipertension" => $historial['HIPERTENSION'],
                                    "dolor" => $historial['DOLOR'],
                                    "ardor" => $historial['ARDOR'],
                                    "golpeojos" => $historial['GOLPEOJOS'],
                                    "otroM" => $historial['OTROM'],
                                    "molestiaotro" => $MOLESTIAOTRO,
                                    "ultimoexamen" => $ULTIMOEXAMEN,
                                    "esfericoder" => $ESFERICODER,
                                    "cilindroder" => $CILINDRODER,
                                    "ejeder" => $EJEDER,
                                    "addder" => $ADDDER,
                                    "altder" => $ALTDER,
                                    "esfericoizq" => $ESFERICOIZQ,
                                    "cilindroizq" => $CILINDROIZQ,
                                    "ejeizq" => $EJEIZQ,
                                    "addizq" => $ADDIZQ,
                                    "altizq" => $ALTIZQ,
                                    "id_producto" => $historial['ID_PRODUCTO'],
                                    "id_paquete" => $historial['ID_PAQUETE'],
                                    "material" => $historial['MATERIAL'],
                                    "materialotro" => $MATERIALOTRO,
                                    "costomaterial" => $COSTOMATERIAL,
                                    "bifocal" => $historial['BIFOCAL'],
                                    "fotocromatico" => $historial['FOTOCROMATICO'],
                                    "ar" => $historial['AR'],
                                    "tinte" => $historial['TINTE'],
                                    "blueray" => $historial['BLUERAY'],
                                    "otroT" => $historial['OTROT'],
                                    "tratamientootro" => $TRATAMIENTOOTRO,
                                    "costotratamiento" => $COSTOTRATAMIENTO,
                                    "observaciones" => $OBSERVACIONES,
                                    "observacionesinterno" => $OBSERVACIONESINTERNO,
                                    "tipo" => $historial['TIPO'],
                                    "bifocalotro" => $BIFOCALOTRO,
                                    "costobifocal" => $COSTOBIFOCAL,
                                    "embarazada" => $EMBARAZADA,
                                    "durmioseisochohoras" => $DURMIOSEISOCHOHORAS,
                                    "actividaddia" => $ACTIVIDADDIA,
                                    "problemasojos" => $PROBLEMASOJOS,
                                    "created_at" => $historial['CREATED_AT'],
                                    "updated_at" => $historial['UPDATED_AT']
                                ]);

                                DB::update("UPDATE producto
                                    SET piezas = piezas - 1,
                                    updated_at = '$fechaActual'
                                    WHERE id = '" . $historial['ID_PRODUCTO'] . "'");
                            }
                        }
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonHistorialesClinicos: " . $historial['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//HISTORIALES

        if (!empty($jsonContratosProductos)) {
            //jsonContratosProductos es diferente a vacio

            foreach ($jsonContratosProductos as $productoContrato) {
                //Recorrido de jsonContratosProductos

                try {

                    $existeProductoContrato = DB::select("SELECT id FROM contratoproducto WHERE id = '" . $productoContrato['ID'] . "' AND id_contrato = '" . $productoContrato['ID_CONTRATO'] . "' AND id_franquicia = '$idFranquicia'");
                    if ($existeProductoContrato == null) { //Existe el producto en ese contrato?
                        //No existe
                        DB::table("contratoproducto")->insert([
                            "id" => $productoContrato['ID'],
                            "id_contrato" => $productoContrato['ID_CONTRATO'],
                            "id_producto" => $productoContrato['ID_PRODUCTO'],
                            "id_franquicia" => $idFranquicia,
                            "id_usuario" => $productoContrato['ID_USUARIO'],
                            "piezas" => $productoContrato['PIEZAS'],
                            "total" => $productoContrato['TOTAL'],
                            "created_at" => $productoContrato['CREATED_AT'],
                            "updated_at" => $productoContrato['UPDATED_AT']
                        ]);

                        DB::update("UPDATE producto
                                            SET piezas = piezas - '" . $productoContrato['PIEZAS'] . "',
                                            updated_at = '$fechaActual'
                                            WHERE id = '" . $productoContrato['ID_PRODUCTO'] . "'");
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonContratosProductos: " . $productoContrato['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }
            }

        }//PRODUCTOS DE CONTRATO

        if (!empty($jsonProductosEliminados)) {
            //jsonProductosEliminados es diferente a vacio

            foreach ($jsonProductosEliminados as $productoEliminado) {
                //Recorrido de jsonProductosEliminados

                try {

                    DB::delete("DELETE FROM contratoproducto WHERE id='" . $productoEliminado['ID_CONTRATOPRODUCTO'] . "' AND id_contrato = '" . $productoEliminado['ID_CONTRATO'] . "' AND id_franquicia = '$idFranquicia'");
                    DB::update("UPDATE producto
                                            SET piezas = piezas + '" . $productoEliminado['PIEZAS'] . "',
                                            updated_at = '$fechaActual'
                                            WHERE id = '" . $productoEliminado['ID_PRODUCTO'] . "'");

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonProductosEliminados: " . $productoEliminado['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//PRODUCTOS ELIMINADOS

        if (!empty($jsonHistorialContratos)) {
            //jsonHistorialContratos es diferente a vacio

            foreach ($jsonHistorialContratos as $historialContrato) {
                //Recorrido de jsonHistorialContratos

                try {

                    $existeHistorialContrato = DB::select("SELECT id FROM historialcontrato WHERE id= '" . $historialContrato['ID'] . "' AND id_usuarioC = '" . $historialContrato['ID_USUARIOC'] . "'");
                    if ($existeHistorialContrato == null) {
                        //No existe el movimiento en la BD
                        DB::table("historialcontrato")->insert([
                            "id" => $historialContrato['ID'],
                            "id_contrato" => $historialContrato['ID_CONTRATO'],
                            "id_usuarioC" => $historialContrato['ID_USUARIOC'],
                            "cambios" => $historialContrato['CAMBIOS'],
                            "created_at" => $historialContrato['CREATED_AT'],
                            "updated_at" => $historialContrato['UPDATED_AT']
                        ]);
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonHistorialContratos: " . $historialContrato['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//HISTORIAL DE MOVIMIENTO DE LOS CONTRATOS

        if (!empty($jsonPromocionContratos)) {
            //jsonPromocionContratos es diferente a vacio

            foreach ($jsonPromocionContratos as $promocionDeUnContrato) {
                //Recorrido de jsonPromocionContratos

                try {

                    $existePromocionContrato = DB::select("SELECT id FROM promocioncontrato WHERE id_contrato = '" . $promocionDeUnContrato['ID_CONTRATO'] . "' AND id_promocion = '" . $promocionDeUnContrato['ID_PROMOCION'] . "'");
                    if ($existePromocionContrato == null) {
                        //No existe la promocion para el contrato
                        DB::table("promocioncontrato")->insert([
                            "id" => $promocionDeUnContrato['ID'],
                            "id_contrato" => $promocionDeUnContrato['ID_CONTRATO'],
                            "id_promocion" => $promocionDeUnContrato['ID_PROMOCION'],
                            "estado" => $promocionDeUnContrato['ESTADO'],
                            "created_at" => $promocionDeUnContrato['CREATED_AT'],
                            "updated_at" => $promocionDeUnContrato['UPDATED_AT'],
                            "id_franquicia" => $idFranquicia
                        ]);
                    } else {
                        //Ya existe la promocion
                        DB::table("promocioncontrato")
                            ->where("id", "=", $promocionDeUnContrato['ID'])
                            ->where("id_contrato", "=", $promocionDeUnContrato['ID_CONTRATO'])
                            ->where("id_promocion", "=", $promocionDeUnContrato['ID_PROMOCION'])
                            ->where("id_franquicia", "=", $idFranquicia)
                            ->update([
                                "estado" => $promocionDeUnContrato['ESTADO'],
                                "updated_at" => $promocionDeUnContrato['UPDATED_AT']
                            ]);
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonPromocionContratos: " . $promocionDeUnContrato['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//PROMOCIONES DE CADA UNO DE LOS CONTRATOS

        if (!empty($jsonPromocionesEliminadas)) {
            //jsonPromocionesEliminadas es diferente a vacio

            foreach ($jsonPromocionesEliminadas as $promocionEliminada) {
                //Recorrido de jsonPromocionesEliminadas

                try {

                    DB::delete("DELETE FROM promocioncontrato WHERE id = '" . $promocionEliminada['ID_PROMOCIONCONTRATO'] . "' AND id_contrato = '" . $promocionEliminada['ID_CONTRATO'] . "' AND id_franquicia = '$idFranquicia'");

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonPromocionesEliminadas: " . $promocionEliminada['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//PROMOCIONES ELIMINADAS

        if (!empty($jsonPayments)) {
            //jsonPayments es diferente a vacio

            foreach ($jsonPayments as $payment) {
                //Recorrido de jsonPayments

                try {

                    DB::table("payments")->insert([
                        "payment_id" => $payment['PAYMENT_ID'],
                        "payer_email" => $payment['PAYER_EMAIL'],
                        "id_abono" => $payment['ID_ABONO'],
                        "amount" => $payment['AMOUNT'],
                        "currency" => $payment['CURRENCY'],
                        "payment_status" => $payment['PAYMENT_STATUS'],
                        "tipoorigen" => $payment['TIPOORIGEN'],
                        "created_at" => $payment['CREATED_AT'],
                        "updated_at" => $payment['UPDATED_AT']
                    ]);

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonPayments: " . $payment['ID_ABONO'] . "\n" . $e);
                    continue;
                }

            }

        }//PAYMENTS

        if (!empty($jsonDatosStripe)) {
            //jsonPayments es diferente a vacio

            foreach ($jsonDatosStripe as $datosstripe) {
                //Recorrido de jsonDatosStripe

                try {

                    DB::table("datosstripe")->insert([
                        "id_contrato" => $datosstripe['ID_CONTRATO'],
                        "id_paymentintent" => $datosstripe['ID_PAYMENTINTENT'],
                        "id_paymentmethod" => $datosstripe['ID_PAYMENTMETHOD'],
                        "created_at" => $datosstripe['CREATED_AT'],
                        "updated_at" => $datosstripe['UPDATED_AT']
                    ]);

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonDatosStripe: " . $datosstripe['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//DATOSSTRIPE

        if (!empty($jsonGarantias)) {
            //$jsonGarantias es diferente a vacio

            foreach ($jsonGarantias as $garantia) {
                //Recorrido de jsonGarantias

                try {

                    $ID = self::validacionDeNulo($garantia['ID']);
                    $ID_CONTRATO = self::validacionDeNulo($garantia['ID_CONTRATO']);
                    $ID_HISTORIAL = self::validacionDeNulo($garantia['ID_HISTORIAL']);
                    $ID_HISTORIALGARANTIA = self::validacionDeNulo($garantia['ID_HISTORIALGARANTIA']);
                    $ID_OPTOMETRISTA = self::validacionDeNulo($garantia['ID_OPTOMETRISTA']);
                    $ESTADOGARANTIA = self::validacionDeNulo($garantia['ESTADOGARANTIA']);
                    $CREATED_AT = self::validacionDeNulo($garantia['CREATED_AT']);
                    $UPDATED_AT = self::validacionDeNulo($garantia['UPDATED_AT']);

                    $existeGarantia = DB::select("SELECT id FROM garantias WHERE id = '" . $ID . "' AND id_contrato = '" . $ID_CONTRATO . "' AND estadogarantia = 1");
                    if ($existeGarantia != null) { //Existe el garantia?
                        //Existe garantia
                        DB::table("garantias")->where("id", "=", $ID)->update([
                            "id_historialgarantia" => $ID_HISTORIALGARANTIA,
                            "estadogarantia" => $ESTADOGARANTIA,
                            "updated_at" => $UPDATED_AT
                        ]);

                    } else {
                        //No existe la garantia

                        //Validamos si existe la garantia (Esto se hace por que se vuelve a insertar el registro)
                        $existeGarantia = DB::select("SELECT id FROM garantias WHERE id = '" . $ID . "' AND id_contrato = '" . $ID_CONTRATO . "'");

                        if($existeGarantia == null) {
                            //No existe garantia

                            DB::table("garantias")->insert([
                                "id" => $ID,
                                "id_contrato" => $ID_CONTRATO,
                                "id_historial" => $ID_HISTORIAL,
                                "id_historialgarantia" => $ID_HISTORIALGARANTIA,
                                "id_optometrista" => $ID_OPTOMETRISTA,
                                "estadogarantia" => $ESTADOGARANTIA,
                                "created_at" => $CREATED_AT,
                                "updated_at" => $UPDATED_AT
                            ]);
                        }
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonGarantias: " . $garantia['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//GARANTIAS

        if (!empty($jsonRuta)) {
            //$jsonRuta es diferente a vacio

            foreach ($jsonRuta as $ruta) {
                //Recorrido de jsonRuta

                try {

                    $ID = self::validacionDeNulo($ruta['ID']);
                    $DIA = self::validacionDeNulo($ruta['DIA']);
                    $ID_CONTRATO = self::validacionDeNulo($ruta['ID_CONTRATO']);
                    $ID_USUARIO = self::validacionDeNulo($ruta['ID_USUARIO']);
                    $POSICION = self::validacionDeNulo($ruta['POSICION']);
                    $ESTADO = self::validacionDeNulo($ruta['ESTADO']);

                    $existeRuta = DB::select("SELECT id FROM ruta WHERE id = '" . $ID . "' AND id_usuario = '" . $ID_USUARIO . "'");
                    if ($existeRuta != null) { //Existe el ruta?
                        //Existe ruta
                        DB::table("ruta")->where("id", "=", $ID)->where("id_usuario", "=", $ID_USUARIO)->update([
                            "id_contrato" => $ID_CONTRATO,
                            "posicion" => $POSICION,
                            "estado" => $ESTADO
                        ]);

                    } else {
                        //No existe la ruta
                        DB::table("ruta")->insert([
                            "id" => $ID,
                            "dia" => $DIA,
                            "id_contrato" => $ID_CONTRATO,
                            "id_usuario" => $ID_USUARIO,
                            "posicion" => $POSICION,
                            "estado" => $ESTADO
                        ]);
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonRuta: " . $ruta['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//RUTA

        if (!empty($jsonHistorialesSinConversion)) {
            //$jsonHistorialesSinConversion es diferente a vacio

            foreach ($jsonHistorialesSinConversion as $historialsinconversion) {
                //Recorrido de jsonHistorialesSinConversion

                try {

                    $ID_CONTRATO = self::validacionDeNulo($historialsinconversion['ID_CONTRATO']);
                    $ID_HISTORIAL = self::validacionDeNulo($historialsinconversion['ID_HISTORIAL']);
                    $ESFERICODER = self::validacionDeNulo($historialsinconversion['ESFERICODER']);
                    $CILINDRODER = self::validacionDeNulo($historialsinconversion['CILINDRODER']);
                    $EJEDER = self::validacionDeNulo($historialsinconversion['EJEDER']);
                    $ADDDER = self::validacionDeNulo($historialsinconversion['ADDDER']);
                    $ESFERICOIZQ = self::validacionDeNulo($historialsinconversion['ESFERICOIZQ']);
                    $CILINDROIZQ = self::validacionDeNulo($historialsinconversion['CILINDROIZQ']);
                    $EJEIZQ = self::validacionDeNulo($historialsinconversion['EJEIZQ']);
                    $ADDIZQ = self::validacionDeNulo($historialsinconversion['ADDIZQ']);
                    $CREATED_AT = self::validacionDeNulo($historialsinconversion['CREATED_AT']);

                    $existeHistorialSinConversion = DB::select("SELECT id_contrato FROM historialsinconversion WHERE id_contrato = '" . $ID_CONTRATO . "' AND id_historial = '" . $ID_HISTORIAL . "'");
                    if ($existeHistorialSinConversion != null) { //Existe el historialsinconversion?
                        //Existe historialsinconversion
                        DB::table("historialsinconversion")->where("id_contrato", "=", $ID_CONTRATO)->where("id_historial", "=", $ID_HISTORIAL)->update([
                            "esfericoder" => $ESFERICODER,
                            "cilindroder" => $CILINDRODER,
                            "ejeder" => $EJEDER,
                            "addder" => $ADDDER,
                            "esfericoizq" => $ESFERICOIZQ,
                            "cilindroizq" => $CILINDROIZQ,
                            "ejeizq" => $EJEIZQ,
                            "addizq" => $ADDIZQ
                        ]);

                    } else {
                        //No existe el historialsinconversion
                        DB::table("historialsinconversion")->insert([
                            "id_contrato" => $ID_CONTRATO,
                            "id_historial" => $ID_HISTORIAL,
                            "esfericoder" => $ESFERICODER,
                            "cilindroder" => $CILINDRODER,
                            "ejeder" => $EJEDER,
                            "addder" => $ADDDER,
                            "esfericoizq" => $ESFERICOIZQ,
                            "cilindroizq" => $CILINDROIZQ,
                            "ejeizq" => $EJEIZQ,
                            "addizq" => $ADDIZQ,
                            "created_at" => $CREATED_AT
                        ]);
                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonHistorialesSinConversion: " . $historialsinconversion['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//HISTORIALES SIN CONVERSION

        $datos[0]["codigo"] = "LOLATV5";
        //\Log::info("{'datos': '" . base64_encode(json_encode($datos)) . "'}");
        return "{'datos': '" . base64_encode(json_encode($datos)) . "'}";

    }

    private static function insertarActualizarAbonosYAbonosEliminados($idFranquicia, $id_usuario, $rol_id, $jsonAbonos, $jsonAbonosEliminados)
    {

        $contador = 0;
        if (!empty($jsonAbonos)) {
            //jsonAbonos es diferente a vacio

            foreach ($jsonAbonos as $abono) {
                //Recorrido de jsonAbonos

                try {

                    //Validacion estado contrato
                    $contrato = DB::select("SELECT id, estatus_estadocontrato FROM contratos WHERE id = '" . $abono['ID_CONTRATO'] . "'");

                    if ($contrato != null) {

                        $estadoContratoActual = $contrato[0]->estatus_estadocontrato;

                        if ($estadoContratoActual == 0 || $estadoContratoActual == 1 || $estadoContratoActual == 9
                            || $estadoContratoActual == 12 || $estadoContratoActual == 2 || $estadoContratoActual == 4
                            || $estadoContratoActual == 5 || $estadoContratoActual == 7 || $estadoContratoActual == 10 || $estadoContratoActual == 11) {
                            //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION, ENVIADO, ENTREGADO, ABONOATRASADO, LIQUIDADO, APROBADO, MANUFACTURA, EN PROCESO DE ENVIO

                            $FOLIO = self::validacionDeNulo($abono['FOLIO']);
                            $CORTE = self::validacionDeNulo($abono['CORTE']);

                            if ($contador == 0 && $CORTE === "1") {
                                DB::table("abonos")->where("id_usuario", "=", $id_usuario)->where("corte", "=", "0")->update([
                                    "corte" => "2"
                                ]);
                                $contador++;
                            }

                            if ($CORTE == "1") {
                                $CORTE = "2";
                            }

                            $existeAbono = DB::select("SELECT id FROM abonos WHERE id = '" . $abono['ID'] . "' AND id_contrato = '" . $abono['ID_CONTRATO'] . "' AND id_franquicia = '$idFranquicia'");
                            if ($existeAbono != null) { //Existe el abono?
                                //Existe
                                DB::table("abonos")->where("id", "=", $abono['ID'])->where("id_contrato", "=", $abono['ID_CONTRATO'])->update([
                                    "tipoabono" => $abono['TIPOABONO']
                                ]);
                            } else {
                                //No existe
                                DB::table("abonos")->where("id", "=", $abono['ID'])->insert([
                                    "id" => $abono['ID'],
                                    "folio" => $FOLIO,
                                    "id_franquicia" => $idFranquicia,
                                    "id_contrato" => $abono['ID_CONTRATO'],
                                    "id_usuario" => $abono['ID_USUARIO'],
                                    "abono" => $abono['ABONO'],
                                    "adelantos" => $abono['ADELANTOS'],
                                    "tipoabono" => $abono['TIPOABONO'],
                                    "atraso" => $abono['ATRASO'],
                                    "metodopago" => $abono['METODOPAGO'],
                                    "corte" => $CORTE,
                                    "poliza" => null,
                                    "created_at" => $abono['CREATED_AT'],
                                    "updated_at" => $abono['UPDATED_AT']
                                ]);

                            }

                        }

                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonAbonos: " . $abono['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//ABONOS

        if (!empty($jsonAbonosEliminados)) {
            //jsonAbonosEliminados es diferente a vacio

            foreach ($jsonAbonosEliminados as $abonoEliminado) {
                //Recorrido de jsonAbonosEliminados

                try {

                    //Validacion estado contrato
                    $contrato = DB::select("SELECT id, estatus_estadocontrato FROM contratos WHERE id = '" . $abonoEliminado['ID_CONTRATO'] . "'");

                    if ($contrato != null) {

                        $estadoContratoActual = $contrato[0]->estatus_estadocontrato;

                        if ($estadoContratoActual == 0 || $estadoContratoActual == 1 || $estadoContratoActual == 9
                            || $estadoContratoActual == 12 || $estadoContratoActual == 2 || $estadoContratoActual == 4
                            || $estadoContratoActual == 5 || $estadoContratoActual == 7 || $estadoContratoActual == 10 || $estadoContratoActual == 11) {
                            //NO TERMINADO, TERMINADO, EN PROCESO DE APROBACION, ENVIADO, ENTREGADO, ABONOATRASADO, LIQUIDADO, APROBADO, MANUFACTURA, EN PROCESO DE ENVIO
                            if ($rol_id == 4) {
                                //Cobranza
                                DB::delete("DELETE FROM abonos WHERE folio = '" . $abonoEliminado['ID_ABONO'] . "' AND id_contrato = '" . $abonoEliminado['ID_CONTRATO'] . "' AND id_franquicia = '$idFranquicia'");
                            }else {
                                //Asistente/Opto
                                DB::delete("DELETE FROM abonos WHERE id = '" . $abonoEliminado['ID_ABONO'] . "' AND id_contrato = '" . $abonoEliminado['ID_CONTRATO'] . "' AND id_franquicia = '$idFranquicia'");
                            }

                        }

                    }

                } catch (\Exception $e) {
                    \Log::info("Error: globalesServicioWeb : jsonAbonosEliminados: " . $abonoEliminado['ID_CONTRATO'] . "\n" . $e);
                    continue;
                }

            }

        }//ABONOS ELIMINADOS

    }

    private static function obtenerJsonDecodificado($datos)
    {
        $datosDecodificado = base64_decode($datos);
        $json = json_decode($datosDecodificado, true);
        return $json;
    }

    private static function validacionDeNulo($valor)
    {
        $respuesta = null;
        if (strlen($valor) > 0) {
            $respuesta = $valor;
        }
        return $respuesta;
    }

    public static function generarIdAlfanumerico($tabla, $length)
    {
        $unico = "";
        $esUnico = false;
        while (!$esUnico) {
            $temporalId = self::generadorRandom($length);
            $existente = DB::select("select id from $tabla where id = '$temporalId'");
            if (sizeof($existente) == 0) {
                $unico = $temporalId;
                $esUnico = true;
            }
        }
        return $unico;
    }   // Comparar si ya existe el id en la base de datos

    private static function generadorRandom($length)
    {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($caracteres);
        $randomId = '';
        for ($i = 0; $i < $length; $i++) {
            $randomId .= $caracteres[rAND(0, $charactersLength - 1)];
        }
        return $randomId;
    }

    public static function obtenerPromocionesContratos($contratos)
    {

        $promocionContrato = array();
        $array = array(); //Bandera de ids de promocioncontrato para que no se mande 2 veces
        if ($contratos != null) {
            //Tiene contratos creados
            foreach ($contratos as $contrato) {
                //Recorrido contratos
                $idContrato = $contrato->id;
                if ($contrato->idcontratorelacion != null) {
                    //Es un hijo
                    $idContrato = $contrato->idcontratorelacion;
                }
                $promocionC = DB::select("SELECT IFNULL(id, '') as id, IFNULL(id_contrato, '') as id_contrato, IFNULL(id_promocion, '') as id_promocion, IFNULL(estado, '') as estado, IFNULL(created_at, '') as created_at, IFNULL(updated_at, '') as updated_at FROM promocioncontrato WHERE id_contrato = '$idContrato'");

                if ($promocionC != null) {
                    //Hay promociones contrato
                    if (!in_array($promocionC[0]->id, $array)) {
                        //No existe promocion en el arreglo $promocionContrato
                        $cadena = str_replace("[", "", json_encode($promocionC)); //Remplazar [ del json
                        $cadena = str_replace("]", "", $cadena); //Remplazar ] del json
                        array_push($promocionContrato, json_decode($cadena, true)); //Agregacion de json ya modificaco sin los [] al principio y al final
                        array_push($array, $promocionC[0]->id); //Se agrega el id de promocioncontrato al array para que este no vuelva a insertarse de nuevo
                    }
                }
            }
        }

        return $promocionContrato;

    }

    public static function obtenerEstadoPromocion($idContrato, $idFranquicia)
    {
        $respuesta = false;

        $contrato = DB::select("SELECT * FROM contratos WHERE id_franquicia = '$idFranquicia' AND id = '$idContrato'");
        if ($contrato[0]->idcontratorelacion != null) {
            //Es un contrato hijo
            $idContrato = $contrato[0]->idcontratorelacion;
        }

        $promocioncontrato = DB::select("SELECT * FROM promocioncontrato WHERE id_franquicia = '$idFranquicia' AND id_contrato = '$idContrato'");

        if ($promocioncontrato != null) {
            if ($promocioncontrato[0]->estado == 1) {
                //Promocion esta activa
                $respuesta = true;
            }
        }
        return $respuesta;
    }

    public static function obtenerGarantiasContratos($contratos)
    {

        $garantiasContrato = array();
        if ($contratos != null) {
            //Tiene contratos creados
            foreach ($contratos as $contrato) {
                //Recorrido contratos
                $idContrato = $contrato->id;
                $garantiaC = DB::select("SELECT IFNULL(id, '') as id, IFNULL(id_contrato, '') as id_contrato, IFNULL(id_historial, '') as id_historial, IFNULL(id_historialgarantia, '') as id_historialgarantia, IFNULL(id_optometrista, '') as id_optometrista, IFNULL(estadogarantia, '') as estadogarantia, IFNULL(created_at, '') as created_at, IFNULL(updated_at, '') as updated_at FROM garantias WHERE id_contrato = '" . $idContrato . "' AND estadogarantia IN (0,1,2,3) ORDER BY created_at DESC limit 1");

                if ($garantiaC != null) {
                    //Hay garantia contrato
                    $cadena = str_replace("[", "", json_encode($garantiaC)); //Remplazar [ del json
                    $cadena = str_replace("]", "", $cadena); //Remplazar ] del json
                    array_push($garantiasContrato, json_decode($cadena, true)); //Agregacion de json ya modificaco sin los [] al principio y al final
                }
            }
        }

        return $garantiasContrato;

    }

    public static function obtenerDia($now, $diaActualNumero, $diaSeleccionado)
    {
        //Dia seleccionado
        // 0-> SabadoAnterior
        // 1-> ViernesSiguiente

        switch ($diaActualNumero) {
            case 1://Es Lunes
                if ($diaSeleccionado == 0) {
                    return $now->subDays(2)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
            case 2://Es Martes
                if ($diaSeleccionado == 0) {
                    return $now->subDays(3)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
            case 3://Es Miercoles
                if ($diaSeleccionado == 0) {
                    return $now->subDays(4)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
            case 4://Es Jueves
                if ($diaSeleccionado == 0) {
                    return $now->subDays(5)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
            case 5://Es Viernes
                if ($diaSeleccionado == 0) {
                    return $now->subDays(6)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
            case 6://Es Sabado
                if ($diaSeleccionado == 0) {
                    return $now->subDays(0)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
            case 7://Es Domingo
                if ($diaSeleccionado == 0) {
                    return $now->subDays(1)->format('Y-m-d'); //Obtengo la fecha del dia sabado anterior
                } elseif ($diaSeleccionado == 1) {
                    return $now->addDays(6)->format('Y-m-d'); //Obtengo la fecha del dia viernes
                }
                break;
        }
        return $now;
    }

    public static function tieneAbonoEnFechas($ultimoabono, $fechaini, $fechafin)
    {
        if (is_null($ultimoabono) || strlen($ultimoabono) == 0) {
            return false;
        } else {
            if (Carbon::parse($ultimoabono)->format('Y-m-d') >= Carbon::parse($fechaini)->format('Y-m-d') && Carbon::parse($ultimoabono)->format('Y-m-d') <= Carbon::parse($fechafin)->format('Y-m-d')) {
                return true;
            }
        }

        return false;
    }

    public static function obtenerRuta($contratos, $idUsuario)
    {

        try {

            //Eliminar todos los registros con estado 0
            DB::delete("DELETE FROM ruta WHERE id_usuario = '$idUsuario' AND estado = '0'");

            //Actualizar posiciones ruta
            $rutas = DB::select("SELECT * FROM ruta WHERE id_usuario = '$idUsuario' ORDER BY CAST(dia AS signed), CAST(posicion AS signed) ASC");
            $posicionNueva = 0;
            $banderaDia = 0;

            foreach ($rutas as $ruta) {

                if ($ruta->dia != $banderaDia) {
                    $banderaDia = $ruta->dia;
                    $posicionNueva = 0;
                }

                if (array_search($ruta->id_contrato, array_column($contratos, 'id'))) {
                    //Se encontro el id_contrato

                    DB::table("ruta")->where("id", "=", $ruta->id)->where("id_usuario", "=", $ruta->id_usuario)->where("dia", "=", $banderaDia)->update([
                        "posicion" => $posicionNueva
                    ]);

                    if ($ruta->estado == 2) {
                        DB::table("ruta")->where("id", "=", $ruta->id)->where("id_usuario", "=", $ruta->id_usuario)->where("dia", "=", $banderaDia)->update([
                            "estado" => 1
                        ]);
                    }

                } else {
                    //No se encontro el id_contrato
                    DB::table("ruta")->where("id", "=", $ruta->id)->where("id_usuario", "=", $ruta->id_usuario)->where("dia", "=", $banderaDia)->update([
                        "posicion" => $posicionNueva,
                        "estado" => '2'
                    ]);
                }

                $posicionNueva++;
            }

            //Obtener rutas actualizadas
            $rutasActualizadas = DB::select("SELECT * FROM ruta WHERE id_usuario = '$idUsuario' ORDER BY CAST(dia AS signed), CAST(posicion AS signed) ASC");

            return $rutasActualizadas;

        } catch (\Exception $e) {
            \Log::info("Error:" . $e);
        }


    }

    public static function obtenerJsonAbonosGeneral($idUsuario)
    {

        try {

            $jsonabonosgeneral = array();
            $abonos = DB::select("SELECT abono FROM abonos WHERE id_usuario = '$idUsuario' AND corte = '0'");

            foreach ($abonos as $abono) {

                $abonoentero = intval($abono->abono);

                if (array_key_exists($abonoentero, $jsonabonosgeneral)) {
                    //Existe la llave del abono
                    $jsonabonosgeneral[$abonoentero] = $jsonabonosgeneral[$abonoentero] + 1;

                } else {
                    //No se encontro la llave del abono
                    $jsonabonosgeneral[$abonoentero] = 1;
                }

            }

        } catch (\Exception $e) {
            \Log::info("Error:" . $e);
        }

        return $jsonabonosgeneral;

    }

    public static function obtenerAbonosContratos($contratos, $idFranquicia)
    {

        $abonos = array();
        if ($contratos != null) {
            //Tiene contratos creados
            foreach ($contratos as $contrato) {
                //Recorrido contratos
                $idContrato = $contrato->id;
                $abonosC = DB::select("SELECT IFNULL(a.id, '') as id, IFNULL(a.folio, '') as folio,
                                                IFNULL(a.id_contrato, '') as id_contrato, IFNULL(a.id_usuario, '') as id_usuario,
                                                IFNULL(a.abono, '') as abono, IFNULL(a.adelantos, '0') as adelantos, IFNULL(a.tipoabono, '') as tipoabono,
                                                IFNULL(a.atraso, '0') as atraso, IFNULL(a.metodopago, '') as metodopago, IFNULL(a.corte, '') as corte,
                                                IFNULL(a.created_at, '') as created_at, IFNULL(a.updated_at, '') as updated_at
                                                FROM abonos a INNER JOIN contratos c ON a.id_contrato = c.id
                                                WHERE c.id_franquicia = '$idFranquicia' AND c.id = '$idContrato'");

                if ($abonosC != null) {
                    //Hay abonos contrato
                    foreach ($abonosC as $abono) {
                        array_push($abonos, $abono);
                    }
                }
            }
        }

        return $abonos;

    }

    public static function generarIdContratoPersonalizado($identificadorFranquicia, $ultimoIdContratoPerzonalizado)
    {

        $arrayRespuesta = array();
        $idContratoPerzonalizado = "";

        $esUnico = false;
        while (!$esUnico) {
            switch (strlen($ultimoIdContratoPerzonalizado)) {
                case 1:
                    $idContratoPerzonalizado = $identificadorFranquicia . "0000" . $ultimoIdContratoPerzonalizado;
                    break;
                case 2:
                    $idContratoPerzonalizado = $identificadorFranquicia . "000" . $ultimoIdContratoPerzonalizado;
                    break;
                case 3:
                    $idContratoPerzonalizado = $identificadorFranquicia . "00" . $ultimoIdContratoPerzonalizado;
                    break;
                case 4:
                    $idContratoPerzonalizado = $identificadorFranquicia . "0" . $ultimoIdContratoPerzonalizado;
                    break;
                default:
                    $idContratoPerzonalizado = $identificadorFranquicia . $ultimoIdContratoPerzonalizado;
            }

            $existente = DB::select("select id from contratos where id = '$idContratoPerzonalizado'");
            if (sizeof($existente) == 0) {
                //No existe
                $esUnico = true;
            }else {
                //Existe
                $ultimoIdContratoPerzonalizado = $ultimoIdContratoPerzonalizado + 1;
            }

        }

        array_push($arrayRespuesta, $idContratoPerzonalizado); //Ejemplo: 2200110001
        array_push($arrayRespuesta, $ultimoIdContratoPerzonalizado); //Ejemplo: 10001

        return $arrayRespuesta;
    }

    public static function obtenerIdentificadorFranquicia($indice)
    {
        $identificadorFranquicia = "";

        //Se creara el identificador de la franquicia
        switch (strlen($indice)) {
            case 1:
                $identificadorFranquicia = "00" . $indice;
                break;
            case 2:
                $identificadorFranquicia = "0" . $indice;
                break;
            default:
                $identificadorFranquicia = $indice;
        }

        return $identificadorFranquicia;
    }

    public static function obtenerVentas($now, $nowParse)
    {

        $ventas = array();
        $polizaGlobales = new polizaGlobales();
        $hoynumero = $now->dayOfWeekIso;    //Obtenemos el dia de la semana actual
        $fechaLunes = $nowParse;    //Obtener fecha con formato
        $ventas;

        if($hoynumero != 1){
            //Diferente de dia lunes
            $fechaLunes = $polizaGlobales::obtenerDia($hoynumero, 1);   //se obtenie la fecha del lunes anterior a la fecha actaul
        }

        //conuslta para obtener Asistente con mas ventas en lo que va de la semana
        $ventasAsistente = DB::select("SELECT u.name as nombre, c.id_usuariocreacion  as id_usuario, u.rol_id as rol, COUNT(c.id) as numeroventas, f.ciudad AS sucursal
                            FROM contratos c
                            INNER JOIN franquicias f ON f.id = c.id_franquicia
                            INNER JOIN users u ON u.id = c.id_usuariocreacion
                            WHERE u.rol_id = 13
                            AND c.estatus_estadocontrato NOT IN (0,1,3,6,8,9)
                            AND f.id != '00000'
                            AND STR_TO_DATE(c.created_at,'%Y-%m-%d') BETWEEN STR_TO_DATE('$fechaLunes','%Y-%m-%d') AND STR_TO_DATE('$nowParse','%Y-%m-%d')
                            GROUP BY id_usuario , sucursal
                            ORDER BY numeroventas DESC LIMIT 5");


        //Obtener Optometrista con mas ventas asignadas en la semana
        $ventasOpto = DB::select("SELECT u.name as nombre, c.id_optometrista  as id_usuario, u.rol_id as rol, COUNT(c.id) as numeroventas, f.ciudad AS sucursal
                            FROM contratos c
                            INNER JOIN franquicias f ON f.id = c.id_franquicia
                            INNER JOIN users u ON u.id = c.id_optometrista
                            WHERE u.rol_id = 12
                            AND c.estatus_estadocontrato NOT IN (0,1,3,6,8,9)
                            AND f.id != '00000'
                            AND STR_TO_DATE(c.created_at,'%Y-%m-%d') BETWEEN STR_TO_DATE('$fechaLunes','%Y-%m-%d') AND STR_TO_DATE('$nowParse','%Y-%m-%d')
                            GROUP BY id_usuario , sucursal
                            ORDER BY numeroventas DESC LIMIT 5");

        $ventas = array_merge($ventasAsistente,$ventasOpto);

        return $ventas; //Retornar arreglo con el dato de obtometrista y Asistente

    }
}//clase
