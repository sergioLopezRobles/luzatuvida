<?php

namespace App\Console\Commands;

use App\Clases\polizaGlobales;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class crearpoliza extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'crear:crearpoliza';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Comando para creacion de poliza';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $hoy = Carbon::now();
        //$hoy = Carbon::parse("2022-05-02");
        $hoyNumero = $hoy->dayOfWeekIso;

        if ($hoyNumero != 7) {
            //Dia es diferente a domingo

            $franquicias = DB::select("SELECT id FROM franquicias WHERE id != '00000'");

            if ($franquicias != null) {
                //Existen franquicias

                foreach ($franquicias as $franquicia) {
                    //Recorrido de franquicias

                    try {

                        $idFranquicia = $franquicia->id;

                        $polizaGlobales = new polizaGlobales(); //Creamos una nueva instancia de polizaGlobales

                        $hoyFormato = $hoy->format('Y-m-d');
                        $fechaLunes = $polizaGlobales::obtenerDia($hoyNumero, 1);  //Obtengo la fecha del dia lunes
                        $ultimaPoliza = DB::select("SELECT estatus,id,total FROM poliza WHERE id_franquicia = '$idFranquicia'  ORDER BY created_at DESC LIMIT 1"); //Tomamos la ultima poliza creada sin importar si es de la misma semana o no.
                        $polizaAnterior = DB::select("SELECT id,total FROM poliza WHERE created_at >= '$fechaLunes' AND id_franquicia = '$idFranquicia' ORDER BY created_at DESC LIMIT 1");//Traemos la ultima poliza de la semana actual.
                        $polizaAnteriorId = $polizaAnterior == null ? "" : $polizaAnterior[0]->id;
                        $polizaAbierta = DB::select("SELECT id FROM poliza WHERE created_at  like '%" . $hoyFormato . "%' AND id_franquicia = '$idFranquicia'"); //Consultamos si ya existe una poliza el dia de hoy

                        if ($polizaAbierta == null) {
                            //Aun no existe la poliza del dia

                            if ($ultimaPoliza != null && $ultimaPoliza[0]->estatus != 1) {
                                $idUsuario = 699; //idUsuario de sistemas automatico
                                $datosusuario = DB::select("SELECT name FROM users WHERE id = '$idUsuario'");
                                if ($datosusuario != null) {
                                    $nameUsuario = $datosusuario[0]->name;

                                    if ($ultimaPoliza[0]->estatus == 0) {
                                        //No ha sido terminada ni autorizada
                                        DB::table("poliza")->where("id", "=", $ultimaPoliza[0]->id)->update([
                                            "estatus" => 1,
                                            "updated_at" => $hoy,
                                            "realizo" => $nameUsuario,
                                            "autorizo" => $nameUsuario
                                        ]);
                                        DB::table('historialpoliza')->insert([
                                            'id_usuarioC' => $idUsuario, 'id_poliza' => $ultimaPoliza[0]->id, 'created_at' => $hoy,
                                            'cambios' => "El usuario '$nameUsuario' entrego la poliza."
                                        ]);
                                    } else {
                                        //Esta terminada pero no ha sido autorizada
                                        DB::table("poliza")->where("id", "=", $ultimaPoliza[0]->id)->update([
                                            "estatus" => 1,
                                            "updated_at" => $hoy,
                                            "autorizo" => $nameUsuario
                                        ]);
                                    }

                                    DB::table('historialpoliza')->insert([
                                        'id_usuarioC' => $idUsuario, 'id_poliza' => $ultimaPoliza[0]->id, 'created_at' => $hoy,
                                        'cambios' => "El usuario '$nameUsuario' autorizo la poliza."
                                    ]);
                                }
                            }

                            \Log::info("Poliza : Creacion " . $idFranquicia);

                            //Creamos la poliza
                            $idPoliza = DB::table("poliza")->insertGetId([
                                "id_franquicia" => $idFranquicia,
                                "ingresosadmin" => 0,
                                "ingresosventas" => 0,
                                "ingresoscobranza" => 0,
                                "gastosadmin" => 0,
                                "gastoscobranza" => 0,
                                "otrosgastos" => 0,
                                "estatus" => 0,
                                "total" => 0,
                                "created_at" => $hoy
                            ]);

                            $usuarios = DB::select("SELECT u.id FROM users u INNER JOIN usuariosfranquicia uf ON uf.id_usuario = u.id WHERE uf.id_franquicia = '$idFranquicia' ORDER BY u.name ASC");

                            foreach ($usuarios as $usuario) {
                                DB::table("asistencia")->insert([
                                    "id_poliza" => $idPoliza,
                                    "id_usuario" => $usuario->id,
                                    "id_tipoasistencia" => 0,
                                    "created_at" => $hoy
                                ]);
                            }

                            \Log::info("Log");

                            DB::update("UPDATE contratos SET poliza = '$idPoliza' WHERE id_franquicia = '$idFranquicia' AND estatus_estadocontrato IN (2,4,5,7,10,11,12) AND datos = '1' AND poliza IS NULL");//Actualizamos todos los contratos

                            \Log::info("Log 0");

                            DB::update("UPDATE abonos
                                            SET poliza = '$idPoliza'
                                            WHERE id_franquicia = '$idFranquicia'
                                            AND poliza IS NULL");//Actualizamos todos los abonos

                            \Log::info("Log 1");

                            $ventasOptos = $polizaGlobales::calculosVentasOptos($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Obtenemos las ventas de Optometristas
                            \Log::info("Log 2");
                            $ventasAsis = $polizaGlobales::calculosVentasAsis($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Obtenemos las ventas de Asistentes
                            \Log::info("Log 3");
                            $productividadOptos = $polizaGlobales::calculoProductividadOptos($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Obetenemos la productividad de Optos
                            \Log::info("Log 4");
                            $productividadAsis = $polizaGlobales::calculoProductividadAsis($idFranquicia, $idPoliza, $polizaAnteriorId, ""); //Optenemos la productividad de Asis
                            \Log::info("Log 5");

                            foreach ($ventasOptos as $ventaOpto) {
                                $idOpto = $ventaOpto->id;
                                $nombreOpto = $ventaOpto->name;
                                $acumuladas = $ventaOpto->acumuladas;
                                $diaActual = $ventaOpto->diaActual;
                                $acumuladasTotal = $diaActual + $acumuladas;
                                $ingresosGotas = $ventaOpto->gotas;
                                $ingresoEnganche = $ventaOpto->enganche;
                                $ingresoPoliza = $ventaOpto->polizas;
                                $ingresosVentas = ($ingresoPoliza == null ? 0 : $ingresoPoliza) + ($ingresoEnganche == null ? 0 : $ingresoEnganche) + ($ingresosGotas == null ? 0 : $ingresosGotas);
                                $ingresosVentasAcumuladas = $ingresosVentas + ($ventaOpto->ingresosventasacumulado == null ? 0 : $ventaOpto->ingresosventasacumulado);


                                $ventasOptosQuery = $polizaGlobales::obtenerQueryVentasOptos($hoyNumero, $diaActual, $idFranquicia, $idOpto);
                                $query = "INSERT INTO polizaventasdias (id,id_franquicia,id_usuario,rol,id_poliza,fechapoliza,fechapolizacierre,nombre,lunes,martes,miercoles,jueves,viernes,sabado,acumuladas,asistencia,ingresosgotas,ingresosenganche,ingresospoliza,totaldia,ingresosventas,ingresosventasacumulado)
                                        VALUES(null,'$idFranquicia','$idOpto','12','$idPoliza','$hoy',null,'$nombreOpto'," . $ventasOptosQuery . ",'$acumuladasTotal',null,'$ingresosGotas','$ingresoEnganche','$ingresoPoliza',null,'$ingresosVentas','$ingresosVentasAcumuladas')";

                                DB::insert($query);
                            }

                            \Log::info("Log 6");


                            foreach ($ventasAsis as $ventaAsis) {
                                $idOpto = $ventaAsis->id;
                                $nombreOpto = $ventaAsis->name;
                                $acumuladas = $ventaAsis->acumuladas;
                                $diaActual = $ventaAsis->diaActual;
                                $asistencia = $ventaAsis->asistencia;
                                $acumuladasTotal = $diaActual + $acumuladas;
                                $ingresosGotas = 0;
                                $ingresoEnganche = 0;
                                $ingresoPoliza = 0;
                                $ingresosVentas = 0;
                                $ingresosVentasAcumuladas = 0;

                                $ventasOptosQuery = $polizaGlobales::obtenerQueryVentasOptos($hoyNumero, $diaActual, $idFranquicia, $idOpto);
                                $query = "INSERT INTO polizaventasdias (id,id_franquicia,id_usuario,rol,id_poliza,fechapoliza,fechapolizacierre,nombre,lunes,martes,miercoles,jueves,viernes,sabado,acumuladas,asistencia,ingresosgotas,ingresosenganche,ingresospoliza,totaldia,ingresosventas,ingresosventasacumulado)
                                        VALUES(null,'$idFranquicia','$idOpto','13','$idPoliza','$hoy',null,'$nombreOpto'," . $ventasOptosQuery . ",'$acumuladasTotal',null,'$ingresosGotas','$ingresoEnganche','$ingresoPoliza',null,'$ingresosVentas','$ingresosVentasAcumuladas')";
                                DB::insert($query);
                            }

                            \Log::info("Log 7");


                            foreach ($productividadOptos as $productividadOpto) {
                                $idOpto = $productividadOpto->ID;
                                $sueldo = $productividadOpto->SUELDO;
                                $ECOJRANT = $productividadOpto->ECOJRANT == null ? 0 : $productividadOpto->ECOJRANT;
                                $ECOJR = $productividadOpto->ECOJR == null ? 0 : $productividadOpto->ECOJR;
                                $totalEcoAcu = $ECOJRANT + $ECOJR;
                                $JUNIORANT = $productividadOpto->JUNIORANT == null ? 0 : $productividadOpto->JUNIORANT;
                                $JUNIOR = $productividadOpto->JUNIOR == null ? 0 : $productividadOpto->JUNIOR;
                                $totalJrAcu = $JUNIORANT + $JUNIOR;
                                $DORADOUNOANT = $productividadOpto->DORADOUNOANT == null ? 0 : $productividadOpto->DORADOUNOANT;
                                $DORADOUNO = $productividadOpto->DORADOUNO == null ? 0 : $productividadOpto->DORADOUNO;
                                $totalDoradoAcu = $DORADOUNOANT + $DORADOUNO;
                                $DORADODOSANT = $productividadOpto->DORADODOSANT == null ? 0 : $productividadOpto->DORADODOSANT;
                                $DORADODOS = $productividadOpto->DORADODOS == null ? 0 : $productividadOpto->DORADODOS;
                                $totalDoradoDosAcu = $DORADODOSANT + ($DORADODOS == 0 ? $DORADODOS : ($DORADODOS / 2));
                                $PLATINOANT = $productividadOpto->PLATINOANT == null ? 0 : $productividadOpto->PLATINOANT;
                                $PLATINO = $productividadOpto->PLATINO == null ? 0 : $productividadOpto->PLATINO;

                                $totalPlatinoAcu = $PLATINOANT + $PLATINO;
                                $numeroVentas = $totalEcoAcu + $totalJrAcu + $totalDoradoAcu + $totalDoradoDosAcu + $totalPlatinoAcu;
                                $productividad = ($numeroVentas * 100) / 30;
                                $insumos = ($productividadOpto->INSUMOS == null ? 0 : $productividadOpto->INSUMOS) * $numeroVentas;

                                DB::table("polizaproductividad")->insert([
                                    "id_franquicia" => $idFranquicia,
                                    "id_poliza" => $idPoliza,
                                    "id_usuario" => $idOpto,
                                    "sueldo" => $sueldo,
                                    "totaleco" => $totalEcoAcu,
                                    "totaljr" => $totalJrAcu,
                                    "totaldoradouno" => $totalDoradoAcu,
                                    "totaldoradodos" => $totalDoradoDosAcu,
                                    "totalplatino" => $totalPlatinoAcu,
                                    "numeroventas" => $numeroVentas,
                                    "productividad" => $productividad,
                                    "insumos" => $insumos
                                ]);

                            }

                            \Log::info("Log 8");


                            foreach ($productividadAsis as $productividadAsi) {
                                $idAsis = $productividadAsi->ID;
                                $sueldo = $productividadAsi->SUELDO;
                                $ECOJRANT = $productividadAsi->ECOJRANT == null ? 0 : $productividadAsi->ECOJRANT;
                                $ECOJR = $productividadAsi->ECOJR == null ? 0 : $productividadAsi->ECOJR;
                                $totalEcoAcu = $ECOJRANT + $ECOJR;
                                $JUNIORANT = $productividadAsi->JUNIORANT == null ? 0 : $productividadAsi->JUNIORANT;
                                $JUNIOR = $productividadAsi->JUNIOR == null ? 0 : $productividadAsi->JUNIOR;
                                $totalJrAcu = $JUNIORANT + $JUNIOR;
                                $DORADOUNOANT = $productividadAsi->DORADOUNOANT == null ? 0 : $productividadAsi->DORADOUNOANT;
                                $DORADOUNO = $productividadAsi->DORADOUNO == null ? 0 : $productividadAsi->DORADOUNO;
                                $totalDoradoAcu = $DORADOUNOANT + $DORADOUNO;
                                $DORADODOSANT = $productividadAsi->DORADODOSANT == null ? 0 : $productividadAsi->DORADODOSANT;
                                $DORADODOS = $productividadAsi->DORADODOS == null ? 0 : $productividadAsi->DORADODOS;
                                $totalDoradoDosAcu = $DORADODOSANT + ($DORADODOS == 0 ? $DORADODOS : ($DORADODOS / 2));
                                $PLATINOANT = $productividadAsi->PLATINOANT == null ? 0 : $productividadAsi->PLATINOANT;
                                $PLATINO = $productividadAsi->PLATINO == null ? 0 : $productividadAsi->PLATINO;
                                $totalPlatinoAcu = $PLATINOANT + $PLATINO;
                                $numeroVentas = $totalEcoAcu + $totalJrAcu + $totalDoradoAcu + $totalDoradoDosAcu + $totalPlatinoAcu;
                                $productividad = ($numeroVentas * 100) / 10;
                                $insumos = $productividadAsi->INSUMOS == null ? 0 : $productividadAsi->INSUMOS;

                                DB::table("polizaproductividad")->insert([
                                    "id_franquicia" => $idFranquicia,
                                    "id_poliza" => $idPoliza,
                                    "id_usuario" => $idAsis,
                                    "sueldo" => $sueldo,
                                    "totaleco" => $totalEcoAcu,
                                    "totaljr" => $totalJrAcu,
                                    "totaldoradouno" => $totalDoradoAcu,
                                    "totaldoradodos" => $totalDoradoDosAcu,
                                    "totalplatino" => $totalPlatinoAcu,
                                    "numeroventas" => $numeroVentas,
                                    "productividad" => $productividad,
                                    "insumos" => $insumos
                                ]);
                            }

                            \Log::info("Log 9");

                            \Log::info("Log 10");


                            $polizaGlobales::calculoDeCobranza($idFranquicia, $idPoliza, $polizaAnteriorId, "");


                            \Log::info("Log 11");


                            $poliza = DB::select("SELECT * FROM poliza WHERE id = '$idPoliza'");

                            $productividad = DB::select("SELECT * FROM polizaproductividad pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '12' ORDER BY u.name");

                            if ($productividad != null) {
                                //Hay datos en productividad

                                foreach ($productividad as $product) {
                                    //Recorrido de productividad por usuario
                                    $arrayRespuesta = $polizaGlobales::obtenerNumeroContratosEntregadosAbonoAtrasadoLiquidadosConGarantiaPorPaqueteYContratosYSumaTotalRealContratosEntregadosPorUsuario($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario);
                                    $arrayNumContratosPorPaquetes = $arrayRespuesta[0]; //Arreglo con el numero de contratos entregados por paquetes
                                    $contratosEntregados = $arrayRespuesta[1]; //Todos los contratos entregados
                                    $sumaTotalRealContratosEntregados = $arrayRespuesta[2]; //Suma de los totalReal de los contratos entregados

                                    $product->totaleco = 0;
                                    $product->totaljr = 0;
                                    $product->totaldoradouno = 0;
                                    $product->totaldoradodos = 0;
                                    $product->totalplatino = 0;

                                    if ($arrayNumContratosPorPaquetes != null) {
                                        //Arreglo con el numero de contratos entregados por paquetes contiene informacion

                                        if (array_key_exists("1", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 1
                                            $product->totaleco += $arrayNumContratosPorPaquetes['1'];
                                        }
                                        if (array_key_exists("2", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 2
                                            $product->totaleco += $arrayNumContratosPorPaquetes['2'];
                                        }
                                        if (array_key_exists("3", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 3
                                            $product->totaleco += $arrayNumContratosPorPaquetes['3'];
                                        }
                                        if (array_key_exists("4", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 4
                                            $product->totaljr = $arrayNumContratosPorPaquetes['4'];
                                        }
                                        if (array_key_exists("5", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 5
                                            $product->totaldoradouno = $arrayNumContratosPorPaquetes['5'];
                                        }
                                        if (array_key_exists("6", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 6
                                            $product->totaldoradodos = $arrayNumContratosPorPaquetes['6'];
                                        }
                                        if (array_key_exists("7", $arrayNumContratosPorPaquetes)) {
                                            //Existe llave con el paquete 7
                                            $product->totalplatino = $arrayNumContratosPorPaquetes['7'];
                                        }

                                    }

                                    $product->numeroventas = count($contratosEntregados); //numeroventas = Todos los contratos entregados
                                    $product->contratosporentregar = $polizaGlobales::obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario, 0);
                                    $product->montototalreal = $polizaGlobales::obtenerContratosPorEntregarOMontoTotalRealPoliza($idFranquicia, $idPoliza, $poliza[0]->created_at, $product->id_usuario, 1);
                                    $product->montoentregadostotalreal = $sumaTotalRealContratosEntregados;

                                    $arrayRespuestaObjetivoVentas = $polizaGlobales::obtenerDineroObjetivoEnVentas($contratosEntregados, $product->numeroventas, $product->totaleco, $product->totaljr, $product->totaldoradouno + $product->totaldoradodos, $product->totalplatino);
                                    $product->dineroobjetivoventastreinta = $arrayRespuestaObjetivoVentas[0];
                                    $product->dineroobjetivoventascuarenta = $arrayRespuestaObjetivoVentas[1];
                                }

                            }

                            $productividadAsistente = DB::select("SELECT * FROM polizaproductividad pvd INNER JOIN users u ON u.id = pvd.id_usuario WHERE pvd.id_poliza = '$idPoliza' AND u.rol_id = '13' ORDER BY u.name");

                            if ($productividadAsistente != null) {
                                //Hay datos en productividadAsistente

                                foreach ($productividadAsistente as $productAsist) {
                                    //Recorrido de productividadAsistente por usuario
                                    $productAsist->numObjetivoSemanaAnterior = $polizaGlobales::obtenerNumeroObjetivoSemanaAnteriorAsistente($idFranquicia, $poliza[0]->created_at, $productAsist->id_usuario);
                                    $arrayResultados = $polizaGlobales::obtenerNoVentasAprobadasVentasAcumuladasYVentasAcumuladasAprobadasAsistente($idFranquicia, $idPoliza, $poliza[0]->created_at, $productAsist->id_usuario);
                                    $productAsist->sumaContratosNumVentas = $arrayResultados[0];
                                    $productAsist->sumaContratosAprobadas = $arrayResultados[1];
                                    $productAsist->sumaContratosVentasAcumuladas = $arrayResultados[2];
                                    $productAsist->sumaContratosVentasAcumuladasAprobadas = $arrayResultados[3];
                                }

                            }

                            $totaldia = DB::select("SELECT SUM(ingresosventas) as ingreso FROM polizaventasdias WHERE id_poliza = '$idPoliza'");
                            $totalingresocobranza = DB::select("SELECT SUM(ingresocobranza) as ingreso FROM polizacobranza WHERE id_poliza = '$idPoliza'");

                            $ingresosVentas = $totaldia[0]->ingreso == null ? 0 : $totaldia[0]->ingreso;
                            $ingresosCobranza = $totalingresocobranza[0]->ingreso == null ? 0 : $totalingresocobranza[0]->ingreso;
                            $totalUltimaPoliza = $ultimaPoliza[0]->total == null ? 0 : $ultimaPoliza[0]->total;
                            $total = $ingresosVentas + $ingresosCobranza + $totalUltimaPoliza;


                            DB::table("poliza")->where("id", "=", $idPoliza)->where("id_franquicia", "=", $idFranquicia)->update([
                                "ingresosadmin" => 0,
                                "ingresosventas" => $ingresosVentas,
                                "ingresoscobranza" => $ingresosCobranza,
                                "gastosadmin" => 0,
                                "gastoscobranza" => 0,
                                "otrosgastos" => 0,
                                "total" => $total
                            ]);

                            \Log::info("Log 12");

                        } else {
                            \Log::info("Ya existe la poliza del dia franquicia " . $idFranquicia);
                        }

                    } catch (\Exception $e) {
                        \Log::info("Error: Comando : crearpoliza: " . $idFranquicia . "\n" . $e);
                        continue;
                    }

                }

            }

        }

    }
}
