<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePolizaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('poliza', function (Blueprint $table) {
            $table->id();
            $table->string('id_franquicia')->nullable();
            $table->string('ingresosadmin')->default("0");
            $table->string('ingresosventas')->default("0");
            $table->string('ingresoscobranza')->default("0");
            $table->string('gastosadmin')->default("0");
            $table->string('gastosventas')->default("0");
            $table->string('gastoscobranza')->default("0");
            $table->string('otrosgastos')->default("0");
            $table->string('realizo')->nullable();
            $table->string('autorizo')->nullable();
            $table->string('total')->default("0");
            $table->string('estatus')->nullable();
            $table->string('observaciones')->nullable();
            $table->string('polizafechaterminada')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('poliza');
    }
}
