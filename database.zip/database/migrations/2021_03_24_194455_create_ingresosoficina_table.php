<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIngresosoficinaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingresosoficina', function (Blueprint $table) {
            $table->id();
            $table->string('id_poliza')->nullable();
            $table->string('descripcion')->nullable();
            $table->string('numrecibo')->nullable();
            $table->string('foto')->nullable();
            $table->string('monto')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingresosoficina');
    }
}
