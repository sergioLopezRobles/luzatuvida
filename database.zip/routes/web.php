<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;


Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/home', function () {
    return redirect()->route('login');
});

//DIRECCIONAMIENTO E INSUMOS

Route::group(['middleware' => 'auth'], function () {
    Route::get('redireccion', 'App\Http\Controllers\direccionamiento@redireccionar')->name('redireccionar');
    Route::get('sucursal/estado', 'App\Http\Controllers\direccionamiento@estadofranquicia')->name('estadofranquicia');
    Route::get('insumos', 'App\Http\Controllers\franquicias@insumos')->name('insumos');
    Route::post('insumos', 'App\Http\Controllers\franquicias@actualizarinsumos')->name('actualizarinsumos');
});

//FRANQUICIA
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('sucursal/tabla', 'App\Http\Controllers\franquicias@tablaFranquicia')->name('listafranquicia');
    Route::get('sucursal/nueva', 'App\Http\Controllers\franquicias@nuevaFranquicia')->name('nuevafranquicia');
    Route::post('sucursal/crear', 'App\Http\Controllers\franquicias@crearFranquicia')->name('crearfranquicia');
    Route::get('sucursal/{idFranquicia}/editar', 'App\Http\Controllers\franquicias@editarFranquicia')->name('editarFranquicia');
    Route::post('sucursal/{idFranquicia}/editar', 'App\Http\Controllers\franquicias@actualizarFranquicia')->name('actualizarFranquicia');
    Route::get('sucursal/{idFranquicia}/usuarios', 'App\Http\Controllers\franquicias@usuariosfranquicia')->name('usuariosFranquicia');
    Route::post('sucursal/{idFranquicia}/usuarios', 'App\Http\Controllers\franquicias@nuevousuariofranquicia')->name('nuevoUsuarioFranquicia');
    Route::get('sucursal/{idfranquiciaactual}/{idfranquicia}/usuario/{idusuario}/eliminar', 'App\Http\Controllers\franquicias@eliminarsuariofranquicia')->name('eliminarUsuarioFranquicia');
    Route::get('sucursal/{idfranquicia}/usuario/{idusuario}/editar', 'App\Http\Controllers\franquicias@editarsuariofranquicia')->name('editarUsuarioFranquicia');
    Route::post('sucursal/{idfranquicia}/usuario/{idusuario}/editar', 'App\Http\Controllers\franquicias@actualizarsuariofranquicia')->name('actualizarUsuarioFranquicia');
    Route::get('sucursal/{idFranquicia}/usuario/{idusuario}/actualizar/dispositivo/{idDispositivo}', 'App\Http\Controllers\franquicias@actualizarsuariofranquiciadispositivo')->name('actualizarUsuarioFranquiciadispositivo');
    Route::get('/descargar-archivo/{idUsuario}/{archivo}', 'App\Http\Controllers\franquicias@descargarArchivo')->name('descargarArchivo');
    Route::get('/usuariosfranquiciatiemporeal', 'App\Http\Controllers\franquicias@usuariosfranquiciatiemporeal')->name('usuariosfranquiciatiemporeal');
    Route::post('sucursal/{idFranquicia}/usuarios/filtrosucursal', 'App\Http\Controllers\franquicias@usuariosfiltrosucursal')->name('usuariosfiltrosucursal');
    Route::post('sucursal/{idfranquicia}/usuario/{idusuario}/editar/controlentradasalida', 'App\Http\Controllers\franquicias@actualizarControlEntradaSalidaUsuarioFranquicia')->name('actualizarControlEntradaSalidaUsuarioFranquicia');
    Route::get('/descomprimirZipUsuario', 'App\Http\Controllers\franquicias@descomprimirZipUsuario')->name('descomprimirZipUsuario');
});

//POLIZA
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('sucursal/{idFranquicia}/polizas/tabla', 'App\Http\Controllers\poliza@tablaPoliza')->name('listapoliza');
    //Route::get('sucursal/{idFranquicia}/poliza/crear', 'App\Http\Controllers\poliza@crearpolizamanual')->name('crearpoliza');
    Route::get('sucursal/{idFranquicia}/poliza/{idPoliza}', 'App\Http\Controllers\poliza@verpoliza')->name('verpoliza');
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/terminar', 'App\Http\Controllers\poliza@terminarPoliza')->name('terminarPoliza');

    //ASISTENCIAS
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/asistencia', 'App\Http\Controllers\poliza@registrarAsistencia')->name('registrarAsistencia');
    Route::get('sucursal/{idFranquicia}/poliza/{idPoliza}/asistencia/tabla', 'App\Http\Controllers\poliza@tablaAsistencia')->name('tablaAsistencia');
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/asistencia/tabla', 'App\Http\Controllers\poliza@registrarAsistenciaTabla')->name('registrarAsistenciaTabla');
    Route::get('sucursal/{idFranquicia}/poliza/{idPoliza}/asistencia/individual', 'App\Http\Controllers\poliza@asistenciaIndividual')->name('asistenciaIndividual');
    Route::get('sucursal/{idFranquicia}/asistencia/generar-codigos', 'App\Http\Controllers\poliza@generarcodigos');

    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/ingreso', 'App\Http\Controllers\poliza@ingresarOficina')->name('ingresarOficina');
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/observacion', 'App\Http\Controllers\poliza@agregarObservacion')->name('agregarObservacion');
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/gasto', 'App\Http\Controllers\poliza@ingresarGasto')->name('ingresarGasto');
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/cobranza', 'App\Http\Controllers\poliza@ingresarCobranza')->name('ingresarCobranza');
    Route::post('sucursal/{idFranquicia}/poliza/{idPoliza}/gasto/venta', 'App\Http\Controllers\poliza@ingresarProductividadG')->name('ingresarProductividadG');
    Route::get('sucursal/{idFranquicia}/poliza/{idPoliza}/gasto/{idGasto}/eliminar', 'App\Http\Controllers\poliza@eliminarGasto')->name('eliminarGasto');
    Route::get('sucursal/{idFranquicia}/poliza/{idPoliza}/gasto/{idOficina}/eliminar/oficina', 'App\Http\Controllers\poliza@eliminarOficina')->name('eliminarOficina');
    Route::get('/crearcargarpolizatiemporeal', 'App\Http\Controllers\poliza@crearcargarpolizatiemporeal')->name('crearcargarpolizatiemporeal');
    Route::get('sucursal/{idFranquicia}/poliza/{idPoliza}/{idUsuario}/polizaactualizarasisoptocobranza', 'App\Http\Controllers\poliza@polizaactualizarasisoptocobranza')->name('polizaactualizarasisoptocobranza');
});

//CONTRATO
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('sucursal/{id}/contratos/tabla', 'App\Http\Controllers\contratos@listacontrato')->name('listacontrato');
    Route::post('sucursal/{idFranquicia}/contratos/tabla/buscar', 'App\Http\Controllers\contratos@filtrarlistacontrato')->name('filtrarlistacontrato');
    Route::post('sucursal/{idFranquicia}/contratos/tabla', 'App\Http\Controllers\contratos@filtrarlistacontratocheckbox')->name('filtrarlistacontratocheckbox');
    Route::get('sucursal/{idFranquicia}/contrato/nuevo', 'App\Http\Controllers\contratos@nuevocontrato')->name('nuevocontrato');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/cancelar', 'App\Http\Controllers\contratos@cancelarContrato')->name('cancelarContrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/nuevo/2', 'App\Http\Controllers\contratos@nuevocontrato2')->name('nuevocontrato2');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/nuevo/hijo/2', 'App\Http\Controllers\contratos@contratoHijos')->name('contratoHijos');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/entregar', 'App\Http\Controllers\contratos@entregarContrato')->name('entregarContrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/atraso', 'App\Http\Controllers\contratos@abonoAtrasado')->name('abonoAtrasado');
    Route::post('sucursal/{idFranquicia}/contrato/nuevo', 'App\Http\Controllers\contratos@crearcontrato')->name('crearcontrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/promocion/agregar', 'App\Http\Controllers\contratos@agregarpromocion')->name('agregarpromocion');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/dia', 'App\Http\Controllers\contratos@entregarDiaPago')->name('entregarDiaPago');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/pago', 'App\Http\Controllers\contratos@agregarformapago')->name('agregarformapago');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/abono/agregar', 'App\Http\Controllers\contratos@agregarabono')->name('agregarabono');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/abono/{idAbono}/eliminar', 'App\Http\Controllers\contratos@eliminarAbono')->name('eliminarAbono');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/producto/eliminar', 'App\Http\Controllers\contratos@eliminarProductoContrato')->name('eliminarProductoContrato');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/abono/agregar/2', 'App\Http\Controllers\contratos@agregarabono2')->name('agregarabono2');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/nuevos/2', 'App\Http\Controllers\contratos@crearcontrato2')->name('crearcontrato2');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/promocion/{idPromocion}/desactivar', 'App\Http\Controllers\contratos@desactivarPromocion')->name('desactivarPromocion');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/promocion/{idPromocion}/eliminar', 'App\Http\Controllers\contratos@eliminarPromocion')->name('eliminarPromocion');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/actualizar', 'App\Http\Controllers\contratos@contratoactualizar')->name('contratoactualizar');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/actualizar', 'App\Http\Controllers\contratos@contratoeditar')->name('contratoeditar');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/producto/agregar', 'App\Http\Controllers\contratos@agregarproducto')->name('agregarproducto');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}', 'App\Http\Controllers\contratos@vercontrato')->name('vercontrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/validarcontrato', 'App\Http\Controllers\contratos@validarContrato')->name('validarContrato');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/atrasar', 'App\Http\Controllers\contratos@atrasarContrato')->name("atrasarContrato");
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/nota', 'App\Http\Controllers\contratos@agregarnota')->name("agregarnota");
    Route::get('correo', 'App\Http\Controllers\contratos@correo');
    Route::get('sms', 'App\Http\Controllers\contratos@sms');

    Route::get('actualizar-contratos-pagos', 'App\Http\Controllers\contratos@darFormatoContratos');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/aumentardescontarsaldocontrato', 'App\Http\Controllers\contratos@aumentardescontarsaldocontrato')->name('aumentardescontarsaldocontrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/agregarhistorialmovimientocontrato', 'App\Http\Controllers\contratos@agregarhistorialmovimientocontrato')->name('agregarhistorialmovimientocontrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/supervisarcontrato', 'App\Http\Controllers\contratos@supervisarcontrato')->name('supervisarcontrato');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/restablecercontrato', 'App\Http\Controllers\contratos@restablecercontrato')->name('restablecercontrato');
    Route::get('sucursal/{idFranquicia}/migrarcuentas/tabla', 'App\Http\Controllers\contratos@migrarcuentas')->name('migrarcuentas');
    Route::post('sucursal/{idFranquicia}/migrarcuentasarchivo/tabla', 'App\Http\Controllers\contratos@migrarcuentasarchivo')->name('migrarcuentasarchivo');

    Route::get('sucursal/{idFranquicia}/contratos/traspasar', 'App\Http\Controllers\contratos@traspasarcontrato')->name('traspasarcontrato');
    Route::post('sucursal/{idFranquicia}/contratos/traspasar/contrato', 'App\Http\Controllers\contratos@buscarcontratotraspasar')->name('buscarcontratotraspasar');
    Route::get('sucursal/{idFranquicia}/contratos/traspasar/contrato/{idContrato}', 'App\Http\Controllers\contratos@obtenercontratotraspasar')->name('obtenercontratotraspasar');
    Route::post('sucursal/{idFranquicia}/contratos/traspasar/{idContrato}/contrato', 'App\Http\Controllers\contratos@generartraspasocontrato')->name('generartraspasocontrato');
    Route::get('/cargarpromociones', 'App\Http\Controllers\contratos@cargarpromocionesfranquicia')->name('cargarpromociones');

    Route::get('sucursal/{idFranquicia}/contratos/reporte', 'App\Http\Controllers\contratos@reportecontratos')->name('reportecontratos');
    Route::get('/reportescontratosdirector', 'App\Http\Controllers\contratos@obtenerreportecontratosdirector')->name('reportescontratosdirector');

    //Solicitar autorizacion garantia y cancelar contrato
    Route::get('sucursal/{idFranquicia}/contratos/solicitud/autorizar', 'App\Http\Controllers\contratos@listasolicitudautorizacion')->name('listasolicitudautorizacion');
    Route::get('sucursal/contrato/{idContrato}/solicitud/{indice}/autorizar', 'App\Http\Controllers\contratos@autorizarcontrato')->name('autorizarcontrato');
    Route::get('sucursal/contrato/{idContrato}/solicitud/{indice}/rechazar', 'App\Http\Controllers\contratos@rechazarcontrato')->name('rechazarcontrato');
    Route::post('sucursal/{idFranquicia}/contratos/{idContrato}/garantia/solicitar', 'App\Http\Controllers\contratos@solicitarautorizaciongarantia')->name('solicitarautorizaciongarantia');
    Route::post('sucursal/{idFranquicia}/contratos/{idContrato}/cancelar/solicitar', 'App\Http\Controllers\contratos@solicitarautorizacioncancelarcontrato')->name('solicitarautorizacioncancelarcontrato');
    Route::post('sucursal/{idFranquicia}/contratos/{idContrato}/aumentardisminuir/solicitar', 'App\Http\Controllers\contratos@solicitarautorizacionaumentardisminuir')->name('solicitarautorizacionaumentardisminuir');
    Route::post('sucursal/{idFranquicia}/contratos/{idContrato}/paquete/solicitar', 'App\Http\Controllers\contratos@solicitarautorizacioncambiopaquete')->name('solicitarautorizacioncambiopaquete');
});

Route::post('servicio/agregararchivoexcel', 'App\Http\Controllers\contratos@agregarArchivoExcel')->name('agregarArchivoExcel');
Route::post('servicio/liquidararchivo', 'App\Http\Controllers\contratos@liquidarContratosArchivo')->name('liquidarContratosArchivo');

//HISTORIAL CLINICO
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
//    Route::get('sucursal/{idFranquicia}/contrato/historialclinico/nuevo', 'App\Http\Controllers\historialclinico@nuevohistorialclinico')->name('nuevohistorialclinico');
//    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/nuevo/2', 'App\Http\Controllers\historialclinico@nuevohistorialclinico2')->name('nuevohistorialclinico2');
    Route::post('sucursal/{idFranquicia}/contrato/historialclinico/nuevo', 'App\Http\Controllers\historialclinico@crearhistorialclinico')->name('crearhistorialclinico');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/crear/2', 'App\Http\Controllers\historialclinico@crearhistorialclinico2')->name('crearhistorialclinico2');
    Route::get('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/{idHistorial}/actualizar', 'App\Http\Controllers\historialclinico@actualizarhistorial')->name('actualizarhistorial');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/{idHistorial}/actualizar', 'App\Http\Controllers\historialclinico@editarHistorial')->name('editarHistorial');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/{idHistorial}/actualizararmazon', 'App\Http\Controllers\historialclinico@editarHistorialArmazon')->name('editarHistorialArmazon');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/{idHistorial}/agregargarantia', 'App\Http\Controllers\historialclinico@agregarGarantiaHistorial')->name('agregarGarantiaHistorial');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/{idHistorial}/cancelargarantia', 'App\Http\Controllers\historialclinico@cancelarGarantiaHistorial')->name('cancelarGarantiaHistorial');
    Route::post('sucursal/{idFranquicia}/contrato/{idContrato}/historialclinico/{idHistorial}/actualizarpaquetehistorial', 'App\Http\Controllers\historialclinico@actualizarpaquetehistorial')->name('actualizarpaquetehistorial');
});

//ADMINISTRACION FRANQUICIA
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('sucursal/{idFranquicia}/tablas/administracion', 'App\Http\Controllers\adminfranquicia@listas')->name('listasfranquicia');
    Route::get('sucursal/{idFranquicia}/producto/nuevo', 'App\Http\Controllers\adminfranquicia@productonuevo')->name('productonuevo');
    Route::post('sucursal/{idFranquicia}/producto/nuevo', 'App\Http\Controllers\adminfranquicia@productocrear')->name('productocrear');
    Route::post('sucursal/{idFranquicia}/productos/tabla', 'App\Http\Controllers\adminfranquicia@filtrarproducto')->name('filtrarproducto');
    Route::get('sucursal/{idFranquicia}/producto/{idProducto}/actualizar', 'App\Http\Controllers\adminfranquicia@productoactualizar')->name('productoactualizar');
    Route::post('sucursal/{idFranquicia}/producto/{idProducto}/actualizar', 'App\Http\Controllers\adminfranquicia@productoeditar')->name('productoeditar');
    Route::get('sucursal/{idFranquicia}/tratamiento/nuevo', 'App\Http\Controllers\adminfranquicia@tratamientonuevo')->name('tratamientonuevo');
    Route::post('sucursal/{idFranquicia}/tratamiento/nuevo', 'App\Http\Controllers\adminfranquicia@tratamientocrear')->name('tratamientocrear');
    Route::get('sucursal/{idFranquicia}/tratamiento/{idTratamiento}/actualizar', 'App\Http\Controllers\adminfranquicia@tratamientoactualizar')->name('tratamientoactualizar');
    Route::post('sucursal/{idFranquicia}/tratamiento/{idTratamiento}/actualizar', 'App\Http\Controllers\adminfranquicia@tratamientoeditar')->name('tratamientoeditar');
    //Route::get('sucursal/{id}/paquete/nuevo','App\Http\Controllers\adminfranquicia@paquetenuevo')->name('paquetenuevo');
    //Route::post('sucursal/{id}/paquete/nuevo','App\Http\Controllers\adminfranquicia@paquetecrear')->name('paquetecrear');
    Route::get('sucursal/{idFranquicia}/paquete/{idPaquete}/actualizar', 'App\Http\Controllers\adminfranquicia@paqueteactualizar')->name('paqueteactualizar');
    Route::post('sucursal/{idFranquicia}/paquete/{idPaquete}/actualizar', 'App\Http\Controllers\adminfranquicia@paqueteeditar')->name('paqueteeditar');
    Route::get('sucursal/{idFranquicia}/producto/{idProducto}/promocion/desactivar', 'App\Http\Controllers\adminfranquicia@productodesactivarpromo')->name('productodesactivarpromo');
    Route::get('sucursal/{idFranquicia}/mensaje/nuevo', 'App\Http\Controllers\adminfranquicia@mensajeNuevo')->name('mensajenuevo');
    Route::post('sucursal/{idFranquicia}/mensaje/crear', 'App\Http\Controllers\adminfranquicia@crearmensaje')->name('crearmensaje');
    Route::get('sucursal/{idFranquicia}/mensaje/{idMensaje}/eliminar', 'App\Http\Controllers\adminfranquicia@eliminarmensaje')->name('eliminarmensaje');
    Route::post('sucursal/{idFranquicia}/subir-excel', 'App\Http\Controllers\adminfranquicia@subirarchivoexcel')->name('subirarchivoexcel');
});

//COBRANZA MOVIMIENTOS
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('sucursal/{idFranquicia}/cobranza/movimientos', 'App\Http\Controllers\cobranza@mostrarMovimientos')->name('cobranzamovimientos');
    Route::get('sucursal/{idUsuario}/cobranza/movimientos/reiniciarcorte', 'App\Http\Controllers\cobranza@cobranzamovimientosreiniciarcorte')->name('cobranzamovimientosreiniciarcorte');
    Route::get('sucursal/{idFranquicia}/ventas/movimientos', 'App\Http\Controllers\ventas@mostrarMovimientosVentas')->name('ventasmovimientos');
    Route::get('/movimientostiemporeal', 'App\Http\Controllers\cobranza@movimientostiemporeal')->name('movimientostiemporeal');
    Route::get('sucursal/{idFranquicia}/ventas/movimientos/filtro', 'App\Http\Controllers\ventas@filtrarMovimientosVentas')->name('filtrarventasmovimientos');
    Route::get('sucursal/cobranza/movimientos/marcarcontratocortellamada', 'App\Http\Controllers\cobranza@marcarcontratocortellamada')->name('marcarcontratocortellamada');
    Route::get('sucursal/{idFranquicia}/cobranza/llamadas', 'App\Http\Controllers\cobranza@llamadascobranza')->name('llamadascobranza');
    Route::get('/listallamadascobranza', 'App\Http\Controllers\cobranza@listallamadascobranza')->name('listallamadascobranza');
    Route::get('sucursal/{idFranquicia}/cobranza/movimientos/{idUsuario}/usuario', 'App\Http\Controllers\cobranza@validacioncortecobranza')->name('cobranzamovimientosvalidacioncorte');
});

//REPORTES
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('reporte/enviados/tabla', 'App\Http\Controllers\reportes@listacontratosreportes')->name('listacontratosreportes');
    Route::post('reporte/enviados/tabla', 'App\Http\Controllers\reportes@filtrarlistacontratosreportes')->name('filtrarlistacontratosreportes');
    Route::get('reporte/cuentasactivas/tabla', 'App\Http\Controllers\reportes@listacontratoscuentasactivas')->name('listacontratoscuentasactivas');
    Route::post('reporte/cuentasactivas/tabla', 'App\Http\Controllers\reportes@filtrarlistacontratoscuentasactivas')->name('filtrarlistacontratoscuentasactivas');
    Route::get('reporte/paquetes/tabla', 'App\Http\Controllers\reportes@listacontratospaquetes')->name('listacontratospaquetes');
    Route::get('reporte/cuentasfisicas/tabla', 'App\Http\Controllers\reportes@validarCuentasLocalPagina')->name('cuentasfisicas');
    Route::post('reporte/cuentasfisicas/tabla', 'App\Http\Controllers\reportes@validarCuentasLocalPaginaArchivo')->name('cuentasfisicasarchivo');
    Route::get('/paquetestiemporeal', 'App\Http\Controllers\reportes@paquetestiemporeal')->name('paquetestiemporeal');
    Route::get('/cuentasactivastiemporeal', 'App\Http\Controllers\reportes@cuentasactivastiemporeal')->name('cuentasactivastiemporeal');
    Route::get('reporte/cancelados/tabla', 'App\Http\Controllers\reportes@listacontratoscancelados')->name('listacontratoscancelados');
    Route::get('reporte/pagados/tabla', 'App\Http\Controllers\reportes@listacontratospagados')->name('listacontratospagados');
    Route::get('/contratosPagados', 'App\Http\Controllers\reportes@contratosPagadosTiempoReal')->name('contratosPagados');
    Route::get('/contratosCancelados', 'App\Http\Controllers\reportes@contratosCanceladosTiempoReal')->name('contratosCancelados');
    Route::get('reporte/movimientos/tabla', 'App\Http\Controllers\reportes@reportemovimientos')->name('reportemovimientos');
    Route::get('/usuariosreportemovimiento', 'App\Http\Controllers\reportes@usuariosreportemovimiento')->name('usuariosreportemovimiento');
    Route::get('/filtroreportemovimientos', 'App\Http\Controllers\reportes@filtroreportemovimientos')->name('filtroreportemovimientos');
    Route::get('reporte/graficas', 'App\Http\Controllers\reportes@reportegraficas')->name('reportegraficas');
    Route::get('/creargraficaventas', 'App\Http\Controllers\reportes@creargraficaventas')->name('creargraficaventas');
    Route::get('/obtenerUsuariosFranquicia', 'App\Http\Controllers\reportes@obtenerUsuariosFranquicia')->name('obtenerUsuariosFranquicia');
    Route::get('reporte/llamadas/tabla', 'App\Http\Controllers\reportes@reportellamadas')->name('reportellamadas');
    Route::get('/listareportellamadas', 'App\Http\Controllers\reportes@listareportellamadas')->name('listareportellamadas');
    Route::get('reporte/asistencia/tabla', 'App\Http\Controllers\reportes@listareporteasistencia')->name('listareporteasistencia');
    Route::get('/diasSemanaSeleccionada', 'App\Http\Controllers\reportes@obtenerdiasasistencia')->name('obtenerdiasasistencia');
    Route::get('/cargarListaAsistencia', 'App\Http\Controllers\reportes@cargarListaAsistencia')->name('cargarListaAsistencia');
});

//PROMOCIONES
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('sucursal/{idFranquicia}/promocion/nueva', 'App\Http\Controllers\promociones@promocionnueva')->name('promocionnueva');
    Route::get('sucursal/{idFranquicia}/promocion/armazones/nueva', 'App\Http\Controllers\promociones@nuevapromoarmazones')->name('nuevaproarmazones');
    Route::post('sucursal/{idFranquicia}/promocion/armazones/nueva', 'App\Http\Controllers\promociones@promocioncrear')->name('promocioncrear');
    Route::get('sucursal/{idFranquicia}/promocion/{idPromocion}/actualizar', 'App\Http\Controllers\promociones@promocionactualizar')->name('promocionactualizar');
    Route::post('sucursal/{idFranquicia}/promocion/{idPromocion}/actualizar', 'App\Http\Controllers\promociones@promocioneditar')->name('promocioneditar');
    Route::get('sucursal/{idFranquicia}/promocion/{idPromocion}/actualizar/estado', 'App\Http\Controllers\promociones@estadoPromocionEditar')->name('estadoPromocionEditar');

});

//CONFIRMACIONES
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('confirmaciones/tabla', 'App\Http\Controllers\confirmaciones@listaconfirmaciones')->name('listaconfirmaciones');
    Route::get('confirmacion/{idContrato}/estado', 'App\Http\Controllers\confirmaciones@estadoconfirmacion')->name('estadoconfirmacion');
    Route::post('confirmacion/{idContrato}/estado', 'App\Http\Controllers\confirmaciones@estadoconfirmacionactualizar')->name('estadoconfirmacionactualizar');
    Route::get('confirmacion/{idContrato}/estado/comentario', 'App\Http\Controllers\confirmaciones@comentarioconfirmacion')->name('comentarioconfirmacion');
    Route::post('confirmacion/{idContrato}/agregar-documentos', 'App\Http\Controllers\confirmaciones@confirmacionesagregardocumentos')->name('confirmacionesagregardocumentos');
    Route::post('confirmacion/{idContrato}/actualizar-contrato', 'App\Http\Controllers\confirmaciones@actualizarContratoConfirmaciones')->name('actualizarContratoConfirmaciones');
    Route::post('confirmacion/{idContrato}/actualizar-total-contrato', 'App\Http\Controllers\confirmaciones@actualizarTotalContratoConfirmacioness')->name('actualizarTotalContratoConfirmaciones');
    Route::post('confirmacion/{idContrato}/rechazar', 'App\Http\Controllers\confirmaciones@rechazarContratoConfirmaciones')->name('rechazarContratoConfirmaciones');
    Route::post('confirmacion/{idContrato}/historial/{idHistorial}/{opcion}/actualizar', 'App\Http\Controllers\confirmaciones@observacioninternalaboratoriohistorial')->name('observacioninternalaboratoriohistorial');
    Route::post('confirmacion/{idContrato}/actualizar-fechaentrega', 'App\Http\Controllers\confirmaciones@actualizarfechaentregaconfirmaciones')->name('actualizarfechaentregaconfirmaciones');
    Route::get('confirmacion/tablagarantias', 'App\Http\Controllers\confirmaciones@listagarantiasconfirmaciones')->name('listagarantiasconfirmaciones');
    Route::get('confirmacion/{idContrato}/contratogarantia', 'App\Http\Controllers\confirmaciones@vercontratogarantiaconfirmaciones')->name('vercontratogarantiaconfirmaciones');
    Route::post('confirmacion/contrato/{idContrato}/historialclinico/{idHistorial}/cancelargarantiaconfirmaciones', 'App\Http\Controllers\confirmaciones@cancelarGarantiaHistorialConfirmaciones')->name('cancelarGarantiaHistorialConfirmaciones');
    Route::get('/listaconfirmacioneslaboratrio', 'App\Http\Controllers\confirmaciones@listaconfirmacioneslaboratrio')->name('listaconfirmacioneslaboratrio');
    Route::post('confirmacion/{idContrato}/agregarproductoconfirmaciones', 'App\Http\Controllers\confirmaciones@agregarproductoconfirmaciones')->name('agregarproductoconfirmaciones');
    Route::get('/listaconfirmacionesgarantiasprincipal', 'App\Http\Controllers\confirmaciones@listaconfirmacionesgarantiasprincipal')->name('listaconfirmacionesgarantiasprincipal');
    Route::post('confirmacion/{idContrato}/diagnostico/actualizar', 'App\Http\Controllers\confirmaciones@actualizardiagnosticoconfirmaciones')->name('actualizardiagnosticoconfirmaciones');
    Route::post('confirmacion/{idFranquicia}/contrato/{idContrato}/pago', 'App\Http\Controllers\confirmaciones@actualizarformapagoconfirmaciones')->name('actualizarformapagoconfirmaciones');

});

//LABORATORIO
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('laboratorio/tabla', 'App\Http\Controllers\laboratorio@listalaboratorio')->name('listalaboratorio');
    Route::get('laboratorio/{idContrato}/estado', 'App\Http\Controllers\laboratorio@estadolaboratorio')->name('estadolaboratorio');
    Route::post('laboratorio/{idContrato}/estado', 'App\Http\Controllers\laboratorio@estadolaboratorioactualizar')->name('estadolaboratorioactualizar');
    Route::post('laboratorio/{idContrato}/rechazar', 'App\Http\Controllers\laboratorio@rechazarContratoLaboratorio')->name('rechazarContratoLaboratorio');
    Route::get('laboratorio/{idContrato}/estado/comentario', 'App\Http\Controllers\laboratorio@comentariolaboratorio')->name('comentariolaboratorio');
    Route::get('laboratorio/auxiliar', 'App\Http\Controllers\laboratorio@auxiliarlaboratorio')->name('auxiliarlaboratorio');
    Route::get('laboratorio/actualizarestadoenviado', 'App\Http\Controllers\laboratorio@actualizarestadoenviado')->name('actualizarestadoenviado');
    Route::get('laboratorio/tabla/actualizarestadoenviado', 'App\Http\Controllers\laboratorio@actualizarestadoenviado')->name('actualizarestadoenviado');
    Route::get('laboratorio/tabla/filtrarcontratosenviados', 'App\Http\Controllers\laboratorio@filtrarcontratosenviados')->name('filtrarcontratosenviados');
    Route::get('/contratosenviadostiemporeal', 'App\Http\Controllers\laboratorio@contratosenviadostiemporeal')->name('contratosenviadostiemporeal');
    Route::post('laboratorio/contrato/{idContrato}/historialclinico/{idHistorial}/cancelargarantialaboratorio', 'App\Http\Controllers\laboratorio@cancelarGarantiaHistorialLaboratorio')->name('cancelarGarantiaHistorialLaboratorio');
});


//GENERAL
Route::group(['middleware' => ['auth']], function () {
    Route::get('general', 'App\Http\Controllers\general@listas')->name('general');
    Route::get('general/dispositivo/nuevo/', 'App\Http\Controllers\general@dispositivonuevo')->name('dispositivonuevo');
    Route::post('general/dispositivo/nuevo', 'App\Http\Controllers\general@dispositivocrear')->name('dispositivocrear');
    Route::get('general/dispositivo/{id}/estatus/{estatus}', 'App\Http\Controllers\general@dispositivoestatus')->name('dispositivoestatus');
    Route::get('general/configuracion', 'App\Http\Controllers\general@configuracion')->name('configuracion');
    Route::post('general/configuracion/actualizar', 'App\Http\Controllers\general@actualizarConfiguracion')->name('actualizarConfiguracion');
});

//SERVICIO WEB TRABAJADOR UNO
Route::post('/api/servicio/iniciarsesion', 'App\Http\Controllers\serviciowebtrabajadoruno@iniciarsesion');
Route::post('/api/servicio/sincronizaruno', 'App\Http\Controllers\serviciowebtrabajadoruno@sincronizaruno');
Route::post('/api/servicio/sincronizarcero', 'App\Http\Controllers\serviciowebtrabajadoruno@sincronizarcero');
Route::post('/api/servicio/sincronizardos', 'App\Http\Controllers\serviciowebtrabajadoruno@sincronizardos');
Route::post('/api/servicio/cerrarsesion', 'App\Http\Controllers\serviciowebtrabajadoruno@cerrarsesion');

//STRIPE
Route::get('/payment/{idFranquicia}/{idContrato}/{abono}/{banderacase}/{nuevoabono}/{cantidadsubscripcion}', 'App\Http\Controllers\PaymentController@index')->name('payment');
Route::get('/charge/{idFranquicia}/contrato/{idContrato}/pagar/{abono}/{banderacase}/{nuevoabono}/{cantidadsubscripcion}', 'App\Http\Controllers\PaymentController@charge')->name('charge');


//LOGIN
Route::get('iniciar-sesion', 'App\Http\Controllers\Auth\LoginController@showLoginForm')->name('login');
Route::post('iniciar-sesion', 'App\Http\Controllers\Auth\LoginController@login');
Route::post('salir', 'App\Http\Controllers\Auth\LoginController@logout')->name('logout');

Route::get('registro', 'App\Http\Controllers\Auth\RegisterController@showRegistrationForm')->name('register');
Route::post('registro', 'App\Http\Controllers\Auth\RegisterController@register');

Route::get('restablecer/contraseña', 'App\Http\Controllers\Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('correo/contraseña', 'App\Http\Controllers\Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
Route::get('restablecer/contraseña/{token}', 'App\Http\Controllers\Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('restablcer/contraseña', 'App\Http\Controllers\Auth\ResetPasswordController@reset');

Route::get('confirmar/contraseña', ' App\Http\Controllers\Auth\ConfirmPasswordController@showConfirmForm');
Route::post('confirmar/contraseña', 'App\Http\Controllers\Auth\ConfirmPasswordController@confirm');

Route::get('webfonts/fa-solid-900.ttf', function () {
    return;
});
Route::get('webfonts/fa-solid-900.woff2', function () {
    return;
});
Route::get('webfonts/fa-solid-900.woff ', function () {
    return;
});

//VEHICULOS
Route::group(['middleware' => ['auth', 'empresaActiva']], function () {
    Route::get('vehiculos/{idFranquicia}/tabla', 'App\Http\Controllers\vehiculos@listavehiculos')->name('listavehiculos');
    Route::get('/cargarlistavehiculos', 'App\Http\Controllers\vehiculos@cargarlistavehiculos')->name('cargarlistavehiculos');
    Route::post('vehiculos/{idFranquicia}/crear', 'App\Http\Controllers\vehiculos@nuevovehiculo')->name('nuevovehiculo');
    Route::get('vehiculos/{idFranquicia}/{idMoto}/editar', 'App\Http\Controllers\vehiculos@vervehiculo')->name('vervehiculo');
    Route::post('vehiculos/{idFranquicia}/{idMoto}/editar', 'App\Http\Controllers\vehiculos@actualizarvehiculo')->name('actualizarvehiculo');
    Route::post('vehiculos/{idFranquicia}/{idMoto}/servicio', 'App\Http\Controllers\vehiculos@registrarnuevoservicio')->name('registrarnuevoservicio');
    Route::get('/descargar-factura-servicio/{idMoto}', 'App\Http\Controllers\vehiculos@descargarfacturaservicio')->name('descargarfacturaservicio');
});

//***************************** PARA CUALQUIER RUTA NO REGISTRADA ********************************************************
Route::get('{any}', function (Request $request) {
    if (Auth::check()) {
        return redirect()->route('redireccionar');
    } else {
        return redirect()->route('login');
    }
})->where('any', '.*');
